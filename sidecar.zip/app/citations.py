from __future__ import annotations

import re

RULES_VERSION = 2

_AUTHOR_YEAR = re.compile(
    r"(?:^|[\s;(])(?:see\s+|cf\.?\s+|e\.g\.,?\s+)?"
    r"[A-Z][^\W\d_][\w'’\-]*"
    r"(?:\s+(?:and|&)\s+[A-Z][^\W\d_][\w'’\-]*|\s+et\s+al\.?)*"
    r",?\s+(?:1[5-9]\d{2}|20\d{2})[a-z]?\b")
_IBID = re.compile(r"^\s*(?:ibid|op\.?\s*cit|loc\.?\s*cit)\b", re.IGNORECASE)
_MONTH = (r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?"
          r"|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)")
_DATED_SOURCE = re.compile(r"^\s*[A-Z][^()]*,\s+" + _MONTH + r"\.?\s+\d{1,2},\s+(?:p\s+)?(?:1[5-9]\d{2}|20\d{2})\b")
_YEAR_PAGE = re.compile(r"\b(?:1[5-9]\d{2}|20\d{2})[a-z]?\s*,\s*pp?\.?\s*\d")
_PAREN = re.compile(r"\s*\(([^()]{1,600})\)")
_NUMERIC = re.compile(r"\s*\[\d{1,4}(?:\s*[,–\-]\s*\d{1,4})*\]")


def _is_citation(inner: str) -> bool:
    return bool(_IBID.match(inner) or _AUTHOR_YEAR.search(inner)
                or _DATED_SOURCE.match(inner) or _YEAR_PAGE.search(inner))


def strip_citations(text: str) -> str:
    out = _PAREN.sub(lambda m: "" if _is_citation(m.group(1)) else m.group(0), str(text or ""))
    out = _NUMERIC.sub("", out)
    out = re.sub(r"\s+([.,;:!?])", r"\1", out)
    out = re.sub(r"([,;:])(?=[.!?])", "", out)
    out = re.sub(r"\s{2,}", " ", out).strip()
    return "" if re.fullmatch(r"[\s.,;:!?]*", out) else out
