"""In-process scheduler. A plain asyncio loop, not a job framework —
simplicity first. Jobs are independent; one failing never stops the rest.
Daily AI jobs (digest refresh, morning note, tag review) run once per day
after the configured hour.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import logging

from . import constants, llm, services, settings
from .generators import (agenda, canvas_maps, dashboard, digests, insight,
                         project_state, responsibilities, tag_hierarchy,
                         tag_review, training, vocab_graphs)
from .ingest import boox, jobsfair, lastfm, lingua, rss
from . import vocab_csv

log = logging.getLogger("sidecar.scheduler")

_last_run: dict[str, dt.datetime] = {}
_last_daily: dt.date | None = None


def _due(name: str, minutes: int, now: dt.datetime) -> bool:
    last = _last_run.get(name)
    if last is None or (now - last) >= dt.timedelta(minutes=minutes):
        _last_run[name] = now
        return True
    return False


async def _run(name: str, fn) -> None:
    try:
        result = fn()
        if asyncio.iscoroutine(result):
            await result
    except Exception as e:
        log.warning("job %s failed: %s", name, e)


async def _vocab_graphs_all() -> None:
    """Regenerate the four relationship canvases for every language that has a
    vocabulary CSV. Cheap when nothing changed — canvas.py writes only when
    nodes are genuinely new or the edge list actually differs."""
    for lang in vocab_csv.known_languages():
        vocab_graphs.regenerate_all(lang)


async def _daily_ai_jobs() -> None:
    """Refresh the digest for the *previous* completed periods + morning note.

    Split by whether a job talks to the LLM. The inference-backed half is
    gated on `scheduler.ai_jobs` so a model is only ever pulled into memory
    because the user asked for something; the rest (audio prefetch, the
    JobsFair prune) is local work that has no reason to wait on that switch.
    """
    today = dt.date.today()
    yesterday = today - dt.timedelta(days=1)
    cfg = settings.effective().scheduler
    if cfg.ai_jobs:
        await _run("weekly_digest",
                   lambda: digests.weekly(constants.weekly_name(yesterday)))
        if today.day == 1:
            await _run("monthly_digest",
                       lambda: digests.monthly(constants.monthly_name(yesterday)))
            if yesterday.month in (3, 6, 9, 12):
                await _run("quarterly_digest",
                           lambda: digests.quarterly(constants.quarterly_name(yesterday)))
        await _run("morning_note", insight.morning_note)
        await _run("tag_review", tag_review.generate)
    if cfg.lingua_audio_prefetch:
        # blocking urllib + subprocess work — keep it off the event loop
        await _run("lingua_audio",
                   lambda: asyncio.to_thread(lingua.audio_prefetch))
    if today.isoweekday() == 1:  # hierarchy proposals are a weekly, not daily, rhythm
        if cfg.ai_jobs:
            await _run("tag_hierarchy", tag_hierarchy.generate)
        await _run("jobsfair_prune",
                   lambda: asyncio.to_thread(jobsfair.run_prune))


async def loop() -> None:
    global _last_daily
    log.info("scheduler running")
    while True:
        # Re-read per tick so Settings.md changes (cadences, enabled) apply
        # live; `enabled: false` is a pause switch, not a startup latch.
        cfg = settings.effective().scheduler
        if not cfg.enabled:
            await asyncio.sleep(60)
            continue
        now = dt.datetime.now()
        if _due("responsibilities", cfg.responsibilities_minutes, now):
            await _run("responsibilities", responsibilities.generate)
            await _run("agenda", agenda.generate)
        if _due("dashboard", cfg.dashboard_minutes, now):
            await _run("dashboard", dashboard.generate)
        if _due("states", cfg.states_minutes, now):
            await _run("states", project_state.generate)
            await _run("training", training.generate)
            await _run("canvas_maps", canvas_maps.stage)
            # Vocabulary relationship graphs. canvas.py leaves files alone when
            # nothing changed (append-only nodes, derived edge ids), so running
            # this on the states tick is cheap even when no relation moved; it
            # just keeps the four family canvases current as /vocab/relate
            # (or a raw /vocab/patch) writes new links.
            await _run("vocab_graphs", _vocab_graphs_all)
        if _due("rss", cfg.rss_minutes, now):
            await _run("rss", rss.poll)
        if _due("jobsfair", cfg.jobsfair_minutes, now):
            await _run("jobsfair", jobsfair.write_feed)
        if cfg.jobsfair_pull_hours and _due("jobsfair_pull",
                                            cfg.jobsfair_pull_hours * 60, now):
            await _run("jobsfair_pull",
                       lambda: asyncio.to_thread(jobsfair.run_pulls))
        if _due("services_reap", 1, now):
            await _run("services_reap", services.reap_idle)
        # Standby for the model itself. Checked every minute so the configured
        # idle window means what it says; the reaper is a no-op until it is
        # actually exceeded, and it never *starts* anything.
        if _due("llm_standby", 1, now):
            await _run("llm_standby", llm.reap_idle)
        if _due("lastfm", cfg.lastfm_minutes, now):
            await _run("lastfm", lastfm.poll)
        if _due("boox", cfg.boox_minutes, now):
            await _run("boox", boox.scan)
        if now.hour >= cfg.daily_jobs_hour and _last_daily != now.date():
            _last_daily = now.date()
            await _daily_ai_jobs()
        await asyncio.sleep(60)
