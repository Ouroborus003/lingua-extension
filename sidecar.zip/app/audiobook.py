from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import queue
import re
import subprocess
import tempfile
import threading
import wave
from pathlib import Path
from typing import Callable

from .citations import RULES_VERSION as CITATION_RULES, strip_citations

log = logging.getLogger("sidecar.audiobook")

AUDIOBOOK_DIR = Path(os.environ.get("AUDIOBOOK_DIR") or Path.home() / "Music/audiobooks/vault")
SAMPLE_RATE = 24000
SENTENCE_GAP = 0.12
PARAGRAPH_GAP = 0.45
BOOK_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,120}$")
MAX_SENTENCE_CHARS = 2000


class RenderCancelled(Exception):
    pass


def valid_book_id(book: str) -> bool:
    return bool(BOOK_ID_RE.match(book or "")) and book not in (".", "..")


def book_dir(book: str) -> Path:
    if not valid_book_id(book):
        raise ValueError(f"bad book id: {book!r}")
    return AUDIOBOOK_DIR / book


def section_hash(voice: str, paragraphs: list[list[str]], skip_citations: bool = False,
                 backend: str = "") -> str:
    """The backend belongs in here. Without it, re-rendering a book after
    switching engines finds every section's hash unchanged and keeps the old
    audio — the render "succeeds" in seconds and sounds exactly as it did
    before, which is indistinguishable from the engine picker doing nothing."""
    blob = json.dumps({"v": voice, "p": paragraphs, "b": backend,
                       "c": CITATION_RULES if skip_citations else 0}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()


def clean_paragraphs(paragraphs) -> list[list[str]]:
    out = []
    for para in paragraphs or []:
        sents = [" ".join(str(s).split())[:MAX_SENTENCE_CHARS] for s in (para or [])]
        out.append([s for s in sents if s])
    return out


def pcm_from_wav(data: bytes) -> bytes:
    """24 kHz mono 16-bit PCM out of whatever the engine produced.

    Kokoro happens to emit exactly that, which is why this used to reject
    anything else. Piper's voices are 22.05 kHz and edge/gTTS hand back mp3,
    so once the renderer stopped being hardwired to one engine, "wrong rate"
    stopped meaning "corrupt" and started meaning "resample it"."""
    try:
        with wave.open(io.BytesIO(data)) as w:
            if w.getframerate() == SAMPLE_RATE and w.getnchannels() == 1 and w.getsampwidth() == 2:
                return w.readframes(w.getnframes())
    except wave.Error:
        pass
    return _ffmpeg_pcm(data)


def _ffmpeg_pcm(data: bytes) -> bytes:
    r = subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-i", "pipe:0", "-f", "s16le",
         "-ar", str(SAMPLE_RATE), "-ac", "1", "pipe:1"],
        input=data, capture_output=True)
    if r.returncode != 0 or not r.stdout:
        raise ValueError("could not decode the synthesizer's audio: "
                         + r.stderr.decode(errors="replace")[-300:])
    return r.stdout


def silence(seconds: float) -> bytes:
    return b"\x00\x00" * int(round(seconds * SAMPLE_RATE))


def write_wav(path: Path, pcm: bytes) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SAMPLE_RATE)
        w.writeframes(pcm)


def encode_opus(wav_path: Path, out_path: Path) -> None:
    result = subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", str(wav_path),
         "-c:a", "libopus", "-b:a", "40k", "-ac", "1", str(out_path)],
        capture_output=True)
    if result.returncode != 0:
        raise RuntimeError("ffmpeg opus encode failed: " + result.stderr.decode(errors="replace")[-400:])


def render_section(paragraphs: list[list[str]], voice: str, synth: Callable[[str, str], bytes],
                   cancelled: Callable[[], bool] = lambda: False,
                   speak: Callable[[str], str] | None = None) -> tuple[bytes, list[dict]]:
    chunks: list[bytes] = []
    cursor = 0
    timings: list[dict] = []
    for p, para in enumerate(paragraphs):
        for s, text in enumerate(para):
            if cancelled():
                raise RenderCancelled()
            spoken = speak(text) if speak else text
            if not spoken:
                timings.append({"p": p, "s": s, "start": round(cursor / SAMPLE_RATE, 3),
                                "end": round(cursor / SAMPLE_RATE, 3), "text": text})
                continue
            pcm = pcm_from_wav(synth(spoken, voice))
            start = cursor
            chunks.append(pcm)
            cursor += len(pcm) // 2
            timings.append({"p": p, "s": s, "start": round(start / SAMPLE_RATE, 3),
                            "end": round(cursor / SAMPLE_RATE, 3), "text": text})
            gap = silence(SENTENCE_GAP if s < len(para) - 1 else PARAGRAPH_GAP)
            chunks.append(gap)
            cursor += len(gap) // 2
    return b"".join(chunks), timings


def read_manifest(book: str) -> dict | None:
    path = book_dir(book) / "manifest.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def write_manifest(book: str, manifest: dict) -> None:
    d = book_dir(book)
    d.mkdir(parents=True, exist_ok=True)
    tmp = d / "manifest.json.tmp"
    tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, d / "manifest.json")


def render_book(req: dict, synth: Callable[[str, str], bytes],
                encode: Callable[[Path, Path], None] = encode_opus,
                cancelled: Callable[[], bool] = lambda: False,
                progress: Callable[[int, int, str], None] = lambda done, total, key: None) -> dict:
    book = req["book"]
    voice = req.get("voice") or ""
    backend = req.get("backend") or ""
    skip = bool(req.get("skip_citations", True))
    speak = strip_citations if skip else None
    d = book_dir(book)
    d.mkdir(parents=True, exist_ok=True)
    old = read_manifest(book) or {}
    old_by_key = {s.get("key"): s for s in old.get("sections", []) if s.get("key") is not None}
    sections_in = req.get("sections") or []
    manifest = {"version": 1, "book": book, "title": req.get("title") or "", "voice": voice,
                "backend": backend, "sections": []}
    for i, sec in enumerate(sections_in):
        paragraphs = clean_paragraphs(sec.get("paragraphs"))
        entry = {"key": str(sec.get("key", i)), "title": sec.get("title") or "",
                 "hash": section_hash(voice, paragraphs, skip, backend), "file": None, "duration": 0,
                 "sentences": [], "status": "pending"}
        prev = old_by_key.get(entry["key"])
        if prev and prev.get("hash") == entry["hash"] and prev.get("status") == "done" \
                and prev.get("file") and (d / prev["file"]).exists():
            entry.update({k: prev[k] for k in ("file", "duration", "sentences")})
            entry["status"] = "done"
        manifest["sections"].append((entry, paragraphs))
    total = len(manifest["sections"])

    def snapshot() -> dict:
        return {**{k: v for k, v in manifest.items() if k != "sections"},
                "sections": [e for e, _ in manifest["sections"]]}

    write_manifest(book, snapshot())
    for i, (entry, paragraphs) in enumerate(manifest["sections"]):
        progress(i, total, entry["key"])
        if entry["status"] == "done":
            continue
        if not any(paragraphs):
            entry.update({"status": "done", "duration": 0, "file": None})
            write_manifest(book, snapshot())
            continue
        entry["status"] = "rendering"
        write_manifest(book, snapshot())
        try:
            pcm, timings = render_section(paragraphs, voice, synth, cancelled, speak)
            name = f"{i:03d}.ogg"
            with tempfile.TemporaryDirectory(dir=d) as tmpd:
                wav_path = Path(tmpd) / "section.wav"
                write_wav(wav_path, pcm)
                encode(wav_path, Path(tmpd) / name)
                os.replace(Path(tmpd) / name, d / name)
            entry.update({"status": "done", "file": name,
                          "duration": round(len(pcm) / 2 / SAMPLE_RATE, 3), "sentences": timings})
        except RenderCancelled:
            entry["status"] = "pending"
            write_manifest(book, snapshot())
            raise
        except Exception as exc:
            log.warning("audiobook %s section %s failed: %s", book, entry["key"], exc)
            entry.update({"status": "error", "error": str(exc)[:300]})
        write_manifest(book, snapshot())
    progress(total, total, "")
    return snapshot()


class Renderer:

    def __init__(self, synth: Callable[[str, str], bytes] | None = None,
                 encode: Callable[[Path, Path], None] = encode_opus) -> None:
        self.synth = synth
        self.encode = encode
        self.jobs: dict[str, dict] = {}
        self.pending: "queue.Queue[str]" = queue.Queue()
        self.lock = threading.Lock()
        self.thread: threading.Thread | None = None

    def _synth(self, backend: str = "", lang: str = ""):
        """The synthesizer for one job.

        This used to return a Kokoro closure unconditionally, ignoring the
        job entirely — so every "Voice source" the reader offered rendered
        the same engine with the same speaker, and the only way to tell was
        to listen. An injected `self.synth` still wins, because the tests
        supply one.

        Returns a `(text, voice) -> audio bytes` callable; render_section
        hands the bytes to pcm_from_wav, which now accepts any rate or
        container."""
        if self.synth is not None:
            return self.synth
        from . import tts_engine

        backend = (backend or "").strip().lower()
        if not backend or backend == "auto":
            backend = ("kokoro" if tts_engine.HAS_KOKORO
                       else tts_engine.pick_read_aloud_backend(lang))

        if backend == "kokoro":
            def kokoro(text: str, voice: str) -> bytes:
                return tts_engine._kokoro.synth(text, voice or tts_engine.KOKORO_DEFAULT_VOICE)
            return kokoro

        if backend == "piper":
            def piper(text: str, voice: str) -> bytes:
                return tts_engine.piper_wav_bytes(text, voice or (lang or "eng"))
            return piper

        # edge-tts and gTTS have no in-memory path — they write a file. A
        # render is a background batch, so the temp file costs nothing next
        # to the network round trip it is already paying for.
        def via_file(text: str, voice: str) -> bytes:
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as fh:
                tmp = fh.name
            try:
                tts_engine.save_sync(
                    text, voice or tts_engine.default_voice_for(backend, lang),
                    "+0%", tmp, backend=backend, lang=lang, use_cache=True,
                    normalize=False, auto_fallback=False)
                with open(tmp, "rb") as fh:
                    return fh.read()
            finally:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
        return via_file

    def submit(self, req: dict) -> dict:
        book = req.get("book") or ""
        if not valid_book_id(book):
            raise ValueError(f"bad book id: {book!r}")
        with self.lock:
            old = self.jobs.get(book)
            if old and old["state"] == "running":
                old["cancel"] = True
            job = {"state": "queued", "done": 0, "total": len(req.get("sections") or []),
                   "current": "", "error": "", "cancel": False, "req": req}
            self.jobs[book] = job
            self.pending.put(book)
            if self.thread is None or not self.thread.is_alive():
                self.thread = threading.Thread(target=self._run, daemon=True)
                self.thread.start()
        return self.public(book)

    def cancel(self, book: str) -> dict:
        with self.lock:
            job = self.jobs.get(book)
            if job and job["state"] in ("queued", "running"):
                job["cancel"] = True
                if job["state"] == "queued":
                    job["state"] = "cancelled"
        return self.public(book)

    def public(self, book: str) -> dict:
        job = self.jobs.get(book)
        if not job:
            return {"state": "idle"}
        return {k: job[k] for k in ("state", "done", "total", "current", "error")}

    def _run(self) -> None:
        while True:
            try:
                book = self.pending.get(timeout=5)
            except queue.Empty:
                with self.lock:
                    if self.pending.empty():
                        self.thread = None
                        return
                continue
            with self.lock:
                job = self.jobs.get(book)
                if not job or job["state"] != "queued" or job["cancel"]:
                    continue
                job["state"] = "running"

            def progress(done, total, key, job=job):
                job["done"], job["total"], job["current"] = done, total, key

            try:
                req = job["req"]
                render_book(req, self._synth(req.get("backend") or "", req.get("lang") or ""),
                            self.encode,
                            cancelled=lambda job=job: job["cancel"], progress=progress)
                job["state"] = "cancelled" if job["cancel"] else "done"
            except RenderCancelled:
                job["state"] = "cancelled"
            except Exception as exc:
                log.exception("audiobook render failed for %s", book)
                job["state"], job["error"] = "error", str(exc)[:300]

    def wait(self, timeout: float = 30) -> None:
        t = self.thread
        if t is not None:
            t.join(timeout)


renderer = Renderer()
