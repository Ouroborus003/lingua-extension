"""
pinyin_accents.py — numbered pinyin → diacritic pinyin.

CEDICT (and most raw dictionary sources) carry tone numbers: "ni3 hao3",
"lu:4 shi1". Learners read diacritics: "nǐ hǎo", "lǜ shī". This module
converts syllable-by-syllable, leaving anything that isn't a numbered
pinyin syllable untouched, so it is safe to run over mixed strings and
over strings that are already accented (no digits → returned unchanged).

Tone-mark placement rules (standard):
  • 'a' or 'e' takes the mark if present (they never co-occur),
  • otherwise 'ou' marks the 'o',
  • otherwise the LAST vowel takes the mark (covers iu → ú, ui → ǐ).
Tone 5 (neutral) strips the number and adds no mark.
'u:' and 'v' are normalized to 'ü' first (CEDICT conventions).
"""

from __future__ import annotations

import re

_MARKS = {
    "a": "aāáǎà", "e": "eēéěè", "i": "iīíǐì",
    "o": "oōóǒò", "u": "uūúǔù", "ü": "üǖǘǚǜ",
    "A": "AĀÁǍÀ", "E": "EĒÉĚÈ", "I": "IĪÍǏÌ",
    "O": "OŌÓǑÒ", "U": "UŪÚǓÙ", "Ü": "ÜǕǗǙǛ",
}

_VOWELS = set("aeiouüAEIOUÜ")

# One pinyin syllable with a trailing tone digit. Letters + optional
# CEDICT ü spellings (u: / v), then 1-5. The r5 of erhua ("r5") and
# standalone "m2"/"n2"-style interjection syllables also match.
_SYL_RE = re.compile(r"([A-Za-zÜü]+|[A-Za-z]*[uU]:[a-zA-Z]*)([1-5])")


def _accent_syllable(letters: str, tone: int) -> str:
    """Place the tone mark on `letters` (no digit) for tone 1-5."""
    letters = letters.replace("u:", "ü").replace("U:", "Ü")
    # CEDICT sometimes writes ü as v
    letters = letters.replace("v", "ü").replace("V", "Ü")
    if tone == 5 or tone == 0:
        return letters
    idx = -1
    for i, ch in enumerate(letters):
        if ch in ("a", "A", "e", "E"):
            idx = i
            break
    if idx < 0:
        ou = letters.lower().find("ou")
        if ou >= 0:
            idx = ou
    if idx < 0:
        for i in range(len(letters) - 1, -1, -1):
            if letters[i] in _VOWELS:
                idx = i
                break
    if idx < 0:
        return letters  # no vowel (shouldn't happen for real syllables)
    ch = letters[idx]
    marked = _MARKS.get(ch)
    if not marked:
        return letters
    return letters[:idx] + marked[tone] + letters[idx + 1:]


def numbered_to_accented(text: str) -> str:
    """Convert every numbered pinyin syllable in `text` to diacritics.

    Non-syllable content (hanzi, punctuation, already-accented pinyin,
    plain English) passes through unchanged. Fast no-op when the string
    contains no digits.
    """
    if not text or not any(c.isdigit() for c in text):
        return text

    def _sub(m: re.Match) -> str:
        return _accent_syllable(m.group(1), int(m.group(2)))

    return _SYL_RE.sub(_sub, text)
