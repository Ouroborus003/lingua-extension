"""ocr.py — tesseract for scans with no text layer.

Library Workspace's offline import reads a scan's own front matter for
identity: title, translator, publisher, year (see that plugin's
first-page.js). A scan that never went through OCR has no text layer at
all — pdf.js's getTextContent() comes back empty — and this module is the
fix: the system `tesseract` binary, shelled out to, never a bundled or
cloud OCR engine (the operator's own ruling; see this repo's CLAUDE.md).

The plugin does the rasterising, not this module. first-page.js already
renders pages through pdf.js with a JPEG2000 wasm decoder this shelf's
scans need — without it a LuraDocument/Internet Archive page renders as a
blank white sheet. Re-rasterising here with poppler would risk OCRing
different pixels than the cover extraction sees, for no gain, so the
plugin POSTs PNGs it already rendered and this module only ever reads
them.

Everything here degrades rather than raises past its own boundary: a
missing binary or language pack is reported (by /health and /ocr/status)
rather than thrown from inside a request, and a bad or slow page never
takes the rest of the batch down with it. The router turns "the operator
asked for something this machine cannot do" (an uninstalled language)
into a 400 they can act on; a machine-state problem (no tesseract at all)
is a 503, not a stack trace.
"""
from __future__ import annotations

import base64
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import httpx

from . import llm, prompts
from .config import Config

log = logging.getLogger("sidecar.ocr")

TESSERACT_BIN = "tesseract"

# What this vault's shelf needs (CLAUDE.md's own inventory) — used only to
# shape /health's summary. The language *check* for an actual request is
# always against the live --list-langs output below, never this set, so a
# machine with a fuller (or thinner) tessdata than this one's is judged on
# what it actually has.
VAULT_LANGS = ("eng", "deu", "rus", "ara", "chi_sim")


def available() -> bool:
    return shutil.which(TESSERACT_BIN) is not None


def _tessdata_env(tessdata_prefix: str) -> dict[str, str] | None:
    """The one place TESSDATA_PREFIX gets decided, so installed_langs() and
    _run_page() can never disagree about which tessdata directory is live —
    the router validates a requested language against the former and then
    runs OCR through the latter, and a mismatch there means "the operator
    can see ara is installed" while the actual OCR call quietly falls back
    to a system pack that doesn't have it.

    Empty, or a path that isn't a readable directory, returns None — meaning
    "inherit the parent environment unchanged", i.e. tesseract's own default
    search of the system tessdata. A configured-but-missing prefix therefore
    degrades to that default rather than raising; tessdata_status() is where
    that fallback gets reported to /ocr/status instead."""
    if not tessdata_prefix:
        return None
    if not Path(tessdata_prefix).expanduser().is_dir():
        return None
    env = os.environ.copy()
    env["TESSDATA_PREFIX"] = str(Path(tessdata_prefix).expanduser())
    return env


def tessdata_status(tessdata_prefix: str) -> dict:
    """/ocr/status's report of the tessdata_prefix knob — separate from the
    env helper above because a missing prefix is silent there (by design,
    §module docstring) and needs to surface *somewhere* the operator can see
    it rather than just quietly OCRing against the wrong tessdata."""
    if not tessdata_prefix:
        return {"configured": "", "active": False}
    ok = Path(tessdata_prefix).expanduser().is_dir()
    out = {"configured": tessdata_prefix, "active": ok}
    if not ok:
        out["reason"] = f"{tessdata_prefix!r} is not a readable directory — using system tessdata"
    return out


def installed_langs(tessdata_prefix: str = "") -> list[str]:
    """Whatever `tesseract --list-langs` reports, minus its header line.
    Blocking (a subprocess) — call from async code via asyncio.to_thread,
    the same way the audio router keeps Forvo's urllib call off the event
    loop."""
    if not available():
        return []
    try:
        res = subprocess.run([TESSERACT_BIN, "--list-langs"],
                             capture_output=True, text=True, timeout=5,
                             env=_tessdata_env(tessdata_prefix))
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning("tesseract --list-langs failed: %s", e)
        return []
    # "List of available languages (129):" on the first line, one language
    # per line after it. Some packaging writes the list to stderr instead
    # of stdout; either way the first line is the header, not a language.
    lines = (res.stdout or "").splitlines() or (res.stderr or "").splitlines()
    return [ln.strip() for ln in lines[1:] if ln.strip()]


def _run_page(png_path: Path, lang: str, timeout_s: int, tessdata_prefix: str = "") -> str:
    """One page, one process, one hard timeout. Explicit argument list —
    never shell=True — and a bound on how long any single page may run, so
    a malformed image can't wedge the sidecar the way an unfenced pdf.js
    render could wedge Obsidian (see library-workspace's IMPORT_SCAN_MS,
    the same fence on the plugin side of this same pipeline)."""
    try:
        res = subprocess.run(
            [TESSERACT_BIN, str(png_path), "stdout", "-l", lang],
            capture_output=True, text=True, timeout=timeout_s,
            env=_tessdata_env(tessdata_prefix))
    except subprocess.TimeoutExpired:
        log.warning("tesseract timed out on %s (lang=%s)", png_path.name, lang)
        return ""
    except OSError as e:
        log.warning("tesseract failed to start: %s", e)
        return ""
    if res.returncode != 0:
        log.warning("tesseract exited %s on %s: %s", res.returncode, png_path.name,
                    (res.stderr or "").strip()[-200:])
        return ""
    return res.stdout or ""


def ocr_images(images_b64: list[str], lang: str, timeout_s: int, max_pages: int,
               tessdata_prefix: str = "") -> str:
    """Front-matter page images (base64 PNG, page order) -> concatenated
    text, blank pages and unreadable ones simply contributing nothing.
    `max_pages` is enforced here, not only by the router, so any future
    direct caller inherits the same ceiling rather than being able to
    queue an unbounded number of tesseract processes. Each page gets its
    own process and its own timeout, so one corrupt image or one slow page
    can't take the rest of the batch down with it."""
    texts = []
    with tempfile.TemporaryDirectory(prefix="library-ocr-") as td:
        for i, b64 in enumerate(images_b64[:max(0, max_pages)]):
            try:
                data = base64.b64decode(b64)
            except Exception:
                continue
            if not data:
                continue
            path = Path(td) / f"page{i}.png"
            path.write_bytes(data)
            text = _run_page(path, lang, timeout_s, tessdata_prefix)
            if text.strip():
                texts.append(text)
    return "\n".join(texts)


class VlmNotConfigured(Exception):
    """`engine: "vlm"` was requested but ocr.vlm_model is empty. Distinct
    from VlmUnavailable because the fix here is a config edit, not "start
    something" — the router still turns both into a 503, but this one's
    message names the setting instead of an `lms load` command."""


class VlmUnavailable(Exception):
    """LM Studio answered, but the request failed for a reason the operator
    can act on (usually: named model isn't loaded, and JIT loading is off
    globally on this machine so it never will be on its own)."""


async def vlm_ocr_images(images_b64: list[str], cfg: Config) -> str:
    """The opt-in VLM escape hatch (a `vlm/` import folder, engine: "vlm" in
    the request) — everything else in this module is tesseract-only by the
    operator's own ruling (module docstring), so this path exists solely for
    the books tesseract does badly on and is never reached by default.

    Takes the whole effective Config (not just OcrCfg) because the request
    needs both halves of it: ocr.vlm_model/max_pages/timeout_seconds decide
    what this call does, and lm_studio.base_url/ttl_seconds decide how it
    talks to LM Studio — the same two configs llm.py's own chat path reads
    from, just via cfg.ocr and cfg.lm_studio instead of a single LMStudioCfg.

    Sends every page in one chat call as OpenAI-style vision content (one
    image_url part per page) rather than one call per page — a VLM answers
    from the whole request's context, and paying for a model load-equivalent
    per page would defeat the point of a single opt-in escape hatch.

    LM Studio here has just-in-time loading turned OFF on purpose (the
    operator's own setting), so naming an unloaded model does not load it —
    it 400s "No models loaded" exactly the way a genuinely bad model name
    would. That is surfaced as VlmUnavailable with an actionable `lms load`
    instruction rather than attempted automatically: auto-loading a model
    behind a global "don't do that" setting is the kind of thing that pins a
    GPU for hours without anyone asking for it (see llm.py's ttl_seconds
    comment for exactly that failure).
    """
    ocr_cfg, lm_cfg = cfg.ocr, cfg.lm_studio
    if not ocr_cfg.vlm_model:
        raise VlmNotConfigured(
            "no VLM model is configured — set ocr.vlm_model in config.yaml "
            "(or ocr_vlm_model in 08 Meta/Settings.md) to the LM Studio model "
            "id you intend to use for scanned-book OCR.")
    images = images_b64[:max(0, ocr_cfg.max_pages)]
    if not images:
        return ""

    content: list[dict] = [{"type": "text", "text": prompts.load("ocr_vlm")}]
    for b64 in images:
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64}"}})
    payload: dict = {
        "model": ocr_cfg.vlm_model,
        "temperature": 0,
        "messages": [{"role": "user", "content": content}],
    }
    if lm_cfg.ttl_seconds:
        # Same rule as llm._chat_once: a request without ttl is a model that
        # sits resident until something else evicts it, which is exactly the
        # bug that just pinned 7.2GB of an 8GB GPU for 15 hours.
        payload["ttl"] = lm_cfg.ttl_seconds

    llm.mark_used()
    try:
        async with httpx.AsyncClient(
                base_url=lm_cfg.base_url,
                # A multi-page vision request is slower than a text chat
                # call of the same token count; scale the budget with how
                # many pages were actually sent rather than reusing the
                # per-page tesseract timeout as-is.
                timeout=max(lm_cfg.timeout_seconds, ocr_cfg.timeout_seconds * len(images))
        ) as client:
            r = await client.post("/chat/completions", json=payload)
            r.raise_for_status()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 400 and "no models loaded" in e.response.text.lower():
            raise VlmUnavailable(
                f"LM Studio has no model loaded for {ocr_cfg.vlm_model!r} — "
                f"just-in-time loading is off on this machine, so run "
                f"`lms load {ocr_cfg.vlm_model}` and retry.") from e
        raise VlmUnavailable(
            f"VLM OCR failed against {lm_cfg.base_url}: {e} — "
            f"body: {e.response.text}") from e
    except Exception as e:
        raise VlmUnavailable(f"VLM OCR failed against {lm_cfg.base_url}: {e}") from e
    llm.mark_used()

    message = r.json()["choices"][0]["message"]
    # Same reasoning-model fallback as llm._chat_once: a model can dump its
    # whole answer into reasoning_content and leave content empty.
    text = message.get("content") or ""
    if not text.strip():
        text = message.get("reasoning_content") or text
    return text
