"""pronounce.py — the one place that decides where a human recording comes from.

The pronunciation equivalent of the dictionary cascade: an ordered list of
sources, tried until one answers, with an honest record of what each one said.

WHY THIS EXISTS

Pronunciation was single-sourced on Forvo, and Forvo is behind an intermittent
CloudFlare challenge — measured 2026-08-14, 2 successes in 12 attempts. A
single source with an 83% per-attempt failure rate has no good failure mode:
either you lie about it ("no recordings for this word") or you show the reader
an error where audio should be. Neither is what they asked for, which was to
hear the word.

So the fix is not a better scraper, it is a second source. `lingualibre.py` has
no key, no bot wall and no rate-limited scrape, and covers the operator's
languages unevenly but really. Forvo stays first because it has far more words
and community vote ordering; Lingua Libre fills the gaps; device TTS remains
the caller's last resort.

THE DISTINCTION THIS MODULE EXISTS TO PRESERVE

    unavailable  = every source FAILED (blocked, unreachable, unparseable)
    empty + not unavailable = the sources worked, the word has no recording

Collapsing those two is the bug that started all of this. A reader told "no
human recordings for this word" when the truth is "Forvo is challenging us"
will stop clicking, and the fault is invisible. So `unavailable` is true only
when **no source succeeded at reaching its provider**, and `tried[]` carries
the per-source detail for the UI to show.
"""
from __future__ import annotations

import logging

from . import forvo, lingualibre, settings

log = logging.getLogger("sidecar.pronounce")

# Registry, as (module, attribute) — resolved at CALL time, never bound here.
#
# Late binding is deliberate and load-bearing. Holding the function object
# would freeze whatever `forvo.list_pronunciations_detailed` was at import,
# so `monkeypatch.setattr(forvo, "list_pronunciations_detailed", fake)` would
# not intercept and the suite would silently reach the real forvo.com — which
# is exactly what happened on the first run of this module: tests that had
# always been offline started returning real MP3 bytes. A registry that cannot
# be stubbed is a registry that gets tested against the internet.
#
# A source is `f(word, lang, limit) -> {items, unavailable, reason}`; both
# existing sources already return exactly that, so there is no adapter layer.
_SOURCES = {
    "forvo": (forvo, "list_pronunciations_detailed"),
    "lingualibre": (lingualibre, "recordings"),
}


def _resolve(name: str):
    mod, attr = _SOURCES[name]
    return getattr(mod, attr)

# Hosts we will fetch audio bytes from. An ALLOWLIST, never a substring test:
# these URLs originate in a scraped third-party page, so "does it contain
# forvo.com" would happily accept `https://evil.example/?x=forvo.com`.
AUDIO_HOSTS = ("https://audio00.forvo.com/", "https://upload.wikimedia.org/")

DEFAULT_ORDER = "forvo,lingualibre"


def _order() -> list[str]:
    """The operator's source order, filtered to sources that exist.

    An unknown name in the setting is dropped rather than raising — a typo in
    `08 Meta/Settings.md` should degrade one source, not take pronunciation
    down entirely.
    """
    raw = getattr(settings.effective().audio, "pronunciation_sources", "") or DEFAULT_ORDER
    names = [n.strip().lower() for n in raw.split(",") if n.strip()]
    out = [n for n in names if n in _SOURCES]
    if not out:
        log.info("no usable pronunciation sources in %r — falling back to default", raw)
        out = [n.strip() for n in DEFAULT_ORDER.split(",")]
    return out


def recordings(word: str, lang: str, limit: int = 6) -> dict:
    """Human recordings for a word, from the first source that has any.

    Returns {items, source, unavailable, reason, tried}:
      items       [{url, user, votes, source}] — `source` on every item, so a
                  later clip fetch knows which host it is talking to.
      source      the name that answered, or "".
      unavailable True only when EVERY source failed provider-side.
      reason      the first source failure, for the UI to show.
      tried       [{name, ok, count, reason}] — the honesty record.
    """
    word = (word or "").strip()
    if not word:
        return {"items": [], "source": "", "unavailable": False, "reason": "", "tried": []}

    tried, first_reason = [], ""
    any_reached = False

    for name in _order():
        fn = _resolve(name)
        try:
            r = fn(word, lang, limit)
        except Exception as exc:            # a source must never take the cascade down
            log.info("pronunciation source %s raised for %r: %s", name, word, exc)
            tried.append({"name": name, "ok": False, "count": 0, "reason": str(exc)})
            first_reason = first_reason or f"{name}: {exc}"
            continue

        failed = bool(r.get("unavailable"))
        items = r.get("items") or []
        # A source that answered — even with nothing — proves the WORD is the
        # reason for the silence, not the network.
        if not failed:
            any_reached = True
        tried.append({"name": name, "ok": not failed, "count": len(items),
                      "reason": r.get("reason", "")})
        if failed and not first_reason:
            first_reason = r.get("reason", "") or f"{name} unavailable"

        if items:
            for it in items:
                it.setdefault("source", name)
            return {"items": items, "source": name, "unavailable": False,
                    "reason": "", "tried": tried}

    # Nothing had anything. Whether that is an outage depends entirely on
    # whether ANY source managed to answer.
    return {"items": [], "source": "", "unavailable": not any_reached,
            "reason": "" if any_reached else first_reason, "tried": tried}


def download(url: str) -> bytes | None:
    """Audio bytes for one recording URL, or None.

    Routed by host so a Lingua Libre `.wav` on upload.wikimedia.org works
    alongside a Forvo `.mp3` — the plugin plays both from a data URI, and
    Chromium decodes wav and ogg natively.
    """
    u = (url or "").strip()
    if not u.startswith(AUDIO_HOSTS):
        log.info("refusing audio fetch from a non-allowlisted host: %.80s", u)
        return None
    if u.startswith("https://audio00.forvo.com/"):
        return forvo.download(u)        # module attr, so a test stub applies
    return _get_bytes(u)


def _get_bytes(url: str, timeout: int = 20) -> bytes | None:
    import urllib.request
    try:
        req = urllib.request.Request(url, headers=lingualibre._HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (allowlisted)
            data = r.read()
        return data if data and len(data) > 256 else None
    except Exception as exc:
        log.debug("audio fetch failed for %s: %s", url, exc)
        return None


def top(word: str, lang: str) -> dict:
    """The single best recording WITH its bytes — the `popular`-mode answer.

    Always returns the same shape; `audio` is empty when there is nothing to
    play. It carries `unavailable`/`reason` too, because `popular` mode used to
    return a bare empty result with no way for the reader to tell a blocked
    source from a word nobody has recorded.
    """
    r = recordings(word, lang)
    miss = {"audio": b"", "url": "", "user": "", "votes": 0, "source": "",
            "unavailable": r["unavailable"], "reason": r["reason"], "tried": r["tried"]}

    for p in r["items"]:
        audio = download(p["url"])
        if audio:
            return {"audio": audio, "url": p["url"], "user": p.get("user", ""),
                    "votes": p.get("votes", 0), "source": p.get("source", r["source"]),
                    "unavailable": False, "reason": "", "tried": r["tried"]}

    # We had URLs but every download failed — that IS a source failure, even
    # though the listing step succeeded.
    if r["items"]:
        miss["unavailable"] = True
        miss["reason"] = "found recordings but none could be downloaded"
    return miss
