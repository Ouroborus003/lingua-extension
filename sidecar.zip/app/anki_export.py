"""anki_export.py — builds the .apkg genanki packages lingua-workspace's
"Export .apkg" buttons ask for. Ported from LinguaStudio's
`generator_api.py` (the vocab-export slice of `GeneratorAPI.export_apkg`
and its helpers), reshaped around pieces this sidecar already owns rather
than LinguaStudio's separate config dir / audio stack.

Adaptations from the source (each is also called out inline, near the code
it touches):

  1. Audio. `_ensure_audio` no longer imports LinguaStudio's own
     `audio_provider` — it calls this sidecar's `app/audio_provider.py`
     (ported in commit 3e46d0a) via `resolve_audio_detailed`, with `cfg`
     obtained the same way `app/routers/vocab_audio.py` obtains it
     (`settings.effective()`). The idempotence rule and the failure policy
     are both kept verbatim: a word already carrying an `audio` filename
     whose file exists on disk is reused rather than refetched, and a
     failed resolve leaves that one word's `Audio` field empty and logs —
     it never aborts the export. That policy is what lets `/vocab/export`
     work with no network at all (Forvo unreachable, TTS unreachable):
     the deck still comes out, just silent on the words that couldn't
     resolve.

  2. Writing-card media — DROPPED. The source's `_writer_media_for_words`
     needs LinguaStudio's `kinesthetic` and `languages` modules plus a
     47MB per-character stroke-data tree, neither of which lives in this
     vault. Out of scope for this port; a named phase-2 item, the same way
     `app/tts_engine.py`'s docstring notes the Qwen3-TTS omission. A
     Writing-template note built here still has a `WriteCfg` field (see
     `anki_note_types.get_hanzi_model`), it's just always empty — the
     template's canvas has nothing to draw until that phase lands.

  3. Image media. The source resolves `image` against its own visual-cards
     cache (`_safe_media_path` + `_VISUAL_SEARCH_DIRS`, both LinguaStudio-
     only paths). Here the `image` value is a path into *this* vault (a
     vocab note's frontmatter), so it's resolved with `app/vault.abs_path`
     instead — that function already implements the resolve-and-check-
     parents traversal guard the rest of the sidecar trusts, so a crafted
     `image` (`../../../etc/passwd`, or an absolute path outside the
     vault) is rejected the same way any other vault read would reject it,
     rather than hand-rolling a second guard. A missing file is skipped
     silently, matching the source's own behavior — the note still
     renders, just without the picture.

  4. Output dir. LinguaStudio writes to `~/.linguastudio/output`. Here:
     `STATE_DIR / "anki_export"`, mirroring `AUDIO_DIR` in
     `audio_provider.py` and `PIPER_VOICE_DIR` in `tts_engine.py`. `.state/`
     is gitignored; the plugin copies the returned absolute path into the
     operator's own apkg directory itself (`copyApkg` in main.js), so no
     plugin-side change was needed for this to work.

  5. `_vocab_model_for_language`'s `from anki_push import MODEL_VOCAB` is
     dropped — it's unused in the source function body (dead import) and
     there is no `anki_push` module in this sidecar: `/vocab/push` (the
     AnkiConnect live-push) deliberately still goes to LinguaStudio this
     phase, so nothing here needs it.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path

from . import audio_provider, settings, vault
from .config import STATE_DIR

log = logging.getLogger("sidecar.anki_export")

# Mirrors AUDIO_DIR (audio_provider.py) / PIPER_VOICE_DIR (tts_engine.py) —
# see module docstring point 4.
OUTPUT_DIR = STATE_DIR / "anki_export"


def _safe_filename(name: str, default: str) -> str:
    """Strip path components and shell metacharacters from a user-supplied filename."""
    name = Path(name).name          # remove any directory traversal
    name = re.sub(r"[^\w\-. ]", "_", name)  # allow only safe chars
    return name if name.endswith(".apkg") else default


# ── Per-language vocab model dispatch ─────────────────────────────────────────
#
# The Mandarin model (`LinguaStudio` / `get_hanzi_model`) is the default. Codes
# that have their own model use it; everything else falls back to Mandarin
# (LinguaStudio currently catalogs vocab in the Mandarin field schema for any
# language that doesn't have a dedicated model). Field-name mapping per model
# is in `_vocab_fields_for_language`.

def _vocab_model_for_language(lang: str, selected=None):
    """Return (model_name_str, genanki_model) for the given language code.

    selected: optional set/list of template names (e.g. {"Writing"}) passed
    through to get_hanzi_model for Mandarin/fallback models.
    Falls back to the Mandarin `LinguaStudio` model when no per-language
    model is registered for `lang`. The except clause is the entire
    mechanism by which `cmn` (and any other unmapped code) gets the hanzi
    model — see `anki_note_types.get_model_for_language`'s own docstring.
    """
    from .anki_note_types import get_hanzi_model, get_model_for_language
    try:
        model = get_model_for_language(lang)
        return model.name, model
    except (ValueError, KeyError):
        pass
    model = get_hanzi_model(selected=selected)
    return model.name, model


def _vocab_fields_for_language(lang: str, word: dict, model) -> dict:
    """Map a plugin-supplied word dict to the field schema of the active model.

    The plugin payload (`word`) carries: word, traditional, trans, meaning,
    audio, image. Each language's model has a different schema (different
    first-field name, different romanization-style field name, etc.). This
    helper maps the common payload onto whatever fields the chosen model
    declares.
    """
    field_names = {f["name"] for f in model.fields}
    audio_tag = f"[sound:{word['audio']}]" if word.get("audio") else ""

    # The "term" field name varies per language: Simplified, Word, Kanji, Hangul.
    # The "reading" field name varies too: Pinyin, Jyutping, Romanization, IPA.
    # Use a precedence list and pick the first that exists in the model.
    def _first_present(*candidates):
        for c in candidates:
            if c in field_names:
                return c
        return None

    term_field    = _first_present("Simplified", "Kanji", "Hangul", "Word")
    reading_field = _first_present("Pinyin", "Jyutping", "Kana", "Romanization", "Romaji", "IPA")

    out = {name: "" for name in field_names}
    if term_field:
        out[term_field] = word.get("word", "")
    if reading_field:
        reading = word.get("trans", "")
        # Mandarin readings must render with diacritics on the card, even if
        # the row arrived carrying raw numbered pinyin (older imports, CSV).
        # Jyutping (yue) keeps its numbers — that IS its standard notation.
        if lang == "cmn" and reading:
            try:
                from .pinyin_accents import numbered_to_accented
                reading = numbered_to_accented(reading)
            except Exception:
                pass
        out[reading_field] = reading
    if "Traditional" in field_names:
        out["Traditional"] = word.get("traditional", "")
    if "Zhuyin" in field_names:
        out["Zhuyin"] = word.get("zhuyin", "")
    if "Meaning" in field_names:
        out["Meaning"] = word.get("meaning", "")
    if "Audio" in field_names:
        out["Audio"] = audio_tag
    if "Image" in field_names:
        # Bare basename (<img src>) — the actual file rides along via
        # _vocab_image_media, and genanki packs media by basename, so the
        # two agree regardless of what directory the vault image lives in.
        img = Path(word.get("image") or "").name
        out["Image"] = f'<img src="{img}">' if img else ""
    if "Tags" in field_names:
        out["Tags"] = lang
    return out


def _vocab_image_media(words: list) -> list:
    """Absolute paths for each word's chosen image, resolved against the
    vault root (path-traversal-safe via `vault.abs_path`). Missing or
    out-of-vault files are skipped — the note still renders, just without
    the picture, same as the source's own behavior. See module docstring
    point 3 for why this resolves differently than upstream.
    """
    out = []
    for w in words:
        img = (w.get("image") or "").strip()
        if not img:
            continue
        try:
            p = vault.abs_path(img)
        except vault.VaultError as exc:
            log.warning("image %r rejected (outside vault): %s", img, exc)
            continue
        if p.exists() and p.is_file():
            out.append(str(p))
    return out


# ── Audio resolution ──────────────────────────────────────────────────────

def _ensure_audio(words: list, lang: str, cfg) -> list:
    """Resolve audio for every word lacking it, in place.

    Sets each word's `audio` field to the media filename (used by
    `_vocab_fields_for_language` to emit `[sound:...]`) and returns the list
    of absolute file paths to ship as genanki media. Idempotent: words that
    already carry an `audio` filename whose file exists on disk are reused,
    not refetched. `cfg` is the caller's `settings.effective()` result, so a
    later call in the same process picks up an operator's mid-session
    Settings.md edit (audio_source, forvo_enabled, ...) exactly as
    /vocab/audio does.

    A failed resolve (Forvo miss + TTS unavailable, or an exception from
    either) leaves that one word's audio empty and logs — it never fails
    the whole export. Kept verbatim from the source: a deck missing one
    word's audio beats no deck at all.
    """
    paths = []
    for w in words:
        existing = w.get("audio") or ""
        if existing:
            p = audio_provider.AUDIO_DIR / existing
            if p.exists():
                paths.append(str(p))
                continue
        try:
            fname, abspath, _source = audio_provider.resolve_audio_detailed(
                w.get("word", ""), lang, cfg)
        except Exception as exc:
            log.warning("audio resolve failed for %r: %s", w.get("word"), exc)
            fname, abspath = None, None
        if fname and abspath:
            w["audio"] = fname
            paths.append(abspath)
    return paths


def export_apkg(words: list, lang: str, filename: str = "",
                deck_name: str = "", selected_templates=None) -> dict:
    """Build a .apkg from `words` and write it under OUTPUT_DIR.

    Returns {"ok": True, "path": "<abs path>"} or {"ok": False, "error":
    str(e)} — kept exactly as the source shapes it, since the plugin
    branches on this exact shape (see main.js's two "Export .apkg" call
    sites).
    """
    try:
        import genanki, random
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        fname = _safe_filename(filename, f"lingua-{lang}-export.apkg") if filename else f"lingua-{lang}-export.apkg"
        out_path = OUTPUT_DIR / fname
        _, model = _vocab_model_for_language(lang, selected=selected_templates)
        resolved_deck = deck_name or f"LinguaStudio::{lang}"
        deck = genanki.Deck(random.randrange(1 << 30, 1 << 31), resolved_deck)
        cfg = settings.effective()
        # Resolve audio first so each note's Audio field carries [sound:...]
        # and the referenced mp3s ride along in the package media. Visual
        # images are bundled the same way (<img src> targets). Writing-card
        # media is NOT bundled here — see module docstring point 2.
        media_paths = list(_ensure_audio(words, lang, cfg)) + _vocab_image_media(words)
        if model.name == "LinguaStudio" or model.name.startswith("LinguaStudio ("):
            from .anki_note_types import VOCAB_MEDIA
            media_paths += VOCAB_MEDIA
        for w in words:
            fields_dict = _vocab_fields_for_language(lang, w, model)
            # genanki.Note expects fields as a positional list matching model.fields order
            deck.add_note(genanki.Note(
                model=model,
                fields=[fields_dict.get(f["name"], "") for f in model.fields],
            ))
        pkg = genanki.Package(deck)
        pkg.media_files = media_paths
        pkg.write_to_file(str(out_path))
        return {"ok": True, "path": str(out_path)}
    except Exception as e:
        return {"ok": False, "error": str(e)}
