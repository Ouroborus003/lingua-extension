"""audio_cache.py — SHA-256 keyed TTS file cache.

Ported close to verbatim from LinguaStudio's `tts_engine`-adjacent
`audio_cache.py`: same key shape (`text|voice|speed|backend`, sha256), same
one-mp3-per-key layout. Only the directory changed — the vault sidecar has no
`~/LinguaStudio` of its own, so cached mp3s live under the sidecar's existing
state area instead (`STATE_DIR`, the same directory `services.py` already
writes supervised-engine logs into).

This cache is a generic "have we synthesized this exact (text, voice, speed,
backend) before" lookup, used by `tts_engine.save_sync`. It is distinct from
`audio_provider`'s per-word canonical file (`<lang>-<word>.mp3`) — a preview
of a sentence and a vocab word's canonical audio are cached separately, since
only the latter is the file a card export re-reads by a fixed name.
"""
from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

from .config import STATE_DIR

CACHE_DIR = STATE_DIR / "tts_cache"


def _key(text: str, voice: str, speed: str, backend: str) -> str:
    raw = f"{text}|{voice}|{speed}|{backend}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def get(text: str, voice: str, speed: str, backend: str) -> Path | None:
    """Return the cached MP3 Path if it exists, else None."""
    path = CACHE_DIR / f"{_key(text, voice, speed, backend)}.mp3"
    return path if path.exists() and path.stat().st_size > 0 else None


def put(text: str, voice: str, speed: str, backend: str, src_path: str) -> Path:
    """Copy src_path into the cache and return the cache Path."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    dest = CACHE_DIR / f"{_key(text, voice, speed, backend)}.mp3"
    shutil.copy2(src_path, dest)
    return dest


def clear() -> int:
    """Delete all cached files. Returns the count deleted."""
    if not CACHE_DIR.exists():
        return 0
    files = list(CACHE_DIR.glob("*.mp3"))
    for f in files:
        try:
            f.unlink()
        except OSError:
            pass
    return len(files)


def size_bytes() -> int:
    """Return total cache size in bytes."""
    if not CACHE_DIR.exists():
        return 0
    return sum(f.stat().st_size for f in CACHE_DIR.glob("*.mp3"))
