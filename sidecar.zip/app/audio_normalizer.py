"""audio_normalizer.py — LUFS normalization, ported verbatim from
LinguaStudio (`linguastudio/audio_normalizer.py`). Human recordings (Forvo)
and TTS output land at wildly different loudness; running both through this
before they're saved means a deck mixing the two plays at an even volume.

Two-pass ffmpeg `loudnorm`: pass 1 measures, pass 2 applies the measured
values (more accurate than a single blind pass). Needs system `ffmpeg`
(already on this machine — `which ffmpeg`); if it's missing or a pass fails,
this returns False and the caller falls back to copying the raw bytes rather
than losing the audio entirely (see `audio_provider._normalize_into`).
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path


def normalize_lufs(in_path: str, out_path: str, target: float = -18.0,
                   sample_rate: int | None = 24000, bitrate: str = "128k") -> bool:
    """Two-pass LUFS normalization using ffmpeg's loudnorm filter.
    Returns True on success.

    sample_rate=None keeps the source's own rate. The 24 kHz / 128k defaults
    are the Anki-deck convention every vocab and Forvo clip is filed under and
    must not change; read-aloud passes its own, because resampling a 22.05 kHz
    piper voice up to 24 kHz and re-encoding it at 128k is two losses bought
    for nothing."""
    try:
        # Pass 1: measure
        pass1_cmd = [
            "ffmpeg", "-y",
            "-i", str(in_path),
            "-af", f"loudnorm=I={target}:TP=-1.5:LRA=11:print_format=json",
            "-f", "null", "-",
        ]
        r1 = subprocess.run(pass1_cmd, capture_output=True, timeout=30)
        # loudnorm's measurement JSON is written to stderr, not stdout.
        stderr = r1.stderr.decode("utf-8", errors="replace")
        start = stderr.rfind("{")
        end = stderr.rfind("}") + 1
        if start == -1 or end <= start:
            return _normalize_single(in_path, out_path, target, sample_rate, bitrate)
        stats = json.loads(stderr[start:end])

        # Pass 2: apply the measured values.
        lnorm = (
            f"loudnorm=I={target}:TP=-1.5:LRA=11"
            f":measured_I={stats['input_i']}"
            f":measured_TP={stats['input_tp']}"
            f":measured_LRA={stats['input_lra']}"
            f":measured_thresh={stats['input_thresh']}"
            f":offset={stats['target_offset']}"
            f":linear=true:print_format=none"
        )
        pass2_cmd = [
            "ffmpeg", "-y",
            "-i", str(in_path),
            "-af", lnorm,
            *(("-ar", str(sample_rate)) if sample_rate else ()),
            "-ac", "1", "-b:a", bitrate,
            str(out_path),
        ]
        r2 = subprocess.run(pass2_cmd, capture_output=True, timeout=60)
        return r2.returncode == 0 and Path(out_path).exists()
    except Exception:
        return _normalize_single(in_path, out_path, target, sample_rate, bitrate)


def _normalize_single(in_path: str, out_path: str, target: float,
                      sample_rate: int | None = 24000, bitrate: str = "128k") -> bool:
    """Fallback: single-pass normalize to mono MP3."""
    try:
        cmd = [
            "ffmpeg", "-y",
            "-i", str(in_path),
            *(("-ar", str(sample_rate)) if sample_rate else ()),
            "-ac", "1", "-b:a", bitrate,
            str(out_path),
        ]
        r = subprocess.run(cmd, capture_output=True, timeout=60)
        return r.returncode == 0 and Path(out_path).exists()
    except Exception:
        return False
