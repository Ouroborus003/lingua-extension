"""Per-feature model selection.

Every AI feature in this vault used to run on one model — `lm_studio.model`,
set once in the Settings note. That is the wrong granularity: a tag proposal
and a book identification want very different things. Extraction is fine on a
4B model and returns in a second; a digest reads better from a bigger one and
nobody minds waiting; a VLM is required for OCR and useless for anything else.
One global setting forces the slowest common denominator on every feature, or
the least capable — whichever the operator picked last.

So each feature may name its own model, and anything unset falls back to the
global default. Nothing here loads a model: resolution is a string lookup, and
the same explicit-loading rules apply downstream (see llm.py).

The resolver is pure and the catalogue is data, both so the suite can see them.
The *point* of this module is a decision — "which model serves this feature" —
and a decision buried in a request handler is one no test can reach.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

# Every feature that can take its own model, in the order the settings tab
# shows them. `key` is the wire/storage name and never changes once shipped —
# a rename orphans the operator's saved choice silently. `label` and `hint` are
# the settings UI's to display.
#
# `kind` splits the catalogue by what can actually serve the request:
#   chat   — an ordinary text completion; any loaded LLM will do
#   vision — needs a vision-language model; a text model cannot answer at all
#   audio  — Whisper sizes, a closed set that is not an LM Studio model id
# The UI must not offer a text model for a vision feature: the request does not
# fail cleanly, it comes back confidently describing nothing.
FEATURES: tuple[dict, ...] = (
    {"key": "sidebar_chat", "label": "Sidebar chat", "kind": "chat",
     "hint": "The ask-the-vault chat. Interactive, so latency is felt."},
    {"key": "reader_gloss", "label": "Reader gloss", "kind": "chat",
     "hint": "Explain, Examine, Exclaim and Enquiry on a passage in the book reader."},
    {"key": "digest", "label": "Digests", "kind": "chat",
     "hint": "Daily/weekly/monthly digests. Scheduled, so slower is fine."},
    {"key": "ratings", "label": "Ratings", "kind": "chat",
     "hint": "Rates listening/reading entries during digest generation."},
    {"key": "insight_qa", "label": "Insight Q&A", "kind": "chat",
     "hint": "Answers questions against the vault's own facts."},
    {"key": "dashboard_note", "label": "Dashboard note", "kind": "chat",
     "hint": "The generated morning note prose."},
    {"key": "tag_proposals", "label": "Tag proposals", "kind": "chat",
     "hint": "Suggests tags for untagged notes. Extraction — a small model does well."},
    {"key": "template_design", "label": "Template design", "kind": "chat",
     "hint": "Writes a note template from an instruction. Structured output, "
             "so a small model does well; it is reviewed before anything is written."},
    {"key": "tag_hierarchy", "label": "Tag hierarchy", "kind": "chat",
     "hint": "Proposes a parent/child structure over existing tags."},
    {"key": "identify_book", "label": "Identify book", "kind": "chat",
     "hint": "Names title and author from the first pages of a file."},
    {"key": "translate", "label": "Translate", "kind": "chat",
     "hint": "Sentence-aligned translation. Structured output — accuracy over prose."},
    {"key": "smart_management", "label": "Smart Management", "kind": "chat",
     "hint": "Runs your own prompts across the library and notes. Batched, so "
             "prefer a model you are happy to run hundreds of times."},
    {"key": "ocr_vlm", "label": "OCR (vision)", "kind": "vision",
     "hint": "Reads text out of images. Requires a vision model."},
    {"key": "whisper", "label": "Speech to text", "kind": "audio",
     "hint": "Whisper size, not an LM Studio model."},
)

FEATURE_KEYS: frozenset[str] = frozenset(f["key"] for f in FEATURES)

# Where a request may be sent. LM Studio is the default and stays the default:
# it is what this machine actually runs, what the explicit-loading and `ttl`
# rules were built around, and what /health knows how to report on.
#
# The others exist because the vault already contains plugins pointed at other
# backends — several at an Ollama that is not running — and because pinning one
# feature to a different route is a legitimate thing to want. A route is a base
# URL and a dialect, nothing more:
#   openai — POST {base}/chat/completions, OpenAI's message shape. LM Studio,
#            llama.cpp's server, LocalAI, vLLM and OpenRouter all speak it.
#   ollama — POST {base}/api/chat, Ollama's own shape. Not OpenAI-compatible on
#            this path, which is why a plugin configured for Ollama cannot be
#            repointed at LM Studio by changing the URL alone.
#
# `explicit_load` records whether the route refuses to pull weights on demand.
# LM Studio here has justInTimeModelLoading off deliberately, so naming an
# unloaded model returns an error instead of silently taking the card. Ollama
# does load on demand. The UI says so, because "why is this slow the first
# time" and "why did my VRAM disappear" are the same question.
ROUTES: tuple[dict, ...] = (
    {"key": "lmstudio", "label": "LM Studio (default)", "dialect": "openai",
     "base_url": "http://127.0.0.1:4444/v1", "explicit_load": True,
     "hint": "This machine's server. Models are loaded deliberately, never on demand."},
    {"key": "ollama", "label": "Ollama", "dialect": "ollama",
     "base_url": "http://127.0.0.1:11434", "explicit_load": False,
     "hint": "Loads a model on first use. Nothing is listening on 11434 unless you start it."},
    {"key": "openai_compatible", "label": "Other OpenAI-compatible", "dialect": "openai",
     "base_url": "", "explicit_load": False,
     "hint": "llama.cpp server, vLLM, LocalAI, OpenRouter — anything speaking /chat/completions."},
)

ROUTE_KEYS: frozenset[str] = frozenset(r["key"] for r in ROUTES)

DEFAULT_ROUTE = "lmstudio"


def route(key: str | None) -> dict:
    """The route record for `key`, falling back to LM Studio.

    Falls back rather than raising for the same reason model_for does: an
    unknown route name is a bug, but the recoverable behaviour is to use the
    server this machine actually runs.
    """
    for r in ROUTES:
        if r["key"] == key:
            return r
    return ROUTES[0]


def chat_url(route_key: str | None, base_url: str = "") -> str:
    """The full completion URL for a route.

    The dialect decides the path, not the operator. Getting this wrong is the
    failure the vault already has on disk — a plugin holding an Ollama base URL
    and an OpenAI path answers 404 and reports it as "error connecting", which
    reads like the server is down when it is running and simply does not serve
    that route.
    """
    r = route(route_key)
    base = (base_url or r["base_url"] or "").rstrip("/")
    if not base:
        return ""
    if r["dialect"] == "ollama":
        return f"{base}/api/chat"
    return f"{base}/chat/completions"

# Whisper is a fixed set of sizes, not an LM Studio id. Mirrors the choices
# already enforced in settings.py so the two cannot drift into disagreeing
# about what is selectable.
WHISPER_SIZES: tuple[str, ...] = ("tiny", "base", "small", "medium")


def model_for(feature: str | None, overrides: dict | None, default: str) -> str:
    """The model that serves `feature`, or the global default.

    Unknown feature keys fall back rather than raise: a caller naming a feature
    this module has not heard of is a bug worth finding, but failing the user's
    request over it turns a mis-set string into an outage. The bad key is
    visible in the settings tab, which lists only known features.
    """
    if not feature:
        return default
    picked = (overrides or {}).get(feature)
    if isinstance(picked, str) and picked.strip():
        return picked.strip()
    if isinstance(picked, dict):
        model = picked.get("model")
        if isinstance(model, str) and model.strip():
            return model.strip()
    return default


def route_for(feature: str | None, overrides: dict | None) -> str:
    """The route that serves `feature`. LM Studio unless told otherwise."""
    picked = (overrides or {}).get(feature or "")
    if isinstance(picked, dict):
        key = picked.get("route")
        if isinstance(key, str) and key in ROUTE_KEYS:
            return key
    return DEFAULT_ROUTE


def sanitize(raw: dict | None) -> dict:
    """Keep only known features mapped to a usable selection.

    Written this way because the store is a JSON file an operator may edit by
    hand, and because a key that survives here goes on to name a model in a
    real request. An empty string is dropped rather than kept: `{"digest": ""}`
    must mean "use the default", not "ask LM Studio for a model called nothing".

    Two shapes are accepted. A bare string is a model on the default route —
    the shape this file had before routes existed, kept readable so an existing
    file keeps working rather than silently resetting every feature. A dict may
    carry `model`, `route` and `base_url`. An entry that says nothing useful is
    dropped entirely: storing `{}` for a feature is indistinguishable in effect
    from having no entry, and a store full of empty dicts hides which features
    the operator actually set.
    """
    out: dict[str, dict] = {}
    for k, v in (raw or {}).items():
        if k not in FEATURE_KEYS:
            continue
        if isinstance(v, str):
            if v.strip():
                out[k] = {"model": v.strip(), "route": DEFAULT_ROUTE}
            continue
        if not isinstance(v, dict):
            continue
        entry: dict[str, str] = {}
        model = v.get("model")
        if isinstance(model, str) and model.strip():
            entry["model"] = model.strip()
        rk = v.get("route")
        entry["route"] = rk if isinstance(rk, str) and rk in ROUTE_KEYS else DEFAULT_ROUTE
        base = v.get("base_url")
        if isinstance(base, str) and base.strip():
            entry["base_url"] = base.strip().rstrip("/")
        # A default-route entry with no model says nothing the absence of an
        # entry does not already say.
        if entry.get("model") or entry["route"] != DEFAULT_ROUTE:
            out[k] = entry
    return out


def state_path(root: str | os.PathLike) -> Path:
    return Path(root) / ".state" / "ai_models.json"


def load(root: str | os.PathLike) -> dict:
    """Read the overrides. A missing or corrupt file means "no overrides".

    Corrupt is deliberately not fatal. This file is not the vault's data — it
    is a set of preferences, and the recoverable behaviour when it cannot be
    parsed is for every feature to run on the global default, which is exactly
    how the sidecar behaved before this module existed.
    """
    p = state_path(root)
    try:
        return sanitize(json.loads(p.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return {}


def save(root: str | os.PathLike, overrides: dict) -> dict:
    """Write the overrides, atomically, and return what was actually stored."""
    clean = sanitize(overrides)
    p = state_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(clean, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    # Atomic: a half-written preferences file that then fails to parse would
    # silently reset every feature to the default.
    os.replace(tmp, p)
    return clean
