"""Append-only access to .canvas files (spec §9.10).

Canvas layouts are AUTHORED — the operator drew them, and the drawing is the
retention mechanism. The sidecar's only license is appending new nodes to a
staging area at the canvas edge; this module makes any other write
impossible: it re-verifies on save that every pre-existing node survived
untouched.
"""
from __future__ import annotations

import json
import uuid

from . import vault


def load(rel: str) -> dict:
    p = vault.abs_path(rel)
    if not p.exists():
        return {"nodes": [], "edges": []}
    data = json.loads(p.read_text() or "{}")
    data.setdefault("nodes", [])
    data.setdefault("edges", [])
    return data


def referenced_files(canvas: dict) -> set[str]:
    return {n.get("file") for n in canvas["nodes"] if n.get("type") == "file"}


def append_file_nodes(rel: str, paths: list[str], color: str | None = "6") -> int:
    """Append file nodes in a staging column right of the rightmost node.

    Existing nodes are never moved, edited, or removed — enforced, not
    assumed. Returns the number of nodes appended.
    """
    if not paths:
        return 0
    canvas = load(rel)
    before = json.dumps(canvas["nodes"], sort_keys=True)

    x = max((n.get("x", 0) + n.get("width", 0) for n in canvas["nodes"]),
            default=0) + 80
    y = min((n.get("y", 0) for n in canvas["nodes"]), default=0)
    for path in paths:
        node = {"id": uuid.uuid4().hex[:16], "type": "file", "file": path,
                "x": x, "y": y, "width": 360, "height": 240}
        if color:
            node["color"] = color
        canvas["nodes"].append(node)
        y += 280

    # The append-only guarantee: everything that was there is still there.
    after_original = json.dumps(canvas["nodes"][:-len(paths)], sort_keys=True)
    if after_original != before:
        raise vault.VaultError(f"canvas append would alter existing nodes: {rel}")

    p = vault.abs_path(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(canvas, ensure_ascii=False, indent=1))
    return len(paths)


def text_node_ids(canvas: dict) -> dict[str, str]:
    """Existing `type: "text"` nodes, keyed by their exact text content."""
    return {n["text"]: n["id"] for n in canvas["nodes"]
            if n.get("type") == "text" and n.get("text")}


def append_text_nodes(rel: str, texts: list[str], color: str | None = None) -> dict[str, str]:
    """Append a text-card node for each of `texts` not already present
    (matched by exact text), staged right of the rightmost node — the same
    append-only guarantee as `append_file_nodes`, for content that has no
    backing file (a vocabulary term is a CSV row, not a note).

    Returns `text -> id` for every one of `texts`, old and new, so a caller
    can go straight from this into `set_edges` without a second lookup.
    """
    canvas = load(rel)
    existing = text_node_ids(canvas)
    new = [t for t in dict.fromkeys(texts) if t not in existing]
    if new:
        before = json.dumps(canvas["nodes"], sort_keys=True)
        x = max((n.get("x", 0) + n.get("width", 0) for n in canvas["nodes"]),
                default=0) + 80
        y = min((n.get("y", 0) for n in canvas["nodes"]), default=0)
        for t in new:
            nid = uuid.uuid4().hex[:16]
            node = {"id": nid, "type": "text", "text": t,
                    "x": x, "y": y, "width": 220, "height": 80}
            if color:
                node["color"] = color
            canvas["nodes"].append(node)
            existing[t] = nid
            y += 100

        after_original = json.dumps(canvas["nodes"][:-len(new)], sort_keys=True)
        if after_original != before:
            raise vault.VaultError(f"canvas append would alter existing nodes: {rel}")

        p = vault.abs_path(rel)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(canvas, ensure_ascii=False, indent=1))
    return {t: existing[t] for t in texts}


def set_edges(rel: str, pairs: list[tuple[str, str]], label: str | None = None) -> int:
    """Replace the canvas's whole edge list with one edge per `(fromNode,
    toNode)` id pair, in the order given.

    Edges are not operator-drawn the way node positions are — they are a live
    view of the underlying relation, so the full array is regenerated every
    call rather than merged. Edge ids are DERIVED from the node pair (not
    random) so an unchanged relation produces byte-identical edges and the
    file is left alone — the same "don't dirty git when nothing moved" rule
    `vocab_csv._write` follows. Raises if a pair references a node id this
    canvas does not have (the caller must create nodes first).
    """
    canvas = load(rel)
    node_ids = {n["id"] for n in canvas["nodes"]}
    for frm, to in pairs:
        if frm not in node_ids or to not in node_ids:
            raise vault.VaultError(f"edge references unknown node in {rel}: {frm} -> {to}")

    built = []
    for frm, to in pairs:
        edge = {"id": f"e-{frm}-{to}", "fromNode": frm, "toNode": to}
        if label:
            edge["label"] = label
        built.append(edge)

    if canvas.get("edges", []) == built:
        return len(built)
    canvas["edges"] = built
    p = vault.abs_path(rel)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(canvas, ensure_ascii=False, indent=1))
    return len(built)
