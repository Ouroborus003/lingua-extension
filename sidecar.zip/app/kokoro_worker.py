
import base64
import contextlib
import io
import json
import os
import sys
import wave

SAMPLE_RATE = 24000

LANG_BY_PREFIX = {
    "a": "a", "b": "b", "e": "e", "f": "f", "h": "h",
    "i": "i", "j": "j", "p": "p", "z": "z",
}


def lang_for_voice(voice: str) -> str:
    return LANG_BY_PREFIX.get((voice or "a")[:1].lower(), "a")


def to_wav_bytes(samples) -> bytes:
    import numpy as np
    arr = np.asarray(samples, dtype=np.float32)
    arr = np.clip(arr, -1.0, 1.0)
    pcm = (arr * 32767.0).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SAMPLE_RATE)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def main() -> int:
    import warnings
    warnings.filterwarnings("ignore")
    with contextlib.redirect_stdout(sys.stderr):
        import numpy as np
        import torch
        from kokoro import KPipeline
        device = "cuda" if torch.cuda.is_available() else "cpu"
        pipelines = {}

        def pipeline_for(lang):
            if lang not in pipelines:
                pipelines[lang] = KPipeline(lang_code=lang, device=device)
            return pipelines[lang]

        warm_voice = os.environ.get("KOKORO_VOICE") or "af_heart"
        for _ in pipeline_for(lang_for_voice(warm_voice))("Ready.", voice=warm_voice):
            pass

    sys.stdout.write(json.dumps({"ready": True, "device": device}) + "\n")
    sys.stdout.flush()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError as exc:
            sys.stdout.write(json.dumps({"ok": False, "error": f"bad request: {exc}"}) + "\n")
            sys.stdout.flush()
            continue
        try:
            text = str(req.get("text") or "")
            if not text.strip():
                raise ValueError("empty text")
            voice = str(req.get("voice") or "af_heart")
            speed = float(req.get("speed") or 1.0)
            with contextlib.redirect_stdout(sys.stderr):
                pipe = pipeline_for(lang_for_voice(voice))
                parts = []
                for chunk in pipe(text, voice=voice, speed=speed):
                    audio = chunk.audio
                    parts.append(audio.numpy() if hasattr(audio, "numpy") else audio)
                if not parts:
                    raise RuntimeError("kokoro produced no audio")
                merged = np.concatenate(parts)
            payload = {"ok": True, "wav": base64.b64encode(to_wav_bytes(merged)).decode("ascii")}
        except Exception as exc:
            payload = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
        sys.stdout.write(json.dumps(payload) + "\n")
        sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
