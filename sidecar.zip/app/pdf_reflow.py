"""pdf_reflow.py — turn a PDF's fixed-page text into a reflowable note, the
same shape whisper_engine.py established: a guarded import, a single
blocking entry point the router calls via asyncio.to_thread, and a "never
raise past this module's own boundary" contract.

The point isn't perfect layout reconstruction — it's making a downloaded
book/paper readable the way an epub already is in this vault (a scrollable
column of paragraphs, not a fixed page image): dehyphenate words that a PDF
line-wrapped mid-word, collapse hard line-wraps back into flowing
paragraphs while keeping real paragraph breaks, and drop running headers/
footers (book title on every page, page numbers) that would otherwise land
as junk mid-paragraph in the output. Table layout, footnote positioning,
and multi-column pages are explicitly not reconstructed — a PDF's text
extraction order for those is already lossy before this module ever sees
it, and chasing that is a distinct, much larger effort than this phase
asked for.

Text extraction: pypdf, not the text-extractor community plugin's API —
pypdf is a small (pure Python, no system libs) dependency this sidecar
already controls and can unit-test against, rather than depending on
another plugin's undocumented internals staying stable.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path

log = logging.getLogger("sidecar.pdf_reflow")

try:
    from pypdf import PdfReader
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False


def available() -> bool:
    return HAS_PYPDF


# ------------------------------ reflow heuristics ----------------------- #
# Pure functions, no PDF library involved — the part worth unit-testing in
# isolation from pypdf itself.

_HYPHEN_WRAP_RE = re.compile(r"(\w)-\n(\w)")
_HYPHEN_WRAP_BLANK_RE = re.compile(r"(\w)-\n\n(\w)")


def dehyphenate(text: str) -> str:
    """"exam-\nple" -> "example". Only a hyphen sitting immediately at a
    line break is touched — a mid-line hyphen ("well-known") never matches
    since the regex requires the newline between the two word characters.
    Also handles "exam-\n\nple" (hyphen split across a blank line).
    Applied before reflow_paragraphs so the rejoined word lands on one
    line, same as anything else in that paragraph's run."""
    text = _HYPHEN_WRAP_RE.sub(r"\1\2", text)
    text = _HYPHEN_WRAP_BLANK_RE.sub(r"\1\2", text)
    return text


_SENTENCE_END_RE = re.compile(r"[.!?][\"')\]]*$")
_LOWER_START_RE = re.compile(r"^[a-z]")


def _is_spurious_blank_line(prev_line: str, next_line: str) -> bool:
    """Heuristic: a blank line between prev_line and next_line is likely
    a PDF extraction artifact (not a real paragraph break) if:
    - prev_line doesn't end with sentence-ending punctuation (.!?), OR
    - next_line starts with a lowercase letter, OR
    - prev_line ends with a comma, semicolon, or colon.
    These patterns strongly suggest the text continues as one paragraph."""
    if not prev_line or not next_line:
        return False
    if _SENTENCE_END_RE.search(prev_line) is None:
        return True
    if _LOWER_START_RE.match(next_line):
        return True
    if prev_line.rstrip()[-1:] in ",;:":
        return True
    return False


def _remove_spurious_blank_lines(text: str) -> str:
    """Collapse blank lines that appear mid-paragraph based on linguistic
    cues. Real paragraph breaks (sentence end + uppercase start) are kept."""
    lines = text.split("\n")
    if len(lines) < 3:
        return text
    out = [lines[0]]
    i = 1
    while i < len(lines) - 1:
        if lines[i].strip() == "":
            prev = out[-1] if out else ""
            nxt = lines[i + 1]
            if _is_spurious_blank_line(prev, nxt):
                i += 1
                continue
        out.append(lines[i])
        i += 1
    out.append(lines[-1])
    return "\n".join(out)


def reflow_paragraphs(text: str) -> str:
    """Collapse each run of consecutive non-blank lines (a paragraph that a
    PDF hard-wrapped one visual line at a time) into one flowing line: a
    blank line is the only thing that still counts as a paragraph break.
    This is the actual "read it like an epub" step — everything else in
    this module exists to make sure this one doesn't choke on artifacts."""
    paragraphs: list[str] = []
    current: list[str] = []
    for line in text.split("\n"):
        if line.strip() == "":
            if current:
                paragraphs.append(" ".join(current))
                current = []
        else:
            current.append(line.strip())
    if current:
        paragraphs.append(" ".join(current))
    return "\n\n".join(paragraphs)


_DIGITS_RE = re.compile(r"\d+")
_DECORATION_RE = re.compile(r"[\s\-–—.|\[\]()]")


def _normalize_running_line(line: str) -> str:
    """A page-number footer changes every page ("- 12 -" vs "- 13 -") but
    is otherwise identical — collapsing digit runs to a placeholder lets
    the frequency count in strip_running_headers_footers treat those as
    the same recurring line instead of N distinct one-off lines.

    Only applied when the line is *basically* a bare number once digits
    and light decoration ("- ", "[]", ".") are stripped away — a real
    heading that merely contains a number ("Chapter 1", "Chapter 12") has
    substantial text left over and is compared literally instead, so
    consecutive differently-numbered chapter openers are never collapsed
    into one "recurring header" by accident.
    """
    stripped = line.strip()
    remainder = _DECORATION_RE.sub("", _DIGITS_RE.sub("", stripped))
    if len(remainder) <= 2:
        return _DIGITS_RE.sub("#", stripped)
    return stripped


def strip_running_headers_footers(pages: list[str], min_pages: int = 3,
                                   threshold: float = 0.6) -> list[str]:
    """Drop a line that recurs (near-identically, page numbers aside) as
    the first or last non-blank line on most pages — a running book title,
    chapter header, or page-number footer. Only the head/tail position is
    a candidate; the same text appearing mid-paragraph is left alone, since
    that's content, not page furniture. Skipped entirely on short documents
    (`min_pages`) where "most pages" isn't a meaningful signal yet."""
    if len(pages) < min_pages:
        return list(pages)

    page_lines = [p.split("\n") for p in pages]
    head_counts: dict[str, int] = {}
    tail_counts: dict[str, int] = {}
    for lines in page_lines:
        idxs = [i for i, ln in enumerate(lines) if ln.strip()]
        if not idxs:
            continue
        head = _normalize_running_line(lines[idxs[0]])
        tail = _normalize_running_line(lines[idxs[-1]])
        if head:
            head_counts[head] = head_counts.get(head, 0) + 1
        if tail:
            tail_counts[tail] = tail_counts.get(tail, 0) + 1

    n = len(pages)
    head_running = {k for k, c in head_counts.items() if c / n >= threshold}
    tail_running = {k for k, c in tail_counts.items() if c / n >= threshold}

    out = []
    for lines in page_lines:
        lines = list(lines)
        idxs = [i for i, ln in enumerate(lines) if ln.strip()]
        if idxs:
            first_i, last_i = idxs[0], idxs[-1]
            if _normalize_running_line(lines[first_i]) in head_running:
                lines[first_i] = ""
            if last_i != first_i and _normalize_running_line(lines[last_i]) in tail_running:
                lines[last_i] = ""
        out.append("\n".join(lines))
    return out


def reflow_pages(pages: list[str]) -> str:
    """The full pipeline: strip running headers/footers across the whole
    document first (it needs all pages at once to find what recurs), then
    dehyphenate, remove spurious blank lines, then paragraph-reflow each page
    on its own, then join pages with a blank line — a hyphen or paragraph
    almost never legitimately spans a *page* boundary the way it spans a line
    boundary, so pages aren't merged before reflowing the way lines are."""
    cleaned = strip_running_headers_footers(pages)
    parts = []
    for page in cleaned:
        page = dehyphenate(page)
        page = _remove_spurious_blank_lines(page)
        page = reflow_paragraphs(page)
        if page.strip():
            parts.append(page.strip())
    return "\n\n".join(parts)


# ------------------------------ pypdf boundary --------------------------- #

def extract(path: str | Path) -> dict:
    """path -> {ok, pages: [str, ...], page_count, title} on success,
    {ok: False, error} on any failure (missing file, not installed, a PDF
    pypdf can't parse) — never raises, matching whisper_engine.transcribe's
    contract so the router's job is just to pass the dict through."""
    path = str(path)
    if not HAS_PYPDF:
        return {"ok": False, "error": "pypdf not installed. Run: pip install pypdf"}
    if not Path(path).exists():
        return {"ok": False, "error": f"file not found: {path}"}
    try:
        reader = PdfReader(path)
        pages = [page.extract_text() or "" for page in reader.pages]
    except Exception as exc:
        return {"ok": False, "error": f"could not read PDF: {exc}"}
    title = ""
    try:
        meta = reader.metadata
        if meta and meta.title:
            title = str(meta.title).strip()
    except Exception:
        pass
    if not title:
        title = Path(path).stem
    return {"ok": True, "pages": pages, "page_count": len(pages), "title": title}


def reflow(path: str | Path) -> dict:
    """extract() + reflow_pages() — the single entry point routers/pdf.py
    calls via asyncio.to_thread (both pypdf's parse and the regex passes
    over a whole book are real CPU/IO time, never awaited directly)."""
    result = extract(path)
    if not result.get("ok"):
        return result
    text = reflow_pages(result["pages"])
    return {"ok": True, "text": text, "page_count": result["page_count"], "title": result["title"]}
