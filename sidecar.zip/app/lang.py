"""Language-code normalisation shared across the sidecar.

The reading-companion plugin carries the canonical `baseLang` (its main.js);
this is the Python twin. Both exist because the two runtimes each need a
language code reduced to a primary subtag before it is compared, and comparing
the raw code instead is silent when it is wrong — a vocab note tagged
`zh-hans` was invisible to an inventory generated for `zh`, so its
`exported_anki` status dropped off the page with no error. See
tests/test_language_codes.py and the story in
Critical/obsidian-workflow/language-subtag-comparison-silently-empties-panels.md.
"""
from __future__ import annotations

# ISO 639-3 codes the vault's sources use, mapped to the ISO 639-1 base codes
# the rest of the stack compares against. Mirrors reading-companion/main.js's
# BASE_LANG_MAP — change both in the same commit.
BASE_LANG_MAP = {
    "cmn": "zh", "yue": "zh", "wuu": "zh",
    "jpn": "ja", "kor": "ko", "deu": "de", "spa": "es", "fra": "fr",
    "ita": "it", "por": "pt", "rus": "ru", "ara": "ar", "hun": "hu", "eng": "en",
}


def base_lang(code: str) -> str:
    """Reduce a BCP-47 / ISO 639-3 code to its primary subtag.

    'zh-hans' -> 'zh', 'jpn' -> 'ja', 'pt-BR' -> 'pt', '' -> ''.
    """
    c = (code or "").strip().lower()
    if not c:
        return ""
    head = c.split("-")[0]
    return BASE_LANG_MAP.get(c) or BASE_LANG_MAP.get(head) or head
