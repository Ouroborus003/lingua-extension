"""The single shared date-format constant (spec §7).

Mirrored by 08 Meta/Scripts/dateFormats.js for Templater — change both in the
same commit. Everything that parses a periodic filename goes through here.
"""
from __future__ import annotations

import datetime as dt
import re

def _settings_folders() -> dict[str, str]:
    """folder_* / dashboard_note overrides from the Settings note.

    Read once at import: relocating a folder needs a sidecar restart, and
    moving the actual directory (plus any Templater/Journals folder
    mappings) is the operator's job. The note location and 08 Meta are
    fixed — they anchor the config that would otherwise relocate them.
    """
    try:
        import frontmatter
        from .config import config
        p = config.vault_path / "08 Meta" / "Settings.md"
        if not p.exists():
            return {}
        meta = frontmatter.load(p).metadata
    except Exception:
        return {}
    out = {}
    for k, v in meta.items():
        if ((k.startswith("folder_") or k == "dashboard_note")
                and isinstance(v, str) and v.strip()):
            out[k] = v.strip().strip("/")
    return out


_F = _settings_folders()

# Folder map (spec §7) — defaults; overridable via the Settings note.
INBOX = _F.get("folder_inbox", "00 Inbox")
NOTES = _F.get("folder_notes", "01 Notes")
PERIODIC = _F.get("folder_periodic", "02 Periodic")
PROJECTS = _F.get("folder_projects", "03 Projects")
COLLECTIONS = _F.get("folder_collections", "04 Collections")
COURSEWORK = _F.get("folder_coursework", "05 Coursework")
TASKS = _F.get("folder_tasks", "07 Tasks")
BODY = _F.get("folder_body", "06 Body")
GENERATED = _F.get("folder_generated", "08 Meta/Generated")
META = "08 Meta"  # fixed: holds the Settings note itself
# Study artefacts (spec §10 rewrite): the per-language vocabulary CSV, the
# append-only review logs (FSRS) and the practice ledger. Fixed like META.
STUDY = f"{META}/Study"

# Collection subfolders (spec §9.7) — where album stubs and Boox canvases land.
BOOKS_DIR = _F.get("folder_books", f"{COLLECTIONS}/Books")
FILMS_DIR = _F.get("folder_films", f"{COLLECTIONS}/Films")
GAMES_DIR = _F.get("folder_games", f"{COLLECTIONS}/Games")
MUSIC_DIR = _F.get("folder_music", f"{COLLECTIONS}/Music")
# Library workspace companion notes (type: source, collections status vocab).
LIBRARY_DIR = _F.get("folder_library", f"{COLLECTIONS}/Library")

# The one generated note living outside GENERATED (spec §9.1): the dashboard
# is the homepage, so it sits in 00 Dashboard/. Exact file, not a folder —
# the folder itself holds no other generated-write license.
DASHBOARD_NOTE = _F.get("dashboard_note", "00 Dashboard/Dashboard.md")


def folder_map() -> dict[str, str]:
    """The effective folder layout, for /settings/effective reporting."""
    return {"inbox": INBOX, "notes": NOTES, "periodic": PERIODIC,
            "projects": PROJECTS, "collections": COLLECTIONS,
            "coursework": COURSEWORK, "body": BODY, "generated": GENERATED,
            "meta": META, "books": BOOKS_DIR, "films": FILMS_DIR,
            "games": GAMES_DIR, "music": MUSIC_DIR, "library": LIBRARY_DIR,
            "dashboard_note": DASHBOARD_NOTE}

DAILY_DIR = f"{PERIODIC}/Daily"
WEEKLY_DIR = f"{PERIODIC}/Weekly"
MONTHLY_DIR = f"{PERIODIC}/Monthly"
QUARTERLY_DIR = f"{PERIODIC}/Quarterly"
YEARLY_DIR = f"{PERIODIC}/Yearly"

DOMAINS = ["neuroscience", "linguistics", "music", "code", "coursework",
           "writing", "body", "admin", "personal"]

_WEEK_RE = re.compile(r"^(\d{4})-W(\d{2})$")
_MONTH_RE = re.compile(r"^(\d{4})-(\d{2})(?:-[A-Za-z]+)?$")
_QUARTER_RE = re.compile(r"^(\d{4})-Q([1-4])$")
_YEAR_RE = re.compile(r"^(\d{4})$")
_DAILY_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:-[A-Za-z]+)?$")


def daily_name(d: dt.date) -> str:
    return f"{d.isoformat()}-{d.strftime('%A')}"


def weekly_name(d: dt.date) -> str:
    year, week, _ = d.isocalendar()
    return f"{year}-W{week:02d}"


def monthly_name(d: dt.date) -> str:
    return f"{d.year}-{d.month:02d}-{d.strftime('%B')}"


def quarterly_name(d: dt.date) -> str:
    return f"{d.year}-Q{(d.month - 1) // 3 + 1}"


# Vault-relative note paths. Nesting (Daily/YYYY/MM-MMMM, others /YYYY) is
# owned by the Journals plugin config — keep the two in the same commit.

def daily_rel(d: dt.date) -> str:
    return f"{DAILY_DIR}/{d.year}/{d.month:02d}-{d.strftime('%B')}/{daily_name(d)}"


def weekly_rel(d: dt.date) -> str:
    return f"{WEEKLY_DIR}/{d.isocalendar()[0]}/{weekly_name(d)}"


def monthly_rel(d: dt.date) -> str:
    return f"{MONTHLY_DIR}/{d.year}/{monthly_name(d)}"


def quarterly_rel(d: dt.date) -> str:
    return f"{QUARTERLY_DIR}/{d.year}/{quarterly_name(d)}"


def yearly_rel(d: dt.date) -> str:
    return f"{YEARLY_DIR}/{d.year}"


def parse_daily(title: str) -> dt.date:
    """'2026-07-18-Saturday' (or bare ISO) -> date."""
    m = _DAILY_RE.match(title)
    if not m:
        raise ValueError(f"not a daily title: {title!r}")
    return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))


def week_range(title: str) -> tuple[dt.date, dt.date]:
    """'2026-W29' -> (ISO Monday, ISO Sunday)."""
    m = _WEEK_RE.match(title)
    if not m:
        raise ValueError(f"not a weekly title: {title!r}")
    start = dt.date.fromisocalendar(int(m.group(1)), int(m.group(2)), 1)
    return start, start + dt.timedelta(days=6)


def month_range(title: str) -> tuple[dt.date, dt.date]:
    m = _MONTH_RE.match(title)
    if not m:
        raise ValueError(f"not a monthly title: {title!r}")
    year, month = int(m.group(1)), int(m.group(2))
    start = dt.date(year, month, 1)
    nxt = dt.date(year + (month == 12), month % 12 + 1, 1)
    return start, nxt - dt.timedelta(days=1)


def quarter_range(title: str) -> tuple[dt.date, dt.date]:
    m = _QUARTER_RE.match(title)
    if not m:
        raise ValueError(f"not a quarterly title: {title!r}")
    year, q = int(m.group(1)), int(m.group(2))
    start = dt.date(year, 3 * q - 2, 1)
    end_month = 3 * q
    nxt = dt.date(year + (end_month == 12), end_month % 12 + 1, 1)
    return start, nxt - dt.timedelta(days=1)


def weeks_in(start: dt.date, end: dt.date) -> list[str]:
    """Weekly titles overlapping [start, end]."""
    out, cur = [], start
    while cur <= end:
        name = weekly_name(cur)
        if name not in out:
            out.append(name)
        cur += dt.timedelta(days=7)
    tail = weekly_name(end)
    if tail not in out:
        out.append(tail)
    return out


def months_in(start: dt.date, end: dt.date) -> list[str]:
    out = []
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        out.append(monthly_name(dt.date(y, m, 1)))
        y, m = y + (m == 12), m % 12 + 1
    return out
