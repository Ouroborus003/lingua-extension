"""Local-first translation hub (dual-reading backbone).

This module encodes translation as a provider cascade — an ordered list of
translators, each tried in turn, the first that answers wins. Passages
default to a dedicated machine-translation engine first, not the LLM:

  0. libretranslate — a self-hosted LibreTranslate instance: a dedicated MT
                 model that runs HERE. It heads the passage order because it is
                 the only member that is both purpose-built for translation and
                 under our own control, and because on 2026-08-25 every other
                 passage provider failed simultaneously (a container that was
                 not running, an IP Google had soft-banned, an API with no key,
                 and an LM Studio with no model loaded) while the one healthy
                 provider — stardict — declines passages by design. Its `q`
                 takes an array, so a caption track is a couple of round trips
                 rather than one request per block.
  1. google    — Google's free, unauthenticated web endpoint. A purpose-built
                 MT model, not an LLM: measured ~6x faster on a multi-block
                 passage against this vault's local model (4.6s vs 28.7s for
                 a 12-paragraph note), and requests fan out concurrently
                 (bounded) since each block is an independent network call —
                 unlike local_ai, which serializes on one inference worker.
  2. local_ai  — the LM Studio model the sidecar already talks to. Offline
                 and private, but an LLM is the wrong tool for bulk passage
                 translation: heavier per block, and provides no throughput
                 gain from concurrent requests (confirmed live: 4 concurrent
                 single-sentence calls to one LM Studio instance took as long
                 as one serialized queue, ~10.7s each). Kept as the fallback
                 for when the network's down, not the default first hit.
  3. stardict  — offline .ifo/.idx/.dict dictionaries (glosses, ideal for the
                 word-pair reader; nothing to install beyond the dict files).
  4. deepl     — DeepL's API (needs a key; the other network fallback shipped).

More providers slot in by adding an entry to PROVIDERS and naming it in
`translate.provider_order` (passages) or `translate.word_order` (single words).
The operator can reorder or drop any of them (e.g. put local_ai first for a
fully offline/no-cloud-calls setup).

Nothing here requires a network or a running model to import, and the cascade
is injectable, so the whole thing is unit-testable offline (tests/test_translate.py).
"""
from __future__ import annotations

import asyncio
import gzip
import html as html_mod
import json
import logging
import re
import struct
import sys
import time
from pathlib import Path

import httpx

from . import llm, settings
from .lang import base_lang

log = logging.getLogger("sidecar.translate")

# Codes -> names for the languages the operator cares about, so the local
# model gets an unambiguous instruction ("Translate from Japanese to English")
# rather than a bare ISO code. Unknown codes fall through as-is.
LANG_NAMES = {
    "en": "English", "es": "Spanish", "fr": "French", "it": "Italian",
    "de": "German", "nl": "Dutch", "pt": "Portuguese", "ru": "Russian",
    "uk": "Ukrainian", "pl": "Polish", "ja": "Japanese", "ko": "Korean",
    "zh": "Chinese", "zh-hans": "Simplified Chinese", "zh-hant": "Traditional Chinese",
    "ar": "Arabic", "fa": "Persian", "no": "Norwegian", "nb": "Norwegian",
    "sv": "Swedish", "da": "Danish", "fi": "Finnish", "tr": "Turkish",
    "el": "Greek", "he": "Hebrew", "hi": "Hindi", "vi": "Vietnamese",
    "th": "Thai", "id": "Indonesian", "cs": "Czech", "ro": "Romanian",
    "hu": "Hungarian", "bg": "Bulgarian",
}


def lang_name(code: str) -> str:
    if not code:
        return "the source language (auto-detect)"
    c = code.strip().lower()
    return LANG_NAMES.get(c) or LANG_NAMES.get(c.split("-")[0]) or code


# Our codes -> Google Translate's codes. Google mostly takes ISO-639-1, but a
# few differ (Chinese is region-tagged, Norwegian Bokmål is "no"). A blank
# source means auto-detect. Unknown codes fall through as the primary subtag,
# which Google accepts for every language the operator listed.
_GOOGLE_LANG = {
    "": "auto", "zh": "zh-CN", "zh-hans": "zh-CN", "zh-hant": "zh-TW",
    "nb": "no", "nn": "no",
}


def google_lang(code: str, *, source: bool) -> str:
    c = (code or "").strip().lower()
    if not c:
        return "auto" if source else "en"
    return _GOOGLE_LANG.get(c) or _GOOGLE_LANG.get(c.split("-")[0]) or c.split("-")[0]


# Word tokenizer that works across the scripts the operator listed. The CJK
# branch is FIRST: those scripts are unspaced, so each ideograph / kana /
# hangul syllable is one token; the letter run below would otherwise swallow a
# whole line of them. Latin / Cyrillic / Greek / Arabic / Hebrew letter runs
# fall through to the second branch.
def _letter_class() -> str:
    r"""`\p{L}` for the stdlib `re`, which has no Unicode-property escapes.

    `[^\W\d_]` reads like "a letter" and very nearly is — but `\w` admits every
    *alphanumeric* character while `\d` excludes only the *decimal* ones, so
    categories No and Nl (superscripts, Roman numerals, vulgar fractions) slip
    through. That is not academic here: this library is full of scholarly texts
    carrying footnote markers, and "bourgeoisie²" tokenized as one word — it
    could never match the reader's `bourgeoisie` vocab entry, and it inflated
    the running-word count, so the *same* passage scored a different Krashen
    band in the sidecar than in reading-companion's offline port, which uses a
    real `\p{L}`. The two must agree; see tests/test_tokenizer_parity.py.

    Derived from unicodedata rather than hardcoded so it tracks whatever
    Unicode version the running Python ships. ~0.15s once at import; the 1023
    offending codepoints collapse to ~80 ranges.
    """
    # `isdecimal`, not `isdigit`: re's `\d` is exactly category Nd, whereas
    # isdigit also answers True for superscripts (²), which is how "bourgeoisie²"
    # survived the first attempt at this fix.
    bad = [cp for cp in range(sys.maxunicode + 1)
           if (c := chr(cp)).isalnum() and not c.isdecimal() and not c.isalpha()]
    parts, start, prev = [], bad[0], bad[0]
    for cp in bad[1:]:
        if cp != prev + 1:
            parts.append((start, prev))
            start = cp
        prev = cp
    parts.append((start, prev))
    excluded = "".join(
        re.escape(chr(a)) if a == b else f"{re.escape(chr(a))}-{re.escape(chr(b))}"
        for a, b in parts)
    return f"[^\\W\\d_{excluded}]"


_L = _letter_class()
_WORD_RE = re.compile(
    "[぀-ヿ㐀-鿿豈-﫿가-힣]"   # one CJK/kana/hangul each
    rf"|[0-9]*{_L}+(?:['’\-]{_L}+)*",                     # alphabetic words
    re.UNICODE,
)


# ── Chinese segmentation (CC-CEDICT forward-max-match) ───────────────
# The base tokenizer splits every ideograph on its own. That is right for
# Japanese kana and Korean hangul (one syllable each) and the correct fallback
# when no dictionary is present, but it is WRONG for the coverage signal in
# Chinese, where 分享 is one word a reader either knows or does not — splitting
# it into 分 + 享 measures "do I know these two characters" instead of "do I
# know this word", and drops the word from the known set entirely when a vocab
# note stores it whole. The JS port merges the same way through
# cedict.js:forwardMatch + mergeCjkSpans; these helpers are the Python twin,
# so the segmented fixtures (tokenizer_fixtures.json cases carrying a `dict`)
# assert identical output on both sides. Longest-first match, like the JS, so
# 分享 wins over 分 even when both are in the dictionary.

# CJK ideographs only — kana and hangul must not match or a Chinese dictionary
# would try to segment Japanese and Korean text (the JS HANZI_RE is the twin;
# the two ranges deliberately exclude U+4DC0–U+4DFF, the Yijing hexagrams).
_HANZI_RE = re.compile("[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")

MAX_WORD_LEN = 5


def is_hanzi(ch: str) -> bool:
    return bool(_HANZI_RE.fullmatch(ch))


def _forward_match(words: set[str], text: str, offset: int,
                   max_len: int = MAX_WORD_LEN) -> str | None:
    """Longest dictionary word starting at `offset` (cedict.js:forwardMatch)."""
    window = text[offset:offset + max_len]
    for ln in range(len(window), 0, -1):
        candidate = window[:ln]
        if candidate in words:
            return candidate
    return None


def _segment_hanzi(tokens: list[str], words: set[str]) -> list[str]:
    """Merge runs of single ideographs into longest dictionary words.

    Only runs of ideographs are touched — a kana/hangul/latin token passes
    through unchanged, so applying this to non-Chinese text is a no-op except
    on any Han characters it happens to contain.
    """
    out: list[str] = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        if len(tok) != 1 or not is_hanzi(tok):
            out.append(tok)
            i += 1
            continue
        run: list[str] = []
        j = i
        while j < len(tokens) and len(tokens[j]) == 1 and is_hanzi(tokens[j]):
            run.append(tokens[j])
            j += 1
        text = "".join(run)
        k = 0
        while k < len(text):
            hit = _forward_match(words, text, k)
            end = k + len(hit) if hit else k + 1
            out.append(text[k:end])
            k = end
        i = j
    return out


def _is_chinese(code: str | None) -> bool:
    """True when `code` names a Chinese language (zh, zh-hans, cmn, yue, …)."""
    return base_lang(code or "") == "zh"


def tokenize(text: str, lang: str | None = None,
             words: set[str] | None = None) -> list[str]:
    """Words for coverage analysis, lower-cased for alphabetic scripts.

    For a Chinese `lang` and a supplied `words` set (CC-CEDICT headwords),
    merges runs of ideographs into the longest dictionary words — 分享 is one
    token, never 分 + 享. Without a dictionary the ideographs stay separate.
    """
    tokens = [m.group(0).lower() for m in _WORD_RE.finditer(text or "")]
    if words and _is_chinese(lang):
        tokens = _segment_hanzi(tokens, words)
    return tokens


# ------------------------------------------------------------------ #
# StarDict — a minimal read-only reader                              #
# ------------------------------------------------------------------ #
class StarDict:
    """Read-only StarDict (.ifo/.idx/.dict[.dz]) dictionary.

    Enough of the format to look a word up: load the .idx (word\\0 + 32-bit
    big-endian offset + size) and slice the .dict (or gunzip the .dict.dz).
    64-bit idx offsets and per-entry type headers beyond a single text block
    are not needed for the bilingual gloss dicts the operator uses, so they
    are intentionally unsupported.
    """

    def __init__(self, ifo_path: str | Path):
        self.ifo = Path(ifo_path).expanduser()
        self.name = self.ifo.stem
        self._index: dict[str, tuple[int, int]] | None = None
        self._dict_bytes: bytes | None = None

    def _sibling(self, ext: str) -> Path:
        # with_name (not with_suffix) so multi-dot ".dict.dz" is valid.
        return self.ifo.with_name(self.ifo.stem + ext)

    def _load(self) -> None:
        if self._index is not None:
            return
        # FreeDict — the most likely source of a dictionary here — ships the
        # index gzipped as `.idx.gz`, and StarDict's own spec allows it. Reading
        # only `.idx` made every FreeDict package fail at load with a
        # FileNotFoundError that surfaced as "dictionary unusable", which reads
        # like a corrupt download rather than an unhandled variant.
        index: dict[str, tuple[int, int]] = {}
        idx_path = self._sibling(".idx")
        if idx_path.exists():
            raw = idx_path.read_bytes()
        else:
            gz = self._sibling(".idx.gz")
            if not gz.exists():
                raise FileNotFoundError(
                    f"no .idx or .idx.gz beside {self.ifo}")
            raw = gzip.decompress(gz.read_bytes())
        i, n = 0, len(raw)
        while i < n:
            j = raw.find(b"\x00", i)
            if j < 0 or j + 9 > n:
                break
            word = raw[i:j].decode("utf-8", "replace")
            offset, size = struct.unpack(">II", raw[j + 1:j + 9])
            index.setdefault(word, (offset, size))
            key = word.lower()
            if key != word:
                index.setdefault(key, (offset, size))
            i = j + 9
        self._index = index
        dz = self._sibling(".dict.dz")
        if dz.exists():
            self._dict_bytes = gzip.decompress(dz.read_bytes())
        else:
            self._dict_bytes = self._sibling(".dict").read_bytes()

    def _entry(self, word: str) -> str | None:
        try:
            self._load()
        except Exception as e:  # a broken/absent dict must never crash a read
            log.warning("stardict %s unusable: %s", self.ifo, e)
            return None
        assert self._index is not None and self._dict_bytes is not None
        hit = self._index.get(word) or self._index.get(word.lower())
        if hit is None:
            return None
        offset, size = hit
        return self._dict_bytes[offset:offset + size].decode("utf-8", "replace").strip()

    def entry(self, word: str) -> str | None:
        """The full definition, with its structure intact.

        A dictionary entry is the reason to consult a dictionary: part of
        speech, numbered senses, usage notes, examples. `lookup()` below
        collapses all of that onto one line, which is right for a one-line
        gloss and throws away most of what was looked up. Markup becomes
        newlines rather than spaces so senses stay separated.
        """
        text = self._entry(word)
        if text is None:
            return None
        # Block-level markup becomes a line break; inline markup disappears.
        text = re.sub(r"(?i)<\s*/?\s*(br|div|p|li|tr)\s*/?>", "\n", text)
        text = re.sub(r"<[^>]+>", "", text)
        text = html_mod.unescape(text)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n\s*\n+", "\n", text)
        return "\n".join(ln.strip() for ln in text.splitlines() if ln.strip()) or None

    def lookup(self, word: str) -> str | None:
        """One-line gloss. Kept for callers that want exactly that."""
        text = self.entry(word)
        if text is None:
            return None
        return re.sub(r"\s+", " ", text).strip() or None


class DictdDict:
    """dictd format — a `.index` plus a `.dict` / `.dict.dz`.

    Worth supporting because it is what most downloadable dictionaries actually
    are. FreeDict publishes every pair in dictd form (and only some in
    StarDict), the `dictd`/`dict-*` packages in every distro's repos ship it,
    and GoldenDict reads it — so "install a dictionary" lands on this format far
    more often than on StarDict.

    The index is plain text, one entry per line:

        headword <TAB> offset <TAB> length

    where offset and length are base64 **digits**, most-significant first, over
    the alphabet A-Za-z0-9+/ — a positional number, not a byte encoding, so
    `base64.b64decode` is the wrong tool and silently returns nonsense. The
    `.dict` is the same concatenated-definitions blob StarDict uses.
    """

    _B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    _B64_INDEX = {c: i for i, c in enumerate(_B64)}

    def __init__(self, index_path: str | Path):
        self.index_path = Path(index_path).expanduser()
        self.name = self.index_path.stem
        self._index: dict[str, tuple[int, int]] | None = None
        self._dict_bytes: bytes | None = None

    @classmethod
    def _num(cls, token: str) -> int:
        n = 0
        for ch in token:
            n = n * 64 + cls._B64_INDEX[ch]
        return n

    def _load(self) -> None:
        if self._index is not None:
            return
        index: dict[str, tuple[int, int]] = {}
        raw = self.index_path.read_bytes()
        if self.index_path.suffix == ".gz":
            raw = gzip.decompress(raw)
        for line in raw.decode("utf-8", "replace").splitlines():
            parts = line.split("\t")
            if len(parts) < 3:
                continue
            word, off, length = parts[0], parts[1], parts[2]
            try:
                pair = (self._num(off), self._num(length))
            except KeyError:      # a stray line is not a reason to lose the file
                continue
            index.setdefault(word, pair)
            key = word.lower()
            if key != word:
                index.setdefault(key, pair)
        self._index = index

        stem = self.index_path.name
        for suffix in (".index.gz", ".index"):
            if stem.endswith(suffix):
                stem = stem[: -len(suffix)]
                break
        base = self.index_path.with_name(stem)
        dz = base.with_name(base.name + ".dict.dz")
        plain = base.with_name(base.name + ".dict")
        if dz.exists():
            self._dict_bytes = gzip.decompress(dz.read_bytes())
        else:
            self._dict_bytes = plain.read_bytes()

    def entry(self, word: str) -> str | None:
        try:
            self._load()
        except Exception as e:  # noqa: BLE001 — a broken dict must not kill a read
            log.warning("dictd %s unusable: %s", self.index_path, e)
            return None
        assert self._index is not None and self._dict_bytes is not None
        hit = self._index.get(word) or self._index.get(word.lower())
        if hit is None:
            return None
        offset, size = hit
        text = self._dict_bytes[offset:offset + size].decode("utf-8", "replace")
        text = re.sub(r"[ \t]+", " ", text)
        return "\n".join(ln.strip() for ln in text.splitlines() if ln.strip()) or None

    def lookup(self, word: str) -> str | None:
        text = self.entry(word)
        return re.sub(r"\s+", " ", text).strip() if text else None


class CedictDict:
    """CC-CEDICT — the standard free Chinese-English dictionary.

    A single UTF-8 text file, one entry per line:

        傳統 传统 [chuan2 tong3] /tradition/traditional/convention/

    Traditional first, then simplified, then space-separated pinyin with tone
    digits, then senses between slashes. Supported as its own format because it
    is what "install a Chinese dictionary" actually means — FreeDict has no
    zho-eng at all, and CC-CEDICT is both larger and better maintained than the
    StarDict conversions floating around.

    **Both scripts index the same entry.** A reader hovering 传统 in a simplified
    text and 傳統 in a traditional one must get the same answer; indexing only
    the headword as written would silently miss half the language.

    Licence and provenance, because both constrain how this may be used:
    CC-CEDICT is **CC BY-SA 4.0** — free for any purpose *provided the source is
    attributed*, and any improvements are shared under the same terms. The file
    comes from MDBG's published export at
    https://www.mdbg.net/chinese/dictionary?page=cc-cedict.

    MDBG offers **no API and no proxy**, and its site prohibits scraping. The
    bulk download is the supported route and carries the same data the site
    serves, so there is nothing to gain by reaching for the website — and doing
    so would break their terms. Refresh by re-downloading the export.
    """

    ATTRIBUTION = ("CC-CEDICT, CC BY-SA 4.0, via MDBG "
                   "(https://www.mdbg.net/chinese/dictionary?page=cc-cedict)")

    _LINE = re.compile(r"^(\S+)\s+(\S+)\s+\[([^\]]*)\]\s+/(.*)/\s*$")

    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser()
        self.name = "CC-CEDICT"
        self._index: dict[str, list[tuple[str, str]]] | None = None

    def _load(self) -> None:
        if self._index is not None:
            return
        index: dict[str, list[tuple[str, str]]] = {}
        raw = self.path.read_bytes()
        if self.path.suffix == ".gz":
            raw = gzip.decompress(raw)
        for line in raw.decode("utf-8", "replace").splitlines():
            if not line or line.startswith("#"):
                continue
            m = self._LINE.match(line)
            if not m:
                continue
            trad, simp, pinyin, senses = m.groups()
            record = (pinyin, senses)
            for key in {trad, simp}:
                index.setdefault(key, []).append(record)
        self._index = index

    def entry(self, word: str) -> str | None:
        try:
            self._load()
        except Exception as e:  # noqa: BLE001
            log.warning("cedict %s unusable: %s", self.path, e)
            return None
        assert self._index is not None
        hits = self._index.get(word)
        if not hits:
            return None
        # A character often has several readings with different meanings; each
        # gets its own line rather than being run together, because "which
        # pronunciation is this" is usually the question being asked.
        out = []
        for pinyin, senses in hits[:6]:
            parts = [s.strip() for s in senses.split("/") if s.strip()]
            out.append(f"[{pinyin}] " + "; ".join(parts))
        return "\n".join(out) or None

    def lookup(self, word: str) -> str | None:
        text = self.entry(word)
        return re.sub(r"\s+", " ", text).strip() if text else None

    def words(self) -> set[str]:
        """Every headword (both scripts), for the forward-max-match segmenter."""
        try:
            self._load()
        except Exception as e:  # noqa: BLE001 — a broken dict must not crash coverage
            log.warning("cedict %s unusable: %s", self.path, e)
            return set()
        assert self._index is not None
        return set(self._index.keys())

    def reading(self, word: str) -> str:
        """The pinyin (tone-numbered) for `word`, or "" when absent. CC-CEDICT is
        the only dictionary format here that carries a clean reading, so the
        other readers simply have no `reading` method at all."""
        try:
            self._load()
        except Exception as e:  # noqa: BLE001
            log.warning("cedict %s unusable: %s", self.path, e)
            return ""
        assert self._index is not None
        hits = self._index.get(word)
        return hits[0][0] if hits else ""


def open_dictionary(path: str | Path):
    """A reader for `path`, chosen by what the file actually is.

    One entry point so a configured dictionary can be any supported format and
    the provider above does not have to care which.
    """
    p = Path(path).expanduser()
    name = p.name
    if name.endswith((".u8", ".u8.gz")) or name.startswith("cedict"):
        if not p.exists():
            raise VaultDictError(f"no dictionary at {p}")
        return CedictDict(p)
    if name.endswith((".index", ".index.gz", ".ifo")):
        # Existence is checked HERE, not deferred to the first lookup. A
        # mistyped path used to construct fine and then return None for every
        # word, which is indistinguishable from a dictionary that simply does
        # not contain them — so a typo looked like poor coverage and the
        # cascade quietly paid for an LLM call instead.
        if not p.exists():
            raise VaultDictError(f"no dictionary at {p}")
        return DictdDict(p) if not name.endswith(".ifo") else StarDict(p)
    # No recognised extension: prefer a sibling that IS recognised, so pointing
    # at a directory-ish path or a bare stem still resolves rather than failing
    # with "unusable" much later, at lookup time.
    for cand in (p.with_suffix(".ifo"), p.with_suffix(".index")):
        if cand.exists():
            return open_dictionary(cand)
    raise VaultDictError(
        f"unrecognised dictionary: {p}. Point `path` at a StarDict .ifo or a "
        "dictd .index (.gz accepted).")


class VaultDictError(ValueError):
    pass


_STARDICTS: dict[str, object] = {}


def _stardicts_for(cfg, src: str) -> list[StarDict]:
    """Every configured dictionary matching the source language, in order.

    All of them, not the first. Bilingual dictionaries disagree about coverage
    far more than they disagree about meaning — a word absent from one is
    routinely present in the next — so stopping at the first configured
    dictionary turned a miss in that one file into a miss overall, and the
    cascade then paid for an LLM call to answer something a dictionary on disk
    already knew.
    """
    out: list[StarDict] = []
    entries = getattr(cfg.translate, "stardict", None) or []
    src_l = base_lang(src)
    for entry in entries:
        if not isinstance(entry, dict) or not entry.get("path"):
            continue
        # base_lang, not split("-")[0]: an ISO 639-3 tag ("deu", "ara", "fra")
        # must be seen as its base ("de", "ar", "fr") or a dictionary tagged
        # with the code that matches its directory is silently skipped and the
        # lookup falls through to the LLM. Both folds also converge subtags.
        lang = base_lang(str(entry.get("lang", "")))
        # An entry with a lang that doesn't match the (known) source is skipped;
        # a lang-less entry, or a "" source, matches anything. A skipped entry
        # warns rather than vanishing — a mistagged dictionary must announce
        # itself, not look like "no entry for this word".
        if lang and src_l and lang != src_l:
            log.warning("stardict %s tagged %s does not match source %s; skipped",
                        entry.get("path"), lang, src_l)
            continue
        path = entry["path"]
        sd = _STARDICTS.get(path)
        if sd is None:
            try:
                sd = _STARDICTS[path] = open_dictionary(path)
            except Exception as e:      # noqa: BLE001 — one bad entry, not the lot
                log.warning("dictionary %s unusable: %s", path, e)
                continue
        if entry.get("name"):
            sd.name = str(entry["name"])
        # The language this dictionary is FOR. Needed when the caller does not
        # know the source language: lemmatisation is per-language, so an
        # unknown source otherwise degrades to surface-form-only lookups.
        sd.lang = lang
        out.append(sd)
    return out


# Characters that belong to ONE language among the dictionaries this vault
# configures. Not a language identifier — a cheap narrowing hint, used only to
# decide which dictionary is worth lemmatising for.
#
# Deliberately conservative: only marks that are unambiguous *within this set*.
# ä/ö/ü are shared by German and Hungarian and are therefore absent; ő and ű
# are Hungarian alone, ß is German alone. A character that would name two
# languages names neither, and the word simply skips lemmatisation as before.
_LANG_MARKS = {
    # Shared marks are listed on every language that uses them, so a character
    # narrows to a FEW languages rather than one. `kutyát` carries only á,
    # which is Hungarian, Spanish, Portuguese and French — four lemmatisations
    # at 0.07ms each once warm, against thirteen at 5.5s. Narrowing to one was
    # too strict and lost that word; narrowing to none is the whole 13.
    "hu": "őűŐŰáéíóúöüÁÉÍÓÚÖÜ",
    "de": "ßẞäöüÄÖÜ",
    "es": "ñÑ¿¡áéíóúÁÉÍÓÚ",
    "fr": "œŒçÇàâèêëîïôùûüÀÂÈÊÎÔÙÛ",
    "pt": "ãõÃÕáéíóúâêôçÁÉÍÓÚÂÊÔÇ",
    "it": "àèéìòùÀÈÉÌÒÙ",
    "tr": "ığİŞıĞ",
    "ru": "бгджзийлптфцчшщъыьэюяБГДЖЗИЙЛПТФЦЧШЩЪЫЬЭЮЯ",
    "ar": "ابتثجحخدذرزسشصضطظعغفقكلمنهوي",
    "zh": "",       # CJK is handled by script detection upstream
    "ja": "ぁ-ゟ゠-ヿ",
}


def likely_langs(word: str, available: list[str]) -> list[str]:
    """Which of `available` this word plausibly belongs to, from its characters.

    Returns [] when there is no distinctive evidence — meaning "do not guess",
    not "no match". The caller then behaves exactly as it did before, so a word
    with nothing to go on cannot get worse.

    This exists because lemmatisation needs a language and single-word
    detection is otherwise unreliable: `Bahnhof` and `kutya` have no diacritics
    at all. Those resolve by exact match anyway. The words that NEED
    lemmatisation are inflected, and inflected forms in these languages
    routinely carry exactly the marks above — `lehetőséget` carries ő, which is
    Hungarian and nothing else here.
    """
    w = str(word or "")
    if not w:
        return []
    out = []
    for lang in available:
        marks = _LANG_MARKS.get((lang or "").lower().split("-")[0])
        if not marks:
            continue
        if any(ch in w for ch in marks):
            out.append(lang)
    return out


def warm_stardicts(cfg) -> int:
    """Open every configured dictionary now, so the first lookup is not slow.

    Opening 13 FreeDict files is well over the provider's 4-second budget, so
    the FIRST word a reader clicked timed out and fell through to Google —
    and the second, on a warm cache, hit the dictionary. Same word, different
    answer, depending on nothing the reader can see. The log showed 31 such
    timeouts.

    That is the real reason dictionary quality felt inconsistent across
    languages: not that German and Hungarian were unsupported, but that
    whichever language was clicked first paid the cold start and lost.

    Returns how many opened. Safe to call repeatedly — `_STARDICTS` is the
    cache, so a second call is free.
    """
    opened = 0
    for entry in (getattr(cfg.translate, "stardict", None) or []):
        if not isinstance(entry, dict) or not entry.get("path"):
            continue
        path = entry["path"]
        if path in _STARDICTS:
            continue
        lang = base_lang(str(entry.get("lang", "")))
        try:
            sd = _STARDICTS[path] = open_dictionary(path)
            # Actually LOAD it, not just open it. open_dictionary() builds the
            # object; the index parse and the gzip decompression of the .dict.dz
            # are lazy, on first lookup. Opening alone therefore warmed nothing —
            # measured, an exact MISS across 13 dictionaries still cost 5.2s
            # (~400ms each) while a hit on an already-loaded one cost 0.1ms.
            # A throwaway lookup forces the load.
            sd.entry("\u0000warm")
            # And the LEMMATISER for that dictionary's language. simplemma
            # loads its model per language on first use — measured 375ms — so
            # a lookup that needs inflected forms across 13 languages spent
            # ~5s loading models and lost the 4s budget to Google. An
            # inflected Hungarian word therefore resolved through a machine
            # translation while its dictionary headword sat on disk.
            if lang:
                try:
                    # A non-ASCII probe: an all-ASCII word can short-circuit
                    # before simplemma is touched, leaving the model unloaded
                    # and the first real lookup paying ~700ms inside the
                    # provider's budget. Measured: after warming with "warm",
                    # variants(de) still cost 698ms.
                    list(word_variants("wärmen", lang))
                except Exception:       # a language simplemma lacks is fine
                    pass
            opened += 1
        except Exception as e:      # noqa: BLE001 — one bad file, not the lot
            log.warning("dictionary %s unusable: %s", path, e)
    return opened


def _stardict_for(cfg, src: str) -> StarDict | None:
    """First matching dictionary. Retained for callers wanting just one."""
    found = _stardicts_for(cfg, src)
    return found[0] if found else None


# ------------------------------------------------------------------ #
# providers                                                           #
# ------------------------------------------------------------------ #
class LocalAIProvider:
    """The LM Studio model — an on-device translator, but not the default
    first hit for passages (see the module docstring): a general LLM is
    heavier per block than a dedicated MT engine and doesn't parallelize
    across concurrent requests the way network calls to google do. Still the
    right default for single-word lookups (word_order), where a few hundred
    ms of LLM latency is cheap and context-aware glossing is worth it, and
    the natural fallback when the network's unreachable."""

    name = "local_ai"

    def available(self, cfg) -> bool:
        return True  # cheapest to just try; a down LM Studio raises and we fall through

    async def alive(self, cfg) -> bool:
        """Whether a model is actually resident. `available()` above is
        unconditionally True, which is right for the cascade (trying is cheap)
        and useless for a status report — on 2026-08-25 it claimed local_ai was
        available while LM Studio held no model and, with just-in-time loading
        off, never would.

        This only ever LISTS what is loaded. Nothing in this vault may load a
        model to answer a status call, so a probe that could trigger one would
        be worse than no probe at all.
        """
        return bool(await llm.loaded_model_ids())

    async def translate(self, texts, src, tgt, cfg):
        blocks = [t for t in texts if t and t.strip()]
        if not blocks:
            return [None] * len(texts)
        numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(texts))
        system = (
            "You are a professional translator. Translate each numbered "
            f"segment from {lang_name(src)} into {lang_name(tgt)}. Keep the "
            "translation natural and faithful; do not add notes or explanations. "
            "Preserve the segment order and count exactly. Return JSON."
        )
        schema = {
            "type": "object",
            "properties": {"translations": {"type": "array", "items": {"type": "string"}}},
            "required": ["translations"],
        }
        out = await llm.chat(system, numbered, temperature=0.2, json_schema=schema)
        data = json.loads(out)
        result = data.get("translations", [])
        # Line the model's output back up with the input length.
        return [(result[i] if i < len(result) else None) for i in range(len(texts))]

    async def word(self, word, src, tgt, context, cfg):
        system = (
            f"You are a bilingual dictionary. The word is in {lang_name(src)}; "
            f"give its {lang_name(tgt)} meaning. Return JSON with a short "
            "`gloss` (the translation, a few words at most) and, when the "
            "source script needs it, a `reading` (romanization/pronunciation, "
            "else empty)."
        )
        user = f"Word: {word}"
        if context:
            user += f"\nSentence it appears in: {context}"
        schema = {
            "type": "object",
            "properties": {"gloss": {"type": "string"}, "reading": {"type": "string"}},
            "required": ["gloss"],
        }
        out = await llm.chat(system, user, temperature=0.2, json_schema=schema)
        data = json.loads(out)
        gloss = (data.get("gloss") or "").strip()
        if not gloss:
            return None
        return {"gloss": gloss, "reading": (data.get("reading") or "").strip()}


try:  # optional; the suffix table below is the backstop when it is absent
    import simplemma  # type: ignore
    _HAS_SIMPLEMMA = True
except Exception:  # pragma: no cover - depends on environment
    simplemma = None
    _HAS_SIMPLEMMA = False

# Languages simplemma refuses, cached so a CJK reader does not pay a raised
# ValueError per word. It raises rather than returning the input for anything
# outside its 54 languages, and an unguarded call took `zh/好` from a full
# entry to an exception — the same shape as the length-guard regression below.
_NO_LEMMA: set[str] = set()


def _lemma(word: str, lang: str) -> str:
    """simplemma's lemma, or "" — never raises, never returns the input.

    Real lemma data beats the hand-written suffix table and is checked first:
    `de/gingen` lemmatises to **gehen**, the infinitive the dictionary actually
    lists, where suffix-stripping only reaches `ging`. The table stays as the
    fallback for the languages simplemma does not cover (here: ar, ku).
    """
    code = (lang or "").lower()[:2]
    if not _HAS_SIMPLEMMA or not code or code in _NO_LEMMA:
        return ""
    try:
        out = simplemma.lemmatize(word, lang=code)
    except ValueError:      # unsupported language — ask once, never again
        _NO_LEMMA.add(code)
        return ""
    except Exception:
        return ""
    return out if out and out != word else ""


# Inflectional endings, longest first, per source language. Not morphology —
# a deliberately blunt list, because the only candidates that survive are ones
# the dictionary itself confirms. A wrong strip produces a word that is not in
# the dictionary and is discarded; it cannot invent a definition.
_SUFFIXES: dict[str, tuple[str, ...]] = {
    "en": ("'s", "ies", "es", "ing", "ed", "er", "est", "ly", "s"),
    "fr": ("eaux", "aux", "es", "e", "s"),
    "es": ("ciones", "iones", "es", "as", "os", "a", "o", "s"),
    "pt": ("ções", "ões", "ães", "es", "as", "os", "s"),
    "it": ("zioni", "i", "e", "o", "a"),
    "de": ("innen", "chen", "lein", "ern", "en", "er", "es", "em", "e", "n", "s"),
    "nl": ("en", "es", "s", "e"),
    "ru": ("ями", "ами", "ов", "ей", "ий", "ая", "ое", "ые", "ам", "ах", "и", "ы", "а", "у", "е", "о", "я"),
    "hu": ("éval", "ével", "évé", "vá", "vé", "ban", "ben", "nak", "nek", "hoz", "hez",
           "ból", "ből", "ról", "ről", "tól", "től", "val", "vel", "ra", "re", "ba", "be",
           "on", "en", "ön", "at", "et", "ot", "öt", "ak", "ek", "ok", "ök", "k", "t", "a", "e"),
    "tr": ("lerinde", "larında", "ler", "lar", "in", "ın", "un", "ün", "de", "da", "te", "ta", "i", "ı"),
    "la": ("orum", "arum", "ibus", "is", "em", "um", "os", "as", "ae", "i", "o", "a", "e"),
}


def word_variants(word: str, lang: str) -> list[str]:
    """Candidate dictionary keys for a surface form, best first.

    The exact form always comes first, so a word that resolves today resolves
    identically — the rest of the ladder is only ever reached on a miss.

    This exists because StarDict matches surface forms only, which quietly
    fails across every inflected language: measured 2026-08-09, `fr/maisons`
    (a regular plural) returned nothing while `fr/maison` returned a full
    entry, and the same for `de/gingen`, `hu/életkérdésévé`.
    """
    w = (word or "").strip()
    if not w:
        return []
    out: list[str] = []

    def add(cand: str) -> None:
        # No minimum length. An earlier version required 2+ characters and
        # silently dropped every single-character CJK word — `zh/好` went from
        # a full entry to nothing, caught only because the control set kept a
        # working language in it. Derived candidates carry their own length
        # guard in the suffix loop below; the surface form needs none.
        if cand and cand not in out:
            out.append(cand)

    add(w)
    add(w.lower())
    # German capitalises nouns; a mid-sentence lowercase hit still wants the
    # noun entry, and vice versa.
    add(w.capitalize())
    # Real lemma data before the hand-written table — it is right more often
    # and reaches forms stripping cannot (gingen -> gehen, not ging).
    lem = _lemma(w, lang)
    if lem:
        add(lem)
        add(lem.capitalize())
    low = w.lower()
    for suf in _SUFFIXES.get((lang or "").lower()[:2], ()):
        if low.endswith(suf) and len(low) - len(suf) >= 3:
            stem = low[: -len(suf)]
            add(stem)
            # Doubled final consonant (running -> run) and restored -e
            # (maisons -> maison handled above; gingen -> ging -> gehen is not
            # reachable this way and is left to the dictionary's own forms).
            if len(stem) >= 4 and stem[-1] == stem[-2]:
                add(stem[:-1])
            add(stem + "e")
    return out


def split_compound(word: str, in_dict, min_part: int = 3):
    """Split a compound into two parts the dictionary knows, or None.

    Hungarian and German build words the dictionary will never list —
    `életkérdés` is `élet` + `kérdés`, and both halves are present. The split
    is only accepted when **every** part is confirmed by the dictionary, so a
    coincidental split cannot produce a bogus gloss. Longest first part wins,
    which keeps `élet|kérdés` over a shorter accidental prefix.
    """
    w = (word or "").lower()
    if len(w) < min_part * 2:
        return None
    for i in range(len(w) - min_part, min_part - 1, -1):
        a, b = w[:i], w[i:]
        if in_dict(a) and in_dict(b):
            return (a, b)
        # Linking -s (German Fugen-s): Arbeitszeit -> Arbeit + zeit.
        if a.endswith("s") and len(a) - 1 >= min_part and in_dict(a[:-1]) and in_dict(b):
            return (a[:-1], b)
    return None


class StarDictProvider:
    """Offline dictionaries. Word-level only (declines whole passages so the
    cascade moves on to a real translator for those)."""

    name = "stardict"
    # Words only — see translate() below. Read by PASSAGE_CAPABLE so
    # /translate/status cannot count a dictionary toward passage readiness.
    passage_capable = False

    def available(self, cfg) -> bool:
        return bool(getattr(cfg.translate, "stardict", None))

    async def translate(self, texts, src, tgt, cfg):
        # Glossing prose word-by-word is more confusing than helpful; a
        # dictionary declines passages and shines on single words.
        return None

    async def word(self, word, src, tgt, context, cfg):
        dicts = _stardicts_for(cfg, src)
        if not dicts:
            return None

        def _entries_for(key):
            out = []
            for sd in dicts:
                entry = sd.entry(key)
                if entry:
                    out.append({"dict": sd.name, "text": entry,
                                "lang": getattr(sd, "lang", "") or ""})
            return out

        def _lookup():
            # 1. The surface form in every dictionary first — exact matches are
            #    the common case and must stay as fast as they were.
            hits = _entries_for(word)
            if hits:
                return word, hits, None
            # 2. Then inflected forms — but ONLY with a known source language.
            #
            #    Lemmatising for an unknown source was tried and reverted. It
            #    meant running word_variants() once per configured dictionary
            #    language, and simplemma loads a model per language on first
            #    use: measured 5,527ms of lemmatisation against 0.3ms of actual
            #    dictionary lookups, which blew the 4s provider budget and sent
            #    the word to Google — the very outcome it was meant to avoid.
            #
            #    Exact matching across every dictionary stays (it is what finds
            #    Oroszország in hun-eng and Bahnhof in deu-eng without being
            #    told the language, and costs 0.3ms warm). An inflected word in
            #    an unknown language falls through to the network, which
            #    answers it correctly. The way to get lemmatisation is to know
            #    the language — which the reader's note usually does.
            if src:
                for cand in word_variants(word, src):
                    hits = _entries_for(cand)
                    if hits:
                        return cand, hits, None
            else:
                # No source given: lemmatise only for a language the word's own
                # characters point at, and only in that language's dictionary.
                # One language costs 0.07ms warm; all thirteen cost 5,527ms,
                # which is what the earlier attempt did.
                langs = likely_langs(word, [getattr(sd, "lang", "") for sd in dicts])
                for sd in dicts:
                    lang = getattr(sd, "lang", "") or ""
                    if lang not in langs:
                        continue
                    for cand in word_variants(word, lang):
                        entry = sd.entry(cand)
                        if entry:
                            return cand, [{"dict": sd.name, "text": entry,
                                           "lang": getattr(sd, "lang", "") or ""}], None
            # 2. Still nothing: try to split a compound the dictionary will
            #    never list as one word. Only accepted when every part is
            #    confirmed, so this cannot fabricate a meaning.
            def in_dict(k):
                return bool(_entries_for(k))
            # Over every candidate, not just the surface form: an agglutinative
            # word is usually inflected AND compound at once. `életkérdésévé`
            # only resolves as strip("évé") -> `életkérdés` -> `élet`+`kérdés`,
            # so splitting the raw input alone finds nothing.
            for cand in (word_variants(word, src) if src else [word]):
                parts = split_compound(cand, in_dict)
                if parts:
                    return None, None, [(p, _entries_for(p)) for p in parts]
            return None, None, None

        matched, entries, parts = await asyncio.to_thread(_lookup)

        if parts:
            # A compound reads best as its pieces, each with its own gloss —
            # that is what the reader needs to see to learn the word.
            joined = " + ".join(p for p, _ in parts)
            gloss = "  ·  ".join(
                p + ": " + re.sub(r"\s+", " ", e[0]["text"]).strip()[:120]
                for p, e in parts if e)
            return {"gloss": gloss, "reading": "", "definition": gloss,
                    "matched": joined, "compound": [p for p, _ in parts],
                    "entries": [e for _, es in parts for e in es]}

        if not entries:
            return None
        # `gloss` stays a single line so every existing caller keeps working;
        # `entries` carries the full definitions for a reader that wants them.
        # `matched` names the form that actually hit, so a reader who clicked
        # "maisons" can see the entry is for "maison".
        first = entries[0]["text"]
        return {"gloss": re.sub(r"\s+", " ", first).strip(),
                "reading": "",
                "definition": first,
                "matched": matched,
                # WHICH dictionary answered. With no source language the lookup
                # searches every dictionary, and the one that hits is the best
                # evidence of the word's language there is — better than any
                # sniffing, because it is an actual match rather than a guess.
                # The reader's audio needs this: without it a Hungarian word
                # falls back to the target language and gets an English voice.
                "lang": entries[0].get("lang", "") if entries else "",
                "entries": entries}


class DeepLProvider:
    """DeepL API — the network fallback (needs `translate.deepl_api_key`)."""

    name = "deepl"

    def available(self, cfg) -> bool:
        return bool(getattr(cfg.translate, "deepl_api_key", ""))

    def _endpoint(self, cfg) -> str:
        free = getattr(cfg.translate, "deepl_free", True)
        host = "api-free.deepl.com" if free else "api.deepl.com"
        return f"https://{host}/v2/translate"

    async def _call(self, texts, src, tgt, cfg):
        key = cfg.translate.deepl_api_key
        data = [("text", t) for t in texts]
        data.append(("target_lang", (tgt or "EN").upper().split("-")[0]))
        if src:
            data.append(("source_lang", src.upper().split("-")[0]))
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(self._endpoint(cfg), data=data,
                                  headers={"Authorization": f"DeepL-Auth-Key {key}"})
            r.raise_for_status()
            return [t.get("text", "") for t in r.json().get("translations", [])]

    async def translate(self, texts, src, tgt, cfg):
        # Send only the non-empty blocks; map results back by position.
        idx = [i for i, t in enumerate(texts) if t and t.strip()]
        if not idx:
            return [None] * len(texts)
        got = await self._call([texts[i] for i in idx], src, tgt, cfg)
        out: list[str | None] = [None] * len(texts)
        for k, i in enumerate(idx):
            out[i] = got[k] if k < len(got) else None
        return out

    async def word(self, word, src, tgt, context, cfg):
        got = await self._call([word], src, tgt, cfg)
        gloss = (got[0] if got else "").strip()
        return {"gloss": gloss, "reading": ""} if gloss else None


class DeepLXProvider:
    """DeepL quality without a DeepL key, via a local DeepLX proxy.

    https://github.com/OwO-Network/DeepLX — a small self-hosted service that
    speaks to DeepL's free web endpoint and exposes it over plain HTTP. It is
    here because the honest state of this vault was that `deepl_api_key` is
    empty, so `DeepLProvider.available()` is False and DeepL never runs. The
    cascade therefore fell past the dictionary straight onto the LLM for every
    hover — which is both the slow path and the one that should be last.

    Endpoint (`POST {base}/translate`), per the project's API docs:
        request : {"text": str, "source_lang": str, "target_lang": str}
        response: {"code": 200, "data": "<translation>", "alternatives": [...]}

    `/v1/translate` needs a Pro `dl_session` and is deliberately not used.
    Nothing is sent anywhere unless the operator sets `deeplx_url`, so this
    stays off by default rather than quietly acquiring a network dependency.
    """

    name = "deeplx"

    # Negative cache, same shape and same rule as LibreTranslate's: armed ONLY
    # by a connection-level failure, keyed by the instance's URL.
    #
    # translate() below is one request per block, and it had no liveness gate
    # at all — this class has carried an `alive()` since 2026-08-25 and only
    # /translate/status ever called it. So with the container down, a single
    # caption track made one doomed TCP connection PER LINE: measured
    # 2026-08-29, 80 "All connection attempts failed" warnings in a 20-second
    # sample, each one spending the cascade's budget to rediscover a fact the
    # first line already established. One probe per window replaces all of it.
    _dead_until: dict[str, float] = {}
    _DEAD_FOR = 15.0

    def available(self, cfg) -> bool:
        return bool(getattr(cfg.translate, "deeplx_url", ""))

    @classmethod
    def _declining(cls, base: str) -> bool:
        return time.monotonic() < cls._dead_until.get(base, 0.0)

    @classmethod
    def declining_for(cls, base: str) -> float:
        """Seconds left on this instance's decline window, for /translate/status."""
        return max(0.0, cls._dead_until.get(base, 0.0) - time.monotonic())

    async def _call(self, text, src, tgt, cfg):
        base = str(cfg.translate.deeplx_url).rstrip("/")
        token = getattr(cfg.translate, "deeplx_token", "")
        body = {"text": text,
                "target_lang": (tgt or "EN").upper().split("-")[0]}
        if src:
            body["source_lang"] = src.upper().split("-")[0]
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(f"{base}/translate", json=body, headers=headers)
            r.raise_for_status()
            payload = r.json()
        # DeepLX answers 200-with-a-code, so an error can arrive inside a
        # successful HTTP response. Check the code, not just the status.
        if int(payload.get("code", 0)) != 200:
            log.warning("deeplx: code %s for %r", payload.get("code"), text[:40])
            return None, []
        return (payload.get("data") or "").strip(), list(payload.get("alternatives") or [])

    async def translate(self, texts, src, tgt, cfg):
        # One request per block: the free endpoint takes a single string, not a
        # list, so there is no batch to exploit here — which is exactly why a
        # dead endpoint has to be discovered ONCE and remembered, rather than
        # per line. See _dead_until.
        base = str(cfg.translate.deeplx_url).rstrip("/")
        if self._declining(base):
            return None
        out: list[str | None] = []
        for t in texts:
            if not t or not t.strip():
                out.append(None)
                continue
            try:
                got, _ = await self._call(t, src, tgt, cfg)
            except (httpx.ConnectError, httpx.ConnectTimeout) as e:
                # Nothing on the other end. Stop the walk here and remember it;
                # every remaining line would fail identically.
                type(self)._dead_until[base] = time.monotonic() + self._DEAD_FOR
                log.warning("deeplx unreachable at %s (%r); declining for %.0fs",
                            base, e, self._DEAD_FOR)
                return None
            except Exception as e:  # noqa: BLE001 — one block must not end the page
                log.warning("deeplx failed: %s", e)
                got = None
            out.append(got or None)
        return out

    async def word(self, word, src, tgt, context, cfg):
        gloss, alts = await self._call(word, src, tgt, cfg)
        if not gloss:
            return None
        # DeepL's alternatives are the closest thing this provider has to
        # multiple senses, and a word popup is exactly where they earn space.
        hit = {"gloss": gloss, "reading": ""}
        if alts:
            hit["alternatives"] = [a for a in alts if a and a != gloss][:5]
        return hit

    async def alive(self, cfg) -> bool:
        """Is anything actually on the other end of `deeplx_url`? A container
        that is not running is the exact failure this answers — on 2026-08-25
        `available()` said true (a URL is configured) while :1188 refused every
        connection, and status reported the vault ready to translate.

        Any HTTP response counts. The question is whether the proxy is up, not
        whether this particular path is one it likes.
        """
        base = str(cfg.translate.deeplx_url).rstrip("/")
        async with httpx.AsyncClient(timeout=2) as client:
            await client.get(base + "/")
            return True


def libretranslate_batches(texts: list[str], size: int) -> list[list[int]]:
    """Indices of the non-blank blocks, grouped into request-sized chunks.

    Pure so the chunking can be asserted offline — the failure it prevents is a
    TIMEOUT, which a live one-line test cannot reach and which reads as "the
    provider is broken" rather than "the batch was too big".

    Blank blocks are dropped rather than sent: they cost a segment of the batch
    and come back as empty strings that the caller would have to re-align
    anyway. Returning indices (not the strings) is what lets the caller put each
    translation back on the block it came from, which matters because the
    response array is only positionally meaningful against what was actually
    sent.
    """
    idx = [i for i, t in enumerate(texts) if t and t.strip()]
    n = max(1, int(size or 1))
    return [idx[i:i + n] for i in range(0, len(idx), n)]


class LibreTranslateProvider:
    """A self-hosted LibreTranslate instance — the local MT engine.

    https://github.com/LibreTranslate/LibreTranslate — Argos/OpenNMT models
    behind a small HTTP API, AGPLv3, no key and no internet at run time.

    It is here because of what took every passage surface down on 2026-08-25:
    the whole passage cascade was `deeplx, google, deepl, local_ai`, and all
    four were dead at once. Three of them are not the kind of dependency that
    fails *loudly* — `deeplx` is an unofficial reverse-engineered API, `google`
    is a scraped web endpoint that answered `302 -> /sorry/` once this IP was
    soft-banned, and `deepl` needs a key nobody had. This provider is the one
    that cannot rot that way, because we run it.

    Two properties earn it first place rather than merely a slot:

    · It is a **dedicated MT model**, so it honours the module docstring's rule
      that passages do not default to the LLM — measured at ~6x the local
      model's speed on a 12-paragraph note, and unlike the LLM it does not
      serialize every block onto one inference worker.
    · It is **local**, so it is the first head of `provider_order` for which
      "local-first" is literally true.

    Endpoint (`POST {base}/translate`), per the project's API docs:
        request : {"q": [str, ...], "source": str, "target": str, "format": "text"}
        response: {"translatedText": [str, ...]}

    `q` takes an ARRAY — a real batch, not a loop of single calls like
    DeepLXProvider and GoogleProvider are forced into. A whole caption track is
    a couple of round trips instead of hundreds. It is chunked anyway; see
    `libretranslate_batches`.

    Nothing is sent anywhere unless the operator sets `libretranslate_url`, so
    this stays off by default rather than quietly acquiring a dependency.
    """

    name = "libretranslate"

    # Concurrent callers queue here rather than hitting the instance in
    # parallel. The container runs gunicorn SYNC workers — one request at a
    # time each — and each translation itself grabs several CPU threads
    # (ARGOS_INTRA_THREADS=4 in the deployment), so TWO concurrent batches
    # pinned every core: the healthcheck queued behind busy workers and timed
    # out, the instance sat "up (unhealthy)" answering nothing, and every
    # translation surface in the vault read empty (2026-08-25, twice in an
    # afternoon). ONE permit serialises our share of the instance: throughput
    # barely moves — segments translate in ~0.12s each, near-linear either way
    # — while a hover word lookup never again queues behind a caption batch.
    _MAX_CONCURRENT = 1
    _gate: asyncio.Semaphore | None = None

    @classmethod
    def _sem(cls):
        if cls._gate is None:
            cls._gate = asyncio.Semaphore(cls._MAX_CONCURRENT)
        return cls._gate

    # Single-flight coalescing: identical concurrent calls SHARE one upstream
    # request instead of queueing behind it. Measured 2026-08-25: two Obsidian
    # instances (the operator's live session and an agent's driver instance)
    # walked the same caption track simultaneously; the second walk queued
    # behind the first inside the cascade's per-provider deadline, which counts
    # QUEUE WAIT, so it timed out and cancelled — while LibreTranslate kept
    # grinding the already-received batch. Abandoned batches piled up unread on
    # the sync worker faster than it could drain them: ~850% CPU, healthcheck
    # starved, every translation surface empty, no log line anywhere. Coalescing
    # removes the duplicate-load class entirely; the dead worker pattern has
    # not recurred since (verified across repeated double-instance walks).
    _inflight: dict | None = None
    _INFLIGHT_TTL = 120.0   # seconds a completed answer stays shared

    @classmethod
    def _key(cls, texts, src, tgt):
        return (src.lower(), tgt.lower(), tuple(texts))

    @classmethod
    def _flight(cls, key):
        """The PENDING attempt for `key`, or None.

        Entries are futures created by translate(); settled ones are removed
        by _flight_settle immediately — deduping is for CONCURRENT calls, not
        a result cache (a cache here would grow with every video watched and
        answer nothing new). The sweep below exists purely as a backstop for
        any future that somehow outlives its caller."""
        if cls._inflight is None:
            cls._inflight = {}
        now = time.monotonic()
        for k in list(cls._inflight):
            fut = cls._inflight[k]
            if fut.done() and now - getattr(fut, "_sl_ts", now) > cls._INFLIGHT_TTL:
                cls._inflight.pop(k, None)
        return cls._inflight.get(key)

    @classmethod
    def _flight_settle(cls, key, fut, value):
        """Release followers with `value`, then forget the flight."""
        if cls._inflight and cls._inflight.get(key) is fut:
            cls._inflight.pop(key, None)
        try:
            fut._sl_ts = time.monotonic()
        except Exception:  # noqa: BLE001 — bookkeeping must never raise
            pass
        if not fut.done():
            fut.set_result(value)

    # Negative cache for an instance that is genuinely NOT THERE, keyed by the
    # instance's own URL.
    #
    # This used to be a bare class float armed by a 2.0s timeout on a
    # `/languages` pre-flight, and it was the outage rather than the guard
    # against one. LibreTranslate runs gunicorn SYNC workers, so `/languages`
    # queues behind whatever translation is in flight — measured 2026-08-29,
    # six consecutive probes: 2.5s, 4ms, >6s, >6s, 0.38s, 4ms, while actual
    # translation answered every time in ~0.47s. The probe was less reliable
    # than the thing it gated, and each overrun blackholed the ONE working
    # provider for 15 seconds across the whole vault, sending every passage
    # down a cascade of four dead fallbacks to `{"provider": "", ...}`.
    #
    # So: slowness is not death. Only a connection-level failure — nothing
    # listening on the port — arms this now, because that is the failure the
    # cache was written for (a container that is not running) and it is the one
    # a timeout cannot be confused with. Per-URL because "which instance" is
    # part of the fact; a bare class attribute tarred a reconfigured endpoint
    # with the previous one's death.
    _dead_until: dict[str, float] = {}
    _DEAD_FOR = 15.0

    # How long to wait for OUR OWN semaphore before declining. The permit is
    # ours, not the instance's, so queue wait here is self-inflicted — and it
    # used to be charged to the caller's per-provider deadline, which is how a
    # timeout came to cancel a batch LibreTranslate had already started. The
    # abandoned batches then piled up on the sync worker faster than it could
    # drain them (~1000% CPU, healthcheck starved) — the same collapse the
    # single-flight comment above describes, reached by a different door, since
    # coalescing only ever deduped IDENTICAL calls. Declining before we start
    # is strictly better than starting work we are about to throw away.
    _QUEUE_WAIT = 3.0

    # The socket must never be the thing that gives up first.
    #
    # The client timeout was a FLAT 20s while `libretranslate_batch_size` is 50,
    # so a full batch got 0.4s per segment against a real cost of ~1.3s, and
    # every chunk of a real page died the same way:
    #
    #   libretranslate chunk of 20 failed: ReadTimeout('')
    #
    # A 247-paragraph article translated NOTHING while the same instance
    # answered a two-line request in 0.7s. That is the shape of the ledgered
    # "client-side timeout outlived the server-side budget it mirrored": two
    # numbers that must move together, held in different places, with nothing
    # tying them.
    #
    # So this does not carry a second per-segment estimate of its own. It reads
    # `passage_seconds_per_block` — the SAME figure the cascade sizes its
    # per-provider deadline from — and adds a margin, so the cascade's
    # `asyncio.wait_for` is always what cancels a slow provider. One number
    # governs both; re-measuring the engine changes one line, and the socket
    # cannot silently become the binding constraint again.
    #
    # Measured 2026-08-29 against real es.wikipedia paragraphs (mean 218 chars):
    #   1 para 0.29s | 5 paras 8.63s | 20 paras 25.58s  -> ~1.3s per paragraph
    _MIN_READ_TIMEOUT = 20.0
    _READ_MARGIN = 1.2

    @classmethod
    def _read_timeout(cls, cfg, n: int) -> float:
        per_block = getattr(cfg.translate, "passage_seconds_per_block", 1.5)
        return max(cls._MIN_READ_TIMEOUT,
                   max(0, int(n)) * float(per_block) * cls._READ_MARGIN)

    @classmethod
    def _declining(cls, base: str) -> bool:
        until = cls._dead_until.get(base, 0.0)
        return time.monotonic() < until

    @classmethod
    def _mark_dead(cls, base: str) -> None:
        cls._dead_until[base] = time.monotonic() + cls._DEAD_FOR

    @classmethod
    def declining_for(cls, base: str) -> float:
        """Seconds left on this instance's decline window, for /translate/status."""
        return max(0.0, cls._dead_until.get(base, 0.0) - time.monotonic())

    def available(self, cfg) -> bool:
        return bool(getattr(cfg.translate, "libretranslate_url", ""))

    # LibreTranslate's own spelling, where it differs from the vault's.
    #
    # Every external destination in this repo keeps its own mapping — Wikimedia
    # and Forvo want `zh`, Tatoeba and LinguaStudio want `cmn` — and this is
    # LibreTranslate's. It advertises Chinese as **zh-Hans** in `/languages`,
    # not `zh`.
    #
    # Bare `zh` does happen to work (measured 2026-08-25: `zh` and `zh-Hans`
    # both translate, in both directions), but that is an undocumented alias
    # and this table does not depend on it. Sending the code the service
    # actually advertises is what makes a later "is this language supported?"
    # check against `/languages` agree with what we send — a string compare
    # that would otherwise quietly answer no for the vault's most-read language.
    #
    # `zh-hant` is kept distinct rather than folded into Simplified: reducing it
    # would silently hand a Traditional reader Simplified output.
    #
    # Cantonese and Wu are NOT kept distinct, and that is the vault's decision
    # rather than this provider's: `base_lang` maps `yue`/`cmn`/`wuu` -> `zh`
    # (they are one language for dictionary and segmentation purposes, which is
    # what `isChineseLang` encodes), so they arrive here already folded and go
    # out as zh-Hans. LibreTranslate ships no Cantonese model, so the real
    # choice is approximate Chinese or nothing — and diverging from `base_lang`
    # here would make this the one place in the vault where `yue` is not
    # Chinese, which is a worse bug than an approximate translation.
    _CODES = {
        "zh": "zh-Hans",
        "zh-hans": "zh-Hans",
        "cmn": "zh-Hans",
        "zh-hant": "zh-Hant",
    }

    def _lang(self, code: str, *, source: bool) -> str:
        """A vault language code in LibreTranslate's spelling.

        "auto" is only ever a SOURCE — a blank target is English, because
        "translate into whatever you like" is not a request. `base_lang` is the
        vault's one right way to reduce a BCP-47 tag; never compare or slice a
        language code by hand here, which is the mistake that silently emptied
        three panels for weeks.

        The reverse direction needs nothing of its own: `base_lang("zh-Hans")`
        is already `"zh"`, so a code coming back from LibreTranslate (a
        `detectedLanguage`, say) reduces to the vault's spelling through the
        same helper every other caller uses. Asserted in the tests.
        """
        raw = (code or "").strip().lower()
        if not raw:
            return "auto" if source else "en"
        return self._CODES.get(raw) or self._CODES.get(base_lang(raw)) or base_lang(raw)

    async def _post(self, client, q: list[str], src: str, tgt: str, cfg) -> list[str | None]:
        base = str(cfg.translate.libretranslate_url).rstrip("/")
        body: dict = {
            "q": q,
            "source": self._lang(src, source=True),
            "target": self._lang(tgt, source=False),
            "format": "text",
        }
        key = getattr(cfg.translate, "libretranslate_api_key", "")
        if key:
            body["api_key"] = key
        r = await client.post(f"{base}/translate", json=body)
        r.raise_for_status()
        payload = r.json()
        got = payload.get("translatedText")
        # The API mirrors the request's shape: an array in, an array out — but a
        # single string comes back for a single-element `q` on some versions.
        # Normalising here keeps the alignment logic in one place instead of
        # making every caller guess which shape it received.
        if isinstance(got, str):
            got = [got]
        if not isinstance(got, list):
            return [None] * len(q)
        out = [(str(v).strip() or None) if v is not None else None for v in got]
        return out[:len(q)] + [None] * max(0, len(q) - len(out))

    async def translate(self, texts, src, tgt, cfg):
        # Identity translation declined in one step, before any provider. On
        # 2026-08-25 a resolver bug shipped es→es here: LibreTranslate answered
        # 400 to every chunk, and each request then ground through the whole
        # cascade's dead fallbacks (deeplx refused, google 429, local_ai's
        # 3s LM Studio wait) before reporting nothing. The resolver owns the
        # fix; this backstop keeps the mistake cheap wherever it reappears.
        if src and tgt and src.lower() == tgt.lower():
            return [None] * len(texts)

        # Single-flight: an identical concurrent call shares THIS attempt's
        # future instead of queueing a duplicate behind it. See _key above for
        # why the duplicate class had to die.
        key = self._key(texts, src, tgt)
        existing = self._flight(key)
        if existing is not None:
            return await existing
        fut = asyncio.get_running_loop().create_future()
        type(self)._inflight[key] = fut

        try:
            result = await self._translate_through_instance(texts, src, tgt, cfg)
        except BaseException:
            # Followers get None (their own cascade falls through normally);
            # a crashed or cancelled attempt is not shared as a failure.
            self._flight_settle(key, fut, None)
            raise
        self._flight_settle(key, fut, result)
        return result

    async def _translate_through_instance(self, texts, src, tgt, cfg):
        """The actual network work, behind the single-flight key."""

        size = getattr(cfg.translate, "libretranslate_batch_size", 50)
        batches = libretranslate_batches(list(texts), size)
        if not batches:
            return [None] * len(texts)

        base = str(cfg.translate.libretranslate_url).rstrip("/")
        # Still inside a decline window for THIS instance (see _dead_until):
        # nothing is listening on the port, so skip rather than spend the
        # provider's slot rediscovering that. The window is deliberately
        # SHORTER than the cascade budget so a container that comes back is
        # picked up promptly.
        if self._declining(base):
            return None

        # Wait for our own permit OUTSIDE the network work, and give up on it
        # rather than start a request the caller's deadline is about to cancel.
        # There is no pre-flight GET any more: the real POST is the probe, and
        # it is both cheaper and more honest than a /languages that shares the
        # instance's single worker with the work it is meant to be reporting on.
        sem = self._sem()
        try:
            await asyncio.wait_for(sem.acquire(), timeout=self._QUEUE_WAIT)
        except asyncio.TimeoutError:
            log.info("libretranslate busy; declining this pass rather than queueing into a cancel")
            return None

        out: list[str | None] = [None] * len(texts)
        try:
            # Sized to the largest chunk we are about to send, not to a constant.
            budget = self._read_timeout(cfg, max((len(g) for g in batches), default=0))
            async with httpx.AsyncClient(timeout=budget) as client:
                for group in batches:
                    try:
                        got = await self._post(client, [texts[i] for i in group], src, tgt, cfg)
                    except (httpx.ConnectError, httpx.ConnectTimeout) as e:
                        # Nothing is listening. THIS is the failure the negative
                        # cache exists for, and the only one it may be armed by
                        # — a slow instance is busy, not absent.
                        self._mark_dead(base)
                        log.warning("libretranslate unreachable at %s (%r); declining for %.0fs",
                                    base, e, self._DEAD_FOR)
                        break
                    except Exception as e:  # noqa: BLE001 — one chunk must not end the page
                        # %r, not %s: on 2026-08-25 five chunks logged "failed: "
                        # with nothing after it — str(e) was empty and the failure
                        # was unidentifiable from the log alone. repr() always
                        # names the exception class.
                        log.warning("libretranslate chunk of %d failed: %r", len(group), e)
                        continue
                    for slot, value in zip(group, got):
                        out[slot] = value
        finally:
            sem.release()
        # Nobody answering means the instance did not help — decline so the
        # cascade moves on rather than returning a page of Nones that a caller
        # checking only `provider` would read as success.
        return out if any(v for v in out) else None

    async def word(self, word, src, tgt, context, cfg):
        async with httpx.AsyncClient(timeout=20) as client:
            got = await self._post(client, [word], src, tgt, cfg)
        gloss = (got[0] or "").strip() if got else ""
        return {"gloss": gloss, "reading": ""} if gloss else None

    async def alive(self, cfg) -> bool:
        """`/languages` is the cheapest proof the models finished unpacking. A
        cold start serves the port for minutes before it can translate, so
        "something is listening" is not the question worth answering here."""
        base = str(cfg.translate.libretranslate_url).rstrip("/")
        async with httpx.AsyncClient(timeout=2) as client:
            r = await client.get(f"{base}/languages")
            r.raise_for_status()
            return bool(r.json())


class GoogleProvider:
    """Google Translate's free web endpoint — no key, every language the
    operator listed, and accurate enough for a reading pane. This is the same
    unauthenticated `translate_a/single` endpoint the `googletrans` library and
    LinguaStudio's translator use. It needs the network but no credentials, so
    it is the natural free fallback ahead of DeepL (which needs a key).

    Blocks are translated one request each (bounded concurrency) rather than
    batched: it keeps each translation aligned to its block exactly and avoids
    the endpoint merging or reordering across blocks.
    """

    name = "google"
    _ENDPOINT = "https://translate.googleapis.com/translate_a/single"
    _MAX_CONCURRENCY = 6

    def available(self, cfg) -> bool:
        # Enabled unless the operator drops it from an order; no key required.
        # Cheapest to just try — a blocked network raises and the cascade moves on.
        return bool(getattr(cfg.translate, "google_enabled", True))

    def _endpoint(self, cfg) -> str:
        """Where to post. Configurable since 2026-08-25, when Google soft-banned
        this IP and answered `302 -> www.google.com/sorry/` for every request,
        with no way to redirect the provider without editing this file.

        An alternative front-end (Lingva, Mozhi, SimplyTranslate) speaks the
        same translate_a/single shape and drops in here — but only when hosted
        somewhere else. They are scrapers, so an instance on this machine
        fetches Google from the same banned address and inherits the ban.
        """
        return str(getattr(cfg.translate, "google_endpoint", "") or self._ENDPOINT)

    def _params(self, src: str, tgt: str) -> dict:
        return {
            "client": "gtx",
            "sl": google_lang(src, source=True),
            "tl": google_lang(tgt, source=False),
            "dt": "t",
        }

    async def _call(self, client, text: str, src: str, tgt: str,
                    endpoint: str | None = None) -> str | None:
        r = await client.post(endpoint or self._ENDPOINT, params=self._params(src, tgt),
                              data={"q": text})
        r.raise_for_status()
        data = r.json()
        # data[0] is a list of [translatedChunk, originalChunk, ...] segments;
        # concatenate the translated chunks back into the block's translation.
        segments = data[0] if isinstance(data, list) and data else []
        out = "".join(seg[0] for seg in segments
                      if isinstance(seg, list) and seg and seg[0])
        return out or None

    async def translate(self, texts, src, tgt, cfg):
        idx = [i for i, t in enumerate(texts) if t and t.strip()]
        if not idx:
            return [None] * len(texts)
        out: list[str | None] = [None] * len(texts)
        sem = asyncio.Semaphore(self._MAX_CONCURRENCY)
        endpoint = self._endpoint(cfg)
        async with httpx.AsyncClient(timeout=20) as client:
            async def one(i: int):
                async with sem:
                    out[i] = await self._call(client, texts[i], src, tgt, endpoint)
            await asyncio.gather(*(one(i) for i in idx))
        # Nobody answering (every block None) means the endpoint didn't help —
        # decline so the cascade tries the next provider.
        return out if any(v for v in out) else None

    async def word(self, word, src, tgt, context, cfg):
        async with httpx.AsyncClient(timeout=20) as client:
            gloss = await self._call(client, word, src, tgt, self._endpoint(cfg))
        gloss = (gloss or "").strip()
        return {"gloss": gloss, "reading": ""} if gloss else None


# Registry — add a provider here and name it in an order list to enable it.
PROVIDERS: dict[str, object] = {
    "local_ai": LocalAIProvider(),
    "stardict": StarDictProvider(),
    "google": GoogleProvider(),
    "deepl": DeepLProvider(),
    "deeplx": DeepLXProvider(),
    "libretranslate": LibreTranslateProvider(),
}

# Which providers can serve a whole PASSAGE, as opposed to only a single word.
# Read off each provider's own `passage_capable` flag (default True — declining
# passages is the exception), so the answer lives next to the `translate()` that
# makes it true and cannot drift away from it.
#
# This distinction exists because it was invisible exactly where it mattered.
# `/translate/status` reported `ready: true` whenever ANY provider was
# configured, so a vault with one healthy dictionary and four dead translators
# reported ready while no passage could be translated at all — and that is the
# very endpoint surf-lingua tells the operator to check when its translation row
# comes up empty. The single diagnostic pointed at the opposite of the symptom.
PASSAGE_CAPABLE: frozenset[str] = frozenset(
    name for name, p in PROVIDERS.items() if getattr(p, "passage_capable", True)
)


def passage_budgets(cfg, blocks: int) -> tuple[float, float]:
    """(per-provider, whole-cascade) deadlines for a passage of `blocks` blocks.

    The configured seconds are a FLOOR, not the whole budget. A flat deadline
    quietly assumed every passage is small — true of the dual reader's handful
    of paragraphs, false of a caption track or a page read. Measured
    2026-08-25: LibreTranslate costs ~0.12s per segment, linearly, so
    surf-lingua's 400-line page read needs ~46s; against the flat 8s cap the
    cascade cancelled a provider that was working perfectly and returned 400
    nulls, which is indistinguishable from the provider being broken.

    Scaling does not weaken what the cap is FOR. It exists so one unreachable
    provider cannot own the request, and an unreachable provider still fails on
    its first chunk no matter how many blocks were asked for. What it stops
    doing is punishing a provider for being handed a lot of legitimate work.

    A hard ceiling keeps "large" from becoming "unbounded".
    """
    t = cfg.translate
    per_floor = getattr(t, "passage_provider_timeout_seconds", 8.0)
    total_floor = getattr(t, "passage_total_timeout_seconds", 20.0)
    per_block = getattr(t, "passage_seconds_per_block", 0.35)
    ceiling = getattr(t, "passage_max_timeout_seconds", 240.0)

    scaled = max(0, blocks) * per_block
    # The cascade budget has to leave room for a second provider to try after
    # the first one used its whole slot; without the headroom a single slow
    # provider consumes the total and the fallback never runs.
    #
    # That headroom used to evaporate at the ceiling: `per` and `total` were
    # both clamped to the SAME `ceiling`, so once a passage was large enough
    # for each to saturate it they came back equal, and the one property this
    # function exists to guarantee quietly stopped holding for exactly the
    # biggest requests — the ones with the most to lose. Clamping `per` to a
    # fraction of the ceiling instead keeps the gap open at every size.
    per = min(max(per_floor, scaled), ceiling / 1.5)
    total = min(max(total_floor, scaled * 1.5), ceiling)
    return per, max(total, per * 1.5)


def decline_windows(cfg) -> dict[str, float]:
    """Seconds remaining on each provider's negative-cache window.

    A provider in a decline window is configured, may well answer a probe, and
    is still being skipped by the cascade — which is precisely the state that
    made /translate/status untrustworthy twice. Surfacing it is what lets the
    endpoint's answer match what the cascade will actually do.

    Zero (or absent) means "not declining". Only providers that keep such a
    window appear here; the rest have nothing to report.
    """
    out: dict[str, float] = {}
    t = cfg.translate
    lt = str(getattr(t, "libretranslate_url", "") or "").rstrip("/")
    if lt:
        out["libretranslate"] = round(LibreTranslateProvider.declining_for(lt), 1)
    dx = str(getattr(t, "deeplx_url", "") or "").rstrip("/")
    if dx:
        out["deeplx"] = round(DeepLXProvider.declining_for(dx), 1)
    return out


async def probe_liveness(cfg, timeout: float = 2.5) -> dict[str, bool | None]:
    """Which configured providers are actually answering right now.

    `available()` is a CONFIGURATION check and always was — it says a provider
    is set up, not that anything is on the other end. That gap is the whole
    reason 2026-08-25 took an afternoon: `/translate/status` reported the vault
    ready to translate while a DeepLX container was not running, Google had
    soft-banned this IP, and LM Studio held no model. Three providers, three
    different dead, all reporting available.

    Values are deliberately three-state:
      True  — probed and answered.
      False — probed and did not answer. This is the useful one.
      None  — not probed, so nothing is claimed. Either the provider is not
              configured, or it has no `alive()` because probing it would mean
              a REMOTE call (google, deepl). A status endpoint that quietly
              reached out to the network on every poll would be a worse bug
              than the one being fixed, and `None` says "unknown" honestly
              rather than guessing in either direction.

    Probes run concurrently under one budget: a status call is a diagnostic and
    must stay fast even when several providers are hanging rather than refusing.
    """
    names = [n for n, p in PROVIDERS.items()
             if hasattr(p, "alive") and p.available(cfg)]
    out: dict[str, bool | None] = {n: None for n in PROVIDERS}
    if not names:
        return out

    async def probe(name: str) -> None:
        try:
            out[name] = bool(await PROVIDERS[name].alive(cfg))
        except Exception as e:  # noqa: BLE001 — a dead provider is the answer
            log.debug("liveness probe for %s failed: %s", name, e)
            out[name] = False

    try:
        await asyncio.wait_for(
            asyncio.gather(*(probe(n) for n in names)), timeout=timeout)
    except asyncio.TimeoutError:
        # Whatever finished is kept; a provider still hanging is not answering,
        # which for this endpoint's purposes is indistinguishable from dead.
        log.warning("liveness probes hit the %.1fs budget", timeout)
        for n in names:
            if out[n] is None:
                out[n] = False
    return out


def _order(cfg, forced: str, attr: str) -> list[str]:
    if forced:
        return [forced] if forced in PROVIDERS else []
    order = getattr(cfg.translate, attr, None) or []
    return [n for n in order if n in PROVIDERS]


async def translate_texts(texts: list[str], src: str, tgt: str,
                          provider: str = "") -> dict:
    """Translate blocks through the passage cascade. Returns
    {provider, translations} — translations aligned to `texts` (None per
    block a provider left untranslated); provider "" means nobody answered."""
    cfg = settings.effective()
    per, total = passage_budgets(cfg, sum(1 for t in texts if t and t.strip()))
    deadline = time.monotonic() + total
    for name in _order(cfg, provider, "provider_order"):
        p = PROVIDERS[name]
        if not p.available(cfg):
            continue
        # The same two deadlines translate_word() has carried since 2026-08-09,
        # and for the same reason: `per` stops one unreachable provider owning
        # the request, `deadline` stops several slow ones summing to the same
        # wait. This path never got them, so the lesson held for hovers and not
        # for the dual reader or captions — which is the surface the operator
        # actually watches. available() is a CONFIGURATION check, not a
        # liveness one, so a provider that reports available can still hang.
        left = deadline - time.monotonic()
        if left <= 0:
            log.warning("passage cascade hit its %.1fs budget before %s", total, name)
            break
        try:
            out = await asyncio.wait_for(p.translate(list(texts), src, tgt, cfg),
                                         timeout=min(per, left))
        except asyncio.TimeoutError:
            log.warning("provider %s timed out on passages after %.1fs",
                        name, min(per, left))
            continue
        except Exception as e:
            log.warning("provider %s declined passages: %s", name, e)
            continue
        if out is None:
            continue
        out = list(out)[:len(texts)] + [None] * max(0, len(texts) - len(out))
        # A provider can answer STRUCTURALLY and translate nothing: deeplx
        # returns a list of Nones when its backend is unreachable. `out is
        # None` above does not see that, so the cascade stopped at the first
        # provider in the order and returned its NAME alongside an empty
        # result — and a caller checking only `provider` (reading-companion's
        # fallback guard is literally `!r || !r.provider`) reads that as
        # success and never falls back. Measured 2026-08-16: /translate
        # answered {"provider":"deeplx","translations":[null]} while the same
        # text with provider=google translated correctly. Every dual-language
        # surface in the vault was silently getting no translation.
        #
        # A PARTIAL result is still an answer and is kept — some blocks
        # translated is real work, and falling through would discard it.
        if texts and not any(t for t in out):
            log.warning("provider %s answered with nothing translated; falling through", name)
            continue
        return {"provider": name, "translations": out}
    return {"provider": "", "translations": [None] * len(texts)}


async def translate_word(word: str, src: str, tgt: str, context: str = "",
                         provider: str = "") -> dict:
    """Single-word lookup for the word-pair reader — dictionary-first cascade.
    Returns {provider, word, gloss, reading}; provider "" means no answer."""
    cfg = settings.effective()
    per = getattr(cfg.translate, "word_provider_timeout_seconds", 4.0)
    total = getattr(cfg.translate, "word_total_timeout_seconds", 10.0)
    deadline = time.monotonic() + total
    for name in _order(cfg, provider, "word_order"):
        p = PROVIDERS[name]
        if not p.available(cfg):
            continue
        # Two deadlines, because one is not enough: `per` stops a single
        # unreachable provider from owning the request, and `deadline` stops
        # four slow providers from summing to the same wait. Without these a
        # lookup for a language no local dictionary covers hung for 90s and
        # then returned an empty gloss — the reader saw "..." forever and read
        # it as the feature being broken, which it effectively was.
        left = deadline - time.monotonic()
        if left <= 0:
            log.warning("word lookup for %r hit the %.1fs cascade budget", word, total)
            break
        try:
            hit = await asyncio.wait_for(p.word(word, src, tgt, context, cfg),
                                         timeout=min(per, left))
        except asyncio.TimeoutError:
            log.warning("provider %s word lookup timed out after %.1fs", name, min(per, left))
            continue
        except Exception as e:
            log.warning("provider %s word lookup failed: %s", name, e)
            continue
        if hit is None:
            continue
        # `matched`/`compound` ride along so the reader can be told WHICH form
        # answered. Without them a click on "maisons" shows an entry headed
        # "maison" and looks like the wrong word was looked up. Only stardict
        # sets them; `or ""` keeps the response shape identical for every
        # other provider.
        return {"provider": name, "word": word,
                "gloss": hit.get("gloss", ""), "reading": hit.get("reading", ""),
                "matched": hit.get("matched") or "",
                # "" for every provider but stardict, which keeps the shape
                # identical and means "no evidence" rather than "English".
                "lang": hit.get("lang") or "",
                "compound": hit.get("compound") or []}
    return {"provider": "", "word": word, "gloss": "", "reading": ""}


# ------------------------------------------------------------------ #
# comprehensible input (Krashen) — pure text analysis                #
# ------------------------------------------------------------------ #
_CHINESE_WORDS: set[str] | None = None
_CHINESE_WORDS_TRIED = False


def _chinese_words() -> set[str] | None:
    """CC-CEDICT headwords for Chinese segmentation, loaded once from the
    configured Chinese dictionary. None when none is configured (or it fails
    to load), so segmentation quietly degrades to per-character — the same
    fallback the JS port takes when data/cedict_ts.u8 is absent."""
    global _CHINESE_WORDS, _CHINESE_WORDS_TRIED
    if _CHINESE_WORDS_TRIED:
        return _CHINESE_WORDS
    _CHINESE_WORDS_TRIED = True
    try:
        cfg = settings.effective()
        entries = getattr(getattr(cfg, "translate", None), "stardict", None) or []
    except Exception:  # noqa: BLE001 — no config, no segmentation
        return None
    for entry in entries:
        if not isinstance(entry, dict) or not entry.get("path"):
            continue
        if base_lang(str(entry.get("lang", ""))) != "zh":
            continue
        try:
            words = open_dictionary(entry["path"]).words()
        except Exception as e:  # noqa: BLE001
            log.warning("cedict unusable for segmentation: %s", e)
            continue
        if words:
            _CHINESE_WORDS = words
            return words
    return None


def analyze_coverage(text: str, known: set[str], threshold: float = 0.95,
                     lang: str = "") -> dict:
    """Krashen's comprehensible-input check: what share of the running words
    the reader already knows. i+1 territory is ~90-98% known — enough context
    to infer the rest. Returns coverage, the band, and the unknown words to
    pre-learn (most frequent first).

    `known` is a set of lower-cased tokens (the reader's vocabulary). A Chinese
    `lang` segments both the text and the vocab terms with CC-CEDICT, so 分享
    is measured as one word, not two characters.
    """
    tokens = tokenize(text, lang=lang,
                      words=_chinese_words() if _is_chinese(lang) else None)
    total = len(tokens)
    freq: dict[str, int] = {}
    for tok in tokens:
        freq[tok] = freq.get(tok, 0) + 1
    known_running = sum(c for w, c in freq.items() if w in known)
    coverage = (known_running / total) if total else 0.0
    unknown = sorted((w for w in freq if w not in known),
                     key=lambda w: (-freq[w], w))
    if coverage >= 0.98:
        band = "easy"            # >98% — nearly no new words, low challenge
    elif coverage >= threshold:
        band = "comprehensible"  # the sweet spot: enough to infer from context
    elif coverage >= 0.80:
        band = "reach"           # doable with support (dictionary, dual view)
    else:
        band = "frustrating"     # too many unknowns to read for meaning
    return {
        "total_words": total,
        "unique_words": len(freq),
        "known_running": known_running,
        "coverage": round(coverage, 4),
        "band": band,
        "threshold": threshold,
        "unknown": [{"word": w, "count": freq[w]} for w in unknown],
        # term -> status_receptive for every tracked word, so the reader can
        # colour by the two-track status instead of the binary known/unknown.
        # Empty when the CSV can't be read; the caller falls back to binary.
        "statuses": _status_map(lang),
    }


def _status_map(lang: str) -> dict[str, str]:
    """term -> status_receptive for the language's tracked words, read from the
    vocabulary CSV (spec §10 rewrite). Never raises — a missing or corrupt CSV
    just yields no statuses and the reader falls back to binary colouring."""
    if not lang:
        return {}
    from . import vocab_csv
    try:
        rows = vocab_csv.read(lang)
    except Exception:  # noqa: BLE001 — status colouring is a nicety, not coverage
        return {}
    # Raw status, not defaulted: a "" status means "tracked but not yet
    # recomputed", which the caller falls back to binary known/unknown for.
    return {str(r.get("term") or ""): str(r.get("status_receptive") or "")
            for r in rows}


def enrich_vocab_rows(rows: list[dict], lang: str) -> None:
    """Fill `reading`/`gloss` on vocab rows from the offline dictionaries (3.4's
    dictionary join). Mutates `rows` in place. A missing or absent dictionary
    leaves the rows bare — the reader degrades to plain terms, never to an empty
    pane or an error.

    reading/gloss are deliberately NOT stored in the CSV (they go stale the
    moment the dictionary is corrected); they are joined here at read time."""
    try:
        dicts = _stardicts_for(settings.effective(), lang)
    except Exception:  # noqa: BLE001
        dicts = []
    for row in rows:
        # Every enriched row carries both fields, so the response shape is
        # identical whether the dictionary answered or not.
        row["gloss"] = ""
        row["reading"] = ""
        term = str(row.get("term") or "").strip()
        if not term or not dicts:
            continue
        for sd in dicts:
            try:
                entry = sd.entry(term)
            except Exception:  # noqa: BLE001 — one dict failing must not blank the row
                entry = None
            if not entry:
                continue
            row["gloss"] = re.sub(r"\s+", " ", entry).strip()
            read = getattr(sd, "reading", None)
            row["reading"] = read(term) if callable(read) else ""
            break


def known_terms(language: str) -> set[str]:
    """The reader's known vocabulary for a language, drawn from the vocabulary
    CSV (spec §10 rewrite — this used to scan `type: vocab` notes). Empty when
    the sidecar can't see the vault or the CSV is missing — the caller can
    still pass `known`.

    A null/empty `language` returns an EMPTY set, not "every tracked word the
    vault holds". Without a source language the reader's vocabulary is UNKNOWN,
    and treating "" as "all languages" handed the coverage check a 100% score
    for text whose language the caller never named."""
    from . import vocab_csv
    out: set[str] = set()
    lang = (language or "").strip().lower()
    if not lang:
        return out
    try:
        rows = vocab_csv.read(lang)
    except Exception:  # noqa: BLE001 — a missing CSV just yields fewer known words
        return out
    for row in rows:
        term = str(row.get("term") or "").strip()
        if not term:
            continue
        out.update(tokenize(term, lang=lang,
                             words=_chinese_words() if _is_chinese(lang) else None)
                   or [term.lower()])
    return out
