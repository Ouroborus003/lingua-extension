"""LM Studio client — the single inference path (spec §11, amended).

Talks to LM Studio's OpenAI-compatible server. The model is never hardcoded:
the Settings note or config names it, or an already-loaded model is used.

Inference is *lazy on purpose*: nothing here loads a model until a real AI
request arrives. Listing models is free, so /health can report what LM Studio
has without pulling weights into memory, and `ttl_seconds` lets LM Studio
evict a JIT-loaded model once the user stops asking for things.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import shutil
import subprocess
import time
from pathlib import Path

import httpx

from . import ai_models, config, settings
from .config import STATE_DIR, LMStudioCfg

log = logging.getLogger("sidecar.llm")

# One autostart attempt at a time, and no second attempt while one is in
# flight — three AI features firing at once (chat, a digest, translate)
# would otherwise each launch their own copy of the app.
_start_lock = asyncio.Lock()


class LLMUnavailable(Exception):
    """LM Studio is not running, has no model loaded, or the call failed."""


class LLMNotReady(LLMUnavailable):
    """LM Studio answered, but its model loader was not up yet.

    Not a configuration fault and not worth showing anybody: the server binds
    its port and serves the full downloaded catalogue a second or two *before*
    just-in-time loading can actually service a request, and a chat call that
    lands in that window comes back 400 "No models loaded". Distinct from
    LLMUnavailable so chat() can wait it out instead of surfacing the one
    failure that fixes itself.
    """


class LLMOffline(LLMUnavailable):
    """LM Studio is down and nobody has agreed to start it.

    Deliberately a *distinct* type rather than a message: this is the one
    failure the user can fix from a dialog, so every route turns it into a
    503 carrying `code: "llm_offline"` and the plugins key their "start the
    model?" prompt off that code rather than off matching English text.
    """


# When the last real inference happened — what the standby reaper measures.
# Set on the way in rather than the way out: a long generation should count
# as activity from the moment it starts, or a slow answer could be reaped
# out from under itself.
_last_used: float = 0.0


def mark_used() -> None:
    global _last_used
    _last_used = time.time()


def idle_seconds() -> float:
    return time.time() - _last_used if _last_used else float("inf")


# Consent for starting LM Studio, remembered across restarts when the user
# ticks "Remember selection". "ask" means a request that finds the server
# down fails with LLMOffline so the UI can offer to start it; "always" means
# invoking an AI feature is itself the permission.
_CONSENT_PATH = STATE_DIR / "llm_consent.json"


def consent() -> str:
    try:
        value = json.loads(_CONSENT_PATH.read_text()).get("consent", "ask")
    except Exception:
        return "ask"
    return value if value in ("ask", "always") else "ask"


def set_consent(value: str) -> str:
    value = value if value in ("ask", "always") else "ask"
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    _CONSENT_PATH.write_text(json.dumps({"consent": value}))
    log.info("LM Studio autostart consent set to %r", value)
    return value


def _is_unreachable(e: Exception) -> bool:
    """A dead server, as opposed to a live one refusing the request. Only the
    former is worth starting anything for: an HTTP error means LM Studio is
    up and answering, and relaunching it would not help."""
    return isinstance(e, (httpx.ConnectError, httpx.ConnectTimeout))


async def _server_is_up(cfg: LMStudioCfg) -> bool:
    """Ready to serve a completion, not merely bound to the port.

    A freshly launched LM Studio answers /api/v0/models with an empty list for
    a second or two while it is still indexing what is on disk, and a chat
    request in that window fails with "No models loaded" — which reads exactly
    like the "nothing is loaded" configuration error and is not one. An empty
    catalogue means "not ready yet", so wait for it rather than race it.

    A *non*-empty catalogue, though, does not mean ready — that was the second
    half of this bug and it is not fixable here. Indexing finishes before the
    just-in-time loader can service a request, so this returns True while a
    chat call still loses, roughly a second either side of "Server started".
    Readiness to serve is only observable by asking for a completion, so that
    window is handled where it shows up: LLMNotReady, waited out in
    _chat_awaiting_loader.
    """
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(_native_models_url(cfg.base_url))
        return r.status_code < 500 and bool(r.json().get("data"))
    except Exception:
        return False


def _session_env(env: dict[str, str], runtime_dir: str = "",
                 x11_dir: str = "/tmp/.X11-unix") -> dict[str, str]:
    """The child's environment, with a display added when we have none.

    LM Studio is an Electron app, and it needs a display even in
    --run-as-service mode: launched without DISPLAY or WAYLAND_DISPLAY it
    exits immediately, printing nothing at all. That is precisely the state
    this sidecar runs in — it is a user service (dinit/turnstiled), and its
    environment carries XDG_RUNTIME_DIR and DBUS_SESSION_BUS_ADDRESS but
    neither display variable. So the first attempt at autostart looked like a
    silent 90-second no-op: the process was started and died before it could
    bind a port, with no log to say why.

    Both sockets are found rather than assumed — a hardcoded ":0" is a guess
    about someone else's session (this one is ":1"), and the guess is the kind
    of thing that works on the machine it was written on and nowhere else.
    """
    out = dict(env)
    if out.get("WAYLAND_DISPLAY") or out.get("DISPLAY"):
        return out
    rt = runtime_dir or out.get("XDG_RUNTIME_DIR", "")
    if rt:
        socks = sorted(p.name for p in Path(rt).glob("wayland-[0-9]*")
                       if not p.name.endswith(".lock"))
        if socks:
            out["WAYLAND_DISPLAY"] = socks[0]
            # Not setdefault: a user service inherits the literal string
            # "unspecified" here, which is not a value to preserve.
            if out.get("XDG_SESSION_TYPE", "") in ("", "unspecified"):
                out["XDG_SESSION_TYPE"] = "wayland"
    # Only an X socket this user owns. /tmp/.X11-unix holds every server on
    # the machine, and the lowest-numbered one here is X0 — root's, from the
    # display manager, which we cannot connect to. Sorting and taking the
    # first handed the child DISPLAY=:0 and it died exactly as it had with no
    # DISPLAY at all; the session's own server is X1.
    if Path(x11_dir).is_dir():
        mine = []
        for p in sorted(Path(x11_dir).glob("X[0-9]*")):
            try:
                if p.stat().st_uid == os.getuid():
                    mine.append(p.name)
            except OSError:
                continue
        if mine:
            out["DISPLAY"] = ":" + mine[0][1:]
    return out


def _lms_binary() -> str:
    """The `lms` CLI. Not just "lms": the sidecar is a user service and its
    PATH is the login default, which does not include ~/.lmstudio/bin."""
    found = shutil.which("lms")
    if found:
        return found
    return str(Path.home() / ".lmstudio" / "bin" / "lms")


def parse_lms_catalogue(raw: str) -> list[str]:
    """Model ids from `lms ls --json`, chat-capable ones only.

    Pure so the suite can see it: the shell-out cannot be asserted offline, but
    the parsing can, and the parsing is where a format change would bite.

    Embeddings are excluded — they are loaded for search and cannot serve a
    chat completion, so offering one in a feature's model picker produces a
    selection that fails at request time for a reason the UI never hinted at.
    """
    try:
        rows = json.loads(raw)
    except (ValueError, TypeError):
        return []
    if not isinstance(rows, list):
        return []
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        if r.get("type") and r.get("type") != "llm":
            continue
        key = r.get("modelKey") or r.get("path") or r.get("indexedModelIdentifier")
        if isinstance(key, str) and key.strip() and key not in out:
            out.append(key.strip())
    return out


def downloaded_model_ids() -> list[str]:
    """Every chat model on disk, loaded or not.

    This exists because /api/v0/models cannot answer it. With just-in-time
    loading off — which is the deliberate configuration on this machine, after
    a JIT-loaded model sat on 7.2GB of an 8GB card for fifteen hours — that
    endpoint reports only what is *resident*, and returns an empty list when
    nothing is. A settings tab built on it therefore offered the operator no
    models at all, which is how "pick a model per feature" shipped with an
    empty picker.

    `lms ls --json` is the only source that enumerates the catalogue, so the
    price is a subprocess. Failure is not an error: an empty list degrades the
    picker to "whatever is loaded", which is where it started.
    """
    try:
        proc = subprocess.run([_lms_binary(), "ls", "--json"],
                              capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError) as e:
        log.info("cannot list downloaded models (%s)", e)
        return []
    if proc.returncode != 0:
        log.info("lms ls exited %s: %s", proc.returncode, (proc.stderr or "").strip()[:200])
        return []
    return parse_lms_catalogue(proc.stdout)


def autostart_commands(cfg: LMStudioCfg) -> list[str]:
    """What to try, in order, to get the server listening.

    Two different broken states, each of which the *other* remedy cannot fix,
    which is why this is a list and not a single command:

    - LM Studio is not running at all. `lms server start` is supposed to
      handle this, and on an AppImage install it usually cannot: it resolves
      the app through ~/.lmstudio/.internal/app-install-location.json, where
      LM Studio records its *current mount* — /tmp/.mount_lm-stuXXXXXX, a path
      that dies with the process and is gone after a reboot. It then reports
      "no valid installation could be found". Launching the installed app
      directly is what works, and it repairs that pointer on the way through.
    - LM Studio is already running but its HTTP server is not listening
      (it was stopped, or a previous instance left the app half-up). Launching
      the app again does nothing at all here — the second process sees the
      first and exits, and the server stays down until the 90s timeout. The
      `lms` CLI, which talks to the running instance, is what starts it.

    Trying `lms` first keeps the common case cheap; the direct launch is the
    fallback that covers a genuinely cold machine.
    """
    cmds = [f"{shlex.quote(_lms_binary())} server start"]
    if cfg.autostart_command.strip():
        cmds.append(cfg.autostart_command.strip())
    return cmds


async def _run_and_wait(command: str, cfg: LMStudioCfg, timeout: float) -> bool:
    log.info("LM Studio unreachable at %s — trying: %s", cfg.base_url, command)
    try:
        # Detached, and output discarded: this outlives the request that
        # triggered it, and a pipe nobody drains is a way to wedge the app
        # once its logging fills the buffer.
        subprocess.Popen(shlex.split(command), start_new_session=True,
                         env=_session_env(os.environ.copy()),
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log.warning("could not run (%s): %s", command, e)
        return False
    deadline = asyncio.get_running_loop().time() + timeout
    while asyncio.get_running_loop().time() < deadline:
        await asyncio.sleep(2)
        if await _server_is_up(cfg):
            log.info("LM Studio server is up at %s", cfg.base_url)
            return True
    return False


async def loaded_model_ids(cfg: LMStudioCfg | None = None) -> list[str]:
    """What is actually resident — i.e. what is holding VRAM right now."""
    cfg = cfg or settings.effective().lm_studio
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            return await _loaded_models(client, cfg)
    except Exception:
        return []


async def unload_owned(cfg: LMStudioCfg | None = None) -> bool:
    """Put back the VRAM this sidecar took — and only that. True if its model
    is no longer resident afterwards.

    Unloading the *model* is the operation that matters for standby: the
    weights are the VRAM, and stopping the HTTP server would not free a byte
    of it. The server is left listening so the next question does not have to
    pay for a cold app launch again.

    What standby must never do is reclaim someone else's. This process can
    only observe its *own* inactivity — `_last_used` is bumped by
    `mark_used()` from the sidecar's own calls, and nothing else touches it.
    "I have not used the model for ten minutes" is a different proposition
    from "the card is idle", and LM Studio here is multi-tenant: `llm-local`,
    a headless CLI job, or a chat in the LM Studio GUI can be generating flat
    out while this counter runs to the window. The previous version resolved
    that gap by running `lms unload --all` on the strength of its own
    idleness, which evicted every model on the machine — including ones it
    neither loaded nor uses, mid-generation. It cost two batches and about
    twenty-five minutes of GPU work before the cause was found, three layers
    away, in a log belonging to a different process.

    So the claim is scoped to what this sidecar can honestly own: the model it
    is configured to load, unloaded by id. Anything else on the card is
    another tenant's and is left alone.
    """
    cfg = cfg or settings.effective().lm_studio
    if not await _server_is_up(cfg):
        return True
    owned = (cfg.model or "").strip()
    if not owned:
        # An empty model means this sidecar borrows whatever is already
        # resident (see _resolve_model). Borrowed is not owned: there is no
        # model here standby is entitled to drop.
        log.debug("standby: no model pinned — nothing this sidecar may unload")
        return True
    loaded = await loaded_model_ids(cfg)
    if owned not in loaded:
        return True
    others = [m for m in loaded if m != owned]
    if others:
        log.info("standby: leaving %d model(s) loaded by others: %s",
                 len(others), ", ".join(others))
    command = f"{shlex.quote(_lms_binary())} unload {shlex.quote(owned)}"
    log.info("standby: unloading own idle model: %s", command)
    try:
        await asyncio.to_thread(
            subprocess.run, shlex.split(command), timeout=120,
            env=_session_env(os.environ.copy()),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log.warning("could not unload (%s): %s", command, e)
        return False
    return owned not in await loaded_model_ids(cfg)


async def reap_idle() -> None:
    """Standby: drop *this sidecar's* model once it has gone unused long enough.

    A scheduler tick, so the timeout is honoured whether the last AI request
    came from the chat panel, a translation, or one of this sidecar's headless
    tasks. Note the boundary: those are the callers that reach `mark_used()`.
    Another *process* using LM Studio is invisible here, which is precisely why
    the unload below is scoped by model id rather than clearing the card.

    Zero disables it and leaves the model resident until something else evicts
    it — `lm_studio.ttl_seconds`, sent on every request, is the other reaper
    and the better-scoped one, since LM Studio applies it per model.
    """
    minutes = settings.effective().lm_studio.standby_minutes
    if minutes <= 0 or idle_seconds() < minutes * 60:
        return
    if await unload_owned():
        # Reset, or every subsequent tick re-runs the unload for a model that
        # is already gone.
        mark_used()


async def server_is_running(cfg: LMStudioCfg | None = None) -> bool:
    """Public readiness probe — what a status indicator should call. Listing is
    free, so this never costs a model load (§11)."""
    return await _server_is_up(cfg or settings.effective().lm_studio)


async def stop_server(cfg: LMStudioCfg | None = None) -> bool:
    """Stop LM Studio's server. True if it is down afterwards.

    `lms server stop` only stops the HTTP server; the app keeps running and
    any loaded model stays resident, which is the right scope for a button
    labelled "stop the server" — it is the inverse of what start does, not a
    way to quit LM Studio.
    """
    cfg = cfg or settings.effective().lm_studio
    if not await _server_is_up(cfg):
        return True
    command = f"{shlex.quote(_lms_binary())} server stop"
    log.info("stopping LM Studio server: %s", command)
    try:
        await asyncio.to_thread(
            subprocess.run, shlex.split(command), timeout=60,
            env=_session_env(os.environ.copy()),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        log.warning("could not stop LM Studio (%s): %s", command, e)
        return False
    # Poll rather than trust the exit code: the CLI returns as soon as it has
    # asked, and the port lingers for a moment after.
    for _ in range(10):
        if not await _server_is_up(cfg):
            return True
        await asyncio.sleep(1)
    return not await _server_is_up(cfg)


async def ensure_server(cfg: LMStudioCfg | None = None, force: bool = False) -> bool:
    """Bring LM Studio's server up if it is down. True if it is up afterwards.

    Called from an actual inference request or from the panel's own start
    button, never from /health: a status poll every few minutes must not be
    the thing that launches an application, or "the sidecar only does AI work
    when asked" stops being true. Starting the server is still not a model
    load — see LMStudioCfg.autostart.
    """
    cfg = cfg or settings.effective().lm_studio
    if await _server_is_up(cfg):
        return True
    # `autostart` governs the *automatic* path only. Pressing the panel's
    # start button is the operator asking directly, and a preference for
    # starting it by hand is not a reason to refuse the hand.
    if not cfg.autostart and not force:
        return False
    async with _start_lock:
        # Another request may have started it while we waited for the lock.
        if await _server_is_up(cfg):
            return True
        cmds = autostart_commands(cfg)
        # The budget is per whole attempt, not per command, so a machine where
        # the first remedy simply does nothing still gets a real try at the
        # second one inside the caller's patience.
        share = max(20.0, cfg.autostart_timeout_seconds / max(1, len(cmds)))
        for command in cmds:
            if await _run_and_wait(command, cfg, share):
                return True
        log.warning("LM Studio did not come up within %ss (tried: %s)",
                    cfg.autostart_timeout_seconds, "; ".join(cmds))
        return False


def _native_models_url(base_url: str) -> str:
    """LM Studio's native API sits beside the OpenAI-compatible one:
    http://host:port/v1 -> http://host:port/api/v0/models."""
    return base_url.rstrip("/").removesuffix("/v1") + "/api/v0/models"


async def _loaded_models(client: httpx.AsyncClient, cfg: LMStudioCfg) -> list[str]:
    """Chat-capable models LM Studio currently holds in memory, best first.

    /v1/models is the wrong endpoint for this and reading like the right one
    is exactly what made it dangerous: it lists every *downloaded* model and
    carries no state field at all, so `models[0]` resolved to whichever model
    sorted first — here a 27B reasoning VLM that was not loaded. LM Studio
    JIT-loaded it on every call, which ran ~10x slower than the small model
    and blew timeout_seconds on the scheduled digests. /api/v0/models is the
    only endpoint that reports `state`, so it is the only one that can answer
    "what is already loaded". Embedding models are excluded — they are loaded
    for search and cannot serve a chat completion.
    """
    r = await client.get(_native_models_url(cfg.base_url))
    r.raise_for_status()
    return [m["id"] for m in r.json().get("data", [])
            if m.get("state") == "loaded" and m.get("type") != "embeddings"]


async def _resolve_model(client: httpx.AsyncClient, cfg: LMStudioCfg,
                         feature: str | None = None) -> str:
    # A feature may name its own model; anything unset falls back to the global
    # one. Resolved here because this is the single choke point every request
    # already passes through — putting the lookup in each caller would give
    # nine places for the fallback to be got subtly wrong.
    picked = ai_models.model_for(feature, ai_models.load(config.SIDECAR_DIR), cfg.model or "")
    if picked:
        return picked
    try:
        loaded = await _loaded_models(client, cfg)
    except Exception as e:
        raise LLMUnavailable(f"cannot list models at {cfg.base_url}: {e}") from e
    if not loaded:
        raise LLMUnavailable(
            "no model is loaded in LM Studio and no model is configured — set "
            "Model in 08 Meta/Settings.md (or load one in LM Studio). Refusing "
            "to guess: the guess is what silently pulled a 27B model into "
            "memory on every call.")
    return loaded[0]


# How long to keep re-asking while LM Studio's loader is still coming up,
# in seconds between attempts. Sized from the observed failures: every one of
# them landed within two seconds of "Server started", so the first retry alone
# covers the common case and the tail is there for a genuinely cold machine
# that is also paging a model in off disk. Bounded, and small against
# timeout_seconds — this waits for a loader, not for a generation.
def _not_ready_backoff(budget: float) -> tuple[float, ...]:
    """Doubling delays that sum to at most `budget` seconds.

    Was a hardcoded (1, 2, 4, 8) — fifteen seconds — and the docstring below
    explains why that felt safe. It is not, with just-in-time loading off:
    "no models loaded" is then a PERMANENT condition and every second waited
    is spent on an event that cannot occur. Derived from config so an operator
    who turns JIT on can pay for it deliberately.
    """
    out: list[float] = []
    delay, spent = 1.0, 0.0
    while spent + delay <= max(0.0, budget):
        out.append(delay)
        spent += delay
        delay *= 2
    return tuple(out)


async def _chat_awaiting_loader(cfg: LMStudioCfg, system: str, user: str,
                                temperature: float | None,
                                json_schema: dict | None,
                                feature: str | None = None) -> str:
    """_chat_once, but patient about a model loader that isn't up yet.

    The retry belongs here rather than beside the connection retry in chat()
    because this is not an unreachable server: LM Studio is answering, it just
    cannot serve a completion for another moment. Waiting is the whole fix —
    the request that failed is valid and succeeds unchanged on the next try,
    which is why the panel showed an error bubble for a question that worked
    the second time the user pressed send.
    """
    last: LLMNotReady | None = None
    budget = getattr(cfg, "loader_wait_seconds", 3.0)
    for delay in (*_not_ready_backoff(budget), None):
        try:
            return await _chat_once(cfg, system, user, temperature, json_schema,
                                    feature)
        except LLMNotReady as e:
            last = e
            if delay is None:
                break
            log.info("LM Studio's loader is not ready yet — retrying in %ss", delay)
            await asyncio.sleep(delay)
    raise LLMUnavailable(
        f"LM Studio never loaded a model for this request: {last}. Waited "
        f"{budget:.1f}s. With just-in-time loading OFF this condition is "
        f"permanent — nothing will load it on its own — so load one "
        f"deliberately (`lms load <model>`) or point lm_studio.model at a "
        f"model that is actually downloaded (`lms ls`)."
    ) from last


async def chat(system: str, user: str, temperature: float | None = None,
               json_schema: dict | None = None, feature: str | None = None) -> str:
    """`feature` selects a per-feature model when one is configured.

    Optional and defaulted so every existing call site keeps its exact
    behaviour: unset means the global model, which is what they all used."""
    cfg = settings.effective().lm_studio
    mark_used()
    try:
        return await _chat_awaiting_loader(cfg, system, user, temperature, json_schema,
                                           feature)
    except LLMUnavailable as e:
        # Only a *connection* failure is retryable, and only once. A model
        # that errors, or a server that answers 4xx, is a real fault: retrying
        # it would double every genuine failure's latency for nothing.
        if not _is_unreachable(e.__cause__ or e):
            raise
        # Nothing starts a model behind the user's back. Weights are VRAM,
        # and the whole point of leaving LM Studio down is that the card
        # stays free until the user actually wants inference — so unless they
        # have already said "always", this comes back as the one error the UI
        # knows how to offer a fix for.
        if consent() != "always":
            raise LLMOffline(
                f"LM Studio is not running at {cfg.base_url}.") from e
        # Not force=True: consent is the user's answer to "may this start
        # itself", `autostart` is the machine-level switch above it, and a
        # remembered yes should not override an operator who turned the whole
        # mechanism off in config. The panel's own button is the forced path.
        if not await ensure_server(cfg):
            raise LLMUnavailable(
                f"LM Studio is not running at {cfg.base_url} and could not be "
                f"started automatically — open LM Studio (its server autostarts) "
                f"or run `lms server start`. Original error: {e}") from e
    mark_used()
    # The patient path matters most here: ensure_server returns as soon as the
    # catalogue is readable, which is earlier than the loader can serve, so a
    # bare _chat_once on a server this call just started is the exact sequence
    # that produced the 400s.
    # `feature` was dropped here, so a request that arrived while LM Studio
    # was down and got it started would silently fall back to the GLOBAL
    # model — item 1 of a batch on a different model from items 2..n.
    return await _chat_awaiting_loader(cfg, system, user, temperature, json_schema,
                                       feature)


async def _chat_once(cfg: LMStudioCfg, system: str, user: str,
                     temperature: float | None = None,
                     json_schema: dict | None = None,
                     feature: str | None = None) -> str:
    async with httpx.AsyncClient(base_url=cfg.base_url,
                                 timeout=cfg.timeout_seconds) as client:
        model = await _resolve_model(client, cfg, feature)
        payload: dict = {
            "model": model,
            "temperature": cfg.temperature if temperature is None else temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        if cfg.ttl_seconds:
            # Without a TTL a model LM Studio JIT-loads for one request stays
            # resident until something else evicts it, which is how a single
            # background job left a 27B model holding memory all day. The TTL
            # is what makes "loads only when the user asks for AI" true on the
            # way back out: idle that long and LM Studio unloads it again.
            payload["ttl"] = cfg.ttl_seconds
        if json_schema is not None:
            payload["response_format"] = {
                "type": "json_schema",
                "json_schema": {"name": "response", "schema": json_schema},
            }
            # A reasoning-capable model (confirmed live against qwen3.5-9b)
            # can dump its *entire* answer into reasoning_content and leave
            # content empty when asked for structured output — every
            # json_schema caller (tag_review, digests, translate, identify)
            # got json.loads("") as a result. reasoning_effort silences
            # thinking for exactly the calls that need clean, parseable
            # output; a non-reasoning model or an LM Studio build that
            # doesn't recognize the field ignores it (confirmed live against
            # qwen3-4b-2507 — same request, no error, same shape either way).
            payload["reasoning_effort"] = "none"
        try:
            r = await client.post("/chat/completions", json=payload)
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            # Matching on LM Studio's English is unpleasant, but it does not
            # give this condition a code of its own — the body carries
            # type "invalid_request_error" and param "model", the same shape
            # a genuinely bad model name produces, so the message is the only
            # thing that separates "loader isn't up yet" from "no such model".
            if (e.response.status_code == 400
                    and "no models loaded" in e.response.text.lower()):
                raise LLMNotReady(
                    f"LM Studio at {cfg.base_url} has no model loaded yet "
                    f"(requested {model!r})") from e
            raise LLMUnavailable(
                f"chat failed against {cfg.base_url}: {e} — body: {e.response.text}"
            ) from e
        except Exception as e:
            raise LLMUnavailable(f"chat failed against {cfg.base_url}: {e}") from e
        message = r.json()["choices"][0]["message"]
        # Defense in depth for a model/LM Studio combination that ignores
        # reasoning_effort above: the real answer landing in reasoning_content
        # with content left empty is exactly the failure this once produced
        # (a bare json.loads("") crash in every caller), so fall back rather
        # than trust reasoning_effort alone to have worked.
        content = message.get("content") or ""
        if not content.strip():
            content = message.get("reasoning_content") or content
        return content


async def chat_stream(system: str, user: str, temperature: float | None = None,
                      feature: str | None = None):
    """chat(), yielding text as the model produces it.

    Same request as _chat_once with `stream: true`, read as OpenAI's SSE
    delta format. Exists because the panel's whole complaint was the silence:
    a local model with a chapter attached can take half a minute before the
    first character, and a blank pane is indistinguishable from a hang.

    Deliberately **not** a streaming variant of the json_schema path. A
    structured answer is parsed as one JSON document by its caller, so a
    half-arrived one is not a partial result but a syntax error — there is
    nothing to render early and nothing to gain.

    The readiness dance the non-streaming path does (_chat_awaiting_loader,
    the consent check, the one connection retry) is done up front against a
    trivial non-streamed request rather than reimplemented here. A stream that
    has already begun cannot be restarted transparently — its first tokens are
    gone — so the choice is to fail before opening it or not at all.

    Yields str chunks. Raises the same LLMOffline / LLMUnavailable the rest of
    this module does, always before the first chunk.
    """
    cfg = settings.effective().lm_studio
    mark_used()

    # Provokes exactly the failures the caller must hear about *before* the
    # UI commits to a streaming bubble — server down, consent not given, no
    # model loaded — and starts the model if the operator has allowed it.
    # One token, so it costs a request rather than a generation.
    await chat("Reply with the single character: .", "ready?", temperature=0)
    mark_used()

    payload: dict = {
        "model": None,
        "temperature": cfg.temperature if temperature is None else temperature,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "stream": True,
    }
    if cfg.ttl_seconds:
        payload["ttl"] = cfg.ttl_seconds

    async with httpx.AsyncClient(base_url=cfg.base_url,
                                 timeout=cfg.timeout_seconds) as client:
        payload["model"] = await _resolve_model(client, cfg, feature)
        try:
            async with client.stream("POST", "/chat/completions", json=payload) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if not data or data == "[DONE]":
                        continue
                    try:
                        chunk = json.loads(data)
                    except ValueError:
                        # A malformed frame is not worth failing a live answer
                        # over — the next one is usually fine.
                        continue
                    choices = chunk.get("choices") or []
                    if not choices:
                        continue
                    delta = choices[0].get("delta") or {}
                    # reasoning_content for the same reason _chat_once falls
                    # back to it: a reasoning model can put the answer there.
                    text = delta.get("content") or delta.get("reasoning_content") or ""
                    if text:
                        yield text
        except httpx.HTTPStatusError as e:
            raise LLMUnavailable(
                f"streaming chat failed against {cfg.base_url}: {e} "
                f"— body: {e.response.text}") from e
        except Exception as e:
            raise LLMUnavailable(
                f"streaming chat failed against {cfg.base_url}: {e}") from e


async def model_id() -> str:
    """What /health reports — and it must never be the thing that loads a model.

    Listing is free, a completion is not, so this only ever lists. A configured
    model that isn't in memory yet is not a fault to report: it loads on the
    first real AI request and unloads again after ttl_seconds. Saying so keeps
    the status bar honest without making a 5-minute poll wake the GPU.
    """
    cfg = settings.effective().lm_studio
    async with httpx.AsyncClient(base_url=cfg.base_url, timeout=10) as client:
        model = await _resolve_model(client, cfg)
        if not cfg.model:
            return model  # resolved *from* the loaded list, so it is loaded
        try:
            loaded = await _loaded_models(client, cfg)
        except Exception as e:
            raise LLMUnavailable(f"cannot reach {cfg.base_url}: {e}") from e
        return model if model in loaded else f"{model} (idle — loads on first use)"
