"""The per-language ignore list (Stage 2.6).

`08 Meta/Study/Ignored — <lang>.md` is the SOURCE OF TRUTH for "I do not want
to track this word". The vocabulary CSV's `ignored` column is a VIEW of it,
written by sync() — never hand-edited, because the next sync overwrites it.
The markdown file is the thing a human actually edits, so it is parsed
tolerantly: one term per line, a leading `-`/`*` bullet and inline-code
backticks stripped, anything after the first token dropped as commentary.

Auto-suggest: suggest() reads the ledger rollup and proposes the words the
reader keeps meeting but never saves (seen_count >= N, saved_count == 0) — the
function words ("the", "of", 的) that pad coverage without ever being worth a
row. The reader decides which belong on the list; nothing auto-adds.
"""
from __future__ import annotations

import logging
import re

from . import constants, ledger, vocab_csv
from .config import config

log = logging.getLogger("sidecar.ignore")

_BULLET = re.compile(r"^\s*[-*]\s+")


def path(lang: str) -> str:
    return f"{constants.STUDY}/Ignored — {vocab_csv.bucket_key(lang)}.md"


def read(lang: str) -> set[str]:
    """The ignored terms, from the markdown file. Empty when the file is absent."""
    p = config.vault_path / path(lang)
    if not p.exists():
        return set()
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    # Skip a leading YAML frontmatter block if one is present, so a template
    # that stamps one does not leak `created:` / `type:` as ignored terms.
    start = 0
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                start = i + 1
                break
    out: set[str] = set()
    for raw in lines[start:]:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue  # blank, or a heading
        line = _BULLET.sub("", line).strip().strip("`").strip()
        term = line.split()[0] if line else ""
        if term:
            out.add(term)
    return out


def suggest(lang: str, min_seen: int = 5, limit: int = 20) -> list[dict]:
    """High-frequency-never-saved terms, most-seen first.

    A term the reader has met `min_seen` times without once saving it is a
    candidate for the ignore list — it is padding coverage, not vocabulary."""
    bucket = vocab_csv.bucket_key(lang)
    ignored = read(lang)
    out = []
    for (term, b), counts in ledger.rollup(ledger.read_events()).items():
        if b != bucket or term in ignored or counts["saved_count"] > 0:
            continue
        if counts["seen_count"] >= min_seen:
            out.append({"term": term, "seen_count": counts["seen_count"]})
    out.sort(key=lambda x: (-x["seen_count"], x["term"]))
    return out[:limit]


def sync(lang: str) -> int:
    """Mirror the .md into the CSV `ignored` column, patching only on change.

    Sets ignored for every term the .md names, and clears it for every tracked
    term it no longer names — so removing a line from the .md un-ignores the
    word. Returns how many rows changed."""
    ignored = read(lang)
    changed = 0
    for row in vocab_csv.read(lang):
        term = str(row.get("term") or "")
        want = term in ignored
        if bool(row.get("ignored")) != want:
            vocab_csv.patch(lang, term, {"ignored": want})
            changed += 1
    return changed
