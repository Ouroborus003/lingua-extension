"""The two-track status resolver (spec §10 rewrite, Stage 2).

PURE: no I/O, no vault, no clock, no globals — every input is an argument and
every output is a function of the arguments alone. That purity is the whole
point: 2.4's tests have to reach it headlessly, and the vault has been bitten
before by decisions buried in DOM wiring that no headless test could exercise.

WHY TWO TRACKS

"Known" used to be binary, inferred from "the word is saved". That is wrong in
both directions: a word glanced past twenty times is not known, and a word you
can READ but cannot PRODUCE is not known in the sense that matters for
speaking. Receptive and productive knowledge are different facts, so they get
different statuses. FSRS is what separates the two: successfully recalling a
RECEPTIVE card (you are shown the word, you recall the meaning) is evidence of
receptive knowledge only, and never moves the productive track.
"""

from __future__ import annotations

RECEPTIVE_STATUSES = ("unknown", "seen", "learning", "known")
PRODUCTIVE_STATUSES = ("unknown", "learning", "known")


def resolve(*, seen: int = 0, lookup: int = 0, saved: int = 0, produced: int = 0,
            involvement: int = 0, receptive_reviews: int = 0,
            productive_reviews: int = 0) -> dict[str, str]:
    """(counts, involvement score, FSRS reviews) -> the two statuses.

    `seen`, `lookup`, `saved`, `produced` are raw event counts for this term
    (the ledger rollup). `involvement` is the Nation involvement-load sum over
    those events. `receptive_reviews` / `productive_reviews` are how many times
    this term's receptive / productive card was successfully recalled (FSRS
    grade GOOD or EASY).

    Receptive ladder — how reliably you recognise the word when reading it:

      unknown   — never engaged at all.
      seen      — passive exposure only (glances/hovers); nothing active.
      learning  — any active engagement, but not yet stable.
      known     — stable recognition, by one of several roads:
                    · FSRS: 2 successful receptive recalls AND you saved it, or
                      4 successful receptive recalls on their own.
                    · savings: saved 3+ times with involvement >= 9 (3 saves at
                      3 involvement each is the canonical case).
                    · production: produced 3+ times, or 3+ successful PRODUCTIVE
                      recalls. Production is harder than recognition, so
                      productive evidence implies receptive knowledge.

    Productive ladder — how reliably you produce the word when speaking:

      unknown   — never produced it and never recalled a productive card.
      learning  — produced it or recalled a productive card at least once.
      known     — produced 3+ times, or recalled a productive card 3+ times.

    The tracks are one-way: receptive evidence never moves the productive
    track (recalling a receptive card does not mean you can say the word), but
    productive evidence moves both (producing a word means you recognise it).

    The negative control (2.4): 20 passive glances give seen=20 and everything
    else zero, so receptive is "seen" — never "known" — and productive is
    "unknown". Passive exposure is not knowledge.
    """
    # Receptive
    if seen == 0 and lookup == 0 and saved == 0 and produced == 0 \
            and receptive_reviews == 0 and productive_reviews == 0:
        receptive = "unknown"
    elif (saved >= 2 and receptive_reviews >= 2) \
            or receptive_reviews >= 4 \
            or (saved >= 3 and involvement >= 9) \
            or produced >= 3 \
            or productive_reviews >= 3:
        receptive = "known"
    elif saved >= 1 or lookup >= 1 or produced >= 1 \
            or receptive_reviews >= 1 or productive_reviews >= 1:
        receptive = "learning"
    else:
        receptive = "seen"

    # Productive
    if produced == 0 and productive_reviews == 0:
        productive = "unknown"
    elif produced >= 3 or productive_reviews >= 3:
        productive = "known"
    else:
        productive = "learning"

    return {"status_receptive": receptive, "status_productive": productive}
