"""Prompts live in version-controlled files (spec §11), not in code."""
from __future__ import annotations

import re
from pathlib import Path

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"

# User-selectable chat personas live in their own subfolder. Dropping a
# `<name>.md` file in here adds a persona to the sidebar's system-prompt
# switcher with no code change — the whole point of keeping prompts as files.
# The base `sidebar_chat` prompt is NOT in here: it is the always-present
# default, offered first and used whenever no persona is chosen, so the switcher
# degrades to today's behaviour when the folder is empty.
PERSONAS_DIR = PROMPTS_DIR / "personas"

# The id the UI uses for "no persona — the built-in reading/writing assistant".
DEFAULT_PERSONA = "sidebar_chat"

# A persona id is a bare file stem: letters, digits, dash, underscore. This is
# also the security boundary for load_persona() — it makes "../secrets" and an
# absolute path un-representable, so a client-supplied id can only ever name a
# file inside PERSONAS_DIR.
_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def load(name: str) -> str:
    return (PROMPTS_DIR / f"{name}.md").read_text(encoding="utf-8")


def _title_of(path: Path) -> str:
    """A human label for a persona: the file's first markdown H1 if it has one,
    otherwise the id with separators turned into spaces and title-cased. Kept
    cheap — reads only enough of the file to find a heading."""
    try:
        with path.open(encoding="utf-8") as f:
            for _ in range(20):            # a title in the first lines or not at all
                line = f.readline()
                if not line:
                    break
                m = re.match(r"^#\s+(.+?)\s*$", line)
                if m:
                    return m.group(1)
    except OSError:
        pass
    return path.stem.replace("_", " ").replace("-", " ").title()


def personas() -> list[dict]:
    """The switcher's menu: the built-in default first, then every persona file,
    alphabetised by label. Each entry is {id, title, builtin}. Listing only —
    this reads filenames and at most a heading line, never a model, so the
    sidebar can populate the dropdown without breaking the lazy-inference rule
    (§11)."""
    out = [{"id": DEFAULT_PERSONA, "title": "Default assistant", "builtin": True}]
    if PERSONAS_DIR.is_dir():
        found = []
        for p in PERSONAS_DIR.glob("*.md"):
            if _ID_RE.match(p.stem):
                found.append({"id": p.stem, "title": _title_of(p), "builtin": False})
        found.sort(key=lambda e: e["title"].lower())
        out.extend(found)
    return out


def load_persona(persona_id: str | None) -> str:
    """The system prompt for a chosen persona.

    Empty/default/unknown all fall back to the base prompt rather than erroring:
    a persona file deleted out from under a remembered selection should quietly
    become the default, not break the panel. The id is validated against
    `_ID_RE` first, so this can never be turned into a path-traversal read — an
    id with a slash or a dot-segment simply isn't a valid persona and falls
    through to the default.
    """
    if not persona_id or persona_id == DEFAULT_PERSONA:
        return load(DEFAULT_PERSONA)
    if not _ID_RE.match(persona_id):
        return load(DEFAULT_PERSONA)
    path = PERSONAS_DIR / f"{persona_id}.md"
    if not path.is_file():
        return load(DEFAULT_PERSONA)
    return path.read_text(encoding="utf-8")
