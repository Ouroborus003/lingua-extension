"""In-vault settings overlay — 08 Meta/Settings.md over config.yaml.

The Settings note is the operator's edit surface (flat frontmatter keys,
Meta Bind widgets); the sidecar only ever READS it. Precedence:
dataclass defaults < config.yaml < Settings.md. A missing or unparseable
note means the base config, so the vault keeps working with zero setup.

The note holds secrets (Last.fm and DeepL keys) and is gitignored;
08 Meta/Settings.example.md is the committed shape. File-only bootstrap
values are never overlaid: vault_path, server.host/port, lm_studio.base_url.

Call sites take `settings.effective().X` instead of `config.X` wherever the
operator should be able to change X without restarting the sidecar. The
note is stat()ed per call and re-parsed only when its mtime changes.
"""
from __future__ import annotations

import copy
import logging
from typing import Any, Callable

import frontmatter

from . import constants
from .config import Config, config

log = logging.getLogger("sidecar.settings")

SETTINGS_NOTE = f"{constants.META}/Settings.md"

# Flat keys whose values must never appear in logs or API responses.
SECRET_KEYS = {"lastfm_api_key", "translate_deepl_api_key"}


def _as_bool(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("true", "yes", "on", "1"):
        return True
    if s in ("false", "no", "off", "0"):
        return False
    raise ValueError(f"not a boolean: {v!r}")


def _int_between(lo: int, hi: int) -> Callable[[Any], int]:
    def cast(v: Any) -> int:
        return min(hi, max(lo, int(v)))
    return cast


def _float_between(lo: float, hi: float) -> Callable[[Any], float]:
    def cast(v: Any) -> float:
        return min(hi, max(lo, float(v)))
    return cast


def _choice(*allowed: str) -> Callable[[Any], str]:
    def cast(v: Any) -> str:
        s = str(v).strip()
        if s not in allowed:
            raise ValueError(f"{s!r} not in {allowed}")
        return s
    return cast


_minutes = _int_between(1, 1440)

# flat frontmatter key -> (attribute path into Config, caster).
# Casters clamp or reject; a rejected value is logged and skipped, never fatal.
OVERLAY: dict[str, tuple[tuple[str, ...], Callable[[Any], Any]]] = {
    "ai_model": (("lm_studio", "model"), str),
    "ai_temperature": (("lm_studio", "temperature"), _float_between(0.0, 2.0)),
    "ai_timeout_seconds": (("lm_studio", "timeout_seconds"), _int_between(10, 3600)),
    "ai_ttl_seconds": (("lm_studio", "ttl_seconds"), _int_between(0, 86400)),
    "ai_standby_minutes": (("lm_studio", "standby_minutes"), _int_between(0, 1440)),
    "ai_daily_jobs": (("scheduler", "ai_jobs"), _as_bool),
    "lastfm_username": (("lastfm", "username"), str),
    "lastfm_api_key": (("lastfm", "api_key"), str),
    "boox_watch_dir": (("boox", "watch_dir"), str),
    "boox_format": (("boox", "format"), _choice("markdown", "canvas")),
    "boox_domain": (("boox", "domain"), _choice(*constants.DOMAINS)),
    "boox_exclude_unopened": (("boox", "exclude_unopened"), _as_bool),
    "scheduler_enabled": (("scheduler", "enabled"), _as_bool),
    "dashboard_minutes": (("scheduler", "dashboard_minutes"), _minutes),
    "responsibilities_minutes": (("scheduler", "responsibilities_minutes"), _minutes),
    "states_minutes": (("scheduler", "states_minutes"), _minutes),
    "lastfm_minutes": (("scheduler", "lastfm_minutes"), _minutes),
    "boox_minutes": (("scheduler", "boox_minutes"), _minutes),
    "rss_minutes": (("scheduler", "rss_minutes"), _minutes),
    "jobsfair_minutes": (("scheduler", "jobsfair_minutes"), _minutes),
    "jobsfair_db": (("jobsfair", "db_path"), str),
    "jobsfair_dashboard_url": (("jobsfair", "dashboard_url"), str),
    "jobsfair_queue_limit": (("jobsfair", "queue_limit"), _int_between(1, 30)),
    "jobsfair_pull_hours": (("scheduler", "jobsfair_pull_hours"), _int_between(0, 48)),
    "lingua_audio_prefetch": (("scheduler", "lingua_audio_prefetch"), _as_bool),
    "services_idle_minutes": (("services", "idle_minutes"), _int_between(2, 60)),
    "lingua_repo": (("services", "lingua_repo"), str),
    "jobsfair_repo": (("services", "jobsfair_repo"), str),
    "daily_jobs_hour": (("scheduler", "daily_jobs_hour"), _int_between(0, 23)),
    "translate_google_enabled": (("translate", "google_enabled"), _as_bool),
    "translate_deepl_api_key": (("translate", "deepl_api_key"), str),
    "translate_deepl_free": (("translate", "deepl_free"), _as_bool),
    # Smart Management. `smart_min_instruction` is mirrored in the plugin's
    # doRun guard — change both or the UI accepts what the server refuses.
    "smart_max_chars": (("smart", "max_chars"), _int_between(500, 40000)),
    "smart_temperature": (("smart", "temperature"), _float_between(0.0, 1.0)),
    "smart_scope_cap": (("smart", "scope_cap"), _int_between(1, 5000)),
    "smart_min_instruction": (("smart", "min_instruction_chars"), _int_between(1, 200)),
    "smart_seconds_per_item": (("smart", "seconds_per_item"), _int_between(1, 120)),
    "ocr_default_lang": (("ocr", "default_lang"), str),
    "ocr_timeout_seconds": (("ocr", "timeout_seconds"), _int_between(5, 120)),
    "ocr_max_pages": (("ocr", "max_pages"), _int_between(1, 10)),
    "ocr_tessdata_prefix": (("ocr", "tessdata_prefix"), str),
    "ocr_vlm_model": (("ocr", "vlm_model"), str),
    "audio_forvo_enabled": (("audio", "forvo_enabled"), _as_bool),
    "audio_forvo_mode": (("audio", "forvo_mode"), _choice("popular", "menu")),
    # Free-form so a source can be added without a settings change; unknown
    # names are dropped by pronounce._order(), not rejected here.
    "audio_pronunciation_sources": (("audio", "pronunciation_sources"), str),
    "audio_forvo_api_key": (("audio", "forvo_api_key"), str),
    "audio_source": (("audio", "audio_source"), _choice("human_first", "tts_only")),
    "audio_tts_backend": (("audio", "tts_backend"), _choice("edge-tts", "piper", "gtts", "qwen3-tts")),
    "audio_tts_voice": (("audio", "tts_voice"), str),
    "audio_tts_rate": (("audio", "tts_rate"),
                       _choice("+30%", "+20%", "+10%", "+0%", "-10%", "-20%", "-30%", "-40%", "-50%")),
    "whisper_model_size": (("whisper", "model_size"), _choice("tiny", "base", "small", "medium")),
    "whisper_default_language": (("whisper", "default_language"), str),
    "responsibilities_horizon_days": (("responsibilities_horizon_days",), _int_between(1, 30)),
    "agenda_horizon_days": (("agenda_horizon_days",), _int_between(1, 30)),
    "tag_review_max": (("tag_review_max",), _int_between(5, 30)),
}

# (mtime, overlaid config, applied flat keys) — one-entry cache.
_cache: tuple[float, Config, dict[str, Any]] | None = None
_note_found = False


def effective() -> Config:
    """Base config with the Settings note overlaid. Never raises."""
    global _cache, _note_found
    p = config.vault_path / SETTINGS_NOTE
    try:
        mtime = p.stat().st_mtime
    except OSError:
        _note_found = False
        return config
    _note_found = True
    if _cache is not None and _cache[0] == mtime:
        return _cache[1]
    try:
        meta = frontmatter.load(p).metadata
    except Exception as e:
        log.warning("unparseable settings note %s: %s", SETTINGS_NOTE, e)
        _cache = None
        return config
    cfg = copy.deepcopy(config)
    applied: dict[str, Any] = {}
    for key, (path, cast) in OVERLAY.items():
        raw = meta.get(key)
        if raw is None or raw == "":
            continue  # empty widget = no override, fall through to config.yaml
        try:
            value = cast(raw)
        except (TypeError, ValueError) as e:
            log.warning("settings key %s: ignoring %r (%s)", key, raw, e)
            continue
        target: Any = cfg
        for attr in path[:-1]:
            target = getattr(target, attr)
        setattr(target, path[-1], value)
        applied[key] = value
    _cache = (mtime, cfg, applied)
    return cfg


def note_found() -> bool:
    return _note_found


def overridden() -> dict[str, Any]:
    """Flat keys the current note actually overrides (secrets unmasked —
    mask with SECRET_KEYS before surfacing)."""
    effective()
    return dict(_cache[2]) if _cache is not None and _note_found else {}
