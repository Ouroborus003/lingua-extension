"""lingualibre.py — human pronunciation recordings from Wikimedia Commons.

The second pronunciation source, and the one that is not going to disappear.
Forvo works intermittently (a CloudFlare challenge, ~17% per attempt — see
`forvo.py`), so a single-source design was always one policy change away from
silence. Lingua Libre is a Wikimedia project: volunteers record word lists, the
files land on Commons under CC licences, and there is **no key, no bot wall and
no rate-limited scrape** — just the ordinary MediaWiki API.

Coverage is real but uneven, and honesty about that is the point. Measured
2026-08-14, exact-word matches: Spanish `perro` 18, German `Hund` 9, French
`chien` 9, Mandarin 好 3, Japanese 犬 1, Arabic كلب 1, Korean 개 1. Whole-language
totals: Italian 12,237 files, Hungarian 259. So a common word usually has a
recording and a rare one often does not — which is a *miss*, not an outage, and
this module reports the difference.

Files follow a strict naming convention, which is what makes them findable:

    LL-Q<wikidata-qid> (<iso3>)-<speaker>-<word>.wav

That gives us language, speaker and word from the filename alone — the same
{url, user} shape `forvo.py` produces, so `pronounce.py` can treat them alike.
"""
from __future__ import annotations

import json
import logging
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

log = logging.getLogger("sidecar.lingualibre")

API = "https://commons.wikimedia.org/w/api.php"

# Wikimedia asks for a descriptive User-Agent and throttles anonymous clients
# that misbehave. A rapid probe loop earned an **HTTP 429** while this module
# was being written, which is why _MIN_INTERVAL exists below.
_HEADERS = {
    "User-Agent": "obsidian-workflow-sidecar/1.0 (personal vault; pronunciation lookup)",
    "Accept": "application/json",
}

# Wikidata language QIDs, as they appear in Lingua Libre filenames.
#
# EVERY entry here was verified against the live API on 2026-08-14 — a wrong
# QID does not error, it silently returns a DIFFERENT language's recordings,
# which is the worst possible failure for a pronunciation tool. So this table
# is deliberately short: an unmapped language returns empty with a reason
# rather than a guess. Add a code only after checking it returns that language.
_QID = {
    "cmn": "Q9192", "zh": "Q9192", "zh-hans": "Q9192", "zh-hant": "Q9192",
    "yue": "Q9186",
    "hun": "Q9067", "hu": "Q9067",
    "deu": "Q188",  "de": "Q188",
    "spa": "Q1321", "es": "Q1321",
    "fra": "Q150",  "fr": "Q150",
    "ita": "Q652",  "it": "Q652",
    "jpn": "Q5287", "ja": "Q5287",
    "kor": "Q9176", "ko": "Q9176",
    "ara": "Q13955", "ar": "Q13955",
}

# Serialise requests and space them out. Commons is a donated resource and the
# reader only ever needs one word at a time; there is nothing to gain from
# concurrency here and a 429 to lose.
_MIN_INTERVAL = 0.35
_throttle_lock = threading.Lock()
_last_call = 0.0


def qid_for(lang: str) -> str:
    """Wikidata QID for a vault language code, or "" when unmapped."""
    c = (lang or "").strip().lower()
    return _QID.get(c) or _QID.get(c.split("-")[0]) or ""


def _api(params: dict, timeout: int = 15) -> dict:
    global _last_call
    with _throttle_lock:
        gap = time.time() - _last_call
        if gap < _MIN_INTERVAL:
            time.sleep(_MIN_INTERVAL - gap)
        _last_call = time.time()
    url = API + "?" + urllib.parse.urlencode({**params, "format": "json"})
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (fixed host)
        return json.loads(r.read().decode("utf-8"))


def _parse_title(title: str) -> tuple[str, str]:
    """('speaker', 'word') from a Lingua Libre filename, or ('', '').

    `File:LL-Q9192 (cmn)-Luilui6666-好.wav` -> ('Luilui6666', '好')

    Speaker names may themselves contain '-' and parentheses (a real one:
    `Levi Highway (列维劳德)`), so the WORD is taken as the tail after the last
    '-' and the speaker as everything between the language block and it.
    """
    name = title[5:] if title.startswith("File:") else title
    stem = name.rsplit(".", 1)[0]
    close = stem.find(")-")
    if close == -1 or "-" not in stem[close + 2:]:
        return "", ""
    rest = stem[close + 2:]
    speaker, _, word = rest.rpartition("-")
    return speaker.strip(), word.strip()


def recordings(word: str, lang: str, limit: int = 6) -> dict:
    """Human recordings for a word: {items, unavailable, reason}.

    Same contract as `forvo.list_pronunciations_detailed`: `unavailable` means
    the SOURCE failed, never that the word has nothing. An unmapped language is
    reported as a miss with a reason — not an outage, and never a guessed QID.
    """
    word = (word or "").strip()
    if not word:
        return {"items": [], "unavailable": False, "reason": ""}

    qid = qid_for(lang)
    if not qid:
        return {"items": [], "unavailable": False,
                "reason": f"no Lingua Libre language code for {lang!r}"}

    try:
        data = _api({
            "action": "query",
            "generator": "search",
            "gsrsearch": f'intitle:"LL-{qid}" intitle:"{word}"',
            "gsrnamespace": 6,          # File:
            "gsrlimit": 30,
            "prop": "imageinfo",
            "iiprop": "url|size|user",
        })
    except urllib.error.HTTPError as exc:
        log.info("lingualibre HTTP %s for %r (%s)", exc.code, word, qid)
        return {"items": [], "unavailable": True,
                "reason": f"Wikimedia Commons returned HTTP {exc.code}"}
    except Exception as exc:
        log.info("lingualibre unreachable for %r (%s): %s", word, qid, exc)
        return {"items": [], "unavailable": True,
                "reason": f"Wikimedia Commons unreachable: {exc}"}

    pages = ((data.get("query") or {}).get("pages") or {}).values()
    items = []
    for p in pages:
        info = (p.get("imageinfo") or [{}])[0]
        src = info.get("url") or ""
        if not src:
            continue
        speaker, got = _parse_title(p.get("title") or "")
        # EXACT word only. Commons' search is substring-ish: asking for 好
        # also returned 讨好 and a whole sentence containing it. Playing a
        # different word than the one clicked is worse than playing nothing.
        if got != word:
            continue
        items.append({
            "url": src.split("?")[0],   # strip Commons' analytics query string
            "user": speaker,
            "votes": 0,                 # Lingua Libre has no voting
            "source": "lingualibre",
        })

    items.sort(key=lambda d: d["user"].lower())   # stable, so a re-click repeats
    # Reached Commons and parsed it: empty here is a genuine "not recorded".
    return {"items": items[:max(1, limit)], "unavailable": False, "reason": ""}


def is_available(timeout: int = 8) -> bool:
    """Best-effort reachability check (diagnostics)."""
    try:
        _api({"action": "query", "meta": "siteinfo"}, timeout=timeout)
        return True
    except Exception:
        return False
