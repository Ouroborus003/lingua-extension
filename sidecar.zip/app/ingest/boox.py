"""Boox/tablet ingestion (spec §9.8): a Syncthing-watched folder is polled;
new annotation exports become markdown notes or canvas cards. Requirement:
unnoticeable — no prompts, files appear.

Improvements:
- Proper diffs: uses file hash (SHA256) to detect changes, not just path
- Exclude unopened books: filters by library's readingEntry.lastOpened
- Efficient state: stores hash+mtime for each file to detect modifications
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import uuid
from pathlib import Path

from .. import constants, settings, vault
from ..config import STATE_DIR

_STATE = STATE_DIR / "boox_seen.json"
# Boox annotation exports: 《Title》Author header, then blocks separated by
# dashed lines with a timestamp line and highlight text.
_TITLE = re.compile(r"[《<]([^》>]+)[》>]")
_BLOCK_SPLIT = re.compile(r"\n-{4,}\n")


def _seen() -> dict:
    """Return the seen state as a dict mapping file path -> {hash, mtime, size}."""
    if _STATE.exists():
        try:
            data = json.loads(_STATE.read_text())
            # Backward compat: if it's a list, convert to dict
            if isinstance(data, list):
                return {path: {"hash": "", "mtime": 0, "size": 0} for path in data}
            return data
        except Exception:
            return {}
    return {}


def _mark(seen: dict) -> None:
    _STATE.write_text(json.dumps(seen, sort_keys=True))


def _file_hash(path: Path) -> str:
    """Compute SHA256 hash of file contents."""
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
    except OSError:
        return ""
    return h.hexdigest()


def _file_stat(path: Path) -> tuple[int, int]:
    """Return (mtime_ns, size) for a file."""
    try:
        st = path.stat()
        return int(st.st_mtime_ns), st.st_size
    except OSError:
        return 0, 0


def _file_changed(path: Path, seen: dict) -> bool:
    """Check if file has changed since last seen using hash."""
    path_str = str(path)
    if path_str not in seen:
        return True
    old = seen[path_str]
    new_hash = _file_hash(path)
    if not new_hash:
        return True
    return old.get("hash") != new_hash


def _update_seen(path: Path, seen: dict) -> None:
    """Update seen state with current file hash and metadata."""
    path_str = str(path)
    seen[path_str] = {
        "hash": _file_hash(path),
        "mtime": path.stat().st_mtime_ns if path.exists() else 0,
        "size": path.stat().st_size if path.exists() else 0,
    }


def _get_opened_books() -> set[str]:
    """Titles of books the reader has actually opened.

    Three bugs lived here, and only the third mattered:

    1. A local `from . import vault` resolved to `app.ingest.vault`, which does
       not exist — while the module already imports `vault` correctly at the
       top. The ImportError was swallowed by the blanket except below, so the
       set was ALWAYS empty, and with exclude_unopened on every book failed the
       match and ingestion stopped while reporting success.
    2. (not a bug, checked: `vault.read` is a frontmatter parser, but YAML is a
       superset of JSON, so it does parse the plugin's data.json correctly.)
    3. The reading entries carry only `notePath` and `lastOpened` — never a
       `title`, which is what this function was reaching for. So even with the
       import fixed it would still return nothing. The title has to come from
       the `library` records, joined on the note path, because reading ids and
       library ids do not overlap (`local:*` vs the library's own ids —
       verified against the live data.json).

    Returns an empty set on any failure, which the caller treats as "cannot
    tell" — it must never turn an unreadable file into "nothing was opened".
    """
    try:
        post = vault.read(".obsidian/plugins/library-workspace/data.json")
        if not post or not post.metadata:
            return set()
        data = post.metadata

        # notePath -> title, from the records that actually carry a title.
        by_note: dict[str, str] = {}
        for rec in (data.get("library") or {}).values():
            note = rec.get("notePath")
            title = rec.get("title")
            if note and title:
                by_note[note] = title

        opened: set[str] = set()
        for entry in (data.get("reading") or {}).values():
            if not entry.get("lastOpened", 0):
                continue
            title = entry.get("title") or entry.get("workTitle")
            if not title:
                note = entry.get("notePath")
                title = by_note.get(note) if note else None
                if not title and note:
                    # Last resort: the note's own filename is the book's name
                    # in this vault's layout.
                    title = note.rsplit("/", 1)[-1].removesuffix(".md")
            if title:
                opened.add(title.replace("/", "-"))
        return opened
    except Exception:
        # Deliberately silent: this is a filter, and a filter that cannot read
        # its input must not break ingestion. The caller's own guard (below)
        # is what stops an empty set from meaning "skip everything".
        return set()


def _parse(text: str, fallback_title: str) -> tuple[str, list[str]]:
    m = _TITLE.search(text.splitlines()[0] if text else "")
    title = m.group(1).strip() if m else fallback_title
    blocks = [b.strip() for b in _BLOCK_SPLIT.split(text) if b.strip()]
    highlights = []
    for b in blocks:
        lines = [l for l in b.splitlines()
                 if l.strip() and not _TITLE.search(l)
                 and not re.match(r"^\d{4}-\d{2}-\d{2}", l.strip())]
        if lines:
            highlights.append(" ".join(l.strip() for l in lines))
    return title, highlights or ([text.strip()] if text.strip() else [])


def _as_markdown(title: str, highlights: list[str], src: str, domain: str) -> None:
    safe = title.replace("/", "-")
    rel = f"{constants.NOTES}/{domain}/{safe} — annotations.md"
    body = "".join(f"\n> [!quote] {h[:80]}\n> {h}\n" for h in highlights)
    initial = f"""---
created: {dt.date.today().isoformat()}
type: source
domain: {domain}
aliases: []
tags: []
generated: false
title: "{title}"
source: "Boox — {src}"
---
# {title} — annotations
"""
    vault.append_only(rel, body, initial)


def _as_canvas(title: str, highlights: list[str], src: str) -> None:
    safe = title.replace("/", "-")
    rel = f"{constants.BOOKS_DIR}/{safe}.canvas"
    p = vault.abs_path(rel)
    canvas = json.loads(p.read_text()) if p.exists() else {"nodes": [], "edges": []}
    # Append new cards to a staging column at the canvas edge; never move
    # operator-placed nodes (§9.10).
    x = max((n.get("x", 0) + n.get("width", 0) for n in canvas["nodes"]), default=0) + 80
    y = 0
    for h in highlights:
        canvas["nodes"].append({
            "id": uuid.uuid4().hex[:16], "type": "text",
            "text": h, "x": x, "y": y, "width": 420,
            "height": max(120, 40 + 22 * (len(h) // 55)),
        })
        y += 180
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(canvas, ensure_ascii=False, indent=1))


def scan() -> dict:
    cfg = settings.effective().boox
    watch = cfg.watch_dir
    if not watch:
        return {"skipped": "boox watch_dir not configured"}
    root = Path(watch).expanduser()
    if not root.exists():
        return {"skipped": f"watch dir missing: {root}"}

    seen = _seen()
    ingested = 0
    skipped_unopened = 0

    # Get opened books if exclude_unopened is enabled
    opened_books = set()
    exclude_unopened = cfg.exclude_unopened
    if exclude_unopened:
        opened_books = _get_opened_books()
        if not opened_books:
            # An empty set means "could not tell", not "nothing was opened".
            # Treating it as the latter is what made this filter silently stop
            # ingestion entirely and still report success — every file failed
            # the match, and the only trace was a skipped_unopened count nobody
            # was reading. Ingest everything rather than nothing when the
            # reading state is unavailable: a duplicate is recoverable, a
            # silently dropped annotation is not.
            exclude_unopened = False

    for f in sorted(root.rglob("*")):
        if f.suffix.lower() not in {".txt", ".md"}:
            continue

        # Check if file has changed (proper diff using hash)
        if not _file_changed(f, seen):
            continue

        # If exclude_unopened is enabled, check if this book has been opened
        if exclude_unopened:
            # Use filename stem as book title approximation
            title_guess = f.stem.replace("_", " ").replace("-", " ")
            # Check if any opened book matches (fuzzy match)
            matched = False
            for opened in opened_books:
                if opened.lower() in title_guess.lower() or title_guess.lower() in opened.lower():
                    matched = True
                    break
            if not matched:
                skipped_unopened += 1
                continue

        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        title, highlights = _parse(text, f.stem)
        if cfg.format == "canvas":
            _as_canvas(title, highlights, f.name)
        else:
            _as_markdown(title, highlights, f.name, cfg.domain)
        _update_seen(f, seen)
        ingested += 1

    _mark(seen)
    result = {"ingested": ingested}
    if skipped_unopened:
        result["skipped_unopened"] = skipped_unopened
    return result