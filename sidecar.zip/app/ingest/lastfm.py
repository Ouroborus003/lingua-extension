"""Last.fm ingestion (spec §9.6). Primary music source — simple API key,
complete history, no OAuth loop. Spotify is recommendations-only and lives
elsewhere (currently deferred; see README).
"""
from __future__ import annotations

import datetime as dt
import json

import httpx

from .. import constants, settings, vault
from ..config import STATE_DIR

LISTENING_PATH = f"{constants.GENERATED}/Feeds/Listening.md"
NOW_PATH = f"{constants.GENERATED}/Feeds/Now Playing.md"
_STATE = STATE_DIR / "lastfm.json"
_API = "https://ws.audioscrobbler.com/2.0/"


def _state() -> dict:
    if _STATE.exists():
        return json.loads(_STATE.read_text())
    return {"last_uts": 0, "now": None}


def _save(state: dict) -> None:
    _STATE.write_text(json.dumps(state))


def _album_note(artist: str, album: str, cover: str = "") -> None:
    if not album:
        return
    safe = album.replace("/", "-").replace(":", " -")
    rel = f"{constants.MUSIC_DIR}/{safe}.md"
    content = f"""---
created: {dt.date.today().isoformat()}
type: album
domain: music
aliases: []
tags: []
generated: false
title: "{album}"
creator: "{artist}"
status: active
rating:
started: {dt.date.today().isoformat()}
finished:
language: en
source_id: "lastfm:{artist} — {album}"
year:
cover: "{cover}"
---
"""
    vault.create_if_absent(rel, content)


def _cover_url(track: dict) -> str:
    """Largest album image last.fm offers for this track, if any."""
    images = track.get("image", [])
    return images[-1].get("#text", "") if images else ""


async def poll() -> dict:
    cfg = settings.effective().lastfm
    if not cfg.api_key or not cfg.username:
        return {"skipped": "lastfm not configured"}
    state = _state()
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(_API, params={
            "method": "user.getrecenttracks", "user": cfg.username,
            "api_key": cfg.api_key, "format": "json", "limit": 50})
        r.raise_for_status()
        tracks = r.json().get("recenttracks", {}).get("track", [])

    now_line = None
    new: list[tuple[int, str, str, str, str]] = []
    for t in tracks:
        artist = t.get("artist", {}).get("#text", "")
        album = t.get("album", {}).get("#text", "")
        name = t.get("name", "")
        if t.get("@attr", {}).get("nowplaying") == "true":
            now_line = f"**{name}** — {artist}" + (f" · *{album}*" if album else "")
            state["now"] = {"track": name, "artist": artist, "album": album}
            continue
        uts = int(t.get("date", {}).get("uts", 0))
        if uts > state["last_uts"]:
            new.append((uts, name, artist, album, _cover_url(t)))

    for uts, name, artist, album, cover in sorted(new):
        day = dt.datetime.fromtimestamp(uts).date().isoformat()
        time = dt.datetime.fromtimestamp(uts).strftime("%H:%M")
        _ensure_day_section(day)
        vault.append_only(LISTENING_PATH,
                          f"- {time} — {name} · {artist}"
                          + (f" · [[{album}]]" if album else "") + "\n")
        _album_note(artist, album, cover)
        state["last_uts"] = uts

    body = "## Now\n" + (now_line or "*Nothing scrobbling.*")
    vault.write_generated(NOW_PATH, body, {"type": "inbox"})
    _save(state)
    return {"new_tracks": len(new), "now_playing": bool(now_line)}


def _ensure_day_section(day: str) -> None:
    post = vault.read(LISTENING_PATH)
    if post is None:
        vault.write_generated(LISTENING_PATH, "# Listening\n", {"type": "inbox"})
        post = vault.read(LISTENING_PATH)
    if f"## {day}" not in post.content:
        vault.append_only(LISTENING_PATH, f"\n## {day}\n")


def now_playing() -> dict | None:
    return _state().get("now")
