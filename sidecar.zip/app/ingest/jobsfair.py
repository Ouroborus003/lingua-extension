"""JobsFair feed — a stateless read-only view over the JobsFair SQLite DB.

JobsFair's own contract is that every interface is a stateless view over
the database; this feed is simply the vault's view. The DB is opened
read-only (mode=ro) so the sidecar can never create or mutate it, and a
missing database renders as a friendly setup line, never an error — the
vault must work with JobsFair not yet installed.

Applying stays in JobsFair (near-one-click, never zero-click); the feed
links to postings and to the local dashboard, it never acts on them. No
guilt surfaces: the pipeline line reports what is live, not what is late.
"""
from __future__ import annotations

import logging
import os
import shlex
import sqlite3
import subprocess
from pathlib import Path

import yaml

from .. import constants, settings, vault

log = logging.getLogger("sidecar.jobsfair")

FEED_PATH = f"{constants.GENERATED}/Feeds/Jobs.md"
PULL_TIMEOUT = 900   # a polite JobSpy pull can take minutes, not tens of them

# The apply worklist, in the order work happens (jobsfair.tracker).
QUEUE_STATUSES = ("queued", "drafted", "applying")
# Live commitments worth a line each.
MOTION_STATUSES = ("applying", "interviewing", "offer")
# Pipeline counts, forward order; archived/rejected are deliberate noise cuts.
PIPELINE = ("inbox", "interested", "queued", "drafted", "applying",
            "applied", "interviewing", "offer")


def jobsfair_home() -> Path:
    """$JOBSFAIR_HOME if set, else ~/.jobsfair — JobsFair's own resolution."""
    return Path(os.environ.get("JOBSFAIR_HOME", "~/.jobsfair")).expanduser()


def db_path() -> Path:
    """Configured path, else <home>/jobsfair.db."""
    cfg = settings.effective().jobsfair
    if cfg.db_path:
        return Path(cfg.db_path).expanduser()
    return jobsfair_home() / "jobsfair.db"


def _connect(path: Path) -> sqlite3.Connection:
    # mode=ro both enforces read-only and refuses to create a missing file.
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def _counts(conn: sqlite3.Connection) -> dict[str, int]:
    rows = conn.execute(
        "SELECT status, COUNT(*) AS n FROM applications GROUP BY status")
    return {r["status"]: r["n"] for r in rows}


def _queue(conn: sqlite3.Connection, limit: int) -> list[sqlite3.Row]:
    marks = ",".join("?" * len(QUEUE_STATUSES))
    return conn.execute(
        f"""SELECT j.title, j.company, j.job_url, a.status,
                   COALESCE(s.stage2_score, s.stage1_score) AS fit
            FROM applications a
            JOIN jobs j ON j.uid = a.job_uid
            LEFT JOIN scores s ON s.job_uid = a.job_uid
            WHERE a.status IN ({marks})
            ORDER BY fit IS NULL, fit DESC, a.updated_at DESC
            LIMIT ?""",
        (*QUEUE_STATUSES, limit)).fetchall()


def _in_motion(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    marks = ",".join("?" * len(MOTION_STATUSES))
    return conn.execute(
        f"""SELECT j.title, j.company, j.job_url, a.status, a.updated_at
            FROM applications a
            JOIN jobs j ON j.uid = a.job_uid
            WHERE a.status IN ({marks})
            ORDER BY a.updated_at DESC""",
        MOTION_STATUSES).fetchall()


def _link(title: str, url: str | None) -> str:
    text = (title or "?").replace("|", "\\|").replace("[", "(").replace("]", ")")
    return f"[{text}]({url})" if url else text


def _fit(v) -> str:
    return f"{float(v):.0f}" if v is not None else "—"


def write_feed() -> str:
    cfg = settings.effective().jobsfair
    path = db_path()
    body = ["## Jobs"]

    if not path.exists():
        body.append(f"*No JobsFair database at `{path}` — run `jobsfair init` "
                    "or set `jobsfair_db` in Settings.*")
        return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})

    try:
        with _connect(path) as conn:
            counts = _counts(conn)
            queue = _queue(conn, cfg.queue_limit)
            motion = _in_motion(conn)
    except sqlite3.Error as e:
        body.append(f"*Couldn't read the JobsFair database at `{path}`: {e}*")
        return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})

    line = " · ".join(f"{s} **{counts[s]}**" for s in PIPELINE if counts.get(s))
    body.append(line or "*Pipeline empty — pull some jobs.*")
    if cfg.dashboard_url:
        body.append(f"[Open JobsFair dashboard]({cfg.dashboard_url})")

    if queue:
        body += ["", "### Queue — best fit first",
                 "| job | company | fit | status |", "|---|---|---|---|"]
        for r in queue:
            body.append(f"| {_link(r['title'], r['job_url'])} | "
                        f"{r['company'] or '—'} | {_fit(r['fit'])} | {r['status']} |")

    if motion:
        body += ["", "### In motion"]
        for r in motion:
            when = str(r["updated_at"] or "")[:10]
            body.append(f"- **{r['status']}** — {_link(r['title'], r['job_url'])}"
                        + (f" at {r['company']}" if r["company"] else "")
                        + (f" ({when})" if when else ""))

    return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})


# ---- headless engine runs (the "job fetching / monitoring" exception) ------
#
# These run JobsFair's own CLI as short-lived subprocesses: RAM is paid only
# for the minutes a pull takes, results land in SQLite exactly as if the
# operator had run the command, and neither `jobsfair serve` nor the Jobs
# workspace needs to be open. Never `apply` — applying stays human.

def search_names() -> list[str]:
    """Saved-search names from <home>/searches.yaml (the `searches:` map)."""
    path = jobsfair_home() / "searches.yaml"
    if not path.exists():
        return []
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as e:
        log.warning("searches.yaml unreadable: %s", e)
        return []
    return sorted((data.get("searches") or {}).keys())


def _cli(*args: str) -> bool:
    cfg = settings.effective().services
    repo = Path(cfg.jobsfair_repo).expanduser()
    if not repo.is_dir():
        log.warning("jobsfair repo %s missing — set jobsfair_repo in Settings", repo)
        return False
    cmd = shlex.split(cfg.jobsfair_cli) + list(args)
    try:
        res = subprocess.run(cmd, cwd=str(repo), timeout=PULL_TIMEOUT,
                             capture_output=True, text=True)
    except (OSError, subprocess.TimeoutExpired) as e:
        log.warning("jobsfair %s failed to run: %s", " ".join(args), e)
        return False
    if res.returncode != 0:
        log.warning("jobsfair %s exited %s: %s", " ".join(args),
                    res.returncode, (res.stderr or res.stdout).strip()[-400:])
        return False
    return True


def run_pulls() -> dict:
    """Pull every saved search, stage-1 rescore, refresh the feed."""
    names = search_names()
    if not names:
        log.info("no saved searches — nothing to pull")
        return {"pulled": [], "scored": False}
    pulled = [n for n in names if _cli("pull", n)]
    scored = _cli("score") if pulled else False
    write_feed()
    log.info("pulled %s/%s searches%s", len(pulled), len(names),
             ", rescored" if scored else "")
    return {"pulled": pulled, "scored": scored}


def run_prune() -> bool:
    """Archive postings gone from the boards (JobsFair's own §4 aging)."""
    ok = _cli("prune")
    if ok:
        write_feed()
    return ok
