"""LinguaStudio bridge (spec §10): one continuously-expanding document per
language, append-only, timestamped, with rhythm lines flowing through the
same pipe. Segmentation itself is NOT done here — rhythm_tab already exists
(§15.13); this endpoint stores its output.
"""
from __future__ import annotations

import datetime as dt
import json
import logging
import re
import urllib.request

from .. import constants, settings, vault

log = logging.getLogger("sidecar.lingua")

LANGUAGES = {"de", "ar", "hu", "es", "zh"}

# Vault codes -> LinguaStudio registry codes (mirrors the lingua-workspace
# plugin's LANGS table — change both in the same commit).
LINGUA_CODES = {"zh": "cmn", "de": "deu", "ar": "ara", "hu": "hun", "es": "spa"}


def language_doc_path(lang: str) -> str:
    return f"{constants.NOTES}/linguistics/Vocabulary — {lang}.md"


_INITIAL = """---
created: {today}
type: note
domain: linguistics
aliases: []
tags: []
generated: false
language: {lang}
---
# Vocabulary — {lang}

Sidecar-appended, append-only (spec §10). Entries carry a timestamp and
source; the generated inventory lives at [[Language Inventory — {lang}]].
"""


def append_entries(lang: str, entries: list[dict], source: str = "") -> int:
    if lang not in LANGUAGES:
        raise ValueError(f"unknown language {lang!r} (know: {sorted(LANGUAGES)})")
    stamp = dt.datetime.now().isoformat(timespec="minutes")
    lines = [f"\n## {stamp}" + (f" — {source}" if source else "") + "\n"]
    for e in entries:
        term = str(e.get("term", "")).strip()
        if not term:
            continue
        parts = [f"- `{term}`"]
        if e.get("reading"):
            parts.append(f"[{e['reading']}]")
        if e.get("gloss"):
            parts.append(f"— {e['gloss']}")
        parts.append(f"({dt.date.today().isoformat()})")
        lines.append(" ".join(parts) + "\n")
        if e.get("rhythm"):
            lines.append("  - rhythm:\n")
            for unit in e["rhythm"]:
                lines.append(f"    - {unit}\n")

    initial = _INITIAL.format(today=dt.date.today().isoformat(), lang=lang)
    vault.append_only(language_doc_path(lang), "".join(lines), initial)
    return sum(1 for e in entries if str(e.get("term", "")).strip())


# ---- audio prefetch (nightly "small task") ---------------------------------
#
# Warm the LinguaStudio audio cache (Forvo→TTS, disk-cached engine-side) for
# recently captured terms, so pushing cards later is instant. Borrows the
# LinguaStudio sidecar through the supervisor: start → resolve → put away.

_ENTRY_LINE = re.compile(r"^- `(?P<term>[^`]+)`.*?\((?P<date>\d{4}-\d{2}-\d{2})\)")

RECENT_DAYS = 7
PREFETCH_CAP = 60   # across all languages — a cache warm-up, not a crawl


def recent_terms(days: int = RECENT_DAYS) -> dict[str, list[str]]:
    """lang -> terms captured within the window, newest first, deduped."""
    cutoff = dt.date.today() - dt.timedelta(days=days)
    out: dict[str, list[str]] = {}
    for lang in sorted(LANGUAGES):
        doc = vault.read(language_doc_path(lang))
        if doc is None:
            continue
        seen: dict[str, dt.date] = {}
        for line in doc.content.splitlines():
            m = _ENTRY_LINE.match(line)
            if not m:
                continue
            try:
                when = dt.date.fromisoformat(m.group("date"))
            except ValueError:
                continue
            if when >= cutoff:
                prev = seen.get(m.group("term"))
                if prev is None or when > prev:
                    seen[m.group("term")] = when
        if seen:
            out[lang] = [t for t, _ in
                         sorted(seen.items(), key=lambda kv: kv[1], reverse=True)]
    return out


def _lingua_base() -> str:
    return settings.effective().services.lingua_health.rsplit("/health", 1)[0]


def audio_prefetch() -> dict:
    """Resolve audio for recent terms via the borrowed LinguaStudio sidecar."""
    from .. import services
    terms = recent_terms()
    if not terms:
        return {"resolved": 0, "failed": 0}
    started_here = services.ensure_for_task("lingua")
    base = _lingua_base()
    resolved = failed = 0
    try:
        budget = PREFETCH_CAP
        for lang, words in terms.items():
            code = LINGUA_CODES[lang]
            for word in words:
                if budget <= 0:
                    break
                budget -= 1
                req = urllib.request.Request(
                    base + "/vocab/audio",
                    data=json.dumps({"word": word, "lang": code}).encode(),
                    headers={"Content-Type": "application/json"})
                try:
                    with urllib.request.urlopen(req, timeout=60) as res:
                        ok = json.loads(res.read()).get("ok")
                    resolved += 1 if ok else 0
                    failed += 0 if ok else 1
                except Exception as e:
                    failed += 1
                    log.debug("audio %s/%s: %s", lang, word, e)
    finally:
        services.release_after_task("lingua", started_here)
    log.info("audio prefetch: %s resolved, %s failed", resolved, failed)
    return {"resolved": resolved, "failed": failed}
