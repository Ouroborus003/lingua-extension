"""RSS/Atom ingestion for dashboard widgets.

Feeds are declared as dashboard widgets in 08 Meta/dashboard.yaml
({type: rss, url: ..., title?: ..., limit?: N}); the scheduler polls them
here and writes one generated feed note per URL, which the rss widget
embeds. Static text only — no images, no motion (§13.5).
"""
from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

import httpx
import yaml

from .. import constants, vault

log = logging.getLogger("sidecar.rss")


def slug(opts: dict) -> str:
    base = opts.get("title") or urlparse(opts.get("url", "")).netloc or "feed"
    return re.sub(r"[^\w\-. ]", "", base).strip() or "feed"


def feed_note_path(opts: dict) -> str:
    return f"{constants.GENERATED}/Feeds/RSS — {slug(opts)}.md"


def _text(el) -> str:
    return (el.text or "").strip() if el is not None else ""


def _parse(xml_text: str) -> list[tuple[str, str]]:
    """Return [(title, link)] for RSS 2.0 or Atom."""
    root = ET.fromstring(xml_text)
    items: list[tuple[str, str]] = []
    ns = {"atom": "http://www.w3.org/2005/Atom"}
    for item in root.iter("item"):  # RSS 2.0
        items.append((_text(item.find("title")), _text(item.find("link"))))
    if not items:  # Atom
        for entry in root.iter("{http://www.w3.org/2005/Atom}entry"):
            title = _text(entry.find("atom:title", ns))
            link_el = entry.find("atom:link[@rel='alternate']", ns)
            if link_el is None:
                link_el = entry.find("atom:link", ns)
            link = link_el.get("href", "") if link_el is not None else ""
            items.append((title, link))
    return items


def _widgets() -> list[dict]:
    p = vault.abs_path(f"{constants.META}/dashboard.yaml")
    if not p.exists():
        return []
    data = yaml.safe_load(p.read_text()) or {}
    return [w for w in data.get("widgets", [])
            if isinstance(w, dict) and w.get("type") == "rss" and w.get("url")]


async def poll() -> dict:
    widgets = _widgets()
    if not widgets:
        return {"skipped": "no rss widgets configured"}
    written = []
    async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
        for opts in widgets:
            try:
                r = await client.get(opts["url"])
                r.raise_for_status()
                items = _parse(r.text)[: int(opts.get("limit", 8))]
            except Exception as e:
                log.warning("feed %s failed: %s", opts["url"], e)
                continue
            body = [f"## {slug(opts)}"]
            body += [f"- [{t or link}]({link})" for t, link in items] or ["*Feed is empty.*"]
            written.append(vault.write_generated(feed_note_path(opts),
                                                 "\n".join(body), {"type": "inbox"}))
    return {"written": written}
