/* LinguaStudio card core v2. Ship as collection media (_ls_core.js); every template loads it.
   Themes · legibility · settings drawer · xiehanzi writing (HanziWriter quiz, stroke counter + voice,
   timer, freehand letter cells, OCR check) · metronome · micro-steps · writing grade.
   Field values are read from hidden DOM nodes, never inlined into JS.
   Never write a bracketed sound-tag literal in this file (Anki rewrites it). ES5 syntax. */
(function () {
  'use strict';
  if (window.__lsCleanup) { try { window.__lsCleanup(); } catch (e) {} window.__lsCleanup = null; }
  var root = document.querySelector('.ls:not([data-ls-ready])');
  if (!root) return;
  root.setAttribute('data-ls-ready', '');

  var PREVIEW = !!window.LS_PREVIEW;
  var side = root.getAttribute('data-side');
  var WRITING = !!root.querySelector('[data-ls-write]');
  var CIRC = ['①', '②', '③', '④', '⑤', '⑥'];
  var NUM = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十',
    '二十一', '二十二', '二十三', '二十四', '二十五', '二十六', '二十七', '二十八', '二十九', '三十'];
  var cleanups = [];
  window.__lsCleanup = function () { cleanups.forEach(function (f) { try { f(); } catch (e) {} }); };

  /* ── Themes ── */
  var THEMES = [
    ['nocturne', 'Nocturne', 'dark'], ['classic', 'Classic', 'dark'], ['sumi', 'Sumi', 'dark'], ['washi', 'Washi', 'dark'],
    ['konstrukt', 'Konstrukt', 'dark'], ['soviet', 'Soviet', 'dark'], ['futurism', 'Futurism', 'dark'], ['terminal', 'Terminal', 'dark'],
    ['lehrbuch', 'Lehrbuch', 'dark'], ['chalk', 'Chalk', 'dark'], ['moss', 'Moss', 'dark'], ['hojicha', 'Hōjicha', 'dark'], ['fog', 'Fog', 'dark'],
    ['paper', 'Paper', 'light'], ['sepia', 'Sepia', 'light'], ['lehrbuch-hell', 'Lehrbuch Hell', 'light'], ['plakat', 'Plakat', 'light']
  ];
  var HERO_ACCENT = { classic: 1, sumi: 1, washi: 1, konstrukt: 1, soviet: 1, futurism: 1, terminal: 1, lehrbuch: 1 };
  var ACCENTS = ['#7c6aff', '#e63946', '#457b9d', '#2a9d8f', '#ca6702', '#6a0572', '#d4a373', '#b5838d'];
  var GRIDS = [['', 'Theme'], ['#f5f0e8', 'Parchment'], ['#ffffff', 'White'], ['#e8edf2', 'Slate'], ['#f0ece6', 'Warm grey'], ['#1e1e2e', 'Dark'], ['#1a1208', 'Ink']];

  /* ── Prefs (one set per device; seeded once from the old xiehanzi keys) ── */
  var KEY = 'ls.prefs.v1';
  var DEF = {
    themeMode: 'split', themeDay: 'paper', themeNight: 'nocturne', theme: 'nocturne', accent: '', scale: 1, tones: true, hc: false, lg: false,
    steps: false, audio: false, autograde: false,
    autoplay: true, mute: false, strokeVoice: true,
    lnPinyin: true, lnZhuyin: true, lnMeaning: true, lnSimp: true, lnTrad: true,
    audioBtn: true, strokeCount: true, outline: false, hints: true, width: 18, canvas: 'md', gridBg: '',
    timer: false, timerDur: 30,
    metro: false, bpm: 80, snd: 'click', vol: 70, countStrokes: false,
    tab: 'look'
  };
  var RANGES = { bpm: [40, 220], vol: [0, 100], timerDur: [5, 120] };
  function legacy() {
    var o = {}, map = {
      lnSimp: '_hw_showSimp', lnTrad: '_hw_showTrad', lnPinyin: '_hw_showPinyin', lnZhuyin: '_hw_showZhuyin', lnMeaning: '_hw_showMeaning',
      strokeCount: '_hw_showStrokeCount', audioBtn: '_hw_showAudioBtn', outline: '_hw_outline', hints: '_hw_hints', width: '_hw_drawWidth',
      strokeVoice: '_hw_strokeAudio', mute: '_hw_muteAll', timer: '_hw_timerEnabled', timerDur: '_hw_timerDuration', canvas: '_hw_canvasSize',
      tones: '_hw_showToneColors', bpm: '_lsm_bpm', vol: '_lsm_vol', snd: '_lsm_snd', countStrokes: '_lsm_ccb'
    };
    for (var k in map) { try { var v = localStorage.getItem(map[k]); if (v !== null) o[k] = JSON.parse(v); } catch (e) {} }
    try { if (localStorage.getItem('hs_autoplay') === 'false') o.autoplay = false; } catch (e) {}
    return o;
  }
  function loadPrefs() {
    var o = window.LS_PREFS_OVERRIDE;
    if (!o) { try { var raw = localStorage.getItem(KEY); o = raw ? JSON.parse(raw) : legacy(); } catch (e) { o = {}; } }
    o = o || {};
    var p = {}; for (var k in DEF) p[k] = k in o ? o[k] : DEF[k];
    if (!('theme' in o) && o.mode && o.mode !== 'auto') p.theme = o.mode === 'light' ? 'paper' : 'nocturne';
    if (!('themeMode' in o) && o.theme && o.theme !== 'auto') p.themeMode = 'one';
    if (!themeById(p.theme)) p.theme = 'nocturne';
    p._open = !!o._open; p._grade = o._grade;
    return p;
  }
  function savePrefs() {
    var c = {}; for (var k in DEF) c[k] = P[k];
    if (window.LS_PREFS_OVERRIDE) { window.LS_PREFS_OVERRIDE = c; return; }
    try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {}
  }
  var P = loadPrefs();

  /* ── Helpers ── */
  function $(s, e) { return (e || root).querySelector(s); }
  function $$(s, e) { return Array.prototype.slice.call((e || root).querySelectorAll(s)); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html) e.innerHTML = html; return e; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function plain(e) { var d = document.createElement('div'); d.innerHTML = e.innerHTML.replace(/<br\s*\/?>/gi, '\n').replace(/<\/(div|p|li)>/gi, '\n'); return d.textContent.replace(/[ \t\u00a0]+/g, ' ').trim(); }
  function field(n) { var e = $('.ls-f [data-f="' + n + '"]'); return e ? plain(e) : ''; }
  function getVar(n) { return getComputedStyle(root).getPropertyValue(n).trim(); }
  function mkBtn(label, fn) { var b = el('button', 'ls-btn'); b.type = 'button'; b.textContent = label; b.addEventListener('click', function () { fn(b); }); return b; }
  function loadScript(src) { return new Promise(function (res, rej) { var s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); }); }
  var CFG = (function () { try { return JSON.parse(field('WriteCfg') || '{}') || {}; } catch (e) { return {}; } })();

  /* ── Characters: code-point aware; CJK (all planes), kana, hangul are writable ── */
  function splitChars(s) {
    var out = [], i = 0;
    while (i < s.length) {
      var hi = s.charCodeAt(i), ch = s.charAt(i);
      if (hi >= 0xD800 && hi <= 0xDBFF && i + 1 < s.length) { var lo = s.charCodeAt(i + 1); if (lo >= 0xDC00 && lo <= 0xDFFF) { ch = s.substring(i, i + 2); i++; } }
      out.push(ch); i++;
    }
    return out;
  }
  function writable(ch) {
    var cp = ch.charCodeAt(0);
    if (cp >= 0xD800 && cp <= 0xDBFF && ch.length === 2) cp = (cp - 0xD800) * 0x400 + (ch.charCodeAt(1) - 0xDC00) + 0x10000;
    return (cp >= 0x4E00 && cp <= 0x9FFF) || (cp >= 0x3400 && cp <= 0x4DBF) || (cp >= 0x20000 && cp <= 0x2A6DF) ||
      (cp >= 0x2A700 && cp <= 0x2B73F) || (cp >= 0x3040 && cp <= 0x309F) || (cp >= 0x30A0 && cp <= 0x30FF) || (cp >= 0xAC00 && cp <= 0xD7A3);
  }

  /* ── Pinyin ── */
  var VW = 'aeiouüvāáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ';
  var MARK = { 1: 'āēīōūǖ', 2: 'áéíóúǘ', 3: 'ǎěǐǒǔǚ', 4: 'àèìòùǜ' };
  var SYL = new RegExp('(?:zh|ch|sh|[bpmfdtnlgkhjqxrzcsyw])?[' + VW + ']+(?:ng(?![' + VW + '])|n(?![' + VW + '])|r(?![' + VW + ']))?[1-5]?', 'gi');
  function toneOf(s) {
    var m = s.match(/[1-5]$/); if (m) return +m[0];
    var l = s.toLowerCase();
    for (var t = 1; t <= 4; t++) for (var i = 0; i < l.length; i++) if (MARK[t].indexOf(l[i]) >= 0) return t;
    return 5;
  }
  function colorPinyin(text) {
    var out = '', last = 0, m; SYL.lastIndex = 0;
    while ((m = SYL.exec(text))) { out += esc(text.slice(last, m.index)) + '<span class="t' + toneOf(m[0]) + '">' + esc(m[0]) + '</span>'; last = m.index + m[0].length; }
    return out + esc(text.slice(last));
  }
  function numToMark(s) {
    return s.replace(/([a-zü:]+)([1-5])/gi, function (m, syl, t) {
      t = +t; syl = syl.replace(/u:|v/gi, 'ü'); if (t === 5) return syl;
      var i = syl.search(/[ae]/i); if (i < 0) i = syl.search(/ou/i);
      if (i < 0) for (var k = syl.length - 1; k >= 0; k--) if ('aeiouü'.indexOf(syl[k].toLowerCase()) >= 0) { i = k; break; }
      if (i < 0) return syl;
      var ch = MARK[t]['aeiouü'.indexOf(syl[i].toLowerCase())];
      if (syl[i] !== syl[i].toLowerCase()) ch = ch.toUpperCase();
      return syl.slice(0, i) + ch + syl.slice(i + 1);
    });
  }

  /* ── Meaning: CC-CEDICT glosses → senses + measure words ── */
  function renderMeaning(e) {
    var raw = plain(e); if (!raw) return;
    var short = e.getAttribute('data-ls-meaning') === 'short';
    var parts = raw.split(/\s*(?:\/|;|\n)\s*/), senses = [], dropped = [], mw = [];
    parts.forEach(function (p) {
      p = p.trim(); if (!p) return;
      if (/^CL:/i.test(p)) {
        p.slice(3).split(',').forEach(function (c) { var m = c.trim().match(/^([^\[|]+)(?:\|([^\[]+))?\[([^\]]+)\]/); if (m) mw.push({ h: (m[2] || m[1]).trim(), p: numToMark(m[3]) }); });
        return;
      }
      p = p.replace(/([^\s\[|,]+)\|([^\s\[,]+)\[([^\]]+)\]/g, function (m, a, b, py) { return b + ' ' + numToMark(py); })
           .replace(/([\u3400-\u9fff]+)\[([^\]]+)\]/g, function (m, h, py) { return h + ' ' + numToMark(py); });
      (/^(used in|variant of|see also|see )/i.test(p) ? dropped : senses).push(p);
    });
    if (!senses.length) senses = dropped;
    if (!senses.length) return;
    var html = '<div class="ls-gloss">' + esc(senses[0]) + '</div>';
    if (!short) {
      if (senses.length > 1) html += '<ul class="ls-senses">' + senses.slice(1, 5).map(function (s) { return '<li>' + esc(s) + '</li>'; }).join('') + '</ul>';
      if (mw.length) html += '<div class="ls-mw">' + mw.map(function (w) { return '<span class="ls-chip"><b>MW</b><span>' + esc(w.h) + '</span>' + esc(w.p) + '</span>'; }).join('') + '</div>';
    }
    e.innerHTML = html;
  }
  function markIn(e, word, rep) {
    var t = plain(e); if (!word || t.indexOf(word) < 0) { e.textContent = t; return; }
    e.innerHTML = t.split(word).map(esc).join(rep ? rep(word) : '<mark>' + esc(word) + '</mark>');
  }
  function isTonal() {
    if (CFG.tones === false) return false;
    if (CFG.tones === true) return true;
    if (CFG.writeModule && CFG.writeModule !== 'hanziwriter') return false;
    if (/_ja_|_ko_/.test(CFG.countPrefix || '')) return false;
    var s = field('Simplified');
    return !/[\u3040-\u30ff\uac00-\ud7a3]/.test(s) && (/[\u3400-\u9fff]/.test(s) || !s);
  }
  function setupText() {
    var simp = field('Simplified'), trad = field('Traditional'), py = field('Pinyin'), zy = field('Zhuyin'), tonal = isTonal();
    var n = splitChars(simp).filter(writable).length;
    root.setAttribute('data-len', String(Math.min(Math.max(n, 1), 3)));
    $$('[data-ls-tone]').forEach(function (e) { var t = plain(e); e.innerHTML = tonal ? colorPinyin(t) : esc(t); });
    $$('[data-ls-meaning]').forEach(renderMeaning);
    $$('[data-ls-mark]').forEach(function (e) { markIn(e, simp); });
    $$('[data-ls-markpy]').forEach(function (e) {
      var t = plain(e), i = py ? t.toLowerCase().indexOf(py.toLowerCase()) : -1, w;
      if (i >= 0) { w = t.slice(i, i + py.length); w = tonal ? colorPinyin(w) : esc(w); }
      e.innerHTML = i < 0 ? esc(t) : esc(t.slice(0, i)) + '<mark>' + w + '</mark>' + esc(t.slice(i + py.length));
    });
    $$('[data-ls-hanzi]').forEach(function (e) {
      var cs = splitChars(plain(e)), sy = (py || '').match(SYL) || [], k = 0;
      var ok = tonal && sy.length === cs.filter(writable).length;
      e.innerHTML = cs.map(function (c) { if (!writable(c)) return esc(c); var t = ok ? toneOf(sy[k++]) : 0; return '<span class="ls-ch' + (t ? ' ls-ct' + t : '') + '">' + esc(c) + '</span>'; }).join('');
    });
    $$('[data-ls-cloze]').forEach(function (e) { markIn(e, simp, function (w) { return '<span class="ls-blank" style="--n:' + splitChars(w).length + '" aria-label="blank"></span>'; }); });
    $$('[data-ls-sub]').forEach(function (e) { e.textContent = [zy, trad && trad !== simp ? trad : ''].filter(Boolean).join(' · '); });
    $$('.ls-trad, [data-line="trad"]').forEach(function (e) { if (!trad || trad === simp) e.setAttribute('data-empty', ''); });
  }

  /* ── Colour ── */
  function hexRgb(h) {
    h = String(h || '').replace('#', '').trim();
    if (h.length === 3) h = h.replace(/(.)/g, '$1$1');
    if (!/^[0-9a-f]{6}/i.test(h)) return null;
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  function lum(c) { var a = c.map(function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }); return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2]; }
  function contrast(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function mix(a, b, t) { return [0, 1, 2].map(function (i) { return Math.round(a[i] + (b[i] - a[i]) * t); }); }
  function toHex(c) { return '#' + c.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); }
  function readable(fg, bg, min) { var to = lum(bg) < 0.4 ? [255, 255, 255] : [0, 0, 0], c = fg; for (var i = 1; i <= 20 && contrast(c, bg) < min; i++) c = mix(fg, to, i / 20); return c; }

  function isNight() { var b = document.body; return /\b(nightMode|night_mode)\b/.test((b ? b.className : '') + ' ' + document.documentElement.className); }
  function themeById(id) { for (var i = 0; i < THEMES.length; i++) if (THEMES[i][0] === id) return THEMES[i]; return null; }
  var OVR = ['--label', '--dot', '--act', '--act-bd', '--act-ink', '--act-hi', '--on-bg', '--on-ink', '--hero', '--cell', '--stroke', '--draw', '--outline', '--grid', '--grid-edge'];
  function applyTheme() {
    var id = P.themeMode === 'one' ? P.theme : (isNight() ? P.themeNight : P.themeDay);
    if (!themeById(id)) id = isNight() ? 'nocturne' : 'paper';
    root.setAttribute('data-theme', id); root.setAttribute('data-tone', themeById(id)[2]);
    OVR.forEach(function (k) { root.style.removeProperty(k); });
    var bg = hexRgb(getVar('--bg')) || [15, 17, 21];
    var a = !P.hc && hexRgb(P.accent);
    if (a) {
      var lab = toHex(readable(a, bg, 4.5)), ink = contrast(a, [255, 255, 255]) >= contrast(a, [16, 16, 16]) ? '#ffffff' : '#101010';
      root.style.setProperty('--label', lab); root.style.setProperty('--dot', lab); root.style.setProperty('--act-hi', lab);
      root.style.setProperty('--act', P.accent); root.style.setProperty('--act-bd', P.accent); root.style.setProperty('--act-ink', ink);
      root.style.setProperty('--on-bg', P.accent); root.style.setProperty('--on-ink', ink);
      if (HERO_ACCENT[id]) root.style.setProperty('--hero', toHex(readable(a, bg, 3)));
    }
    var g = !P.hc && hexRgb(P.gridBg);
    if (g) {
      var light = lum(g) > 0.4;
      root.style.setProperty('--cell', P.gridBg);
      root.style.setProperty('--stroke', light ? '#3a3a3a' : '#e8e4da');
      root.style.setProperty('--draw', light ? '#1f1f1f' : '#ffffff');
      root.style.setProperty('--outline', light ? '#d9d4ca' : '#3d3d50');
      root.style.setProperty('--grid', light ? 'rgba(0,0,0,.12)' : 'rgba(255,255,255,.10)');
      root.style.setProperty('--grid-edge', light ? 'rgba(0,0,0,.25)' : 'rgba(255,255,255,.22)');
    }
    if (document.body) document.body.style.background = getVar('--bg');
  }

  /* ── Audio: note audio → device speech fallback ── */
  function speak(text, after, lang) {
    if (!text || !window.speechSynthesis) return false;
    try { var u = new SpeechSynthesisUtterance(text); u.lang = lang || 'zh-CN'; u.rate = 0.9; if (after) u.onend = after; speechSynthesis.speak(u); return true; } catch (e) { return false; }
  }
  function hasAudio() { var b = $('.ls-audio'); return !!(b && b.querySelector('audio, a')); }
  function play(btn, tts) {
    if (btn) { btn.classList.add('is-playing'); setTimeout(function () { btn.classList.remove('is-playing'); }, 900); }
    var box = $('.ls-audio'), a = box && box.querySelector('audio');
    if (a) { try { a.currentTime = 0; var pr = a.play(); if (pr && pr.catch) pr.catch(function () {}); return true; } catch (e) {} }
    var link = box && box.querySelector('a');
    if (link) { try { link.click(); return true; } catch (e) {} }
    if (tts === false) return false;
    if (window.speechSynthesis) speechSynthesis.cancel();
    return speak(field('Simplified'));
  }
  function setupAudio() {
    $$('[data-ls-play]').forEach(function (b) { b.addEventListener('click', function () { play(b, true); }); });
    if (PREVIEW || P.mute || !root.hasAttribute('data-af') || (!P.autoplay && !P.audio)) return;
    var sent = side === 'back' && P.audio ? field('Sentence') : '';
    var t = setTimeout(function () {
      var has = hasAudio();
      if (has && P.autoplay) play(null, false);
      else if (!has && P.audio) { speak(field('Simplified'), sent ? function () { speak(sent); } : null); return; }
      if (sent) setTimeout(function () { speak(sent); }, has ? 1400 : 300);
    }, 300);
    cleanups.push(function () { clearTimeout(t); if (window.speechSynthesis) speechSynthesis.cancel(); });
  }

  /* ── Micro-steps ── */
  function setupSteps() {
    var steps = $$('[data-step]').filter(function (s) { return !s.hidden; }), old = $('.ls-next');
    if (old) old.parentNode.removeChild(old);
    steps.forEach(function (s, i) {
      var l = $('.ls-label', s); if (l) l.setAttribute('data-n', CIRC[i] || '');
      s.setAttribute('data-veil', (CIRC[i] || '') + ' ' + (l ? l.textContent : '') + ' · tap below');
      s.classList.remove('ls-veil');
    });
    if (side !== 'back' || !P.steps || steps.length < 2) return;
    var n = 1, wrap = el('div', 'ls-next', '<div class="ls-pips">' + steps.map(function () { return '<i></i>'; }).join('') + '</div><button type="button"></button>');
    var btn = $('button', wrap), pips = $$('.ls-pips i', wrap);
    function upd() {
      steps.forEach(function (s, i) { s.classList.toggle('ls-veil', i >= n); });
      pips.forEach(function (p, i) { p.classList.toggle('on', i < n); });
      var l = steps[n] && $('.ls-label', steps[n]);
      btn.textContent = 'Reveal ' + (CIRC[n] || '') + ' ' + (l ? l.textContent.toLowerCase() : '');
      wrap.hidden = n >= steps.length;
    }
    btn.addEventListener('click', function () { n++; upd(); });
    root.insertBefore(wrap, $('.ls-f')); upd();
  }

  /* ── Metronome (xiehanzi engine: Web Audio tick, drum, counts strokes aloud) ── */
  var M = { on: false, beat: 0, t: null, ctx: null, sc: 8 };
  function actx() {
    if (!M.ctx) { var C = window.AudioContext || window.webkitAudioContext; if (!C) return null; M.ctx = new C(); }
    if (M.ctx.state === 'suspended') { try { M.ctx.resume(); } catch (e) {} }
    return M.ctx;
  }
  function pulse(accent) {
    [$('.ls-metro'), sheet && $('.ls-drum', sheet)].forEach(function (e) {
      if (!e) return; e.classList.remove('hit', 'hit-a'); void e.offsetWidth; e.classList.add(accent ? 'hit-a' : 'hit');
    });
  }
  function tick(accent) {
    pulse(accent);
    if (P.mute || P.snd === 'off') return;
    try {
      var c = actx(); if (!c) return;
      var o = c.createOscillator(), g = c.createGain(), f, d, ty, v = P.vol / 100;
      o.connect(g); g.connect(c.destination);
      if (P.snd === 'wood') { ty = 'sine'; f = accent ? 350 : 220; d = 0.18; }
      else if (P.snd === 'soft') { ty = 'sine'; f = accent ? 660 : 480; d = 0.14; }
      else if (P.snd === 'bell') { ty = 'sine'; f = accent ? 1047 : 784; d = 0.5; }
      else { ty = 'square'; f = accent ? 1100 : 700; d = 0.06; }
      o.type = ty; o.frequency.value = f;
      g.gain.setValueAtTime(Math.max(0.001, accent ? v * 0.9 : v * 0.5), c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + d);
      o.start(c.currentTime); o.stop(c.currentTime + d + 0.02);
    } catch (e) {}
  }
  function countLang() { return /_ja_/.test(CFG.countPrefix || '') ? 'ja-JP' : 'zh-CN'; }
  function sayNum(n) {
    if (P.mute || !window.speechSynthesis) return;
    try { var u = new SpeechSynthesisUtterance((n <= 30 && NUM[n]) || String(n)); u.lang = countLang(); u.rate = 0.95; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) {}
  }
  function mLabel(t) { var e = sheet && $('[data-mlbl]', sheet); if (e) e.textContent = t; }
  function step() {
    if (!M.on) return;
    var s = P.countStrokes ? (M.sc || 8) : (window.__lsExtTotal || 4), acc = M.beat === 0;
    tick(acc);
    if (P.countStrokes) { var n = M.beat % s + 1; mLabel('Stroke ' + n + ' / ' + s); sayNum(n); }
    else mLabel('Beat ' + (M.beat % s + 1) + ' / ' + s);
    var b1 = M.beat + 1; M.beat = (M.beat + 1) % s;
    window._lsmBeatNum = M.beat; window._lsmAccent = acc;
    if (window.__lsCascadeBeat) { try { window.__lsCascadeBeat(acc, b1); } catch (e) {} }
    M.t = setTimeout(step, Math.round(60000 / (window.__lsExtBpm || P.bpm)));
  }
  function metroStart() { if (M.on) return; M.on = true; M.beat = 0; step(); }
  function metroStop() { M.on = false; clearTimeout(M.t); mLabel(''); }
  window._metroCountStrokes = function () {
    if (!P.countStrokes) return;
    tick(false); var s = M.sc || 8, n = M.beat % s + 1; mLabel('Stroke ' + n + ' / ' + s); sayNum(n); M.beat = (M.beat + 1) % s;
  };
  window._lsmBeat = function (accent) {
    tick(accent);
    if (P.countStrokes) { var s = M.sc || 8, n = M.beat % s + 1; mLabel('Stroke ' + n + ' / ' + s); sayNum(n); M.beat = (M.beat + 1) % s; }
    else { var bc = window.__lsExtTotal || 4; mLabel('Beat ' + (M.beat % bc + 1)); M.beat = (M.beat + 1) % bc; }
  };
  window._lsmSay = function (t) { speak(t, null, countLang()); };
  window._lsmStop = metroStop;
  cleanups.push(metroStop);
  function setupMetro() {
    var bar = $('.ls-metro'), tag = $('.ls-metro-tag');
    if (P.metro) {
      if (!bar) { bar = el('div', 'ls-metro'); root.appendChild(bar); }
      if (!tag) { tag = el('span', 'ls-metro-tag'); var r = $('.ls-bar-r'); if (r) r.insertBefore(tag, r.firstChild); }
      tag.textContent = '♩ ' + P.bpm;
      metroStart();
    } else {
      if (bar) bar.parentNode.removeChild(bar);
      if (tag) tag.parentNode.removeChild(tag);
      metroStop();
    }
  }

  /* ── Writing grade → Anki rating ──
     Scored against total strokes: 0 slips Easy · ≤20% Good · ≤45% Hard · more, Reveal or time-out Again.
     Minimums of 1 (Good) and 2 (Hard) keep short characters fair. */
  var GKEY = 'ls.grade.v1', GNAME = { 1: 'Again', 2: 'Hard', 3: 'Good', 4: 'Easy' };
  function limits(strokes) { return { good: Math.max(1, Math.round(strokes * 0.2)), hard: Math.max(2, Math.round(strokes * 0.45)) }; }
  function gradeFor(slips, strokes) { var l = limits(strokes); return slips === 0 ? 4 : slips <= l.good ? 3 : slips <= l.hard ? 2 : 1; }
  function storeGrade(g) { if (side !== 'front') return; g.word = field('Simplified'); g.t = Date.now(); try { localStorage.setItem(GKEY, JSON.stringify(g)); } catch (e) {} }
  function clearGrade() { if (side !== 'front') return; try { localStorage.removeItem(GKEY); } catch (e) {} }
  function readGrade() {
    if (P._grade) return P._grade;
    var g; try { g = JSON.parse(localStorage.getItem(GKEY) || 'null'); } catch (e) {}
    try { localStorage.removeItem(GKEY); } catch (e) {}
    return g && g.word === field('Simplified') && Date.now() - g.t < 15 * 60000 ? g : null;
  }
  function answerFn(n) {
    if (PREVIEW) return null;
    if (typeof pycmd === 'function') return function () { pycmd('ease' + n); };
    if (typeof window['buttonAnswerEase' + n] === 'function') return function () { window['buttonAnswerEase' + n](); };
    return null;
  }
  function flip() {
    if (PREVIEW) return;
    if (typeof pycmd === 'function') { try { pycmd('ans'); } catch (e) {} return; }
    if (typeof window.showAnswer === 'function') { try { window.showAnswer(); } catch (e) {} return; }
    var b = document.querySelector('#ansbutla, .show-answer'); if (b) b.click();
  }
  function slipTxt(n) { return n === 1 ? '1 slip' : n + ' slips'; }
  function setupGrade() {
    var gEl = $('[data-ls-grade]'); if (!gEl) return;
    var g = readGrade(); if (!g) { gEl.hidden = true; return; }
    var name = GNAME[g.grade], go = answerFn(g.grade), timer = null;
    var why = g.timeout ? 'time ran out' : g.revealed ? 'answer revealed' : g.self ? 'self-check' :
      g.ocr ? 'handwriting check' + (g.tries ? ' after ' + g.tries + (g.tries === 1 ? ' retry' : ' retries') : '') :
      slipTxt(g.slips) + (g.strokes ? ' in ' + g.strokes + ' strokes' : '');
    gEl.className = 'ls-block ls-grade g' + g.grade;
    gEl.innerHTML = '<div class="ls-label">Writing check</div><div class="ls-grade-row"><b>' + name + '</b><span>' + esc(why) + '</span></div>' +
      (go ? '<button type="button" class="ls-grade-btn">Rate ' + name + '</button>' : '<small>Tap <b>' + name + '</b> in Anki\'s answer buttons.</small>');
    var btn = $('.ls-grade-btn', gEl); if (!btn) return;
    btn.addEventListener('click', function () { if (timer) { clearInterval(timer); timer = null; btn.textContent = 'Rate ' + name; return; } go(); });
    if (P.autograde) {
      var s = 3; btn.textContent = 'Rating ' + name + ' in ' + s + '… tap to cancel';
      timer = setInterval(function () { s--; if (s <= 0) { clearInterval(timer); timer = null; go(); } else btn.textContent = 'Rating ' + name + ' in ' + s + '… tap to cancel'; }, 1000);
      cleanups.push(function () { if (timer) clearInterval(timer); });
    }
  }

  /* ── Answer lines on writing fronts ── */
  var LINES = { pinyin: 'lnPinyin', zhuyin: 'lnZhuyin', meaning: 'lnMeaning', simp: 'lnSimp', trad: 'lnTrad' };
  function applyLines() {
    if (side !== 'front') return;
    $$('[data-line]').forEach(function (e) { var k = LINES[e.getAttribute('data-line')]; e.hidden = e.hasAttribute('data-empty') || (k ? !P[k] : false); });
    $$('[data-audio-btn]').forEach(function (b) { b.hidden = !P.audioBtn; });
  }
  function showAnswer() {
    var a = $('[data-ls-answer]'); if (a) { a.hidden = false; applyLines(); }
    var w = field('Simplified'); $$('.ls-blank').forEach(function (b) { var m = el('mark'); m.textContent = w; b.parentNode.replaceChild(m, b); });
  }

  /* ── Completion: done sound + toast (做得好！or WriteCfg.congratsText) ── */
  function countPrefix() { return CFG.countPrefix || '_cnt_'; }
  function toast(text) {
    var old = $('.ls-toast'); if (old) old.parentNode.removeChild(old);
    var t = el('div', 'ls-toast'); t.textContent = text; root.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 560); }, 2800);
  }
  function celebrate(def, sound) {
    var text = CFG.congratsText || def;
    if (!sound || P.mute || PREVIEW) return toast(text);
    var shown = false, a;
    function show() { if (!shown) { shown = true; toast(text); } }
    try { a = new Audio(countPrefix() + 'done.mp3'); a.addEventListener('ended', function () { setTimeout(show, 200); }); a.onerror = show; var p = a.play(); if (p && p.catch) p.catch(show); } catch (e) { show(); }
    setTimeout(show, 1200);
  }

  /* ── Stroke counting voice: media _cnt_<n>.mp3 (WriteCfg.countPrefix), speech fallback ── */
  var voice = null;
  function strokeVoice(n) {
    if (!P.strokeVoice || P.mute || P.countStrokes) return;
    if (PREVIEW) return sayNum(n);
    try {
      voice = voice || new Audio();
      voice.pause(); voice.onerror = function () { voice.onerror = null; sayNum(n); };
      voice.src = countPrefix() + n + '.mp3'; voice.currentTime = 0;
      var p = voice.play(); if (p && p.catch) p.catch(function () {});
    } catch (e) { sayNum(n); }
  }

  /* ── HanziWriter + stroke data (media first: _hanzi-writer.min.js, _<char>.json) ── */
  var HW_CDN = 'https://cdn.jsdelivr.net/npm/hanzi-writer@3.7.3/dist/hanzi-writer.min.js';
  var HWD_CDN = 'https://cdn.jsdelivr.net/npm/hanzi-writer-data@2.0.1/';
  var STROKES = {};
  function getHW() {
    if (window.HanziWriter) return Promise.resolve(window.HanziWriter);
    var p = PREVIEW ? loadScript(HW_CDN) : loadScript('_hanzi-writer.min.js').catch(function () { return loadScript(HW_CDN); });
    return p.then(function () { return window.HanziWriter; });
  }
  function xhrJson(url, ok, fail) {
    var x = new XMLHttpRequest(); x.open('GET', url);
    x.onload = function () { if ((x.status === 200 || x.status === 0) && x.responseText) { try { ok(JSON.parse(x.responseText)); return; } catch (e) {} } fail(); };
    x.onerror = fail; x.send();
  }
  function loadChar(ch, ok, fail) {
    function done(d) { if (d && d.strokes) STROKES[ch] = d.strokes.length; ok(d); }
    if (window._hwPreviewData && window._hwPreviewData[ch]) { setTimeout(function () { done(window._hwPreviewData[ch]); }, 0); return; }
    function cdn() { xhrJson(HWD_CDN + encodeURIComponent(ch) + '.json', done, fail || function () {}); }
    if (PREVIEW) return cdn();
    xhrJson('_' + ch + '.json', done, cdn);
  }
  function colors() { return { stroke: getVar('--stroke'), outline: getVar('--outline'), draw: getVar('--draw'), ok: getVar('--ok'), hi: getVar('--act-hi') }; }
  function canvasPx() { var base = { sm: 180, md: 228, lg: 272 }[P.canvas] || 228; return Math.max(140, Math.min(base, (window.innerWidth || 360) - 56)); }

  function hanziQuiz(box, chars) {
    var size = canvasPx(), n = chars.length, cur = 0, miss = 0, done = false, dead = false, writer = null, timerT = null, strokeNum = 0, strokeTot = 0;
    var trace = P.outline;
    var seq = n > 1 ? el('div', 'ls-seq') : null;
    var block = el('div', 'ls-wblock'), cell = el('div', 'ls-cell'), counter = el('div', 'ls-counter', '<div class="ls-ctrack"><i></i></div><div class="ls-clbl"></div>');
    var tbar = el('div', 'ls-tbar', '<i></i>'), status = el('div', 'ls-status'), ctrl = el('div', 'ls-ctrl');
    cell.style.width = cell.style.height = size + 'px'; counter.style.width = tbar.style.width = size + 'px';
    block.appendChild(cell); block.appendChild(counter);
    if (seq) { chars.forEach(function () { seq.appendChild(el('span', 'ls-slot')); }); box.appendChild(seq); }
    box.appendChild(block); box.appendChild(tbar); box.appendChild(status); box.appendChild(ctrl);
    tbar.hidden = true;
    function sync() { counter.hidden = !P.strokeCount; block.classList.toggle('nocount', !P.strokeCount); }
    function slots() { if (!seq) return; $$('.ls-slot', seq).forEach(function (s, i) { s.className = 'ls-slot' + (i < cur || done ? ' done' : i === cur ? ' on' : ''); s.textContent = i < cur || done ? chars[i] : ''; }); }
    function setLabel(k, t) {
      var lbl = $('.ls-clbl', counter), fill = $('.ls-ctrack i', counter);
      if (!t) { lbl.textContent = ''; lbl.classList.remove('quiet'); fill.style.width = '0%'; return; }
      if (k === 0) { lbl.textContent = '· ' + (NUM[t] || t) + ' ·'; lbl.classList.add('quiet'); fill.style.width = '0%'; return; }
      lbl.classList.remove('quiet'); lbl.textContent = (NUM[k] || k) + ' · ' + (NUM[t] || t); fill.style.width = Math.round(k / t * 100) + '%';
    }
    function statusText() {
      status.classList.remove('ok');
      status.textContent = (n > 1 ? 'Character ' + (cur + 1) + ' of ' + n : trace ? 'Trace the character' : 'Write from memory') + (miss ? ' · ' + slipTxt(miss) : '');
    }
    function stopTimer(hide) { if (timerT) { clearInterval(timerT); timerT = null; } if (hide) tbar.hidden = true; }
    function startTimer() {
      stopTimer();
      if (!P.timer || side !== 'front') { tbar.hidden = true; return; }
      var fill = $('i', tbar), t0 = Date.now(), dur = P.timerDur * 1000;
      tbar.hidden = false; fill.className = ''; fill.style.width = '100%';
      timerT = setInterval(function () {
        var e = Date.now() - t0, pct = Math.max(0, 100 - e / dur * 100);
        fill.style.width = pct + '%'; fill.className = pct < 15 ? 'crit' : pct < 40 ? 'warn' : '';
        if (e >= dur) { stopTimer(); reveal('timeout'); setTimeout(flip, 600); }
      }, 100);
    }
    function mk(i) {
      cell.innerHTML = ''; strokeNum = 0; strokeTot = STROKES[chars[i]] || 0; setLabel(0, strokeTot);
      var c = colors(), failed = false;
      getHW().then(function (HW) {
        if (dead || cur !== i) return;
        writer = HW.create(cell, chars[i], {
          width: size, height: size, padding: Math.round(size * 0.05), showCharacter: false, showOutline: P.outline,
          strokeColor: c.stroke, outlineColor: c.outline, drawingColor: c.draw, drawingWidth: Math.round(P.width * size / 220),
          showHintAfterMisses: P.hints ? 2 : false, highlightOnComplete: true, highlightColor: c.ok,
          strokeAnimationSpeed: 1.2, delayBetweenStrokes: 160,
          charDataLoader: function (ch, onLoad, onErr) {
            loadChar(ch, function (d) { strokeTot = STROKES[ch] || 0; setLabel(0, strokeTot); M.sc = strokeTot || M.sc; onLoad(d); }, function () {
              if (failed) return; failed = true;
              cell.innerHTML = '<div class="ls-static" style="font-size:' + Math.round(size * 0.7) + 'px">' + esc(ch) + '</div>';
              setTimeout(function () { advance(); }, 400);
              if (onErr) onErr();
            });
          }
        });
        writer.quiz({
          onMistake: function () { miss++; statusText(); },
          onCorrectStroke: function () { strokeNum++; strokeVoice(strokeNum); setLabel(strokeNum, strokeTot); if (window._metroCountStrokes) window._metroCountStrokes(); },
          onComplete: function () { block.classList.add('ls-done'); stopTimer(); setTimeout(advance, 450); }
        });
      }).catch(function () {
        if (dead) return;
        status.textContent = 'Stroke data is not available offline';
        freehandWord(box, field('Simplified'), CFG, false);
        block.hidden = true; ctrl.hidden = true; if (seq) seq.hidden = true;
      });
      statusText(); startTimer();
    }
    function advance() {
      if (dead || done) return;
      cur++;
      if (cur < n) { block.classList.remove('ls-done'); slots(); mk(cur); return; }
      done = true; stopTimer(true); slots();
      var total = chars.reduce(function (a, ch) { return a + (STROKES[ch] || 8); }, 0), g = gradeFor(miss, total);
      status.textContent = (miss ? 'Done · ' + slipTxt(miss) : 'Done · clean') + ' → ' + GNAME[g];
      status.classList.add('ok');
      storeGrade({ grade: g, slips: miss, strokes: total });
      showAnswer(); celebrate('做得好！', true);
    }
    function reveal(why) {
      if (done || dead) return;
      done = true; stopTimer(true); if (writer) { try { writer.cancelQuiz(); } catch (e) {} }
      block.hidden = true; if (seq) seq.hidden = true;
      var r = el('div', 'ls-revealed'); r.setAttribute('lang', 'zh-CN'); r.textContent = chars.join(''); box.insertBefore(r, tbar);
      status.textContent = (why === 'timeout' ? 'Time is up' : 'Revealed') + ' → Again'; status.classList.remove('ok');
      storeGrade(why === 'timeout' ? { grade: 1, slips: miss, timeout: true } : { grade: 1, slips: miss, revealed: true });
      showAnswer();
    }
    var ob = mkBtn('Outline', function () { P.outline = !P.outline; savePrefs(); setupWriters(); syncSheet(); });
    ob.setAttribute('aria-pressed', String(P.outline));
    ctrl.appendChild(ob);
    ctrl.appendChild(mkBtn('↻ Retry', function () { clearGrade(); setupWriters(); }));
    ctrl.appendChild(mkBtn('Reveal', function () { reveal('reveal'); }));
    clearGrade(); sync(); slots(); mk(0);
    return {
      sync: sync, retry: function () { clearGrade(); setupWriters(); }, reveal: function () { reveal('reveal'); },
      destroy: function () { dead = true; stopTimer(); if (writer) { try { writer.cancelQuiz(); } catch (e) {} } }
    };
  }

  function hanziShow(box, chars) {
    var n = chars.length, size = n === 1 ? 170 : Math.max(100, Math.min(160, Math.floor(300 / n))), dead = false;
    var cellsEl = el('div', 'ls-cells'), status = el('div', 'ls-status'), ctrl = el('div', 'ls-ctrl');
    var cells = chars.map(function () { var d = el('div', 'ls-cell'); d.style.width = d.style.height = size + 'px'; cellsEl.appendChild(d); return d; });
    box.appendChild(cellsEl); box.appendChild(status); box.appendChild(ctrl);
    status.textContent = 'Loading strokes…';
    getHW().then(function (HW) {
      if (dead) return;
      var c = colors();
      var ws = cells.map(function (cell, i) {
        return HW.create(cell, chars[i], { width: size, height: size, padding: Math.round(size * 0.08), showOutline: false, strokeColor: c.stroke, outlineColor: c.outline, strokeAnimationSpeed: 1.2, delayBetweenStrokes: 160, charDataLoader: loadChar });
      });
      function animateAll(i) { if (dead || i >= ws.length) return; ws[i].animateCharacter({ onComplete: function () { animateAll(i + 1); } }); }
      status.textContent = 'Stroke order';
      ctrl.appendChild(mkBtn('▶ Play strokes', function () { ws.forEach(function (w) { w.hideCharacter(); }); animateAll(0); }));
    }).catch(function () { status.textContent = 'Stroke data is not available offline'; });
    return { destroy: function () { dead = true; } };
  }

  /* ── Freehand (non-CJK WriteCfg): letter-by-letter cells, whole word, OCR check ── */
  function penCanvas(w, h) {
    var dpr = window.devicePixelRatio || 1, c = el('canvas', 'ls-fh-canvas');
    c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); c.style.width = w + 'px'; c.style.height = h + 'px';
    var ctx = c.getContext('2d'); ctx.scale(dpr, dpr); ctx.lineCap = ctx.lineJoin = 'round';
    var mirror = document.createElement('canvas'); mirror.width = w; mirror.height = h;
    var mx = mirror.getContext('2d'); mx.fillStyle = '#fff'; mx.fillRect(0, 0, w, h); mx.lineCap = mx.lineJoin = 'round'; mx.strokeStyle = '#000';
    var down = false, lx = 0, ly = 0, inked = false, col = getVar('--draw');
    function pt(e) { var r = c.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
    c.addEventListener('pointerdown', function (e) { down = true; try { c.setPointerCapture(e.pointerId); } catch (x) {} var p = pt(e); lx = p[0]; ly = p[1]; e.preventDefault(); });
    c.addEventListener('pointermove', function (e) {
      if (!down) return; e.preventDefault();
      var p = pt(e), pr = e.pressure > 0 ? e.pressure : 0.5, lw = Math.max(1.5, Math.min(7, pr * 8)) * (P.width / 18);
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(p[0], p[1]); ctx.stroke();
      mx.lineWidth = Math.max(3, lw); mx.beginPath(); mx.moveTo(lx, ly); mx.lineTo(p[0], p[1]); mx.stroke();
      lx = p[0]; ly = p[1]; inked = true;
    });
    function up() { down = false; }
    c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up); c.addEventListener('pointerleave', up);
    return { el: c, mirror: mirror, inked: function () { return inked; },
      clear: function () { ctx.clearRect(0, 0, w, h); mx.fillStyle = '#fff'; mx.fillRect(0, 0, w, h); inked = false; } };
  }
  function guide(w, h, glyph, fs, rtl, baseline, family) {
    return '<svg class="ls-fh-guide" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true">' +
      (baseline ? '<line x1="6" x2="' + (w - 6) + '" y1="' + Math.round(h * 0.72) + '" y2="' + Math.round(h * 0.72) + '" stroke="currentColor" stroke-width="1" stroke-dasharray="3,3" opacity="0.35"/>' : '') +
      '<text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle" font-size="' + fs + 'px" fill="currentColor" opacity="0.3"' +
      (rtl ? ' direction="rtl"' : '') + (family ? ' style="font-family:' + esc(family) + '"' : '') + '>' + esc(glyph) + '</text></svg>';
  }
  function letterAudio(name) {
    if (!name || CFG.letterAudio === false || P.mute || PREVIEW) return;
    try { new Audio((CFG.letterAudioPrefix || '_ar_') + name + '.mp3').play().catch(function () {}); } catch (e) {}
  }
  function freehandCells(box, cells) {
    var row = el('div', 'ls-fh-row' + (CFG.rtl ? ' rtl' : '')), W = 110, H = 130, pads = [], els = [], fin = [], cur = 0, finished = false;
    cells.forEach(function (c, i) {
      var glyph = (CFG.diacriticsOn !== false && c.marks) ? c.form + c.marks : c.form;
      var cell = el('div', 'ls-fh-cell' + (CFG.useNastaliq ? ' nastaliq' : '')), cw = el('div', 'ls-fh-cw'), pad = penCanvas(W, H);
      cw.appendChild(pad.el); cw.insertAdjacentHTML('beforeend', guide(W, H, glyph, Math.round(H * 0.62), CFG.rtl, CFG.baselineOn !== false));
      var b = el('button', 'ls-fh-done'); b.type = 'button'; b.textContent = '✓ ' + (c.name || '');
      b.addEventListener('click', function () { if (fin[i]) return; fin[i] = true; cell.classList.remove('on'); cell.classList.add('fin'); advance(); });
      cell.appendChild(cw); cell.appendChild(b); row.appendChild(cell); pads.push(pad); els.push(cell);
    });
    var status = el('div', 'ls-status'), ctrl = el('div', 'ls-ctrl');
    status.textContent = 'Write each letter, then tick it';
    ctrl.appendChild(mkBtn('✕ Clear all', function () { pads.forEach(function (p) { p.clear(); }); }));
    ctrl.appendChild(mkBtn('✓ Done', finish));
    box.appendChild(row); box.appendChild(status); box.appendChild(ctrl);
    function advance() {
      while (cur < cells.length && fin[cur]) cur++;
      if (cur >= cells.length) return finish();
      els.forEach(function (e) { e.classList.remove('on'); }); els[cur].classList.add('on'); letterAudio(cells[cur].name);
    }
    function finish() { if (finished) return; finished = true; status.textContent = 'Done'; status.classList.add('ok'); showAnswer(); celebrate('✓', false); }
    advance();
    return { destroy: function () {} };
  }
  function freehandWord(box, word, cfg, ocr) {
    var wrap = el('div', 'ls-fh-wrap' + (cfg.useNastaliq ? ' nastaliq' : '')), W = Math.min(320, (window.innerWidth || 360) - 48), H = 180;
    var fam = (cfg.useNastaliq ? "'LS Nastaliq', " : '') + "'LS Naskh', " + (cfg.fontFamily || 'sans-serif');
    var cw = el('div', 'ls-fh-cw'), pad = penCanvas(W, H), res = el('div', 'ls-ocr'), status = el('div', 'ls-status'), ctrl = el('div', 'ls-ctrl');
    var finished = false, wrongs = 0, check = null;
    cw.appendChild(pad.el);
    if (cfg.ghost !== false) cw.insertAdjacentHTML('beforeend', guide(W, H, word, Math.round(H * 0.52), cfg.rtl, false, fam));
    wrap.appendChild(cw); wrap.appendChild(res); wrap.appendChild(status); wrap.appendChild(ctrl); box.appendChild(wrap);
    status.textContent = ocr ? 'Write the word, then check it' : 'Write the word';
    ctrl.appendChild(mkBtn('✕ Clear', function () { pad.clear(); res.innerHTML = ''; if (check) { check.disabled = false; check.textContent = '✓ Check'; } }));
    function win(g) { finished = true; status.textContent = 'Done'; status.classList.add('ok'); showAnswer(); celebrate('✓', false); if (g) storeGrade(g); }
    if (!ocr) { ctrl.appendChild(mkBtn('✓ Done', function () { if (!finished) win(null); })); return { destroy: function () {} }; }
    function norm(t) {
      var s = (t || '').replace(/\s+/g, '');
      if (/^(ara|fas|urd)$/.test(cfg.tesseractLang || '')) s = s.replace(/[\u0610-\u061A\u064B-\u065F\u0670]/g, '').replace(/[\u0622\u0623\u0625\u0671]/g, '\u0627');
      else { try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').normalize('NFC'); } catch (e) {} s = s.toLowerCase(); }
      return s;
    }
    function selfGrade() {
      res.innerHTML = '<span>Check it yourself:</span>';
      var ok = mkBtn('✓ Correct', function () { res.innerHTML = '<span class="ls-ok">✓ Correct</span>'; win({ grade: wrongs ? 2 : 3, slips: 0, self: true }); });
      var bad = mkBtn('✗ Wrong', function () { wrongs++; res.innerHTML = '<span class="ls-bad">✗ Wrong</span>'; storeGrade({ grade: 1, slips: 0, self: true }); check.disabled = false; check.textContent = '↻ Retry'; });
      ok.classList.add('ls-ok-btn'); bad.classList.add('ls-bad-btn'); res.appendChild(ok); res.appendChild(bad);
    }
    function run() {
      check.disabled = true; check.textContent = '…';
      function go() {
        if (typeof Tesseract === 'undefined') { check.disabled = false; check.textContent = '✓ Check'; return selfGrade(); }
        Tesseract.recognize(pad.mirror, cfg.tesseractLang || 'eng', { langPath: '', cacheMethod: 'none', workerPath: '_tesseract-worker.min.js', corePath: '_tesseract-core.wasm.js', logger: null })
          .then(function (r) {
            var raw = ((r.data && r.data.text) || '').trim(), got = norm(raw), want = norm(word), ok = got === want || (got.length > 0 && want.indexOf(got) !== -1);
            res.innerHTML = ok ? '<span class="ls-ok">✓ Correct</span>' : '<span class="ls-bad">✗ Not quite</span>' + (raw ? '<span>read as “' + esc(raw) + '”</span>' : '');
            check.disabled = false; check.textContent = ok ? '✓' : '↻ Retry';
            if (ok) win({ grade: wrongs ? 2 : 3, slips: 0, ocr: true, tries: wrongs }); else wrongs++;
          })
          .catch(function () { check.disabled = false; check.textContent = '✓ Check'; selfGrade(); });
      }
      if (typeof Tesseract === 'undefined' && !PREVIEW) loadScript('_tesseract.min.js').then(go, go); else go();
    }
    check = mkBtn('✓ Check', function () { if (pad.inked() && !finished) run(); });
    ctrl.appendChild(check);
    return { destroy: function () {} };
  }

  var W = null;
  function setupWriters() {
    var box = $('[data-ls-write]'); if (!box) return;
    if (W && W.destroy) W.destroy();
    W = null; box.innerHTML = '';
    $$('.ls-revealed').forEach(function (r) { r.parentNode.removeChild(r); });
    var ans = $('[data-ls-answer]'); if (ans && side === 'front') ans.hidden = true;
    var kind = box.getAttribute('data-ls-write'), simp = field('Simplified'), chars = splitChars(simp).filter(writable), mod = CFG.writeModule;
    var fh = (mod && mod !== 'hanziwriter') || !chars.length;
    if (kind === 'show') {
      var blk = box.closest ? box.closest('[data-step]') : null;
      if (fh) { if (blk) blk.hidden = true; return; }
      W = hanziShow(box, chars); return;
    }
    if (!fh) { W = hanziQuiz(box, chars); return; }
    clearGrade();
    var cells = (CFG.letterByLetter !== false && CFG.lettersByWord) ? CFG.lettersByWord[simp] : null;
    W = (mod !== 'freehand_ocr' && cells && cells.length) ? freehandCells(box, cells) : freehandWord(box, simp, CFG, mod === 'freehand_ocr');
  }
  cleanups.push(function () { if (W && W.destroy) W.destroy(); });

  /* ── Settings drawer (⚙, edge handle, or swipe in from the right) ── */
  var sheet = null;
  function row(k, t, d) { return '<button type="button" class="ls-row" role="switch" data-k="' + k + '"><span><b>' + t + '</b>' + (d ? '<small>' + d + '</small>' : '') + '</span><i class="ls-sw"></i></button>'; }
  function chip(k, t) { return '<button type="button" class="ls-chipbtn" role="switch" data-k="' + k + '">' + t + '</button>'; }
  function seg(k, opts) { return '<div class="ls-seg" data-k="' + k + '">' + opts.map(function (o) { return '<button type="button" data-v="' + o[0] + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function grp(label, html) { return '<div class="ls-grp"><div class="ls-glabel">' + label + '</div>' + html + '</div>'; }
  function range(k, min, max, stp, pm) {
    return '<div class="ls-rangerow">' + (pm ? '<button type="button" data-d="' + k + ':-' + pm + '" aria-label="Less">−</button>' : '') +
      '<input type="range" min="' + min + '" max="' + max + '" step="' + stp + '" data-range="' + k + '" aria-label="' + k + '">' +
      (pm ? '<button type="button" data-d="' + k + ':' + pm + '" aria-label="More">+</button>' : '') + '<span class="ls-rv" data-rv="' + k + '"></span></div>';
  }
  function buildSheet() {
    var scrim = el('div', 'ls-scrim');
    sheet = el('aside', 'ls-sheet'); sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-label', 'Card settings');
    var themes = '<div class="ls-themes" data-k="theme">' + THEMES.map(function (t) {
      var ch = '<span class="ls-tchip" data-theme="' + t[0] + '" data-tone="' + t[2] + '"><b>字</b><i></i></span>';
      return '<button type="button" class="ls-theme" data-v="' + t[0] + '">' + ch + '<span class="ls-tname">' + t[1] + '</span></button>';
    }).join('') + '</div>';
    var accents = '<div class="ls-accents" data-k="accent"><button type="button" class="ls-acc ls-acc-none" data-v="">Theme</button>' +
      ACCENTS.map(function (c) { return '<button type="button" class="ls-acc" data-v="' + c + '" style="background:' + c + '" aria-label="Accent ' + c + '"></button>'; }).join('') +
      '</div><input class="ls-hex" data-hex type="text" spellcheck="false" autocomplete="off" placeholder="Custom colour, e.g. #7c6aff">';
    var grids = '<div class="ls-grids" data-k="gridBg">' + GRIDS.map(function (g) {
      return g[0] ? '<button type="button" class="ls-gsw" data-v="' + g[0] + '" style="background:' + g[0] + '" title="' + g[1] + '" aria-label="' + g[1] + '"></button>'
        : '<button type="button" class="ls-gsw ls-gsw-theme" data-v="">Theme</button>';
    }).join('') + '</div>';
    var panes = {
      look: grp('Theme', seg('themeMode', [['split', 'Day & night'], ['one', 'One theme']]) +
          '<div class="ls-seg" data-slot><button type="button" data-sv="night">Night theme</button><button type="button" data-sv="day">Day theme</button></div>' + themes) + grp('Accent colour', accents) + grp('Text size', seg('scale', [['0.9', 'S'], ['1', 'M'], ['1.15', 'L'], ['1.3', 'XL']])) +
        '<div class="ls-grp">' + row('tones', 'Tone colours', 'Colour pinyin by tone') + row('hc', 'High contrast', 'Pure black and white, heavier lines') + row('lg', 'Large targets', 'Bigger buttons for phones and tablets') + '</div>',
      learn: '<div class="ls-grp">' + row('steps', 'Micro-steps', 'Reveal the back one section at a time') +
        row('audio', 'Audio-first', 'Speak the word when a note has no audio, and read the example aloud') +
        row('autograde', 'Auto-rate writing', 'Press the rating your slips earned: none Easy · up to 20% of strokes Good · up to 45% Hard') + '</div>',
      write: grp('Show while writing', '<div class="ls-chips">' + chip('lnPinyin', 'Pinyin') + chip('lnZhuyin', 'Zhuyin') + chip('lnMeaning', 'Meaning') + chip('audioBtn', 'Audio button') + '</div>') +
        grp('Show after writing', '<div class="ls-chips">' + chip('lnSimp', 'Simplified') + chip('lnTrad', 'Traditional') + '</div>') +
        grp('Visual aids', '<div class="ls-chips">' + chip('strokeCount', 'Stroke count') + chip('outline', 'Stroke outline') + chip('hints', 'Hints') + '</div>') +
        grp('Drawing width', seg('width', [['12', 'Thin'], ['18', 'Normal'], ['24', 'Thick']])) +
        grp('Canvas size', seg('canvas', [['sm', 'Small'], ['md', 'Normal'], ['lg', 'Large']])) +
        grp('Grid background', grids) +
        '<div class="ls-grp">' + row('timer', 'Timed quiz', 'When time runs out the card flips and counts as Again') + '<div data-show="timer">' + range('timerDur', 5, 120, 5) + '</div></div>',
      sound: '<div class="ls-grp">' + row('autoplay', 'Auto-play on load', 'Play the word audio when a card opens') +
        row('strokeVoice', 'Stroke counting voice', 'Count each correct stroke aloud') +
        row('mute', 'Mute all', 'Silence auto-play, voices and the metronome. Play buttons still work') + '</div>',
      metro: '<div class="ls-drumwrap"><div class="ls-drum"></div><div class="ls-mlbl" data-mlbl></div></div><button type="button" class="ls-bigbtn" data-metro></button>' +
        grp('Tempo', range('bpm', 40, 220, 1, 5)) +
        grp('Sound', seg('snd', [['click', 'Click'], ['wood', 'Wood'], ['soft', 'Soft'], ['bell', 'Bell'], ['off', 'Off']])) +
        grp('Volume', range('vol', 0, 100, 5)) +
        '<div class="ls-grp">' + row('countStrokes', 'Count with strokes', 'One beat per stroke of the current character, counted aloud in Chinese') + '</div>'
    };
    var tabs = [['look', 'Look'], ['learn', 'Learn'], ['write', 'Write'], ['sound', 'Sound'], ['metro', 'Metro']].filter(function (t) { return t[0] !== 'write' || WRITING; });
    sheet.innerHTML = '<div class="ls-sheet-hd"><strong>Card settings</strong><button type="button" class="ls-icon" data-x aria-label="Close">×</button></div>' +
      (WRITING && side === 'front' ? '<div class="ls-actions"><button type="button" data-act="retry">↻ Retry quiz</button><button type="button" data-act="reveal">Reveal character</button></div>' : '') +
      '<div class="ls-tabs" role="tablist">' + tabs.map(function (t) { return '<button type="button" class="ls-tab" role="tab" data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div>' +
      tabs.map(function (t) { return '<div class="ls-pane" role="tabpanel" data-pane="' + t[0] + '">' + panes[t[0]] + '<p class="ls-note">Applies to all LinguaStudio cards on this device. Other phones or computers keep their own settings.</p></div>'; }).join('');
    root.appendChild(scrim); root.appendChild(sheet);
    scrim.addEventListener('click', closeSheet);
    sheet.addEventListener('click', function (e) {
      var t = e.target.closest ? e.target.closest('button') : null; if (!t || !sheet.contains(t)) return;
      if (t.hasAttribute('data-x')) return closeSheet();
      if (t.getAttribute('data-tab')) { P.tab = t.getAttribute('data-tab'); savePrefs(); return syncSheet(); }
      if (t.getAttribute('data-sv')) { SLOT = t.getAttribute('data-sv'); return syncSheet(); }
      var act = t.getAttribute('data-act'); if (act) { closeSheet(); if (W && W[act]) W[act](); return; }
      if (t.hasAttribute('data-metro')) { P.metro = !P.metro; return commit('metro'); }
      var d = t.getAttribute('data-d');
      if (d) { var kv = d.split(':'), lim = RANGES[kv[0]]; P[kv[0]] = Math.max(lim[0], Math.min(lim[1], P[kv[0]] + parseInt(kv[1], 10))); return commit(kv[0]); }
      var gk = t.parentNode && t.parentNode.getAttribute ? t.parentNode.getAttribute('data-k') : null;
      if (gk === 'theme' && t.hasAttribute('data-v')) { P[themeKey()] = t.getAttribute('data-v'); return commit('theme'); }
      if (gk && t.hasAttribute('data-v')) { var v = t.getAttribute('data-v'); P[gk] = gk === 'scale' ? parseFloat(v) : gk === 'width' ? parseInt(v, 10) : v; return commit(gk); }
      var k = t.getAttribute('data-k'); if (k) { P[k] = !P[k]; return commit(k); }
    });
    sheet.addEventListener('input', function (e) {
      var r = e.target, k = r.getAttribute && r.getAttribute('data-range'); if (!k) return;
      P[k] = parseInt(r.value, 10); savePrefs(); syncSheet();
      if (k === 'bpm') setupMetro();
    });
    sheet.addEventListener('change', function (e) {
      var r = e.target; if (r.getAttribute && r.getAttribute('data-range') === 'timerDur') setupWriters();
      if (!r.hasAttribute || !r.hasAttribute('data-hex')) return;
      var v = r.value.trim(); if (v && v.charAt(0) !== '#') v = '#' + v;
      if (!v) { P.accent = ''; commit('accent'); } else if (/^#[0-9a-f]{3}([0-9a-f]{3})?$/i.test(v)) { P.accent = v.toLowerCase(); commit('accent'); }
    });
    $$('[data-ls-open]').forEach(function (b) { b.addEventListener('click', openSheet); });
    var edge = el('div', 'ls-edge'); edge.setAttribute('role', 'button'); edge.setAttribute('aria-label', 'Card settings');
    edge.addEventListener('click', openSheet); root.appendChild(edge);
    window.__lsOpenSheet = openSheet;
    if (!window.__lsSwipe) {
      window.__lsSwipe = true; var sx = 0, sy = 0;
      document.addEventListener('touchstart', function (e) { var t = e.touches[0]; sx = t.clientX; sy = t.clientY; }, { passive: true });
      document.addEventListener('touchend', function (e) {
        var t = e.changedTouches && e.changedTouches[0]; if (!t) return;
        var dx = t.clientX - sx, dy = t.clientY - sy;
        if (sx > window.innerWidth - 24 && dx < -40 && Math.abs(dy) < Math.abs(dx) && window.__lsOpenSheet) window.__lsOpenSheet();
      }, { passive: true });
    }
  }
  var SLOT = isNight() ? 'night' : 'day';
  function themeKey() { return P.themeMode === 'one' ? 'theme' : SLOT === 'night' ? 'themeNight' : 'themeDay'; }
  function openSheet() { root.classList.add('sheet-open'); syncSheet(); }
  function closeSheet() { root.classList.remove('sheet-open'); }
  function syncSheet() {
    if (!sheet) return;
    var tab = $('[data-pane="' + P.tab + '"]', sheet) ? P.tab : 'look';
    $$('[data-tab]', sheet).forEach(function (b) { b.setAttribute('aria-selected', String(b.getAttribute('data-tab') === tab)); });
    $$('[data-pane]', sheet).forEach(function (p) { p.hidden = p.getAttribute('data-pane') !== tab; });
    $$('[data-k]', sheet).forEach(function (g) {
      var k = g.getAttribute('data-k');
      if (g.classList.contains('ls-row') || g.classList.contains('ls-chipbtn')) { g.setAttribute('aria-checked', String(!!P[k])); return; }
      var cur = k === 'theme' ? P[themeKey()] : P[k];
      $$('[data-v]', g).forEach(function (b) { b.setAttribute('aria-pressed', String(String(cur) === b.getAttribute('data-v'))); });
    });
    $$('[data-range]', sheet).forEach(function (r) { if (document.activeElement !== r) r.value = P[r.getAttribute('data-range')]; });
    $$('[data-rv]', sheet).forEach(function (s) { var k = s.getAttribute('data-rv'); s.textContent = k === 'bpm' ? P.bpm + ' bpm' : k === 'vol' ? P.vol + '%' : P.timerDur + ' s'; });
    $$('[data-show]', sheet).forEach(function (d) { d.hidden = !P[d.getAttribute('data-show')]; });
    var sl = $('[data-slot]', sheet); if (sl) { sl.hidden = P.themeMode !== 'split'; $$('[data-sv]', sl).forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-sv') === SLOT)); }); }
    var mb = $('[data-metro]', sheet); if (mb) mb.textContent = P.metro ? '■ Stop metronome' : '▶ Start metronome';
    var hex = $('[data-hex]', sheet); if (hex && document.activeElement !== hex) hex.value = P.accent || '';
  }

  /* ── Apply ── */
  var REINIT = { theme: 1, themeMode: 1, accent: 1, hc: 1, gridBg: 1, outline: 1, hints: 1, width: 1, canvas: 1, timer: 1 };
  function applyBase() {
    root.style.setProperty('--scale', P.scale);
    ['hc', 'lg', 'steps', 'audio', 'metro', 'autograde'].forEach(function (k) { if (P[k]) root.setAttribute('data-' + k, ''); else root.removeAttribute('data-' + k); });
    if (P.tones) root.removeAttribute('data-notones'); else root.setAttribute('data-notones', '');
    applyTheme();
  }
  function commit(k) {
    savePrefs(); applyBase();
    if (k === 'steps') setupSteps();
    if (/^(metro|bpm|snd|vol|countStrokes)$/.test(k)) { if (k === 'countStrokes') M.beat = 0; setupMetro(); }
    if (/^(ln|audioBtn|strokeCount)/.test(k)) { applyLines(); if (W && W.sync) W.sync(); }
    if (REINIT[k]) setupWriters();
    syncSheet();
  }

  setupText();
  buildSheet();
  applyBase();
  applyLines();
  setupWriters();
  setupSteps();
  setupMetro();
  setupAudio();
  setupGrade();
  syncSheet();
  if (P._open) openSheet();
})();
