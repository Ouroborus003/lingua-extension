"""Agenda feed — the time-anchored half of catching up (Rainbell homepage
adaptation, 2026-07-19). Responsibilities (§9.5) answers "what do I owe";
this answers "what is scheduled": open tasks carrying a Tasks-plugin date
(📅 due / ⏳ scheduled) that land within the horizon, plus anything overdue.

Lines with `[due:: ]` belong to the Responsibilities feed and are skipped
here so nothing appears on the dashboard twice. Rendered as plain bullets,
not checkboxes — a checkbox in a generated feed that silently reverts on
the next regeneration is a lie; tasks are ticked in their source note.

MIRROR: .obsidian/plugins/reading-desk/desk-sources.js parseTaskLine mirrors
_TASK / _DUE / _SCHEDULED / _EMOJI_META below. Change both together.
"""
from __future__ import annotations

import datetime as dt
import re

from .. import constants, settings, vault

FEED_PATH = f"{constants.GENERATED}/Feeds/Agenda.md"
MAX_UPCOMING = 12

_TASK = re.compile(r"^\s*[-*] \[ \] (.+)$")
_DUE = re.compile(r"📅\s*(\d{4}-\d{2}-\d{2})")
_SCHEDULED = re.compile(r"⏳\s*(\d{4}-\d{2}-\d{2})")
# Tasks-plugin metadata stripped for display: dated markers, recurrence
# rules, priority/id markers, and tags — the dashboard wants the bare text.
_EMOJI_META = re.compile(
    r"🔁[^📅⏳🛫➕✅⏰]*"
    r"|[📅⏳🛫➕✅⏰]\s*\d{4}-\d{2}-\d{2}"
    r"|[⏫🔼🔽⏬🔺🆔⛔]\S*"
    r"|#[\w/-]+")


def _task_date(text: str) -> dt.date | None:
    m = _DUE.search(text) or _SCHEDULED.search(text)
    if not m:
        return None
    try:
        return dt.date.fromisoformat(m.group(1))
    except ValueError:
        return None


def _items(horizon: dt.date) -> list[tuple[dt.date, str, str]]:
    items = []
    for folder in (constants.INBOX, constants.NOTES, constants.PROJECTS,
                   constants.COURSEWORK, constants.PERIODIC, constants.TASKS):
        for rel, post in vault.notes(folder):
            for line in post.content.splitlines():
                m = _TASK.match(line)
                if m is None or "[due::" in line:
                    continue
                when = _task_date(m.group(1))
                if when is None or when > horizon:
                    continue
                text = _EMOJI_META.sub("", m.group(1)).strip(" ,;—-")
                if text:
                    items.append((when, text, rel.rsplit("/", 1)[-1][:-3]))
    return sorted(items)


def _day_label(when: dt.date, today: dt.date) -> str:
    if when == today:
        return "**today**"
    if when == today + dt.timedelta(days=1):
        return "tomorrow"
    return when.strftime("%a %d")


def generate() -> str:
    today = dt.date.today()
    horizon = today + dt.timedelta(days=settings.effective().agenda_horizon_days)
    items = _items(horizon)
    overdue = [i for i in items if i[0] < today]
    upcoming = [i for i in items if i[0] >= today]

    body = ["## Agenda"]
    if overdue:
        body.append("> [!loop] Overdue")
        body.extend(f"> - {text} ([[{src}]]) — was {when.strftime('%a %d')}"
                    for when, text, src in overdue)
        body.append("")
    for when, text, src in upcoming[:MAX_UPCOMING]:
        body.append(f"- {_day_label(when, today)} — {text} ([[{src}]])")
    if len(upcoming) > MAX_UPCOMING:
        body.append(f"*…and {len(upcoming) - MAX_UPCOMING} more this week.*")
    if not items:
        body.append(f"*Clear through {horizon.strftime('%a %d %b')}. "
                    "Nothing hidden either — this list is exhaustive.*")
    return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})
