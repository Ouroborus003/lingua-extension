"""Responsibilities feed (spec §9.5). Not a task manager — a flat checklist.

Sources: 05 Coursework frontmatter (due/status) and inline `- [ ]` tasks with
[due:: YYYY-MM-DD] anywhere authored. Overdue sorts first with a distinct
callout. No guilt language, no streaks.

Checkbox sync: before overwriting, any line the operator checked since the
last generation flips the source note's status to done (a sidecar-maintained
key, §6).
"""
from __future__ import annotations

import datetime as dt
import re

from .. import constants, settings, vault

FEED_PATH = f"{constants.GENERATED}/Feeds/Responsibilities.md"
_INLINE_DUE = re.compile(r"^\s*[-*] \[ \] (.+?)\s*\[due::\s*(\d{4}-\d{2}-\d{2})\s*\]")
_CHECKED_LINE = re.compile(r"^- \[x\] .*\[\[([^\]|]+)")


def _sync_checked() -> None:
    post = vault.read(FEED_PATH)
    if post is None:
        return
    for line in post.content.splitlines():
        m = _CHECKED_LINE.match(line.strip())
        if not m:
            continue
        target = m.group(1)
        rel = f"{constants.COURSEWORK}/{target}.md"
        note = vault.read(rel)
        if note is not None and note.metadata.get("status") != "done":
            vault.set_frontmatter_key(rel, "status", "done")


def _coursework_items(today: dt.date, horizon: dt.date) -> list[tuple[dt.date, str]]:
    items = []
    for rel, post in vault.notes(constants.COURSEWORK):
        fm = post.metadata
        due, status = fm.get("due"), fm.get("status", "todo")
        if status == "done" or not due:
            continue
        try:
            due_d = due if isinstance(due, dt.date) else dt.date.fromisoformat(str(due))
        except ValueError:
            continue
        if due_d <= horizon:
            name = rel.rsplit("/", 1)[-1][:-3]
            course = f" *({fm['course']})*" if fm.get("course") else ""
            items.append((due_d, f"- [ ] [[{name}]]{course} — due {due_d.isoformat()}"))
    return items


def _inline_items(horizon: dt.date) -> list[tuple[dt.date, str]]:
    items = []
    for folder in (constants.NOTES, constants.PROJECTS, constants.COURSEWORK,
                   constants.TASKS):
        for rel, post in vault.notes(folder):
            for line in post.content.splitlines():
                m = _INLINE_DUE.match(line)
                if not m:
                    continue
                try:
                    due_d = dt.date.fromisoformat(m.group(2))
                except ValueError:
                    continue
                if due_d <= horizon:
                    name = rel.rsplit("/", 1)[-1][:-3]
                    items.append((due_d, f"- [ ] {m.group(1).strip()} ([[{name}]]) — due {due_d.isoformat()}"))
    return items


def generate() -> str:
    _sync_checked()
    today = dt.date.today()
    horizon = today + dt.timedelta(
        days=settings.effective().responsibilities_horizon_days)

    items = sorted(_coursework_items(today, horizon) + _inline_items(horizon))
    overdue = [line for due, line in items if due < today]
    upcoming = [line for due, line in items if due >= today]

    body = ["## Responsibilities"]
    if overdue:
        body.append("> [!loop] Overdue")
        body.extend("> " + l for l in overdue)
        body.append("")
    if upcoming:
        body.extend(upcoming)
    if not items:
        body.append("*Nothing due. Nothing hidden either — this list is exhaustive.*")

    return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})
