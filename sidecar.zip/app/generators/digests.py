"""AI digests and ratings (spec §11.1-11.3), LM Studio-backed.

daily → weekly → monthly → quarterly rollups. Every digest is a generated
file linking back to its sources; a period rating (the Time Garden paid
feature) rides along as frontmatter on the digest, never on authored notes.
"""
from __future__ import annotations

import json
import re

from .. import constants, llm, prompts, vault

_RATING_SCHEMA = {
    "type": "object",
    "properties": {
        "rating": {"type": "integer", "minimum": 1, "maximum": 10},
        "explanation": {"type": "string"},
    },
    "required": ["rating", "explanation"],
}


def _digest_path(period: str) -> str:
    return f"{constants.GENERATED}/Digests/{period} Digest.md"


def _strip_generated_noise(text: str) -> str:
    text = text.replace(vault.GENERATED_HEADER, "")
    return re.sub(r"!\[\[[^\]]*\]\]", "", text)


async def _write_digest(period: str, prompt_name: str, sources: list[tuple[str, str]],
                        stats: str = "") -> str:
    if not sources:
        raise ValueError(f"no source notes found for {period}")
    corpus = "\n\n".join(
        f"### {name}\n{_strip_generated_noise(body)[:6000]}" for name, body in sources)

    narrative = await llm.chat(prompts.load(prompt_name), corpus, feature="digest")
    rating_raw = await llm.chat(prompts.load("ratings"), corpus, feature="ratings",
                                temperature=0.2, json_schema=_RATING_SCHEMA)
    try:
        rating = json.loads(rating_raw)
    except json.JSONDecodeError:
        rating = {"rating": None, "explanation": rating_raw.strip()[:300]}

    body = [f"# {period}", ""]
    if stats:
        body.append(stats)
        body.append("")
    body.append(narrative.strip())
    body.append("")
    if rating.get("rating") is not None:
        body.append(f"**Period rating:** {rating['rating']}/10 — {rating['explanation']}")
        body.append("")
    body.append("## Sources")
    body.extend(f"- [[{name}]]" for name, _ in sources)

    return vault.write_generated(
        _digest_path(period), "\n".join(body),
        {"type": "note", "domain": "personal", "period": period,
         "rating": rating.get("rating")})


async def weekly(period: str) -> str:
    start, end = constants.week_range(period)
    sources, moods, energies = [], [], []
    for rel, post in vault.notes(constants.DAILY_DIR):
        name = rel.rsplit("/", 1)[-1][:-3]
        try:
            d = constants.parse_daily(name)
        except ValueError:
            continue
        if start <= d <= end:
            sources.append((name, post.content))
            if isinstance(post.metadata.get("mood"), (int, float)):
                moods.append(post.metadata["mood"])
            if isinstance(post.metadata.get("energy"), (int, float)):
                energies.append(post.metadata["energy"])
    stats = ""
    if moods:
        stats = (f"*{len(sources)} days · mood avg {sum(moods)/len(moods):.1f}"
                 + (f" · energy avg {sum(energies)/len(energies):.1f}" if energies else "")
                 + "*")
    return await _write_digest(period, "weekly_digest", sources, stats)


async def monthly(period: str) -> str:
    start, end = constants.month_range(period)
    sources = []
    for week in constants.weeks_in(start, end):
        post = vault.read(_digest_path(week))
        if post is not None:
            sources.append((f"{week} Digest", post.content))
    return await _write_digest(period, "monthly_digest", sources)


async def quarterly(period: str) -> str:
    start, end = constants.quarter_range(period)
    sources = []
    for month in constants.months_in(start, end):
        post = vault.read(_digest_path(month))
        if post is not None:
            sources.append((f"{month} Digest", post.content))
    return await _write_digest(period, "quarterly_digest", sources)


LEVELS = {"weekly": weekly, "monthly": monthly, "quarterly": quarterly}
