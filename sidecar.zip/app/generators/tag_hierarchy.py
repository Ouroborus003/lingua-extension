"""Emergent tag hierarchy (spec §9.11): groupings are proposed from observed
co-occurrence, never designed upfront and never auto-applied.

Flat tags that repeatedly appear together form a candidate group; the LLM
only names the parent. Proposals land in a review queue:
- check a line → tags are renamed to nested form (#parent/tag) everywhere
- delete a line → the grouping is recorded as rejected, never re-offered
Hierarchy stays plain text and reversible (nested tag syntax).
"""
from __future__ import annotations

import json
import logging
import re
from collections import Counter
from itertools import combinations

import yaml

from .. import constants, llm, prompts, vault
from ..config import STATE_DIR
from .tag_review import REJECTED_PATH, VOCAB_PATH, _rejected, _save_rejected

log = logging.getLogger("sidecar.tag_hierarchy")

QUEUE_PATH = f"{constants.GENERATED}/Feeds/TagHierarchy.md"
_STATE = STATE_DIR / "tag_hierarchy_offers.json"

MIN_CO = 3        # a pair must share at least this many notes
MAX_PROPOSALS = 3  # §9.11 guardrail: a long queue is a stall
_REJ_KEY = "_hierarchy"

_LINE = re.compile(r"^- \[(x| )\] #([\w\-]+) ⊃ (.+)$")

_SCHEMA = {"type": "object",
           "properties": {"parent": {"type": "string"}},
           "required": ["parent"]}


def _tags_by_note() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for folder in (constants.INBOX, constants.NOTES, constants.PROJECTS):
        for rel, post in vault.notes(folder):
            tags = post.metadata.get("tags") or []
            flat = [str(t).lstrip("#") for t in tags
                    if isinstance(t, str) and "/" not in t]
            if flat:
                out[rel] = flat
    return out


def _components(pairs: dict[tuple[str, str], int]) -> list[set[str]]:
    parent: dict[str, str] = {}

    def find(t: str) -> str:
        while parent.setdefault(t, t) != t:
            parent[t] = parent[parent[t]]
            t = parent[t]
        return t

    for (a, b), n in pairs.items():
        if n >= MIN_CO:
            parent[find(a)] = find(b)
    groups: dict[str, set[str]] = {}
    for t in parent:
        groups.setdefault(find(t), set()).add(t)
    return [g for g in groups.values() if len(g) >= 3]


def _group_key(group: set[str]) -> str:
    return " ".join(sorted(group))


def apply_reviewed() -> dict:
    """Apply checked proposals; record deleted ones as rejected."""
    post = vault.read(QUEUE_PATH)
    prev_offers: list[list] = (json.loads(_STATE.read_text())
                               if _STATE.exists() else [])
    if post is None:
        return {"renamed_notes": 0, "rejected": 0}

    renamed = 0
    seen_keys: set[str] = set()
    rej = _rejected()
    for line in post.content.splitlines():
        m = _LINE.match(line.strip())
        if not m:
            continue
        checked, parent_tag = m.group(1) == "x", m.group(2)
        group = set(re.findall(r"#([\w\-]+)", m.group(3)))
        seen_keys.add(_group_key(group))
        if not checked:
            continue
        for rel, post_ in list(_iter_tagged(group)):
            tags = [f"{parent_tag}/{t}" if t in group and "/" not in t else t
                    for t in (str(x).lstrip("#") for x in post_.metadata.get("tags") or [])]
            vault.set_frontmatter_key(rel, "tags", tags)
            renamed += 1
        _nest_vocab(parent_tag, group)

    newly_rejected = 0
    for offer in prev_offers:
        key = _group_key(set(offer))
        if key not in seen_keys and key not in rej.get(_REJ_KEY, []):
            rej.setdefault(_REJ_KEY, []).append(key)
            newly_rejected += 1
    if newly_rejected:
        _save_rejected(rej)
    return {"renamed_notes": renamed, "rejected": newly_rejected}


def _iter_tagged(group: set[str]):
    for folder in (constants.INBOX, constants.NOTES, constants.PROJECTS):
        for rel, post in vault.notes(folder):
            tags = {str(t).lstrip("#") for t in post.metadata.get("tags") or []}
            if tags & group:
                yield rel, post


def _nest_vocab(parent_tag: str, group: set[str]) -> None:
    p = vault.abs_path(VOCAB_PATH)
    data = (yaml.safe_load(p.read_text()) or {}) if p.exists() else {}
    tags = [t for t in data.get("tags", []) if t not in group]
    tags.extend(sorted(f"{parent_tag}/{t}" for t in group))
    data["tags"] = sorted(set(tags))
    p.write_text(yaml.safe_dump(data, allow_unicode=True, sort_keys=False))


async def generate() -> str:
    apply_reviewed()

    pairs: Counter = Counter()
    for tags in _tags_by_note().values():
        for a, b in combinations(sorted(set(tags)), 2):
            pairs[(a, b)] += 1

    rejected_keys = set(_rejected().get(_REJ_KEY, []))
    groups = [g for g in _components(pairs)
              if _group_key(g) not in rejected_keys][:MAX_PROPOSALS]

    lines = ["# Tag hierarchy proposals", "",
             "These tags keep appearing together. Check a line to nest them "
             "under the proposed parent (#parent/tag everywhere); delete a "
             "line to never see that grouping again.", ""]
    offers: list[list[str]] = []
    for group in groups:
        try:
            raw = await llm.chat(prompts.load("tag_hierarchy"),
                                 "TAGS: " + ", ".join(sorted(group)),
                                 temperature=0.2, json_schema=_SCHEMA,
                                 feature="tag_hierarchy")
            parent_tag = json.loads(raw)["parent"]
        except Exception as e:
            log.warning("parent naming failed (%s); using frequency fallback", e)
            parent_tag = sorted(group)[0]
        parent_tag = re.sub(r"[^\w\-]", "-", str(parent_tag).lstrip("#").lower()) or "group"
        members = " ".join(f"#{t}" for t in sorted(group))
        lines.append(f"- [ ] #{parent_tag} ⊃ {members}")
        offers.append(sorted(group))

    if not offers:
        lines.append("*No stable co-occurring groups yet — flat tags need "
                     "more time to accumulate. This is the intended state, "
                     "not an error.*")
    _STATE.write_text(json.dumps(offers))
    return vault.write_generated(QUEUE_PATH, "\n".join(lines), {"type": "inbox"})
