"""Per-relationship graph views over the vocabulary CSV (spec §10 rewrite,
Stage 9): one `<Family> — <lang>.canvas` per relationship family
(synonyms/derived_from/contrasts/collocates) and language, regenerated from
`vocab_csv`'s relationship columns.

Only `canvas.append_text_nodes` / `canvas.set_edges` ever touch these files:
node positions are the operator's the moment they drag one, and a regen never
moves or removes a node — it only adds nodes for terms newly drawn into the
relation and rebuilds the edge list to match the current data. That split
(nodes stay, edges regenerate) is `canvas.py`'s own rule, not invented here.
"""
from __future__ import annotations

import logging

from .. import canvas, vault, vocab_csv
from ..vocab_csv import RELATION_COLUMNS, SYMMETRIC_RELATIONS

log = logging.getLogger("sidecar.vocab_graphs")

_FAMILY_TITLE = {
    "synonyms": "Synonyms",
    "derived_from": "Derived from",
    "contrasts": "Contrasts",
    "collocates": "Collocates",
}


def graph_path(family: str, lang: str) -> str:
    if family not in RELATION_COLUMNS:
        raise vocab_csv.VocabError(f"not a relationship column {family!r}")
    key = vocab_csv.bucket_key(lang)
    return f"{vocab_csv.STUDY_DIR}/{_FAMILY_TITLE[family]} — {key}.canvas"


def _pairs(rows: list[dict], family: str) -> list[tuple[str, str]]:
    """One entry per relation: an unordered pair, deduped, for a symmetric
    family (both rows list each other, so take it once); the as-recorded
    direction for a directional one. A reference to a term no longer in the
    CSV is dropped rather than drawn as a dangling edge."""
    by_term = {str(r.get("term") or ""): r for r in rows}
    symmetric = family in SYMMETRIC_RELATIONS
    seen: set[tuple[str, str]] = set()
    pairs: list[tuple[str, str]] = []
    for term in sorted(by_term):
        for other in by_term[term].get(family) or []:
            if other not in by_term:
                continue
            if symmetric:
                key = tuple(sorted((term, other)))
                if key in seen:
                    continue
                seen.add(key)
                pairs.append(key)
            else:
                pairs.append((term, other))
    return pairs


def regenerate(lang: str, family: str) -> dict:
    """Rebuild one family's graph for one language. A family with no
    recorded relations *yet* writes nothing — there is nothing to stage, same
    as the domain canvas maps skipping an empty folder. A family whose last
    relation was REMOVED is a different case and is handled below: the canvas
    exists, and it must stop drawing an edge that no longer exists."""
    rows = vocab_csv.read(lang)
    pairs = _pairs(rows, family)
    rel = graph_path(family, lang)
    if not pairs:
        # Nothing to stage and nothing drawn yet: write no file at all, the
        # same way the domain canvas maps skip an empty folder.
        if not vault.abs_path(rel).exists():
            return {"path": rel, "nodes": 0, "edges": 0}
        # But a canvas that already exists must not keep drawing a relation
        # the operator has since removed. Unlinking the LAST pair in a family
        # is reachable from the word-detail "Remove this relation" chip
        # (lingua-workspace/main.js:3167, which posts add:false), and an early
        # return here left that edge on the canvas permanently — contradicting
        # set_edges' own rule that edges are a live view of the relation while
        # nodes are the operator's drawing. So: clear the edges, keep the cards.
        n_cleared = canvas.set_edges(rel, [], label=family)
        log.info("regenerated %s: relation now empty, edges cleared", rel)
        return {"path": rel, "nodes": 0, "edges": n_cleared}
    terms = sorted({t for pair in pairs for t in pair})
    ids = canvas.append_text_nodes(rel, terms)
    id_pairs = [(ids[a], ids[b]) for a, b in pairs]
    n_edges = canvas.set_edges(rel, id_pairs, label=family)
    log.info("regenerated %s: %d nodes, %d edges", rel, len(terms), n_edges)
    return {"path": rel, "nodes": len(terms), "edges": n_edges}


def regenerate_all(lang: str) -> dict:
    """All four family graphs for one language."""
    return {family: regenerate(lang, family) for family in sorted(RELATION_COLUMNS)}
