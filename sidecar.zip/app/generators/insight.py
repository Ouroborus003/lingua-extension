"""Insight Q&A and the morning dashboard note (spec §11.4-11.5).

Retrieval is deliberately naive — term-overlap ranking over authored notes —
because the operator's recall is verbal: if they remember the phrasing, the
overlap finds it. Every answer links its sources.
"""
from __future__ import annotations

import datetime as dt
import random
import re

from .. import constants, llm, prompts, vault

ANSWERS_PATH = f"{constants.GENERATED}/Answers.md"
MORNING_PATH = f"{constants.GENERATED}/Feeds/Morning Note.md"


def _score(question_terms: set[str], text: str) -> int:
    words = set(re.findall(r"\w+", text.lower()))
    return len(question_terms & words)


def _top_notes(question: str, k: int = 6) -> list[tuple[str, str]]:
    terms = {w for w in re.findall(r"\w+", question.lower()) if len(w) > 2}
    scored = []
    for folder in (constants.NOTES, constants.PROJECTS, constants.INBOX,
                   constants.DAILY_DIR, constants.COURSEWORK):
        for rel, post in vault.notes(folder):
            s = _score(terms, post.content + " " + rel)
            if s:
                scored.append((s, rel, post.content))
    scored.sort(reverse=True)
    return [(rel, body[:3000]) for _, rel, body in scored[:k]]


async def ask(question: str) -> dict:
    sources = _top_notes(question)
    context = "\n\n".join(f"### [[{rel.rsplit('/', 1)[-1][:-3]}]]\n{body}"
                          for rel, body in sources) or "(no matching notes)"
    answer = await llm.chat(prompts.load("insight_qa"),
                            f"QUESTION: {question}\n\nNOTES:\n{context}",
                            feature="insight_qa")

    stamp = dt.datetime.now().isoformat(timespec="minutes")
    entry = (f"\n## {stamp} — {question}\n\n{answer.strip()}\n\n"
             + ("Sources: " + " · ".join(f"[[{r.rsplit('/', 1)[-1][:-3]}]]"
                                         for r, _ in sources) + "\n" if sources else ""))
    post = vault.read(ANSWERS_PATH)
    if post is None:
        vault.write_generated(ANSWERS_PATH, "# Answers\n" + entry, {"type": "note"})
    else:
        vault.write_generated(ANSWERS_PATH, post.content + entry, {"type": "note"})
    return {"answer": answer,
            "sources": [r for r, _ in sources], "path": ANSWERS_PATH}


def _stale_note() -> str | None:
    base = vault.abs_path(constants.NOTES)
    if not base.exists():
        return None
    files = sorted(base.rglob("*.md"), key=lambda f: f.stat().st_mtime)
    return files[0].stem if files else None


async def morning_note() -> str:
    """A slightly different entry point each morning (spec §11.5)."""
    today = dt.date.today()
    stale = _stale_note()
    loops = []
    for rel, post in vault.notes(constants.PROJECTS):
        if rel.endswith("/_state.md"):
            loops.extend(re.findall(r"- \[ \] (.+)", post.content)[:2])
    pick = random.choice(loops) if loops else None

    facts = [f"Today is {today.strftime('%A, %B %d')}."]
    if stale:
        facts.append(f"The longest-untouched note is [[{stale}]].")
    if pick:
        facts.append(f"An open loop: {pick}")
    text = await llm.chat(prompts.load("dashboard_note"), "\n".join(facts), feature="dashboard_note")

    body = ["## Morning", "", text.strip()]
    if stale:
        body.append(f"\nRevisit: [[{stale}]]")
    return vault.write_generated(MORNING_PATH, "\n".join(body), {"type": "note"})
