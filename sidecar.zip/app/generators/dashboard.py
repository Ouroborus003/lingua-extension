"""Dashboard generator (spec §9.1) — the highest-priority feature.

One screen. Shows only what is live. Composition is widget-based and driven
by 08 Meta/dashboard.yaml:

- `pins`: operator-pinned notes and folders, always rendered first
- `widgets`: ordered list of sections; a string ("projects") or a mapping
  ({type: embed, note: ...}). Adding a new tool = one render function in
  WIDGETS + one config line. Unknown types degrade to a visible placeholder,
  so future widgets (e.g. rss) can be configured before they exist.
- `folders`: per-folder recency depth; rows sort by most recent access
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import yaml

from .. import constants, vault

DASHBOARD_PATH = constants.DASHBOARD_NOTE
MORNING_PATH = f"{constants.GENERATED}/Feeds/Morning Note.md"

DEFAULT_WIDGETS = ["pins", "agenda", "responsibilities", "projects",
                   "now-playing", "reading", "domains",
                   "folders", "morning"]


def _cfg() -> dict:
    p = vault.abs_path(f"{constants.META}/dashboard.yaml")
    data = (yaml.safe_load(p.read_text()) or {}) if p.exists() else {}
    data.setdefault("pins", [])
    data.setdefault("folders", {})
    data.setdefault("default_recent", 5)
    data.setdefault("widgets", DEFAULT_WIDGETS)
    return data


def _mtime(p: Path) -> float:
    try:
        return max((f.stat().st_mtime for f in p.rglob("*.md")), default=0.0)
    except OSError:
        return 0.0


# --- widgets ---------------------------------------------------------------

def _w_pins(cfg: dict, opts: dict) -> list[str]:
    pins = cfg["pins"]
    if not pins:
        return []
    out = ["## Pinned"]
    for pin in pins:
        name = str(pin).strip().strip("[]")
        target = vault.abs_path(name) if "/" in name else None
        if target is not None and target.is_dir():
            files = sorted(target.rglob("*.md"), key=lambda f: f.stat().st_mtime,
                           reverse=True)[:3]
            recent = " · ".join(f"[[{f.stem}]]" for f in files) or "—"
            out.append(f"- 📌 **{name}** — {recent}")
        else:
            out.append(f"- 📌 [[{name}]]")
    return out


def _w_responsibilities(cfg: dict, opts: dict) -> list[str]:
    return ["## Responsibilities",
            f"![[{constants.GENERATED}/Feeds/Responsibilities#Responsibilities]]"]


def _w_projects(cfg: dict, opts: dict) -> list[str]:
    today = dt.date.today()
    rows = []
    for rel, post in vault.notes(constants.PROJECTS):
        fm = post.metadata
        if fm.get("type") != "project" or fm.get("status") != "active":
            continue
        last = fm.get("last_touched")
        try:
            days = (today - dt.date.fromisoformat(str(last))).days if last else None
        except ValueError:
            days = None
        rows.append((days if days is not None else 10**6,
                     rel.rsplit("/", 1)[-1][:-3], fm.get("next_action") or "—", days))
    if not rows:
        return ["## Projects", "*No active projects.*"]
    out = ["## Projects", "| project | next action | idle |", "|---|---|---|"]
    for _, name, nxt, days in sorted(rows):
        out.append(f"| [[{name}]] | {nxt} | {f'{days}d' if days is not None else '—'} |")
    return out


def _w_agenda(cfg: dict, opts: dict) -> list[str]:
    return ["## Agenda", f"![[{constants.GENERATED}/Feeds/Agenda#Agenda]]"]


def _w_reading(cfg: dict, opts: dict) -> list[str]:
    """Rainbell's "currently reading", reduced to what is live: books —
    and Library workspace texts (type: source) — whose `status` is
    `reading`. Nothing on the go = no widget."""
    limit = int(opts.get("limit", 3))
    rows = []
    for folder in (constants.BOOKS_DIR, constants.LIBRARY_DIR):
        for rel, post in vault.notes(folder):
            fm = post.metadata
            if fm.get("type") not in ("book", "source") or fm.get("status") != "reading":
                continue
            name = rel.rsplit("/", 1)[-1][:-3]
            creator = fm.get("creator")
            rows.append(f"- 📖 [[{name}]]" + (f" — {creator}" if creator else ""))
    if not rows:
        return []
    return ["## Reading"] + rows[:limit]


def _w_countdown(cfg: dict, opts: dict) -> list[str]:
    """Rainbell's birthday countdown, static form: one line of "Nd — label".
    Events come from `countdowns:` in dashboard.yaml; `MM-DD` recurs
    yearly, a full date is one-shot and disappears once past."""
    today = dt.date.today()
    parts = []
    for ev in (opts.get("events") or cfg.get("countdowns") or []):
        label, raw = ev.get("label", "?"), str(ev.get("date", ""))
        try:
            if len(raw) == 5:  # MM-DD, next occurrence
                month, day = int(raw[:2]), int(raw[3:])
                target = dt.date(today.year, month, day)
                if target < today:
                    target = dt.date(today.year + 1, month, day)
            else:
                target = dt.date.fromisoformat(raw)
        except ValueError:
            continue
        days = (target - today).days
        if days < 0:
            continue
        parts.append((days, f"**{'today' if days == 0 else f'{days}d'}** — {label}"))
    if not parts:
        return []
    return ["## Countdown", " · ".join(p for _, p in sorted(parts))]


def _w_now_playing(cfg: dict, opts: dict) -> list[str]:
    return ["## Now", f"![[{constants.GENERATED}/Feeds/Now Playing#Now]]"]


def _w_domains(cfg: dict, opts: dict) -> list[str]:
    links = " · ".join(
        f"[[{constants.META}/Bases/{d.capitalize()}.base|{d}]]"
        for d in ["neuroscience", "linguistics", "music", "code", "writing", "personal"])
    return ["## Domains", links]


def _w_folders(cfg: dict, opts: dict) -> list[str]:
    entries = []
    for base in (constants.NOTES, constants.PROJECTS):
        base_path = vault.abs_path(base)
        if not base_path.exists():
            continue
        for child in (p for p in base_path.iterdir() if p.is_dir()):
            fcfg = cfg["folders"].get(child.name, {})
            if fcfg.get("show", True) is False:
                continue
            n = fcfg.get("recent", cfg["default_recent"])
            files = sorted(child.rglob("*.md"), key=lambda f: f.stat().st_mtime,
                           reverse=True)[:n]
            recent = " · ".join(f"[[{f.stem}]]" for f in files) or "—"
            entries.append((_mtime(child), f"| **{child.name}** | {recent} |"))
    if not entries:
        return []
    out = ["## Folders — most recent first", "| folder | recent |", "|---|---|"]
    out += [row for _, row in sorted(entries, reverse=True)]
    return out


def _w_morning(cfg: dict, opts: dict) -> list[str]:
    if vault.read(MORNING_PATH) is None:
        return []
    return [f"![[{MORNING_PATH.removesuffix('.md')}#Morning]]"]


def _w_embed(cfg: dict, opts: dict) -> list[str]:
    """Generic tool slot: transclude any note. The cheap way to bolt a new
    feed onto the dashboard before it earns a dedicated widget."""
    note = opts.get("note")
    if not note:
        return []
    title = opts.get("title")
    head = [f"## {title}"] if title else []
    return head + [f"![[{note}]]"]


def _w_rss(cfg: dict, opts: dict) -> list[str]:
    from ..ingest import rss
    if not opts.get("url"):
        return ["## Feed", "*rss widget needs a `url` option.*"]
    note = rss.feed_note_path(opts)
    if vault.read(note) is None:
        return [f"## {rss.slug(opts)}", "*Feed not fetched yet — next poll fills this in.*"]
    return [f"![[{note.removesuffix('.md')}#{rss.slug(opts)}]]"]


def _w_training(cfg: dict, opts: dict) -> list[str]:
    return ["## Training", f"![[{constants.GENERATED}/Feeds/Training#Training]]"]


def _w_jobs(cfg: dict, opts: dict) -> list[str]:
    return ["## Jobs", f"![[{constants.GENERATED}/Feeds/Jobs#Jobs]]"]


WIDGETS = {
    "pins": _w_pins,
    "agenda": _w_agenda,
    "responsibilities": _w_responsibilities,
    "projects": _w_projects,
    "now-playing": _w_now_playing,
    "reading": _w_reading,
    "countdown": _w_countdown,
    "domains": _w_domains,
    "folders": _w_folders,
    "morning": _w_morning,
    "embed": _w_embed,
    "rss": _w_rss,
    "training": _w_training,
    "jobs": _w_jobs,
}


# --- assembly --------------------------------------------------------------

def generate() -> str:
    cfg = _cfg()
    today = dt.date.today()
    daily = constants.daily_rel(today)

    title = today.strftime(cfg.get("title_format", "%A, %B %d"))
    # Rainbell's AGENDA ladder: every periodic altitude one click away.
    lines = [f"# {title}", "",
             f"[[{daily}|open today]] · "
             f"[[{constants.weekly_rel(today)}|week]] · "
             f"[[{constants.monthly_rel(today)}|month]] · "
             f"[[{constants.quarterly_rel(today)}|quarter]] · "
             f"[[{constants.yearly_rel(today)}|year]]"]
    # Meta Bind errors loudly on a missing target note, so the mood/energy
    # sliders only render once today's daily exists (next regen picks it up).
    if vault.read(daily + ".md") is not None:
        lines += ["",
                  f"`INPUT[slider(title(mood), minValue(1), maxValue(10)):{daily}#mood]` "
                  f"`INPUT[slider(title(energy), minValue(1), maxValue(10)):{daily}#energy]`"]

    for entry in cfg["widgets"]:
        wtype, opts = (entry, {}) if isinstance(entry, str) else \
            (entry.get("type", ""), {k: v for k, v in entry.items() if k != "type"})
        render = WIDGETS.get(wtype)
        block = render(cfg, opts) if render else \
            [f"*Unknown widget `{wtype}` — known: {', '.join(sorted(WIDGETS))}*"]
        if block:
            lines.append("")
            lines.extend(block)

    # Operator-supplied frontmatter (banner keys, extra cssclasses, …) from
    # dashboard.yaml rides along; the generated guard keys stay protected.
    fm = {"type": "dashboard", "cssclasses": ["dashboard"]}
    extra = cfg.get("frontmatter")
    if isinstance(extra, dict):
        fm.update({k: v for k, v in extra.items()
                   if k not in ("generated", "generated_at")})
    return vault.write_generated(DASHBOARD_PATH, "\n".join(lines), fm,
                                 header=bool(cfg.get("warning_header", False)))
