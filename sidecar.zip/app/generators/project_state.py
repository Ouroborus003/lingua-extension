"""Project state notes (spec §9.4) — what makes re-entry cheap.

For each project note in 03 Projects/, generates a sibling _state.md with the
last files touched, open loops, next_action, blockers, and recent digest
mentions.
"""
from __future__ import annotations

import re

from .. import constants, vault

_UNCHECKED = re.compile(r"^\s*[-*] \[ \] (.+)$")


def _open_loops(folder: str) -> list[str]:
    loops = []
    for rel, post in vault.notes(folder):
        if rel.endswith("/_state.md"):
            continue
        for line in post.content.splitlines():
            m = _UNCHECKED.match(line)
            if m:
                loops.append(m.group(1).strip())
    return loops[:10]


def _digest_mentions(project: str, n: int = 3) -> list[str]:
    hits = []
    for rel, post in vault.notes(f"{constants.GENERATED}/Digests"):
        if project.lower() in post.content.lower():
            hits.append(rel.rsplit("/", 1)[-1][:-3])
    return sorted(hits, reverse=True)[:n]


def generate(only: str | None = None) -> list[str]:
    written = []
    for rel, post in vault.notes(constants.PROJECTS):
        fm = post.metadata
        if fm.get("type") != "project":
            continue
        name = rel.rsplit("/", 1)[-1][:-3]
        if only and name != only:
            continue
        folder = rel.rsplit("/", 1)[0]
        if folder == constants.PROJECTS:
            continue  # project note must live in its own subfolder

        touched = vault.last_touched_files(folder, fm.get("repo") or None)
        loops = _open_loops(folder)

        body = [f"# {name} — where you left off", ""]
        body.append(f"**Next action:** {fm.get('next_action') or '*none recorded — set one on exit*'}")
        blockers = fm.get("blockers") or []
        if blockers:
            body.append("")
            body.append("> [!loop] Blockers")
            body.extend(f"> - {b}" for b in blockers)
        body.append("")
        body.append("## Last touched")
        body.extend(f"- `{f}`" for f in touched) if touched else body.append("- —")
        body.append("")
        body.append("## Open loops")
        body.extend(f"- [ ] {l}" for l in loops) if loops else body.append("- none")
        mentions = _digest_mentions(name)
        if mentions:
            body.append("")
            body.append("## Recent digests that mention this")
            body.extend(f"- [[{m}]]" for m in mentions)

        written.append(vault.write_generated(
            f"{folder}/_state.md", "\n".join(body),
            {"type": "state", "project": name}))
    return written
