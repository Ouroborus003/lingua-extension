"""Domain canvas maps (spec §9.10): canvas as a navigation mode.

Each domain folder under 01 Notes gets a `<Domain> Map.canvas`. The layout
is the operator's — created empty once, then never rearranged. The sidecar
appends notes that are not yet on the map to a staging column at the canvas
edge (visibly colored), so nothing goes missing while the operator decides
where it belongs.
"""
from __future__ import annotations

import logging

from .. import canvas, constants, vault

log = logging.getLogger("sidecar.canvas_maps")

STAGE_CAP = 20  # per domain per run — a wall of 200 staged cards helps no one


def map_path(domain: str) -> str:
    return f"{constants.NOTES}/{domain}/{domain.capitalize()} Map.canvas"


def _domain_dirs() -> list[str]:
    base = vault.abs_path(constants.NOTES)
    if not base.exists():
        return []
    return sorted(p.name for p in base.iterdir() if p.is_dir())


def stage(only_domain: str | None = None) -> dict:
    staged: dict[str, int] = {}
    for domain in _domain_dirs():
        if only_domain and domain != only_domain:
            continue
        folder = f"{constants.NOTES}/{domain}"
        notes = [rel for rel, post in vault.notes(folder)
                 if not rel.endswith("/_state.md")]
        if not notes:
            continue
        rel_map = map_path(domain)
        on_map = canvas.referenced_files(canvas.load(rel_map))
        missing = [n for n in notes if n not in on_map][:STAGE_CAP]
        if missing:
            n = canvas.append_file_nodes(rel_map, missing)
            staged[domain] = n
            log.info("staged %d note(s) on %s", n, rel_map)
    return {"staged": staged}
