"""Workout views (spec §9.9): logging, not programming.

One generated feed: a PR table per lift (top set by weight, with reps and
date), latest bodyweight, and the last few sessions. Charts stay in the
Tracker/Bases layer; this is the glanceable summary.
"""
from __future__ import annotations

import datetime as dt

from .. import constants, vault

FEED_PATH = f"{constants.GENERATED}/Feeds/Training.md"


def _workouts() -> list[dict]:
    rows = []
    for rel, post in vault.notes(constants.BODY):
        fm = post.metadata
        if fm.get("type") != "workout":
            continue
        try:
            date = fm["date"] if isinstance(fm.get("date"), dt.date) else \
                dt.date.fromisoformat(str(fm.get("date")))
        except (KeyError, ValueError, TypeError):
            continue
        rows.append({
            "name": rel.rsplit("/", 1)[-1][:-3],
            "date": date,
            "session": str(fm.get("session", "?")),
            "kg": float(fm.get("top_set_kg") or 0),
            "reps": int(fm.get("top_set_reps") or 0),
            "rpe": fm.get("rpe"),
            "bw": fm.get("bodyweight_kg"),
        })
    return sorted(rows, key=lambda r: r["date"])


def generate() -> str:
    rows = _workouts()
    body = ["## Training"]
    if not rows:
        body.append("*No workouts logged yet.*")
        return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})

    prs: dict[str, dict] = {}
    for r in rows:
        best = prs.get(r["session"])
        if best is None or (r["kg"], r["reps"]) > (best["kg"], best["reps"]):
            prs[r["session"]] = r
    body += ["", "### PRs", "| lift | top set | date |", "|---|---|---|"]
    for session, r in sorted(prs.items()):
        body.append(f"| {session} | {r['kg']:g} kg × {r['reps']} | {r['date']} |")

    latest_bw = next((r["bw"] for r in reversed(rows) if r["bw"]), None)
    if latest_bw:
        body += ["", f"**Bodyweight:** {latest_bw} kg (last logged)"]

    body += ["", "### Recent", "| date | session | top set | RPE |", "|---|---|---|---|"]
    for r in rows[-5:][::-1]:
        rpe = r["rpe"] if r["rpe"] is not None else "—"
        body.append(f"| [[{r['name']}\\|{r['date']}]] | {r['session']} | "
                    f"{r['kg']:g} kg × {r['reps']} | {rpe} |")

    return vault.write_generated(FEED_PATH, "\n".join(body), {"type": "inbox"})
