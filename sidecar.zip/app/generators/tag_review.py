"""Assisted tagging (spec §9.11): the system proposes, the operator judges.

Proposals land in a review queue, never applied silently. Convention:
- check a line → the tag is applied to the note on the next pass
- delete a line → recorded as rejected, never re-offered
Vocabulary lives in 08 Meta/tags.yaml; rejections in 08 Meta/tags-rejected.yaml.
"""
from __future__ import annotations

import json
import re

import yaml

from .. import constants, llm, prompts, settings, vault

QUEUE_PATH = f"{constants.GENERATED}/Feeds/TagReview.md"
VOCAB_PATH = f"{constants.META}/tags.yaml"
REJECTED_PATH = f"{constants.META}/tags-rejected.yaml"

_LINE = re.compile(r"^- \[(x| )\] #([\w/\-]+) — \[\[([^\]|]+)\]\]")

_SCHEMA = {
    "type": "object",
    "properties": {
        "tags": {"type": "array", "items": {"type": "string"}, "maxItems": 3},
    },
    "required": ["tags"],
}


def _vocab() -> list[str]:
    p = vault.abs_path(VOCAB_PATH)
    if not p.exists():
        return []
    data = yaml.safe_load(p.read_text()) or {}
    return list(data.get("tags", []))


def _rejected() -> dict[str, list[str]]:
    p = vault.abs_path(REJECTED_PATH)
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text()) or {}


def _save_rejected(rej: dict[str, list[str]]) -> None:
    vault.abs_path(REJECTED_PATH).write_text(
        yaml.safe_dump(rej, allow_unicode=True, sort_keys=True))


def _find_note(basename: str) -> str | None:
    for folder in (constants.INBOX, constants.NOTES):
        for rel, _ in vault.notes(folder):
            if rel.rsplit("/", 1)[-1][:-3] == basename:
                return rel
    return None


def apply_reviewed() -> dict:
    """Process the operator's verdicts from the existing queue."""
    post = vault.read(QUEUE_PATH)
    if post is None:
        return {"applied": 0, "rejected": 0}
    applied = 0
    offered: list[tuple[str, str]] = []
    rej = _rejected()
    for line in post.content.splitlines():
        m = _LINE.match(line.strip())
        if not m:
            continue
        checked, tag, note = m.group(1) == "x", m.group(2), m.group(3)
        offered.append((note, tag))
        if checked:
            rel = _find_note(note)
            if rel:
                current = vault.read(rel).metadata.get("tags") or []
                if tag not in current:
                    vault.set_frontmatter_key(rel, "tags", current + [tag])
                    applied += 1
    # Lines that were offered last time and are now gone were deleted → rejected.
    prev = _load_offered_state()
    now_offered = set(offered)
    newly_rejected = 0
    for note, tag in prev:
        if (note, tag) not in now_offered:
            rej.setdefault(note, [])
            if tag not in rej[note]:
                rej[note].append(tag)
                newly_rejected += 1
    if newly_rejected:
        _save_rejected(rej)
    _save_offered_state(offered)
    return {"applied": applied, "rejected": newly_rejected}


_OFFERED_STATE = "tag_offers.json"


def _load_offered_state() -> list[tuple[str, str]]:
    from ..config import STATE_DIR
    p = STATE_DIR / _OFFERED_STATE
    if not p.exists():
        return []
    return [tuple(x) for x in json.loads(p.read_text())]


def _save_offered_state(offers: list[tuple[str, str]]) -> None:
    from ..config import STATE_DIR
    (STATE_DIR / _OFFERED_STATE).write_text(json.dumps(offers))


async def generate() -> str:
    apply_reviewed()
    vocab = _vocab()
    rej = _rejected()

    candidates = []
    for folder in (constants.INBOX, constants.NOTES):
        for rel, post in vault.notes(folder):
            if not post.metadata.get("tags") and len(post.content.strip()) > 80:
                candidates.append((rel, post))
    candidates = candidates[:settings.effective().tag_review_max]

    lines = ["# Tag review", "",
             "Check a line to apply the tag; delete a line to reject it "
             "(it will not be offered again).", ""]
    offers: list[tuple[str, str]] = []
    for rel, post in candidates:
        name = rel.rsplit("/", 1)[-1][:-3]
        prompt = (f"EXISTING VOCABULARY (prefer these): {', '.join(vocab) or '(empty)'}\n\n"
                  f"NOTE:\n{post.content[:3000]}")
        try:
            raw = await llm.chat(prompts.load("tag_proposals"), prompt, feature="tag_proposals",
                                 temperature=0.2, json_schema=_SCHEMA)
            tags = json.loads(raw).get("tags", [])
        except Exception:
            continue
        for tag in tags:
            tag = tag.strip().lstrip("#").replace(" ", "-").lower()
            if not tag or tag in rej.get(name, []):
                continue
            marker = "" if tag in vocab else " *(new)*"
            lines.append(f"- [ ] #{tag} — [[{name}]]{marker}")
            offers.append((name, tag))

    if not offers:
        lines.append("*Queue is empty — nothing untagged, or LM Studio is offline.*")
    _save_offered_state(offers)
    return vault.write_generated(QUEUE_PATH, "\n".join(lines), {"type": "inbox"})
