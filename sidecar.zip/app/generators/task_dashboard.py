"""Task Dashboard generator — AuDHD-friendly task management view.

Composes a dashboard widget with:
- Micro-task inbox (tasks tagged #micro due today)
- Project progress bars (Tracker embeds)
- Course progress bars (Tracker embeds)
- Next due countdown
- Time-since-last-touch per project/course
- Week heatmap of scheduled work
- Sensory regulation toggles (Meta Bind buttons)
- Body-doubling link
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any

import yaml

from . import constants, vault


TASK_DASHBOARD_PATH = f"{constants.GENERATED}/Feeds/Task Dashboard.md"


def _cfg() -> dict:
    """Load task dashboard config from dashboard.yaml or use defaults."""
    p = vault.abs_path(f"{constants.META}/dashboard.yaml")
    data = (yaml.safe_load(p.read_text()) or {}) if p.exists() else {}
    task_cfg = data.get("task_dashboard", {})
    return {
        "micro_tag": task_cfg.get("micro_tag", "micro"),
        "projects": task_cfg.get("projects", []),
        "courses": task_cfg.get("courses", []),
        "body_doubling_url": task_cfg.get("body_doubling_url", "https://www.focusmate.com/"),
        "show_heatmap": task_cfg.get("show_heatmap", True),
        "heatmap_weeks": task_cfg.get("heatmap_weeks", 4),
    }


def _parse_frontmatter_date(value: Any) -> dt.date | None:
    """Parse date from frontmatter (string or datetime)."""
    if not value:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    s = str(value).strip()
    try:
        return dt.date.fromisoformat(s[:10])
    except ValueError:
        return None


def _days_since(date: dt.date | None) -> int | None:
    if not date:
        return None
    return (dt.date.today() - date).days


def _w_micro_tasks(cfg: dict) -> list[str]:
    """Micro-task inbox: #micro tasks due today or overdue."""
    tag = cfg["micro_tag"]
    today = dt.date.today()
    out = ["## 🔹 Micro-tasks (due today)"]
    found = False

    for folder in (constants.NOTES, constants.PROJECTS, constants.COURSEWORK):
        for rel, post in vault.notes(folder):
            fm = post.metadata
            tags = fm.get("tags", [])
            if isinstance(tags, str):
                tags = [tags]
            tags = [t.lstrip("#").lower() for t in tags]
            if tag not in tags:
                continue

            due = _parse_frontmatter_date(fm.get("due"))
            if due and due <= today:
                found = True
                status = fm.get("status", "todo")
                checkbox = "x" if status == "done" else " "
                title = rel.rsplit("/", 1)[-1][:-3]
                overdue = " ⚠️ OVERDUE" if due < today else ""
                out.append(f"- [{checkbox}] [[{title}]] (due: {due}){overdue}")

    if not found:
        out.append("*No micro-tasks due today.*")
    return out


def _w_project_progress(cfg: dict) -> list[str]:
    """Project progress bars via Tracker embeds."""
    projects = cfg["projects"]
    if not projects:
        return []
    out = ["## 📦 Project Progress"]
    for p in projects:
        name = p.get("name", "Unnamed")
        tracker_key = p.get("tracker", name.lower().replace(" ", "-"))
        out.append(f"### {name}")
        out.append(f"![[tracker: {tracker_key}]]")
        out.append("")
    return out


def _w_course_progress(cfg: dict) -> list[str]:
    """Course progress bars via Tracker embeds."""
    courses = cfg["courses"]
    if not courses:
        return []
    out = ["## 🎓 Course Progress"]
    for c in courses:
        name = c.get("name", "Unnamed")
        tracker_key = c.get("tracker", name.lower().replace(" ", "-"))
        out.append(f"### {name}")
        out.append(f"![[tracker: {tracker_key}]]")
        out.append("")
    return out


def _w_next_due(cfg: dict) -> list[str]:
    """Countdown to nearest due date across all tasks."""
    today = dt.date.today()
    nearest: tuple[dt.date, str, str] | None = None  # (due, title, rel)

    for folder in (constants.NOTES, constants.PROJECTS, constants.COURSEWORK):
        for rel, post in vault.notes(folder):
            fm = post.metadata
            due = _parse_frontmatter_date(fm.get("due"))
            if not due:
                continue
            if due < today:
                continue  # skip overdue for "next due"
            title = rel.rsplit("/", 1)[-1][:-3]
            if nearest is None or due < nearest[0]:
                nearest = (due, title, rel)

    if not nearest:
        return ["## ⏭️ Next Due", "*No upcoming due dates.*"]

    due, title, rel = nearest
    days = (due - today).days
    label = "today" if days == 0 else f"in {days} day{'s' if days != 1 else ''}"
    return [f"## ⏭️ Next Due", f"**[[{title}]]** — due **{label}** ({due})"]


def _w_time_since_touch(cfg: dict) -> list[str]:
    """Time since last touch per project/course."""
    today = dt.date.today()
    entries = []

    for folder in (constants.PROJECTS, constants.COURSEWORK):
        for rel, post in vault.notes(folder):
            fm = post.metadata
            if fm.get("type") not in ("project", "coursework"):
                continue
            last = _parse_frontmatter_date(fm.get("last_touched"))
            days = _days_since(last)
            title = rel.rsplit("/", 1)[-1][:-3]
            if days is not None:
                entries.append((days, f"[[{title}]] — {days}d ago"))
            else:
                entries.append((9999, f"[[{title}]] — never"))

    if not entries:
        return ["## 🕐 Last Touched", "*No projects/courses found.*"]

    entries.sort()
    out = ["## 🕐 Last Touched", "| Item | Idle |", "|---|---|"]
    for days, label in entries[:15]:  # top 15
        idle = "—" if days >= 9999 else f"{days}d"
        out.append(f"| {label} | {idle} |")
    return out


def _w_week_heatmap(cfg: dict) -> list[str]:
    """Simple week heatmap of scheduled work (tasks with due dates)."""
    if not cfg.get("show_heatmap", True):
        return []

    today = dt.date.today()
    weeks = cfg.get("heatmap_weeks", 4)
    start = today - dt.timedelta(days=today.weekday())  # Monday of this week
    start = start - dt.timedelta(weeks=weeks - 1)

    # Count tasks due per day
    day_counts: dict[dt.date, int] = {}
    for folder in (constants.NOTES, constants.PROJECTS, constants.COURSEWORK):
        for rel, post in vault.notes(folder):
            fm = post.metadata
            due = _parse_frontmatter_date(fm.get("due"))
            if due and start <= due <= today + dt.timedelta(weeks=1):
                day_counts[due] = day_counts.get(due, 0) + 1

    if not day_counts:
        return ["## 📅 Week Heatmap", "*No scheduled tasks in range.*"]

    max_count = max(day_counts.values())
    # Build markdown table: weeks as rows, days as columns
    out = ["## 📅 Week Heatmap (tasks due)", ""]
    header = "| Week | Mon | Tue | Wed | Thu | Fri | Sat | Sun |"
    sep = "|---|---|---|---|---|---|---|---|"
    out.append(header)
    out.append(sep)

    for w in range(weeks):
        week_start = start + dt.timedelta(weeks=w)
        week_label = week_start.strftime("%m/%d")
        row = [f"| **{week_label}**"]
        for d in range(7):
            day = week_start + dt.timedelta(days=d)
            count = day_counts.get(day, 0)
            if count == 0:
                cell = "·"
            elif count <= max_count // 3:
                cell = "▫️"
            elif count <= 2 * max_count // 3:
                cell = "▪️"
            else:
                cell = "🟦"
            if day == today:
                cell = f"**{cell}**"
            row.append(f" {cell} ")
        row.append("|")
        out.append("|".join(row))

    out.append("")
    out.append("*· = none · ▫️ = low · ▪️ = medium · 🟦 = high*")
    return out


def _w_sensory_toggles(cfg: dict) -> list[str]:
    """Meta Bind buttons for sensory regulation."""
    out = ["## 🎛️ Sensory Regulation", ""]
    out.append("Quick toggles for focus environment:")
    out.append("")
    out.append("`INPUT[button:!eink-optimizer:toggle]` `INPUT[button:!obsidian-hider:toggle]` `INPUT[button:!zen-mode:toggle]`")
    out.append("")
    out.append("> `!eink-optimizer:toggle` — Toggle E-Ink mode (requires `eink-optimizer` plugin)")
    out.append("> `!obsidian-hider:toggle` — Toggle UI chrome hiding (requires `obsidian-hider` plugin)")
    out.append("> `!zen-mode:toggle` — Toggle Zen mode (built-in Obsidian)")
    return out


def _w_body_doubling(cfg: dict) -> list[str]:
    """Body-doubling link."""
    url = cfg.get("body_doubling_url", "https://www.focusmate.com/")
    out = ["## 👥 Body Doubling", ""]
    out.append(f"[Open Focusmate →]({url})")
    out.append("")
    out.append("*External accountability without social pressure. Start a session, work silently alongside others.*")
    return out


WIDGETS = {
    "micro_tasks": _w_micro_tasks,
    "project_progress": _w_project_progress,
    "course_progress": _w_course_progress,
    "next_due": _w_next_due,
    "time_since_touch": _w_time_since_touch,
    "week_heatmap": _w_week_heatmap,
    "sensory_toggles": _w_sensory_toggles,
    "body_doubling": _w_body_doubling,
}


def generate() -> str:
    cfg = _cfg()
    today = dt.date.today()

    lines = [f"# Task Dashboard — {today.strftime('%A, %B %d')}", ""]

    # Ordered widget list (can be configured later via dashboard.yaml)
    widget_order = [
        "micro_tasks",
        "project_progress",
        "course_progress",
        "next_due",
        "time_since_touch",
        "week_heatmap",
        "sensory_toggles",
        "body_doubling",
    ]

    for wname in widget_order:
        render = WIDGETS.get(wname)
        if render:
            block = render(cfg)
            if block:
                lines.append("")
                lines.extend(block)

    fm = {"type": "dashboard", "cssclasses": ["dashboard", "task-dashboard"]}
    return vault.write_generated(TASK_DASHBOARD_PATH, "\n".join(lines), fm, header=True)