"""forvo.py — human-recorded pronunciation fetcher (Forvo).

Ported from LinguaStudio's `forvo_client.py`, itself modeled on the
`realmayus/anki_forvo_dl` add-on: it retrieves the same MP3 a person would get
by clicking play on a Forvo word page (web scraping — Forvo has no free official
API). Standard library only (urllib + re + base64), so the sidecar gains no new
dependency; the page is parsed with targeted regexes rather than an HTML lib.

Two entry points serve the dual reader's two pronunciation modes:
    list_pronunciations(word, lang, limit) -> [{url, votes, user}]
        ranked alternates, no download — the "menu" mode (pick a speaker).
    fetch(word, lang) -> bytes | None
        the single most-voted clip's MP3 — the "popular" mode (auto-play).
    download(url) -> bytes | None      # fetch one alternate's MP3
    is_available() -> bool             # cheap reachability check

Every path is wrapped so any failure (network blocked, layout change, no
pronunciation) returns None/[] — the reader then falls back to device TTS, so a
word click never errors.
"""
from __future__ import annotations

import base64
import json
import logging
import random
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import STATE_DIR

log = logging.getLogger("sidecar.forvo")

# --------------------------------------------------------------------------
# Retry + cache policy — every number below came from a measurement.
#
# Forvo's word page is behind a CloudFlare *interactive* challenge
# (`cf-mitigated: challenge`, "Just a moment…"), not a ban. Measured
# 2026-08-14, 12 sequential lookups of 好: **2 succeeded, 10 returned HTTP
# 403** — and `popular` mode returned a real MP3 seconds after `menu` mode had
# 403'd. So the source is intermittently available at roughly 17% per attempt,
# and a single shot is the wrong way to ask.
#
# A previous session sampled this ONCE, concluded "Forvo is blocked upstream,
# not a code bug", and shipped an error message instead of a retry. That is
# P-VERIFY/V10: an empty result from a bounded probe promoted to a cause.
# --------------------------------------------------------------------------

# 4 attempts, jittered. Jitter matters: a fixed backoff from several words in
# one click lands as a synchronised burst, which is what a rate limiter is
# built to punish.
_ATTEMPTS = 4
_BACKOFF = (0.4, 1.2, 2.5)

# HTTP codes worth trying again. 403 is the challenge and is *transient* here.
# 404 means the word genuinely has no page — retrying it just burns seconds per
# click for a guaranteed miss.
_RETRY_CODES = frozenset({403, 429, 500, 502, 503, 504})

# Resolved URLs, persisted. This is the highest-value part of the whole fix:
# audio00.forvo.com is NOT challenge-gated (verified — a bad path returns a
# clean 404, a good one 200 + audio), so a URL captured during one lucky scrape
# keeps playing forever. One success per word is all we ever need.
_URL_CACHE = STATE_DIR / "forvo_urls.json"
_CACHE_TTL = 90 * 24 * 3600     # Forvo recordings essentially never change.
_cache_lock = threading.Lock()
_cache: dict | None = None


def _load_cache() -> dict:
    global _cache
    with _cache_lock:
        if _cache is None:
            try:
                _cache = json.loads(_URL_CACHE.read_text(encoding="utf-8"))
            except Exception:
                _cache = {}          # absent or corrupt — rebuild from scratch
        return _cache


def _cache_get(key: str) -> list | None:
    entry = _load_cache().get(key)
    if not entry or (time.time() - entry.get("ts", 0)) > _CACHE_TTL:
        return None
    return entry.get("items") or None


def _cache_put(key: str, items: list) -> None:
    """Persist a SUCCESS. Failures are never written — a cached failure is what
    turned this intermittent source into an apparently dead one."""
    if not items:
        return
    c = _load_cache()
    with _cache_lock:
        c[key] = {"items": items, "ts": time.time()}
        try:
            _URL_CACHE.parent.mkdir(parents=True, exist_ok=True)
            _URL_CACHE.write_text(json.dumps(c, ensure_ascii=False), encoding="utf-8")
        except Exception as exc:      # a cache that cannot write is not an error
            log.debug("forvo url cache write failed: %s", exc)

# Forvo serves a CloudFlare-gated page; a desktop browser UA is required or the
# request is bounced. These headers mirror what anki_forvo_dl sends.
_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://forvo.com/",
}

_WORD_URL = "https://forvo.com/word/{word}/"
# Forvo serves audio from numbered hosts; audio00 is the canonical default the
# add-on uses. The decoded base64 token is the path under /audios/mp3/.
_MP3_BASE = "https://audio00.forvo.com/audios/mp3/"

# Vault language codes -> Forvo's 2-letter codes. Codes match the operator's
# reading languages; anything unlisted falls through to its primary subtag
# (covers es/fr/it/de/pt/ru/… directly). The deu/ara/hun/spa entries are
# lingua-workspace's LinguaStudio-style 3-letter codes (main.js's LANGS
# table) — without them the fallback returns the 3-letter code itself
# ("deu", not "de"), _language_block() never finds a matching container,
# and list_pronunciations() silently falls back to parsing the *whole* page
# instead of nothing, which can hand back a wrong-language clip.
_LANG_MAP = {
    "zh-hans": "zh", "zh-hant": "zh", "cmn": "zh", "yue": "zh",
    "jpn": "ja", "kor": "ko", "nb": "no", "nn": "no",
    "deu": "de", "ara": "ar", "hun": "hu", "spa": "es",
}

# The play button embeds the audio path as base64 in a Play(...) call. Args are:
#   Play(id,'<mp3-lowqual-b64>','<ogg-b64>',<bool>,'<mp3-highqual-b64>',...)
# The 5th argument (group 1) is the high-quality MP3 path; same shape
# anki_forvo_dl relies on.
_PLAY_RE = re.compile(r"Play\(\d+,'[^']*','[^']*',\w+,'([^']+)'")
_VOTES_RE = re.compile(r"num_votes[^>]*>[^\d-]*(-?\d+)")
# Speaker attribution near the play button: "Pronunciation by <a ...>user</a>".
_SPEAKER_RE = re.compile(r"Pronunciation\s+by\s*(?:<[^>]*>\s*)*([^<>\s][^<>]{0,39}?)\s*<")


def forvo_lang(lang: str) -> str:
    """Map a vault language code to Forvo's language code."""
    c = (lang or "").strip().lower()
    return _LANG_MAP.get(c) or _LANG_MAP.get(c.split("-")[0]) or c.split("-")[0]


def _get(url: str, timeout: int = 12) -> bytes | None:
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 (fixed hosts)
        return r.read()


def _language_block(html: str, code: str) -> str | None:
    """Return the HTML slice for the requested language container, or None.

    Forvo wraps each language's pronunciations in `id="language-container-<code>"`.
    Slice from that marker to the next language container (or end of document) so
    a word that exists in several languages picks the right one.
    """
    start = html.find(f"language-container-{code}")
    if start == -1:
        return None
    nxt = re.search(r"language-container-\w{2,4}", html[start + 1:])
    end = (start + 1 + nxt.start()) if nxt else len(html)
    return html[start:end]


def _pronunciations(block: str) -> list[dict]:
    """[{url, votes, user}] for each pronunciation in a language block.

    Sorted by vote count descending so the community-preferred clip wins.
    Speaker attribution is best-effort (blank when the layout hides it).
    """
    items = []
    matches = list(_PLAY_RE.finditer(block))
    for i, m in enumerate(matches):
        token = m.group(1)
        try:
            path = base64.b64decode(token).decode("utf-8", errors="replace").strip()
        except Exception:
            continue
        if not path:
            continue
        # Scope votes + speaker to this item's segment (button -> next button) so
        # one pronunciation never inherits its neighbour's attribution.
        seg_end = matches[i + 1].start() if i + 1 < len(matches) else len(block)
        segment = block[m.start():seg_end]
        vm = _VOTES_RE.search(segment)
        sm = _SPEAKER_RE.search(segment)
        items.append({
            "url":   _MP3_BASE + path,
            "votes": int(vm.group(1)) if vm else 0,
            "user":  sm.group(1).strip() if sm else "",
        })
    items.sort(key=lambda d: d["votes"], reverse=True)
    return items


def list_pronunciations_detailed(word: str, lang: str, limit: int = 6) -> dict:
    """Ranked alternates PLUS why the list is empty when it is.

    `list_pronunciations` collapses three different situations into `[]`:
    Forvo blocked us, Forvo changed its markup, or the word genuinely has no
    recordings. Only the third is the reader's problem, and telling them "no
    human recordings found" when the truth is a 403 is the same silent-failure
    shape that has bitten this vault repeatedly — the reported condition is not
    the real one.

    Returns {items, unavailable, reason}. `unavailable` means the SOURCE failed,
    not that the word has nothing.
    """
    word = (word or "").strip()
    if not word:
        return {"items": [], "unavailable": False, "reason": ""}
    code = forvo_lang(lang)

    # A previously resolved word never touches the network again — and because
    # the MP3 host is ungated, those URLs still play even while forvo.com is
    # challenging every request.
    ckey = f"{code}|{word}"
    cached = _cache_get(ckey)
    if cached:
        return {"items": cached[:max(1, limit)], "unavailable": False,
                "reason": "", "cached": True}

    url = _WORD_URL.format(word=urllib.parse.quote(word, safe=""))
    raw, last_reason = None, ""
    for attempt in range(_ATTEMPTS):
        try:
            raw = _get(url)
            break
        except urllib.error.HTTPError as exc:
            last_reason = f"Forvo returned HTTP {exc.code}"
            if exc.code not in _RETRY_CODES:
                # A real 404 is an answer, not an outage: this word has no page.
                log.info("forvo has no page for %r (%s): HTTP %s", word, code, exc.code)
                return {"items": [], "unavailable": False, "reason": ""}
        except Exception as exc:
            last_reason = f"Forvo unreachable: {exc}"
        if attempt < _ATTEMPTS - 1:
            base = _BACKOFF[min(attempt, len(_BACKOFF) - 1)]
            time.sleep(base * (0.6 + random.random() * 0.8))

    if raw is None:
        log.info("forvo unavailable for %r (%s) after %d attempts: %s",
                 word, code, _ATTEMPTS, last_reason)
        return {"items": [], "unavailable": True, "reason": last_reason}

    if not raw:
        return {"items": [], "unavailable": True, "reason": "Forvo returned an empty page"}
    try:
        html = raw.decode("utf-8", errors="replace")
        block = _language_block(html, code)
        prons = _pronunciations(block if block else html)
    except Exception as exc:
        log.info("forvo parse failed for %r (%s): %s", word, code, exc)
        return {"items": [], "unavailable": True, "reason": f"Forvo page could not be parsed: {exc}"}

    seen, out = set(), []
    for p in prons:
        if p["url"] in seen:
            continue
        seen.add(p["url"])
        out.append(p)
        if len(out) >= max(1, limit):
            break
    _cache_put(ckey, out)
    # Reached Forvo and parsed it: an empty list here really does mean the word
    # has no recordings.
    return {"items": out, "unavailable": False, "reason": ""}


def list_pronunciations(word: str, lang: str, limit: int = 6) -> list[dict]:
    """Ranked pronunciation alternates for a word: [{url, votes, user}].

    No audio is downloaded — pair with download(). Returns [] on any failure
    (network blocked, layout change, no pronunciations), never raises. Kept as
    the plain-list form for existing callers; use list_pronunciations_detailed
    when the caller needs to tell a source outage from an empty result.
    """
    return list_pronunciations_detailed(word, lang, limit)["items"]



def download(url: str) -> bytes | None:
    """Fetch one pronunciation's MP3 bytes; None on failure or tiny stub."""
    if not (url or "").startswith(_MP3_BASE):
        return None   # only ever fetch Forvo's own audio host
    try:
        audio = _get(url)
        if audio and len(audio) > 256:
            return audio
        return None
    except Exception as exc:
        log.debug("forvo download failed for %s: %s", url, exc)
        return None


def fetch(word: str, lang: str) -> dict | None:
    """The single most-voted human pronunciation: {audio, url, user, votes}, or
    None on any failure. `audio` is raw MP3 bytes. Never raises."""
    for p in list_pronunciations(word, lang):
        audio = download(p["url"])
        if audio:
            return {"audio": audio, "url": p["url"],
                    "user": p.get("user", ""), "votes": p.get("votes", 0)}
    return None


def is_available(timeout: int = 6) -> bool:
    """Best-effort reachability check for forvo.com (diagnostics)."""
    try:
        return bool(_get("https://forvo.com/", timeout=timeout))
    except Exception:
        return False
