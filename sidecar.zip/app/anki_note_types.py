"""anki_note_types.py — Anki note-type/card-template definitions, ported
from LinguaStudio (`linguastudio/anki_note_types.py`, 16,411 lines) so the
vault sidecar can build .apkg decks itself instead of borrowing the separate
LinguaStudio process for it — the same decoupling already done for TTS (see
`tts_engine.py`, and `git show 3e46d0a --stat` for the precedent this port
follows).

Ported: exactly the 5 model builders the vault's own language set needs.
`LANGUAGES = {"de","ar","hu","es","zh"}` maps through `LINGUA_CODES` (see
`ingest/lingua.py`) to `cmn/deu/ara/hun/spa`:
  - get_hanzi_model()      — cmn; also the model callers fall back to when
                              get_model_for_language() raises (no per-language
                              model applies, e.g. for cmn itself, or a code
                              this trimmed dispatcher doesn't carry).
  - get_arabic_model()     — ara
  - get_hungarian_model()  — hun
  - get_german_model()     — deu
  - get_spanish_model()    — spa
get_model_for_language() is carried too, but trimmed: its upstream `_MAP` has
16 entries (yue/jpn/kor/ara/fas/urd/hun/deu/spa/fra/ita/por/rus/nld/pol/tur);
this one keeps only ara/hun/deu/spa. The `raise ValueError(...)` for an
unmapped code is kept verbatim — callers rely on catching it to fall back to
get_hanzi_model(), and that fallback now also covers every code this port
dropped (jpn, fra, rus, ...), not just cmn.

NOT ported (phase 2/3 Card Studio types, out of scope for the vault):
get_cantonese_vocab_model, get_farsi_model, get_urdu_model,
_make_european_model (and its French/Italian/Portuguese/Russian/Dutch/
Polish/Turkish callers), get_custom_cloze_model, get_visual_model, the
Cascade/Matching/Shadowing/Dialogue/... families, and the remaining ~40
get_*_model() builders upstream defines. This module imports nothing from
any LinguaStudio-internal module — every name it references is defined
below, extracted mechanically by line range from the source so no template
string was hand-retyped (a single mis-copied escape in these raw HTML/JS
blocks would corrupt a card silently rather than raising).

Asset omission (mirrors tts_engine.py's Qwen3-TTS note above — read that one
first for the tone this is matching): the source's `assets/` directory is
deliberately NOT copied here. `_build_hanzi_writer_load()` and
`_build_arabic_fontface()` below both run at *import time* and probe
`Path(__file__).parent / "assets"`; in this package that directory doesn't
exist, so both silently take their own pre-existing fallback branch — this
port doesn't add that behavior, it just means the fallback (rather than the
bundled-asset path) is what always runs here:
  (a) `_build_arabic_fontface()` looks directly under `assets/` for
      `_NotoNaskhArabic-Regular.ttf` / `_NotoNastaliqUrdu-Regular.ttf`
      (leading underscore, no subfolder). Upstream's own files on disk live
      at `assets/fonts/NotoNaskhArabic-Regular.ttf` etc. — no leading
      underscore *and* one directory deeper — so upstream itself never
      takes the bundled-font branch either; it already ships on the CSS
      fallback fonts declared in `_ARA_CSS`/`_LANG_BASE_CSS`. Omitting the
      fonts here is not a regression relative to upstream's actual
      behavior.
  (b) `_build_hanzi_writer_load()` falls back to an external
      `<script src="_hanzi-writer.min.js" onerror=...>` tag whose handler
      looks up a `crw-load-err` element to show a visible error dot. The
      Writing template ported here (CARD4_FRONT) never defines that
      element — same as upstream, where it only exists on a different,
      unported Card Studio note type — so the handler's `if(_d)` guard
      makes it a silent no-op instead; upstream's own classic 5-template
      model has this exact gap already, it isn't introduced by this port.
      Per-character stroke JSON (`hanzi-writer-data/`, ~47MB) is a named
      phase-2 item, so either way the canvas never renders strokes here.
"""
from __future__ import annotations

from pathlib import Path

try:
    import genanki
    HAS_GENANKI = True
except ImportError:
    HAS_GENANKI = False

# ── Stable model/deck IDs (do not change) ─────────────────────────────────────

HANZI_MODEL_ID          = 2024081900

# ── Shared CSS ────────────────────────────────────────────────────────────────
# Merges xiehanzi's tone colors + sidebar with Monkey's Paw theming

SHARED_CSS = r"""
/* ═══════════════════════════════════════════════════════════════════
   LinguaStudio — Card Styling
   Merged: Monkey's Paw aesthetics + xiehanzi features
   ═══════════════════════════════════════════════════════════════════ */

:root {
  --tone-1: #f44336;
  --tone-2: #ff9800;
  --tone-3: #4caf50;
  --tone-4: #2196f3;
  --tone-5: #607d8b;
}

/* ── Light mode ─────────────────────────────────────────────────── */
.card {
  --bg: #fafaf8;
  --bg2: #f0ebe0;
  --fg: #1a1208;
  --fg2: #5a4a30;
  --accent: #c2410c;
  --accent2: #6d28d9;
  --border: #d4c9b0;
  --cloze-color: #c2410c;
  --pinyin-color: #ef6c00;
  --simplified-color: #1e40af;
  --traditional-color: #047857;
  --meaning-color: #334155;
  --hanzi-grid: #f5f0e8;
  --stroke: #555;
  --outline: #ddd;
  --drawing: #333;
  --elevated: rgba(0,0,0,0.03);

  font-family: 'Noto Sans CJK SC', 'PingFang SC', 'Microsoft YaHei', sans-serif;
  font-size: 18px;
  text-align: center;
  color: var(--fg);
  background: var(--bg);
  padding: 24px 20px;
  line-height: 1.6;
  max-width: 680px;
  margin: 0 auto;
}

/* ── Dark mode ──────────────────────────────────────────────────── */
.card.night_mode {
  --bg: #0f0f14;
  --bg2: #1e1e2e;
  --fg: #e2e8f0;
  --fg2: #94a3b8;
  --accent: #c084fc;
  --accent2: #818cf8;
  --border: #2d2d3f;
  --cloze-color: #c084fc;
  --pinyin-color: #27b46e;
  --simplified-color: #60a5fa;
  --traditional-color: #fbbf24;
  --meaning-color: #94a3b8;
  --hanzi-grid: #16161f;
  --stroke: #e2e8f0;
  --outline: #3d3d50;
  --drawing: #fff;
  --elevated: rgba(255,255,255,0.04);
}

/* ── Entrance animations ────────────────────────────────────────── */
@keyframes _hw_char_in {
  from { opacity: 0; transform: scale(0.90) translateY(4px); }
  to   { opacity: 1; transform: scale(1)    translateY(0); }
}
@keyframes _hw_item_in {
  from { opacity: 0; transform: translateY(7px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ── Typography ─────────────────────────────────────────────────── */
.char-big {
  font-size: 2em;
  font-weight: 400;
  color: var(--accent);           /* tracks user's accent choice on all cards */
  letter-spacing: 0.05em;
  margin: 16px 0;
  line-height: 1.3;
  animation: _hw_char_in 0.4s cubic-bezier(.22,1,.36,1) both;
}

.char-trad {
  font-size: 1.25em;
  color: var(--fg2);
  margin: 2px 0 10px;
  letter-spacing: 0.03em;
  opacity: 0.75;
}

.pinyin-display {
  font-size: 1.3em;
  color: var(--accent);           /* consistent with writing-card question prompt */
  margin: 8px 0;
  letter-spacing: 0.02em;
  font-weight: 600;
}

.meaning-display {
  font-size: 1.05em;
  color: var(--fg);
  text-align: left;
  padding: 14px 18px;
  background: var(--elevated);
  border-radius: 12px;
  border-left: 3px solid var(--accent);
  margin: 12px 0;
  line-height: 1.75;
}

/* ── Info strip stagger reveal ──────────────────────────────────── */
#_hw_info_strip > div { animation: _hw_item_in 0.28s ease both; }
#_hw_info_strip > div:nth-child(1) { animation-delay: 0s; }
#_hw_info_strip > div:nth-child(2) { animation-delay: 0.06s; }
#_hw_info_strip > div:nth-child(3) { animation-delay: 0.12s; }
#_hw_info_strip > div:nth-child(4) { animation-delay: 0.18s; }

/* ── Tone colors ────────────────────────────────────────────────── */
.tone1, .char-tone1 { color: var(--tone-1); }
.tone2, .char-tone2 { color: var(--tone-2); }
.tone3, .char-tone3 { color: var(--tone-3); }
.tone4, .char-tone4 { color: var(--tone-4); }
.tone5, .char-tone5, .char-tone0 { color: var(--tone-5); }

/* ── Sentence / context ─────────────────────────────────────────── */
.sentence-block {
  text-align: left;
  padding: 16px 20px;
  background: var(--elevated);
  border-left: 3px solid var(--accent);
  border-radius: 0 12px 12px 0;
  margin: 16px 0;
}

.sentence-zh {
  font-size: 1.2em;
  color: var(--fg);
  margin-bottom: 6px;
}

.sentence-pinyin {
  font-size: 0.9em;
  color: var(--accent);
  opacity: 0.8;
  margin-bottom: 4px;
}

.sentence-en {
  font-size: 0.95em;
  color: var(--fg2);
  font-style: italic;
}

/* ── Header / question prompt ───────────────────────────────────── */
.card-header {
  font-size: 0.85em;
  color: var(--fg2);
  text-transform: uppercase;
  letter-spacing: 0.12em;
  margin-bottom: 20px;
  font-weight: 600;
}

.card-header .highlight {
  color: var(--accent);
  font-weight: 700;
  text-decoration: underline;
  text-decoration-color: var(--accent);
  text-underline-offset: 3px;
  text-decoration-thickness: 2px;
}

/* ── Audio button ───────────────────────────────────────────────── */
.audio-hidden {
  position: absolute;
  width: 0; height: 0;
  overflow: hidden;
  opacity: 0;
  pointer-events: none;
}

.play-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 46px;
  height: 46px;
  border-radius: 50%;
  background: var(--accent);
  color: #fff;
  font-size: 18px;
  cursor: pointer;
  border: none;
  margin: 8px 4px;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
  box-shadow: 0 3px 12px rgba(0,0,0,0.18);
}
.play-btn:hover {
  transform: scale(1.12);
  box-shadow: 0 6px 20px rgba(0,0,0,0.22);
}
.play-btn:active { transform: scale(0.93); box-shadow: 0 1px 6px rgba(0,0,0,0.15); }

/* ── Divider ────────────────────────────────────────────────────── */
.card-divider {
  border: none;
  height: 1px;
  background: var(--border);
  margin: 20px 0;
}

/* ── Writing quiz area ──────────────────────────────────────────── */
#character-target-div {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}

#character-target-div > div { display: none; }
#character-target-div > :first-child { display: block; }

.grid-color {
  background: var(--hanzi-grid);
  border-radius: 10px;
  padding: 4px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.10);
}

/* ── Canvas + stroke counter unified block ──────────────────────── */
#_hw_canvas_wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: fit-content;
  margin: 0 auto;
}

/* Flatten canvas bottom corners when counter is attached below */
#_hw_canvas_wrap .grid-color {
  border-radius: 10px 10px 0 0;
  padding-bottom: 0;
  box-shadow: none; /* shadow on the whole block instead */
}

/* Counter sits flush under the canvas, same bg, bottom radius only */
#_hw_stroke_counter {
  width: 228px; /* SVG 220 + grid-color padding 4+4 */
  background: var(--hanzi-grid, #f5f0e8);
  border-radius: 0 0 10px 10px;
  padding: 7px 14px 10px;
  box-sizing: border-box;
  box-shadow: 0 4px 16px rgba(0,0,0,0.10);
  margin: 0;
}

/* Drop shadow on the whole canvas block */
#_hw_canvas_wrap {
  filter: drop-shadow(0 4px 14px rgba(0,0,0,0.12));
  border-radius: 10px;
  transition: outline 0.3s ease, outline-offset 0.3s ease;
  outline: 3px solid transparent;
  outline-offset: 0px;
}
#_hw_canvas_wrap._hw_complete {
  outline: 3px solid #4caf50;
  outline-offset: 2px;
  filter: drop-shadow(0 4px 14px rgba(0,0,0,0.12)) drop-shadow(0 0 10px rgba(76,175,80,0.35));
}

/* Countdown timer bar (timed writing quiz) */
#_hw_timer_wrap {
  width: 228px;
  height: 6px;
  background: rgba(0,0,0,0.08);
  border-radius: 3px;
  margin: 6px auto 0;
  overflow: hidden;
  display: none;
  box-sizing: border-box;
}
#_hw_timer_wrap.active { display: block; }
#_hw_timer_fill {
  height: 100%;
  background: var(--accent, #7c6aff);
  width: 100%;
  transition: width 0.1s linear, background 0.2s ease;
  border-radius: 3px;
}
#_hw_timer_fill.warning { background: #ff9800; }
#_hw_timer_fill.critical { background: #e53935; }
._hw_range_input {
  width: 100%;
  margin-top: 6px;
  accent-color: var(--accent, #7c6aff);
}
._hw_range_label {
  font-size: 0.78em;
  opacity: 0.75;
  margin-top: 2px;
  text-align: center;
}

.writing-controls {
  display: flex;
  gap: 10px;
  justify-content: center;
  margin: 14px 0 4px;
}

.ctrl-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 20px;
  border-radius: 10px;
  background: var(--bg2);
  color: var(--fg2);
  font-size: 0.88em;
  font-weight: 600;
  cursor: pointer;
  border: 1.5px solid var(--border);
  transition: all 0.18s ease;
  letter-spacing: 0.02em;
}
.ctrl-btn:hover {
  background: var(--accent); color: var(--bg); border-color: var(--accent);
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(0,0,0,0.12);
}
.ctrl-btn:active { transform: translateY(0); box-shadow: none; }

/* ── Cloze ──────────────────────────────────────────────────────── */
.cloze { font-weight: bold; color: var(--cloze-color); font-size: 1.15em; }
.night_mode .cloze { color: var(--cloze-color); }

.cloze-extra {
  font-size: 0.95em;
  color: var(--fg2);
  text-align: left;
  padding: 16px;
  background: var(--elevated);
  border-radius: 12px;
  margin-top: 16px;
  line-height: 1.7;
}

/* ── Tags ───────────────────────────────────────────────────────── */
.tag-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  justify-content: center;
  margin-top: 20px;
}

.tag-pill {
  font-size: 0.7em;
  padding: 3px 10px;
  border-radius: 99px;
  background: var(--bg2);
  color: var(--fg2);
  letter-spacing: 0.05em;
  text-transform: lowercase;
}

/* ── Source attribution ─────────────────────────────────────────── */
.source-tag {
  font-size: 0.7em;
  color: var(--fg2);
  margin-top: 24px;
  opacity: 0.6;
}

/* ── Stroke progress bar (inside counter strip) ─────────────────── */
#_hw_stroke_track {
  height: 3px;
  background: var(--border);
  border-radius: 2px;
  overflow: hidden;
}
#_hw_stroke_fill {
  height: 100%;
  width: 0%;
  background: var(--accent);
  border-radius: 2px;
  transition: width 0.35s cubic-bezier(.4,0,.2,1);
}
#_hw_stroke_lbl {
  font-size: 0.75em;
  font-weight: 700;
  color: var(--accent);
  letter-spacing: 0.1em;
  text-align: center;
  margin-top: 5px;
  min-height: 1em;
  text-transform: uppercase;
}

/* ── Responsive ─────────────────────────────────────────────────── */
@media (max-width: 400px) {
  .card { padding: 16px 12px; }
  .char-big { font-size: 2.6em; }
}

/* ── Sensory accommodation (neurodivergent / reduced-motion) ────── */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.06ms !important;
  }
  .play-btn:hover { transform: none; }
  .ctrl-btn:hover { background: var(--accent); }
}
"""

# ── Audio playback script (shared across cards) ──────────────────────────────

AUDIO_SCRIPT = """
<script>
function playAudio(id) {
  // 1. Try to play the <audio> element directly — works in browser, AnkiMobile,
  //    AnkiDroid, and Anki desktop (which render sound-tags as audio elements).
  //    NEVER write a bracketed sound-tag literal in card JS: Anki's renderer
  //    rewrites every "["+"sound:...]" occurrence — even inside scripts and
  //    comments — into replay-button HTML, which breaks the whole script with
  //    "Unexpected token '<'". See .claude/mistakes.d/sound-tag-in-card-js.md.
  //    currentTime=0 ensures replay from start even if track already finished.
  var el = document.getElementById(id || 'card-audio');
  var played = false;
  if (el) {
    var audios = el.querySelectorAll('audio');
    for (var i = 0; i < audios.length; i++) {
      try {
        audios[i].currentTime = 0;
        var p = audios[i].play();
        if (p && typeof p.catch === 'function') { p.catch(function(){}); }
        played = true;
        break;
      } catch(e) {}
    }
    if (!played) {
      var links = el.querySelectorAll('a[href]');
      if (links.length) { try { links[0].click(); played = true; } catch(e) {} }
    }
  }
  // 2. Fallback: Anki desktop audio queue (mpv) via bridge — replays last queued sound
  if (!played && typeof pycmd === 'function') {
    try { pycmd('replayAudio'); } catch(e) {}
  }
  var links = el.querySelectorAll('a');
  if (links.length) links[0].click();
}
document.querySelectorAll('.play-btn').forEach(function(btn) {
  btn.addEventListener('click', function() {
    playAudio(this.getAttribute('data-audio') || 'card-audio');
  });
});
// Auto-play on card load (configurable)
try {
  if (localStorage.getItem('hs_autoplay') !== 'false') {
    setTimeout(function(){ playAudio(); }, 300);
  }
} catch(e) {}
</script>
"""

# ── HanziWriter quiz script (for Card 4: Writing) ────────────────────────────
# The HanziWriter library is inlined directly into the template so the writing
# quiz works even when _hanzi-writer.min.js is not in Anki's media collection.
# Character stroke data (_{char}.json) is still loaded via XHR from media.

def _build_hanzi_writer_load() -> str:
    """Inline _hanzi-writer.min.js if available; fall back to <script src>.

    BUGFIX: a literal "</script" substring inside the minified library (common
    in any minifier that preserves string/regex literals verbatim) closes the
    wrapping <script> tag early. The browser then treats the remainder of the
    library — and everything else concatenated after HANZI_WRITER_LOAD in the
    card (freehand writer, settings panel, metronome, quiz engine) — as inert
    HTML text. `HanziWriter` never becomes defined, `crToggle` never gets
    attached, and the writing canvas silently never appears (the
    `typeof HanziWriter==='undefined'` guard just bails out with no visible
    error). Escaping the slash breaks the substring without changing the JS
    the browser executes.
    """
    _js = Path(__file__).parent / "assets" / "_hanzi-writer.min.js"
    if _js.exists():
        _code = _js.read_text(encoding="utf-8")
        _code = _code.replace("</script", "<\\/script").replace("</SCRIPT", "<\\/SCRIPT")
        return f"<script>{_code}</script>\n"
    # External fallback: media file missing/not yet synced is a real, common
    # case (matches the same "asset not bundled" pattern as the Arabic
    # fonts). onerror flips a flag + the visible crw-load-err dot immediately
    # on 404, instead of waiting for the user to start the write phase before
    # `typeof HanziWriter==='undefined'` notices anything is wrong.
    return (
        '<script src="_hanzi-writer.min.js" '
        'onerror="window._lsHwLoadFailed=true;'
        'var _f=function(){var _d=document.getElementById(\'crw-load-err\');'
        'if(_d) _d.style.display=\'block\';};'
        'if(document.readyState===\'loading\'){'
        'document.addEventListener(\'DOMContentLoaded\',_f);}else{_f();}"></script>\n'
    )

HANZI_WRITER_LOAD = _build_hanzi_writer_load()

# ── Arabic-script (Naskh/Nastaliq) @font-face — freehand/Arabic mode only ────
# Previously hardcoded verbatim in TWO places (FREEHAND_WRITER_CSS and
# _CASCADE_WRITING_CSS), unconditionally, with no unicode-range and no check
# that the .ttf files actually exist. Every Cascade Writing card — including
# pure Hanzi-mode ones that never touch Arabic/freehand — shipped both
# @font-face rules, and older QtWebEngine/Blink builds eagerly probe every
# @font-face src at stylesheet-parse time regardless of whether any element
# on the page uses that font-family. Result: 404s for
# _NotoNaskhArabic-Regular.ttf / _NotoNastaliqUrdu-Regular.ttf on cards that
# were never using the Arabic path — i.e. exactly the "conflation" symptom.
# Fix: build once, only emit a rule if its font file is actually bundled
# (mirrors _build_hanzi_writer_load's existence-check pattern), and restrict
# each rule's unicode-range to Arabic/Urdu code points so compliant engines
# never need to fetch it to render Hanzi/Latin text either way.
def _build_arabic_fontface() -> str:
    _dir = Path(__file__).parent / "assets"
    _ur = "unicode-range: U+0600-06FF, U+0750-077F, U+08A0-08FF, U+FB50-FDFF, U+FE70-FEFF;"
    rules = []
    if (_dir / "_NotoNaskhArabic-Regular.ttf").exists():
        rules.append(
            "@font-face {\n"
            "  font-family: 'LS Naskh';\n"
            "  src: url('_NotoNaskhArabic-Regular.ttf') format('truetype');\n"
            "  font-display: swap;\n"
            f"  {_ur}\n"
            "}"
        )
    if (_dir / "_NotoNastaliqUrdu-Regular.ttf").exists():
        rules.append(
            "@font-face {\n"
            "  font-family: 'LS Nastaliq';\n"
            "  src: url('_NotoNastaliqUrdu-Regular.ttf') format('truetype');\n"
            "  font-display: swap;\n"
            f"  {_ur}\n"
            "}"
        )
    return "\n".join(rules)

ARABIC_FONTFACE_CSS = _build_arabic_fontface()

HANZI_WRITER_SCRIPT = """
<!-- Field values are read from these hidden nodes at runtime, never inlined
     into the script below as field-token string literals: a field carrying a
     quote, backslash, newline or (rich-text) HTML would otherwise break the
     whole script and silently blank the card. See
     .claude/mistakes.d/anki-field-token-in-js-comment.md and
     scripts/validate_card_templates.py. -->
<div id="_hw_fields" style="display:none" aria-hidden="true"><span id="_hw_f_simp">{{Simplified}}</span><span id="_hw_f_trad">{{Traditional}}</span><span id="_hw_f_zhuyin">{{Zhuyin}}</span></div>
<style>
@keyframes _hw_fadein  { from { opacity:0; transform:scale(0.88) translateY(6px); } to { opacity:1; transform:scale(1) translateY(0); } }
@keyframes _hw_fadeout { from { opacity:1; transform:translateY(0); } to { opacity:0; transform:translateY(10px); } }
@keyframes _hw_edgepulse { 0%,100% { opacity:.42; width:5px; } 50% { opacity:.72; width:7px; } }

/* Edge hint pulse — draws attention on fresh cards */
#_hw_edge_hint { animation: _hw_edgepulse 2.6s ease-in-out infinite; }
#_hw_edge_hint:hover { animation: none; opacity:.85 !important; width:8px !important; }

/* ---------- Right-edge settings panel ---------- */
#_hw_settings_panel {
  position: fixed; top: 0; right: 0; width: 280px; height: 100%;
  background: var(--bg, #fff); box-shadow: -4px 0 24px rgba(0,0,0,0.18);
  transform: translateX(100%); transition: transform 0.28s cubic-bezier(.4,0,.2,1); z-index: 9999;
  padding: 0; box-sizing: border-box;
  display: flex; flex-direction: column; overflow: hidden;
}
#_hw_settings_panel.open { transform: translateX(0); }
#_hw_panel_header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 16px 16px 12px; border-bottom: 1px solid var(--border, #ddd);
  flex-shrink: 0;
}
#_hw_panel_scroll {
  flex: 1; overflow-y: auto; padding: 12px 16px 20px; display: flex; flex-direction: column; gap: 8px;
}
#_hw_backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.22); z-index: 9998; display: none; backdrop-filter: blur(2px); }
#_hw_backdrop.visible { display: block; }
#_hw_panel_close {
  width: 28px; height: 28px; border: none; background: var(--bg2, #f0ebe0);
  border-radius: 50%; cursor: pointer; font-size: 1.1em; color: var(--fg2);
  display: flex; align-items: center; justify-content: center; line-height: 1;
}
#_hw_panel_close:hover { background: var(--accent, #7c6aff); color: #fff; }
._hw_panel_btn {
  padding: 10px 12px; border: none; border-radius: 10px; font-size: 1em;
  cursor: pointer; background: var(--accent, #7c6aff); color: #fff; text-align: center;
  font-weight: 600; transition: opacity 0.15s, transform 0.1s;
}
._hw_panel_btn:active { opacity: 0.8; transform: scale(0.98); }
/* Latched state (e.g. the Repeat-word proxy mirroring the widget's _rep_on) */
._hw_panel_btn._hw_btn_on { background: #2d1f6e; box-shadow: inset 0 0 0 1.5px var(--accent, #7c6aff); }
._hw_toggle_btn {
  padding: 7px 10px; border: 1.5px solid var(--border, #ddd); border-radius: 8px;
  font-size: 0.88em; cursor: pointer; background: transparent; color: var(--fg2, #666);
  text-align: center; transition: background 0.18s, color 0.18s, border-color 0.18s;
}
._hw_toggle_btn.active {
  background: var(--accent, #7c6aff); color: #fff; border-color: var(--accent, #7c6aff);
}
#_hw_edge_hint {
  position: fixed; right: 0; top: 40%; width: 5px; height: 56px;
  background: var(--accent, #7c6aff); opacity: 0.5; border-radius: 4px 0 0 4px;
  z-index: 9997; cursor: pointer; transition: opacity 0.2s, width 0.2s;
}
#_hw_edge_hint:hover { opacity: 0.85; width: 7px; }
._hw_panel_section {
  font-weight: 700; font-size: 0.72em; color: var(--fg2); margin-top: 10px; margin-bottom: 2px;
  text-transform: uppercase; letter-spacing: 1px;
  padding-bottom: 4px; border-bottom: 1px solid var(--border, #ddd);
}
._hw_option_group { display: flex; gap: 6px; flex-wrap: wrap; }

/* Accent colour swatches */
._hw_accent_swatch {
  width: 34px; height: 34px; border-radius: 50%; border: 3px solid transparent;
  cursor: pointer; transition: transform 0.15s, box-shadow 0.15s;
  display: inline-block; margin: 2px; position: relative;
}
._hw_accent_swatch:hover { transform: scale(1.18); }
._hw_accent_swatch.selected {
  box-shadow: 0 0 0 2px var(--bg, #fff), 0 0 0 4px var(--fg, #333);
}

/* Tab buttons — pill style */
._hw_tab_btn {
  flex: 1; padding: 7px 8px; border: none; background: var(--bg2, #f0ebe0);
  color: var(--fg2); font-size: 0.83em; font-weight: 600; cursor: pointer; border-radius: 20px;
  transition: background 0.2s, color 0.2s;
}
._hw_tab_btn.active { background: var(--accent, #7c6aff); color: #fff; }
/* Tab content panels — hidden unless active */
._hw_tab_content { display: none; flex-direction: column; gap: 8px; }
._hw_tab_content.active { display: flex; }
/* Metronome (inside panel) */
#_lsm_drum {
  width:60px; height:60px; border-radius:50%; flex-shrink:0;
  background:radial-gradient(circle at 38% 32%,#b8a9ff 0%,var(--accent,#7c6aff) 55%,#3a2d99 100%);
  box-shadow:0 4px 16px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.15);
  transition:transform .06s ease-out,box-shadow .06s ease-out;
}
#_lsm_drum._hit{transform:scale(0.84);
  box-shadow:0 1px 8px rgba(0,0,0,.4),inset 0 0 24px rgba(124,106,255,.85),0 0 20px rgba(124,106,255,.6);}
#_lsm_drum._hit_a{transform:scale(0.80);
  box-shadow:0 0 6px rgba(0,0,0,.3),inset 0 0 30px rgba(160,140,255,.9),0 0 28px rgba(160,140,255,.75);}
#_lsm_slbl{font-size:12px;font-weight:600;color:var(--fg2);text-align:center;min-height:1.4em;margin:4px 0 6px;}
#_lsm_slbl._playing{color:var(--accent,#7c6aff);}
._lsm_r{display:flex;align-items:center;gap:7px;margin:5px 0;font-size:12px;color:var(--fg);}
#_lsm_bpm,#_lsm_vol{flex:1;accent-color:var(--accent,#7c6aff);}
#_lsm_bval{min-width:52px;font-weight:700;font-size:12px;text-align:right;color:var(--fg);}
#_lsm_snd{flex:1;background:var(--bg2);color:var(--fg);border:1px solid var(--border);
  border-radius:5px;font-size:11px;padding:2px 4px;}
#_lsm_play{display:block;width:100%;padding:8px;margin-top:8px;
  background:var(--accent,#7c6aff);color:#fff;border:none;border-radius:10px;
  cursor:pointer;font-size:13px;font-weight:700;letter-spacing:.03em;
  transition:opacity .15s;box-sizing:border-box;}
#_lsm_play:hover{opacity:.85;}
._lsm_crow{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--fg2);margin:7px 0 2px;flex-wrap:wrap;}
._lsm_crow label{display:flex;align-items:center;gap:4px;cursor:pointer;}
._lsm_sin{width:36px;padding:2px 4px;background:var(--bg2);color:var(--fg);
  border:1px solid var(--border);border-radius:4px;font-size:12px;text-align:center;}
._lsm_sec{font-size:10px;color:var(--fg2);letter-spacing:.06em;text-transform:uppercase;
  margin:9px 0 3px;border-top:1px solid var(--border);padding-top:7px;font-weight:600;}

/* Canvas size variants */
#_hw_canvas_wrap.size-sm { transform: scale(0.78); transform-origin: top center; }
#_hw_canvas_wrap.size-lg { transform: scale(1.18); transform-origin: top center; }

/* Tab active section header */
._hw_tab_label {
  font-size: 0.7em; font-weight: 700; letter-spacing: 1.2px; text-transform: uppercase;
  color: var(--accent, #7c6aff); padding: 5px 0 8px; border-bottom: 2px solid var(--accent, #7c6aff);
  margin-bottom: 8px;
}

/* Accent custom input */
._hw_hex_input {
  width: 100%; padding: 6px 8px; border: 1.5px solid var(--border, #ddd); border-radius: 8px;
  background: var(--bg2); color: var(--fg); font-size: 0.88em; box-sizing: border-box;
  margin-top: 6px; font-family: monospace;
}
._hw_hex_input:focus { outline: none; border-color: var(--accent, #7c6aff); }

/* Background texture options */
._hw_grid_swatch {
  width: 40px; height: 40px; border-radius: 8px; border: 2px solid transparent;
  cursor: pointer; transition: transform 0.15s, border-color 0.15s;
  display: inline-block;
}
._hw_grid_swatch:hover { transform: scale(1.12); }
._hw_grid_swatch.selected { border-color: var(--accent, #7c6aff); }
</style>

<div id="_hw_backdrop"></div>
<div id="_hw_settings_panel">
  <!-- Panel header -->
  <div id="_hw_panel_header">
    <div style="font-weight:700;font-size:1.1em;color:var(--fg);">Settings</div>
    <button id="_hw_panel_close" title="Close">&#215;</button>
  </div>

  <div id="_hw_panel_scroll">
    <!-- Actions (writing cards only) -->
    <button class="_hw_panel_btn _hw_writing_only" id="btnRetryQuiz_panel">&#8635; Retry Quiz</button>
    <button class="_hw_panel_btn _hw_writing_only" id="btnRevealChar_panel">&#128065; Reveal Character</button>

    <!-- Tab buttons -->
    <div style="display:flex; gap:5px; margin-top:4px; flex-wrap:wrap;" id="_hw_tab_bar">
      <button class="_hw_tab_btn active" id="_hw_tab_display" title="Visual customization options">&#128397; Display</button>
      <button class="_hw_tab_btn" id="_hw_tab_audio" title="Audio and playback settings">&#128266; Audio</button>
      <button class="_hw_tab_btn" id="_hw_tab_metronome" title="Metronome and tempo settings">&#127937; Metro</button>
    </div>

    <!-- Display & Visuals tab content -->
    <div class="_hw_tab_content active" id="_hw_tab_content_display">
      <div class="_hw_panel_section _hw_writing_only">Info Lines</div>
      <div class="_hw_option_group _hw_writing_only" style="flex-direction:column; gap:6px;">
        <button class="_hw_toggle_btn active" id="_hw_toggle_info_simp">Simplified</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_info_trad">Traditional</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_info_pinyin">Pinyin</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_info_zhuyin">Zhuyin</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_info_meaning">Meaning</button>
      </div>

      <div class="_hw_panel_section _hw_writing_only">Visual Aids</div>
      <div class="_hw_option_group _hw_writing_only" style="flex-wrap:wrap;">
        <button class="_hw_toggle_btn active" id="_hw_toggle_strokes">Stroke Count</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_audio_btn">Audio Button</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_outline">Stroke Outline</button>
        <button class="_hw_toggle_btn active" id="_hw_toggle_hints">Hints</button>
      </div>

      <div class="_hw_panel_section _hw_writing_only">Drawing Width</div>
      <div class="_hw_option_group _hw_writing_only">
        <button class="_hw_toggle_btn" id="_hw_width_thin">Thin</button>
        <button class="_hw_toggle_btn active" id="_hw_width_normal">Normal</button>
        <button class="_hw_toggle_btn" id="_hw_width_thick">Thick</button>
      </div>

      <div class="_hw_panel_section _hw_writing_only">Canvas Size</div>
      <div class="_hw_option_group _hw_writing_only">
        <button class="_hw_toggle_btn" id="_hw_size_sm">Small</button>
        <button class="_hw_toggle_btn active" id="_hw_size_md">Normal</button>
        <button class="_hw_toggle_btn" id="_hw_size_lg">Large</button>
      </div>

      <div class="_hw_panel_section _hw_writing_only">Grid Background</div>
      <div class="_hw_option_group _hw_writing_only" id="_hw_grid_picker" style="gap:8px;margin-top:4px;"></div>

      <div class="_hw_panel_section _hw_writing_only">Tone Colors</div>
      <div class="_hw_option_group _hw_writing_only">
        <button class="_hw_toggle_btn active" id="_hw_toggle_tones">Show Tone Colors</button>
      </div>

      <div class="_hw_panel_section _hw_writing_only">Timed Quiz</div>
      <div class="_hw_option_group _hw_writing_only" style="flex-direction:column;gap:6px;">
        <button class="_hw_toggle_btn" id="_hw_toggle_timer">Enable Timer</button>
        <input type="range" class="_hw_range_input" id="_hw_timer_dur" min="5" max="120" step="5" value="30">
        <div class="_hw_range_label" id="_hw_timer_dur_lbl">30 seconds</div>
      </div>

      <div class="_hw_panel_section">Accent Color</div>
      <div id="_hw_accent_picker" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:4px;"></div>
      <input type="text" class="_hw_hex_input" id="_hw_accent_hex" placeholder="#7c6aff — custom hex">
    </div>

    <!-- Audio tab content -->
    <div class="_hw_tab_content" id="_hw_tab_content_audio">
      <div class="_hw_panel_section">Playback</div>
      <div class="_hw_option_group" style="flex-direction:column;gap:6px;">
        <button class="_hw_toggle_btn active" id="_hw_toggle_autoplay">Auto-play on load</button>
      </div>
      <div class="_hw_panel_section _hw_writing_only">Stroke Counting Voice</div>
      <button class="_hw_toggle_btn active _hw_writing_only" id="_hw_toggle_stroke_audio">Stroke Audio</button>
      <div class="_hw_panel_section">Volume</div>
      <div class="_hw_option_group">
        <button class="_hw_toggle_btn active" id="_hw_mute_off">Unmuted</button>
        <button class="_hw_toggle_btn" id="_hw_mute_on">Mute All</button>
      </div>
    </div>

    <!-- Metronome tab content -->
    <div class="_hw_tab_content" id="_hw_tab_content_metronome">
      <div style="display:flex;justify-content:center;padding:12px 0 6px;">
        <div id="_lsm_drum"></div>
      </div>
      <div id="_lsm_slbl"></div>

      <div class="_lsm_sec">Tempo</div>
      <div class="_lsm_r">
        <input type="range" id="_lsm_bpm" min="40" max="220" value="80">
        <span id="_lsm_bval">80 BPM</span>
      </div>

      <div class="_lsm_sec">Sound</div>
      <div class="_lsm_r">
        <select id="_lsm_snd">
          <option value="click">Click</option>
          <option value="wood">Wood</option>
          <option value="soft">Soft</option>
          <option value="bell">Bell</option>
        </select>
      </div>
      <div class="_lsm_r">
        <label style="font-size:11px;color:var(--fg2);">Vol</label>
        <input type="range" id="_lsm_vol" min="0" max="100" value="70">
      </div>

      <div id="_lsm_count_wrap" class="_hw_writing_only">
        <div class="_lsm_sec">Count Strokes</div>
        <div class="_lsm_crow">
          <label><input type="checkbox" id="_lsm_ccb"> Count with strokes</label>
          <input type="number" class="_lsm_sin" id="_lsm_sc" min="1" max="36" value="8">
        </div>
      </div>

      <button id="_lsm_play">&#9654; Start</button>
    </div>
  </div>
</div>
<div id="_hw_edge_hint"></div>

<script>
(function() {
  // Writing-card detection: show/hide writing-only panel sections
  var IS_W = !!document.getElementById('character-target-div');
  document.querySelectorAll('._hw_writing_only').forEach(function(el) {
    el.style.display = IS_W ? '' : 'none';
  });

  // ========== Global config (survives retries + localStorage) ==========
  var LS = (function() {
    var P = '_hw_';
    function get(k, d) { try { var v = localStorage.getItem(P + k); return v === null ? d : JSON.parse(v); } catch(e) { return d; } }
    function set(k, v) { try { localStorage.setItem(P + k, JSON.stringify(v)); } catch(e) {} }
    return { get: get, set: set };
  })();

  window._hwConfig = window._hwConfig || {
    showSimp: LS.get('showSimp', true),
    showTrad: LS.get('showTrad', true),
    showPinyin: LS.get('showPinyin', true),
    showZhuyin: LS.get('showZhuyin', true),
    showMeaning: LS.get('showMeaning', true),
    showStrokeCount: LS.get('showStrokeCount', true),
    showAudioBtn: LS.get('showAudioBtn', true),
    outlineVisible: LS.get('outline', true),
    hintsEnabled: LS.get('hints', true),
    drawingWidth: LS.get('drawWidth', 18),
    strokeAudio: LS.get('strokeAudio', true),
    muteAll: LS.get('muteAll', false),
    accentColor: LS.get('accentColor', '#7c6aff'),
    timerEnabled: LS.get('timerEnabled', false),
    timerDuration: LS.get('timerDuration', 30)
  };

  // Apply accent immediately
  document.documentElement.style.setProperty('--accent', window._hwConfig.accentColor);

  // Read fields from the hidden #_hw_fields nodes (never inlined as JS
  // string literals — a quote/newline/HTML in a field would break this
  // whole script otherwise). textContent is the raw, un-parsed value.
  function _hwReadField(id) {
    var el = document.getElementById(id);
    return el ? (el.textContent || el.innerText || '').replace(/^\s+|\s+$/g, '') : '';
  }
  var simpStr = _hwReadField('_hw_f_simp');
  var tradStr = _hwReadField('_hw_f_trad');
  var zhuyinStr = _hwReadField('_hw_f_zhuyin');

  // Code-point-aware split (ES5-safe): naive split('') breaks surrogate pairs,
  // so any character beyond the BMP (CJK Ext-B+, e.g. 𠮟) became two broken
  // halves that HanziWriter could never load.
  function _hwSplitChars(s) {
    var out = [], i = 0;
    while (i < s.length) {
      var hi = s.charCodeAt(i), ch = s.charAt(i);
      if (hi >= 0xD800 && hi <= 0xDBFF && i + 1 < s.length) {
        var lo = s.charCodeAt(i + 1);
        if (lo >= 0xDC00 && lo <= 0xDFFF) { ch = s.substring(i, i + 2); i++; }
      }
      out.push(ch); i++;
    }
    return out;
  }
  // True for characters the writer datasets can actually draw: CJK unified
  // (all planes), kana, and hangul syllables. Punctuation, Latin, and digits
  // must never get a writer cell — they used to render as broken blanks.
  function _hwWritable(ch) {
    var cp = ch.charCodeAt(0);
    if (cp >= 0xD800 && cp <= 0xDBFF && ch.length === 2) {
      cp = (cp - 0xD800) * 0x400 + (ch.charCodeAt(1) - 0xDC00) + 0x10000;
    }
    return (cp >= 0x4E00 && cp <= 0x9FFF)   // CJK Unified
        || (cp >= 0x3400 && cp <= 0x4DBF)   // Ext A
        || (cp >= 0x20000 && cp <= 0x2A6DF) // Ext B
        || (cp >= 0x2A700 && cp <= 0x2B73F) // Ext C
        || (cp >= 0x3040 && cp <= 0x309F)   // Hiragana
        || (cp >= 0x30A0 && cp <= 0x30FF)   // Katakana
        || (cp >= 0xAC00 && cp <= 0xD7A3);  // Hangul syllables
  }
  var chars = _hwSplitChars(simpStr);

  // Read optional per-note WriteCfg (used by non-CJK languages to dispatch
  // away from HanziWriter). Empty / missing field falls through to HanziWriter.
  var _hwWriteCfg = (function(){
    var raw = document.getElementById('hw-write-cfg');
    var s = raw ? (raw.textContent||raw.innerText||'').trim() : '';
    try { return s ? JSON.parse(s) : {}; } catch(e) { return {}; }
  })();

  var stroke_color  = '#555', outline_color = '#DDD', drawing_color = '#333';
  if (document.body && document.body.classList.contains('night_mode')) {
    stroke_color = '#e2e8f0'; outline_color = '#3d3d50'; drawing_color = '#fff';
  }

  var _HW_NUM = ['','一','二','三','四','五','六','七','八','九','十',
    '十一','十二','十三','十四','十五','十六','十七','十八','十九','二十',
    '二十一','二十二','二十三','二十四','二十五','二十六','二十七','二十八','二十九','三十'];

  var _hwAudio = new Audio();
  function _hwCountPrefix() {
    // Language-specific stroke counter prefix from WriteCfg (set when the card
    // loads). Defaults to '_cnt_' (Chinese); Japanese cards override to '_cnt_ja_'.
    try {
      if (_hwWriteCfg && _hwWriteCfg.countPrefix) return _hwWriteCfg.countPrefix;
    } catch(e) {}
    return '_cnt_';
  }
  function _hwSpeak(n) {
    if (!window._hwConfig.strokeAudio || window._hwConfig.muteAll) return;
    try {
      _hwAudio.pause();
      _hwAudio.src = _hwCountPrefix() + n + '.mp3';
      _hwAudio.currentTime = 0;
      _hwAudio.play();
    } catch(e) {}
  }

  var _hwDoneCalled = false;
  function _hwDone() {
    if (_hwDoneCalled) return;
    _hwDoneCalled = true;
    try {
      var doneAudio = new Audio(_hwCountPrefix() + 'done.mp3');
      var congratsShown = false, fallbackTimer = null;
      function showCongrats() {
        if (congratsShown) return;
        congratsShown = true;
        if (fallbackTimer) clearTimeout(fallbackTimer);
        var existing = document.getElementById('_hw_congrats');
        if (existing) existing.remove();
        var congrats = document.createElement('div');
        congrats.id = '_hw_congrats';
        congrats.style.cssText = 'position:fixed;bottom:28px;left:0;right:0;'
          + 'text-align:center;font-size:2em;font-weight:700;'
          + 'color:var(--accent,#7c6aff);letter-spacing:.1em;'
          + 'animation:_hw_fadein 0.45s ease;z-index:9990;pointer-events:none;'
          + 'text-shadow:0 2px 24px rgba(124,106,255,0.3);';
        congrats.textContent = (_hwWriteCfg && _hwWriteCfg.congratsText) || '做得好！';
        (document.body || document.documentElement).appendChild(congrats);
        // Auto-dismiss after 2.8 s with a fade-out
        setTimeout(function() {
          congrats.style.animation = '_hw_fadeout 0.55s ease forwards';
          setTimeout(function() { if (congrats.parentNode) congrats.remove(); }, 560);
        }, 2800);
      }
      function playDoneAndShow() {
        try { doneAudio.play(); } catch (e) {}
        doneAudio.addEventListener('ended', function() { setTimeout(showCongrats, 200); }, { once: true });
        fallbackTimer = setTimeout(function() { if (!doneAudio.ended) showCongrats(); }, 1200);
      }
      if (_hwAudio && !_hwAudio.paused && !_hwAudio.ended) {
        _hwAudio.addEventListener('ended', function() { playDoneAndShow(); }, { once: true });
      } else {
        setTimeout(playDoneAndShow, 150);
      }
    } catch (e) {}
  }

  function _hwSetLabel(n, total) {
    var lbl = document.getElementById('_hw_stroke_lbl');
    var fill = document.getElementById('_hw_stroke_fill');
    if (n === 0 && !total) {
      if (lbl) lbl.textContent = '';
      if (fill) fill.style.width = '0%';
      return;
    }
    if (n === 0 && total) {
      // Before first stroke: show total count as a quiet hint
      if (lbl) { lbl.textContent = '· ' + (_HW_NUM[total] || String(total)) + ' ·'; lbl.style.opacity = '0.45'; }
      if (fill) fill.style.width = '0%';
      return;
    }
    if (lbl) { lbl.textContent = (_HW_NUM[n] || String(n)) + ' · ' + (_HW_NUM[total] || String(total)); lbl.style.opacity = '1'; }
    if (fill && total) fill.style.width = Math.round(n / total * 100) + '%';
  }

  function loadCharData(char, onComplete, onError) {
    if (window._hwPreviewData && window._hwPreviewData[char]) {
      setTimeout(function() { onComplete(window._hwPreviewData[char]); }, 0);
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '_' + char + '.json');
    xhr.onload = function() {
      if (xhr.status === 200) { try { onComplete(JSON.parse(xhr.responseText)); } catch(e) { if (onError) onError(); } }
      else if (onError) onError();
    };
    xhr.onerror = function() { if (onError) onError(); };
    xhr.send();
  }

  function applyVisibility() {
    var c = window._hwConfig;
    // Info strip elements (null-safe)
    var simp = document.getElementById('_hw_info_simp');
    if (simp) simp.style.display = c.showSimp ? '' : 'none';
    var trad = document.getElementById('_hw_info_trad');
    if (trad) trad.style.display = c.showTrad && tradStr ? '' : 'none';
    var ipinyin = document.getElementById('_hw_info_pinyin');
    if (ipinyin) ipinyin.style.display = c.showPinyin ? '' : 'none';
    var izhuyin = document.getElementById('_hw_info_zhuyin');
    if (izhuyin) izhuyin.style.display = c.showZhuyin && zhuyinStr ? '' : 'none';
    var imeaning = document.getElementById('_hw_info_meaning');
    if (imeaning) imeaning.style.display = c.showMeaning ? '' : 'none';
    // Stroke counter
    var counter = document.getElementById('_hw_stroke_counter');
    if (counter) counter.style.display = c.showStrokeCount ? '' : 'none';
    // Audio button
    var abtn = document.getElementById('_hw_audio_btn');
    if (abtn) abtn.style.display = c.showAudioBtn ? '' : 'none';
    // Pinyin prompt at top
    var pyHdr = document.getElementById('_hw_pinyin');
    if (pyHdr) pyHdr.style.display = c.showPinyin ? '' : 'none';
  }

  // ===== Countdown timer (timed writing quiz) =====
  var _hwTimerInterval = null, _hwTimerExpired = false;
  window._hwStartTimer = function() {
    var bar = document.getElementById('_hw_timer_wrap');
    var fill = document.getElementById('_hw_timer_fill');
    if (!bar || !fill) return;
    window._hwStopTimer(false);
    if (!window._hwConfig.timerEnabled) { bar.classList.remove('active'); return; }
    bar.classList.add('active');
    fill.classList.remove('warning'); fill.classList.remove('critical');
    fill.style.width = '100%';
    var start = Date.now();
    var dur = (window._hwConfig.timerDuration || 30) * 1000;
    _hwTimerExpired = false;
    _hwTimerInterval = setInterval(function() {
      var elapsed = Date.now() - start;
      var pct = Math.max(0, 100 - (elapsed / dur) * 100);
      fill.style.width = pct + '%';
      fill.classList.toggle('warning', pct < 40 && pct >= 15);
      fill.classList.toggle('critical', pct < 15);
      if (elapsed >= dur && !_hwTimerExpired) {
        _hwTimerExpired = true;
        window._hwStopTimer(false);
        _hwOnTimerExpired();
      }
    }, 100);
  };
  window._hwStopTimer = function(hide) {
    if (_hwTimerInterval) { clearInterval(_hwTimerInterval); _hwTimerInterval = null; }
    if (hide) {
      var bar = document.getElementById('_hw_timer_wrap');
      if (bar) bar.classList.remove('active');
    }
  };
  function _hwOnTimerExpired() {
    // Reveal the character then ask Anki to rate Again so SRS tracks the struggle
    var revealBtn = document.getElementById('btnRevealChar');
    if (revealBtn) revealBtn.click();
    setTimeout(function() {
      if (typeof pycmd === 'function') {
        pycmd('ans');
        setTimeout(function() { pycmd('ans 1'); }, 450);
      } else {
        var sa = document.querySelector('.show-answer, #ansbutla');
        if (sa) sa.click();
      }
    }, 600);
  }

  function initWriters() {
    _hwDoneCalled = false;
    applyVisibility();
    var container = document.getElementById('character-target-div');
    if (!container) return;

    // Non-CJK dispatch: route to the appropriate freehand module.
    if (_hwWriteCfg && _hwWriteCfg.writeModule && _hwWriteCfg.writeModule !== 'hanziwriter') {
      container.innerHTML = '';
      var _wm = _hwWriteCfg.writeModule;
      // ES5 shallow copy (card JS must stay ES5 — COMMON_MISTAKES)
      var _cbCfg = {};
      for (var _ck in _hwWriteCfg) { if (_hwWriteCfg.hasOwnProperty(_ck)) _cbCfg[_ck] = _hwWriteCfg[_ck]; }
      _cbCfg.onDone = function(){ if(typeof _hwDone === 'function') _hwDone(); };
      if (_wm === 'freehand_ocr' && typeof window.lsFreehandOcrInit === 'function') {
        window.lsFreehandOcrInit('character-target-div', simpStr, _cbCfg);
      } else if (typeof window.lsFreehandInit === 'function') {
        window.lsFreehandInit('character-target-div', simpStr, _cbCfg);
      }
      return;
    }

    if (typeof HanziWriter === 'undefined') return;
    container.innerHTML = '';
    var cfg = window._hwConfig;

    // Only writable characters get writer cells — punctuation / Latin used to
    // produce permanently-blank cells that wedged the whole quiz.
    var wchars = [];
    for (var ci = 0; ci < chars.length; ci++) {
      if (_hwWritable(chars[ci])) wchars.push(chars[ci]);
    }
    if (!wchars.length) {
      // Nothing drawable (bad data / pure punctuation): show the word rather
      // than an empty broken canvas.
      container.innerHTML = '<div class="char-big" style="font-size:3em;color:var(--accent,#7c6aff);">'
        + simpStr + '</div>';
      return;
    }
    var _hwTotalChars = wchars.length, _hwDoneChars = 0;

    // Shared advance: called on quiz completion AND on data-load failure so a
    // character with missing stroke data can never block the rest of the word.
    function _hwAdvance(idx) {
      _hwDoneChars++;
      var next = document.getElementById('hw-target-' + (idx + 1));
      if (next) {
        next.style.display = 'inline-block';
        _hwSetLabel(0, 0);
      } else if (_hwDoneChars >= _hwTotalChars) {
        _hwDone();
        _hwSetLabel(0, 0);
      } else {
        if (window._hwStartTimer) window._hwStartTimer();
      }
    }

    wchars.forEach(function(ch, idx) {
      var wrap = document.createElement('div');
      wrap.className = 'grid-color';
      wrap.id = 'hw-target-' + idx;
      wrap.style.display = idx === 0 ? 'inline-block' : 'none';
      container.appendChild(wrap);

      var _strokeNum = 0, _strokeTotal = 0, _failed = false;
      var writer = HanziWriter.create('hw-target-' + idx, ch, {
        width: 220, height: 220, padding: 10,
        showOutline: cfg.outlineVisible,
        strokeColor: stroke_color, outlineColor: outline_color,
        drawingColor: drawing_color, drawingWidth: cfg.drawingWidth,
        showHintAfterMisses: cfg.hintsEnabled ? 2 : false,
        highlightOnComplete: true, highlightColor: '#4caf50',
        charDataLoader: (function(captureIdx) {
          return function(char, onLoad, onError) {
            loadCharData(char, function(data) {
              if (data && data.strokes) {
                _strokeTotal = data.strokes.length;
                if (captureIdx === 0) {
                  // Show total stroke count before the user starts drawing
                  _hwSetLabel(0, _strokeTotal);
                  var scEl = document.getElementById('_lsm_sc');
                  if (scEl) {
                    scEl.value = _strokeTotal;
                    scEl.dispatchEvent(new Event('change', {bubbles: true}));
                  }
                }
              }
              onLoad(data);
            }, function() {
              // Stroke data missing for this char: show it statically and
              // move on instead of leaving a dead blank cell.
              if (_failed) return;
              _failed = true;
              wrap.innerHTML = '<div style="width:220px;height:220px;display:flex;'
                + 'align-items:center;justify-content:center;font-size:4em;'
                + 'color:var(--accent,#7c6aff);">' + char + '</div>';
              setTimeout(function() { _hwAdvance(captureIdx); }, 400);
              if (onError) onError();
            });
          };
        })(idx)
      });

      writer.quiz({
        onCorrectStroke: function() {
          _strokeNum++;
          _hwSpeak(_strokeNum);
          _hwSetLabel(_strokeNum, _strokeTotal);
          if (window._metroCountStrokes) window._metroCountStrokes();
        },
        onComplete: function() {
          var canvasBlock = document.getElementById('_hw_canvas_wrap');
          if (canvasBlock) canvasBlock.classList.add('_hw_complete');
          if (window._hwStopTimer) window._hwStopTimer(true);
          _strokeNum = 0;
          _hwAdvance(idx);
        }
      });
    });
    // Kick off timer for the first character
    if (window._hwStartTimer) window._hwStartTimer();
  }

  // ---------- Settings panel logic ----------
  (function setupEdgePanel() {
    var panel = document.getElementById('_hw_settings_panel');
    var backdrop = document.getElementById('_hw_backdrop');
    var edgeHint = document.getElementById('_hw_edge_hint');
    if (!panel) return;

    function openPanel()  { panel.classList.add('open'); backdrop.classList.add('visible'); }
    function closePanel() { panel.classList.remove('open'); backdrop.classList.remove('visible'); }

    if (edgeHint) edgeHint.addEventListener('click', function(e) { e.stopPropagation(); openPanel(); });
    if (backdrop) backdrop.addEventListener('click', closePanel);
    var closeBtn = document.getElementById('_hw_panel_close');
    if (closeBtn) closeBtn.addEventListener('click', closePanel);

    var touchStartX = 0, touchStartY = 0;
    document.addEventListener('touchstart', function(e) {
      touchStartX = e.touches[0].clientX; touchStartY = e.touches[0].clientY;
    }, {passive: true});
    document.addEventListener('touchend', function(e) {
      var t = e.changedTouches && e.changedTouches[0];
      var dx = (t ? t.clientX : touchStartX) - touchStartX;
      var dy = (t ? t.clientY : touchStartY) - touchStartY;
      if (touchStartX > window.innerWidth - 24 && dx < -40 && Math.abs(dy) < Math.abs(dx)) openPanel();
    });

    // Retry / Reveal bindings
    function bindButton(pId, tId) {
      var p = document.getElementById(pId), t = document.getElementById(tId);
      if (p && t) p.addEventListener('click', function() { t.click(); setTimeout(closePanel, 100); });
    }
    bindButton('btnRetryQuiz_panel', 'btnRetryQuiz');
    bindButton('btnRevealChar_panel', 'btnRevealChar');

    // Toggle helper
    function setupToggle(btnId, configKey, applyFn) {
      var btn = document.getElementById(btnId);
      if (!btn) return;
      btn.classList.toggle('active', !!window._hwConfig[configKey]);
      btn.addEventListener('click', function() {
        var newState = !btn.classList.contains('active');
        btn.classList.toggle('active', newState);
        window._hwConfig[configKey] = newState;
        LS.set(configKey, newState);
        if (applyFn) applyFn(newState);
      });
    }

    // Tab switching
    var tabBtns = document.querySelectorAll('#_hw_settings_panel ._hw_tab_btn');
    var tabContents = document.querySelectorAll('#_hw_settings_panel ._hw_tab_content');
    tabBtns.forEach(function(btn) {
      btn.addEventListener('click', function() {
        var target = btn.getAttribute('id').replace('_hw_tab_', '_hw_tab_content_');
        tabBtns.forEach(function(b) { b.classList.remove('active'); });
        tabContents.forEach(function(c) { c.classList.remove('active'); });
        btn.classList.add('active');
        document.getElementById(target).classList.add('active');
      });
    });

    // Info line toggles
    setupToggle('_hw_toggle_info_simp', 'showSimp', function(v) {
      document.getElementById('_hw_info_simp').style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_info_trad', 'showTrad', function(v) {
      var el = document.getElementById('_hw_info_trad');
      if (el && tradStr) el.style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_info_pinyin', 'showPinyin', function(v) {
      var ipinyin = document.getElementById('_hw_info_pinyin');
      if (ipinyin) ipinyin.style.display = v ? '' : 'none';
      var hdr = document.getElementById('_hw_pinyin');
      if (hdr) hdr.style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_info_zhuyin', 'showZhuyin', function(v) {
      var el = document.getElementById('_hw_info_zhuyin');
      if (el && zhuyinStr) el.style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_info_meaning', 'showMeaning', function(v) {
      document.getElementById('_hw_info_meaning').style.display = v ? '' : 'none';
    });

    // Visual aids
    setupToggle('_hw_toggle_strokes', 'showStrokeCount', function(v) {
      document.getElementById('_hw_stroke_counter').style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_audio_btn', 'showAudioBtn', function(v) {
      var btn = document.getElementById('_hw_audio_btn');
      if (btn) btn.style.display = v ? '' : 'none';
    });
    setupToggle('_hw_toggle_outline', 'outlineVisible', function() { initWriters(); });
    setupToggle('_hw_toggle_hints', 'hintsEnabled', function() { initWriters(); });

    // Drawing width group
    var widthMapping = { '_hw_width_thin': 12, '_hw_width_normal': 18, '_hw_width_thick': 24 };
    function setWidthBtn(id) {
      ['_hw_width_thin','_hw_width_normal','_hw_width_thick'].forEach(function(i) {
        var b = document.getElementById(i); if (b) b.classList.toggle('active', i === id);
      });
      window._hwConfig.drawingWidth = widthMapping[id];
      LS.set('drawWidth', widthMapping[id]);
      initWriters();
    }
    var wThin = document.getElementById('_hw_width_thin');
    var wNormal = document.getElementById('_hw_width_normal');
    var wThick = document.getElementById('_hw_width_thick');
    if (wThin) wThin.addEventListener('click', function() { setWidthBtn('_hw_width_thin'); });
    if (wNormal) wNormal.addEventListener('click', function() { setWidthBtn('_hw_width_normal'); });
    if (wThick) wThick.addEventListener('click', function() { setWidthBtn('_hw_width_thick'); });

    // Canvas size group
    var savedSize = LS.get('canvasSize', 'md');
    function setSizeBtn(sz) {
      ['_hw_size_sm','_hw_size_md','_hw_size_lg'].forEach(function(i) {
        var b = document.getElementById(i); if (b) b.classList.toggle('active', i === '_hw_size_' + sz);
      });
      var cw = document.getElementById('_hw_canvas_wrap');
      if (cw) { cw.classList.remove('size-sm','size-lg'); if (sz !== 'md') cw.classList.add('size-' + sz); }
      LS.set('canvasSize', sz);
    }
    setSizeBtn(savedSize);
    var szSm = document.getElementById('_hw_size_sm');
    var szMd = document.getElementById('_hw_size_md');
    var szLg = document.getElementById('_hw_size_lg');
    if (szSm) szSm.addEventListener('click', function() { setSizeBtn('sm'); });
    if (szMd) szMd.addEventListener('click', function() { setSizeBtn('md'); });
    if (szLg) szLg.addEventListener('click', function() { setSizeBtn('lg'); });

    // Grid background picker
    var GRID_COLORS = [
      { label: 'Parchment', val: '#f5f0e8' },
      { label: 'White',     val: '#ffffff' },
      { label: 'Slate',     val: '#e8edf2' },
      { label: 'Warm Gray', val: '#f0ece6' },
      { label: 'Dark',      val: '#1e1e2e' },
      { label: 'Ink',       val: '#1a1208' }
    ];
    var savedGrid = LS.get('gridColor', '#f5f0e8');
    var gridPicker = document.getElementById('_hw_grid_picker');
    if (gridPicker) {
      GRID_COLORS.forEach(function(gc) {
        var s = document.createElement('span');
        s.className = '_hw_grid_swatch' + (gc.val === savedGrid ? ' selected' : '');
        s.style.cssText = 'background:' + gc.val + ';border:2px solid ' + (gc.val === savedGrid ? 'var(--accent,#7c6aff)' : 'var(--border,#ddd)') + ';';
        s.title = gc.label;
        s.onclick = function() {
          document.documentElement.style.setProperty('--hanzi-grid', gc.val);
          LS.set('gridColor', gc.val);
          gridPicker.querySelectorAll('._hw_grid_swatch').forEach(function(b) {
            b.classList.remove('selected');
            b.style.borderColor = 'var(--border,#ddd)';
          });
          s.classList.add('selected');
          s.style.borderColor = 'var(--accent,#7c6aff)';
        };
        gridPicker.appendChild(s);
      });
    }
    // Apply saved grid color
    if (savedGrid) document.documentElement.style.setProperty('--hanzi-grid', savedGrid);

    // Tone colors toggle
    var savedTones = LS.get('showToneColors', true);
    (function applyToneColors(on) {
      var sheet = document.getElementById('_hw_tone_style');
      if (!on) {
        if (!sheet) {
          sheet = document.createElement('style');
          sheet.id = '_hw_tone_style';
          sheet.textContent = '.tone1,.tone2,.tone3,.tone4,.tone5{color:inherit!important;}';
          document.head.appendChild(sheet);
        }
      } else {
        if (sheet) sheet.remove();
      }
    })(savedTones);
    setupToggle('_hw_toggle_tones', 'showToneColors', function(v) {
      var sheet = document.getElementById('_hw_tone_style');
      if (!v) {
        if (!sheet) {
          sheet = document.createElement('style');
          sheet.id = '_hw_tone_style';
          sheet.textContent = '.tone1,.tone2,.tone3,.tone4,.tone5{color:inherit!important;}';
          document.head.appendChild(sheet);
        }
      } else {
        if (sheet) sheet.remove();
      }
    });
    // Sync initial toggle state
    (function() {
      var tb = document.getElementById('_hw_toggle_tones');
      if (tb) tb.classList.toggle('active', savedTones);
      window._hwConfig.showToneColors = savedTones;
    })();

    // Accent colour picker
    function applyAccentColor(col) {
      document.documentElement.style.setProperty('--accent', col);
      window._hwConfig.accentColor = col;
      LS.set('accentColor', col);
      var eh = document.getElementById('_hw_edge_hint');
      if (eh) eh.style.background = col;
      var sf = document.getElementById('_hw_stroke_fill');
      if (sf) sf.style.background = col;
      var sl = document.getElementById('_hw_stroke_lbl');
      if (sl) sl.style.color = col;
      var py = document.getElementById('_hw_pinyin');
      if (py) py.style.color = col;
    }

    var PRESETS = ['#7c6aff','#e63946','#457b9d','#2a9d8f','#ca6702','#6a0572','#d4a373','#b5838d'];
    var picker = document.getElementById('_hw_accent_picker');
    PRESETS.forEach(function(col) {
      var s = document.createElement('span');
      s.className = '_hw_accent_swatch';
      if (col === window._hwConfig.accentColor) s.classList.add('selected');
      s.style.backgroundColor = col;
      s.onclick = function() {
        applyAccentColor(col);
        picker.querySelectorAll('._hw_accent_swatch').forEach(function(b) { b.classList.remove('selected'); });
        s.classList.add('selected');
        var hexIn = document.getElementById('_hw_accent_hex');
        if (hexIn) hexIn.value = col;
      };
      picker.appendChild(s);
    });

    // Custom hex input for accent
    var hexInput = document.getElementById('_hw_accent_hex');
    if (hexInput) {
      hexInput.value = window._hwConfig.accentColor;
      hexInput.addEventListener('change', function() {
        var v = hexInput.value.trim();
        if (/^#[0-9a-fA-F]{3,8}$/.test(v)) {
          applyAccentColor(v);
          picker.querySelectorAll('._hw_accent_swatch').forEach(function(b) { b.classList.remove('selected'); });
        }
      });
    }

    // Audio tab toggles
    var savedAutoplay = LS.get('autoplay', true);
    (function() {
      var ab = document.getElementById('_hw_toggle_autoplay');
      if (ab) ab.classList.toggle('active', savedAutoplay);
    })();
    var apBtn = document.getElementById('_hw_toggle_autoplay');
    if (apBtn) apBtn.addEventListener('click', function() {
      var on = !apBtn.classList.contains('active');
      apBtn.classList.toggle('active', on);
      LS.set('autoplay', on);
      try { localStorage.setItem('hs_autoplay', on ? 'true' : 'false'); } catch(e) {}
    });
    setupToggle('_hw_toggle_stroke_audio', 'strokeAudio');

    // ===== Timed writing quiz =====
    var timerBtn = document.getElementById('_hw_toggle_timer');
    if (timerBtn) {
      timerBtn.classList.toggle('active', !!window._hwConfig.timerEnabled);
      timerBtn.addEventListener('click', function() {
        var on = !timerBtn.classList.contains('active');
        timerBtn.classList.toggle('active', on);
        window._hwConfig.timerEnabled = on;
        LS.set('timerEnabled', on);
        if (on) { window._hwStartTimer && window._hwStartTimer(); }
        else    { window._hwStopTimer  && window._hwStopTimer(true); }
      });
    }
    var timerDur = document.getElementById('_hw_timer_dur');
    var timerDurLbl = document.getElementById('_hw_timer_dur_lbl');
    if (timerDur) {
      timerDur.value = window._hwConfig.timerDuration;
      if (timerDurLbl) timerDurLbl.textContent = window._hwConfig.timerDuration + ' seconds';
      timerDur.addEventListener('input', function() {
        var v = parseInt(timerDur.value, 10) || 30;
        window._hwConfig.timerDuration = v;
        LS.set('timerDuration', v);
        if (timerDurLbl) timerDurLbl.textContent = v + ' seconds';
        if (window._hwConfig.timerEnabled) { window._hwStartTimer && window._hwStartTimer(); }
      });
    }
    // Mute buttons (mutually exclusive)
    var muteOff = document.getElementById('_hw_mute_off'), muteOn = document.getElementById('_hw_mute_on');
    if (muteOff && muteOn) {
      muteOff.classList.toggle('active', !window._hwConfig.muteAll);
      muteOn.classList.toggle('active', window._hwConfig.muteAll);
      muteOff.addEventListener('click', function() {
        muteOff.classList.add('active'); muteOn.classList.remove('active');
        window._hwConfig.muteAll = false; LS.set('muteAll', false);
      });
      muteOn.addEventListener('click', function() {
        muteOn.classList.add('active'); muteOff.classList.remove('active');
        window._hwConfig.muteAll = true; LS.set('muteAll', true);
      });
    }
  })();

  // ========== Metronome engine ==========
  (function() {
    var bpmR = document.getElementById('_lsm_bpm');
    var bval = document.getElementById('_lsm_bval');
    var volR = document.getElementById('_lsm_vol');
    var sndS = document.getElementById('_lsm_snd');
    var play = document.getElementById('_lsm_play');
    var slbl = document.getElementById('_lsm_slbl');
    var drum = document.getElementById('_lsm_drum');
    var ccb  = document.getElementById('_lsm_ccb');
    var scIn = document.getElementById('_lsm_sc');
    if (!bpmR || !play) return;

    var M = {p:false, bpm:80, beat:0, sc:8, cnt:false, ctx:null, t:null};
    var MN = ['','一','二','三','四','五','六','七','八','九','十',
      '十一','十二','十三','十四','十五','十六','十七','十八','十九','二十',
      '二十一','二十二','二十三','二十四','二十五','二十六','二十七','二十八','二十九','三十'];

    var _LSP = '_lsm_';
    function _lsmGet(k,d){try{var v=localStorage.getItem(_LSP+k);return v===null?d:JSON.parse(v);}catch(e){return d;}}
    function _lsmSet(k,v){try{localStorage.setItem(_LSP+k,JSON.stringify(v));}catch(e){}}

    (function(){
      var sv=_lsmGet('vol',70),ss=_lsmGet('snd','click'),sb=_lsmGet('bpm',80);
      if(volR)volR.value=sv;
      if(sndS)sndS.value=ss;
      if(bpmR&&sb){bpmR.value=sb;M.bpm=+sb;bval.textContent=sb+' BPM';window.__lsExtBpm=+sb;}
      if(ccb){ccb.checked=_lsmGet('ccb',false);M.cnt=ccb.checked;}
      if(scIn){scIn.value=_lsmGet('sc',8);M.sc=+scIn.value||8;}
    }());

    if(volR)volR.oninput=function(){_lsmSet('vol',+this.value);};
    if(sndS)sndS.onchange=function(){_lsmSet('snd',this.value);};
    if(ccb)ccb.onchange=function(){M.cnt=this.checked;_lsmSet('ccb',this.checked);};
    if(scIn)scIn.onchange=function(){M.sc=Math.max(1,Math.min(36,+this.value||8));_lsmSet('sc',M.sc);};

    bpmR.oninput=function(){
      M.bpm=+this.value;bval.textContent=M.bpm+' BPM';
      _lsmSet('bpm',M.bpm);window.__lsExtBpm=M.bpm;
      if(window.__lsSyncBpm)window.__lsSyncBpm(M.bpm);
    };

    play.onclick=function(){
      if(M.p){
        M.p=false;clearTimeout(M.t);
        play.innerHTML='&#9654; Start';
        if(slbl){slbl.textContent='';slbl.classList.remove('_playing');}
        if(drum)drum.classList.remove('_hit','_hit_a');
      } else {
        M.p=true;M.beat=0;play.innerHTML='&#9209; Stop';
        if(slbl)slbl.classList.add('_playing');
        _step();
      }
    };

    function _getCtx(){if(!M.ctx)M.ctx=new(window.AudioContext||window.webkitAudioContext)();return M.ctx;}
    function _tick(accent){
      try{
        var vol=(volR?+volR.value:70)/100;
        var snd=sndS?sndS.value:'click';
        var c=_getCtx(),o=c.createOscillator(),g=c.createGain();
        o.connect(g);g.connect(c.destination);
        var freq,dur,type;
        if(snd==='wood'){  type='sine';freq=accent?350:220;dur=0.18;}
        else if(snd==='soft'){type='sine';freq=accent?660:480;dur=0.14;}
        else if(snd==='bell'){type='sine';freq=accent?1047:784;dur=0.5;}
        else{type='square';freq=accent?1100:700;dur=0.06;}
        o.type=type;o.frequency.value=freq;
        g.gain.setValueAtTime(accent?vol*0.9:vol*0.5,c.currentTime);
        g.gain.exponentialRampToValueAtTime(0.001,c.currentTime+dur);
        o.start(c.currentTime);o.stop(c.currentTime+dur+0.02);
        if(drum){drum.classList.add(accent?'_hit_a':'_hit');
          setTimeout(function(){drum.classList.remove('_hit','_hit_a');},accent?110:80);}
      }catch(e){}
    }
    function _say(t){if(!window.speechSynthesis)return;
      try{var u=new SpeechSynthesisUtterance(t);u.lang='zh-CN';u.rate=.95;u.volume=1;
        window.speechSynthesis.cancel();window.speechSynthesis.speak(u);}catch(e){}}
    function _beatCount(){return window.__lsExtTotal||(M.cnt?M.sc:4);}
    function _step(){if(!M.p)return;
      var total=_beatCount(),s=M.cnt?(M.sc||8):total;
      var _wasAccent=(M.beat===0);
      _tick(_wasAccent);
      if(M.cnt){var n=M.beat%s+1;
        if(slbl)slbl.textContent='Stroke '+n+' / '+s;
        _say((n<=30&&MN[n])||String(n));}
      else if(slbl)slbl.textContent='Beat '+(M.beat%total+1)+' / '+total;
      var _beatNum1=M.beat+1;
      M.beat=(M.beat+1)%s;
      window._lsmBeatNum=M.beat;window._lsmAccent=_wasAccent;
      if(window.__lsCascadeBeat)try{window.__lsCascadeBeat(_wasAccent,_beatNum1);}catch(e){}
      var bpm=window.__lsExtBpm||M.bpm;
      M.t=setTimeout(_step,Math.round(60000/bpm));
    }

    window._metroCountStrokes=function(){
      if(ccb&&ccb.checked){_tick(false);
        var s=M.sc||8,n=M.beat%s+1;
        if(slbl)slbl.textContent='Stroke '+n+' / '+s;
        _say((n<=30&&MN[n])||String(n));M.beat=(M.beat+1)%s;}};
    window._lsmBeat=function(accent){
      _tick(accent);
      if(M.cnt){var s=M.sc||8,n=M.beat%s+1;
        if(slbl)slbl.textContent='Stroke '+n+' / '+s;
        _say((n<=30&&MN[n])||String(n));M.beat=(M.beat+1)%s;}
      else{var _bc=_beatCount();if(slbl)slbl.textContent='Beat '+(M.beat%_bc+1);M.beat=(M.beat+1)%_bc;}};
    window._lsmSay=_say;
    window._lsmStop=function(){if(M.p){M.p=false;clearTimeout(M.t);play.innerHTML='&#9654; Start';
      if(slbl)slbl.textContent='';}};
  })();

  // Original card buttons
  var revealBtn = document.getElementById('btnRevealChar');
  if (revealBtn) revealBtn.addEventListener('click', function() {
    var c = document.getElementById('character-target-div');
    if (c) {
      c.innerHTML = '<div class="char-big" style="'
        + 'font-size:3.8em; margin:10px 0; animation:_hw_fadein 0.3s ease;'
        + 'color:var(--accent,#7c6aff);">' + chars.join('') + '</div>';
    }
    // Dim the stroke counter — no longer meaningful after reveal
    var sc = document.getElementById('_hw_stroke_counter');
    if (sc) { sc.style.opacity = '0'; sc.style.transition = 'opacity 0.3s'; }
  });
  var retryBtn = document.getElementById('btnRetryQuiz');
  if (retryBtn) retryBtn.addEventListener('click', function() {
    var m = document.getElementById('_hw_congrats'); if(m) m.remove();
    var sc = document.getElementById('_hw_stroke_counter');
    if (sc) { sc.style.opacity = ''; sc.style.transition = ''; }
    var canvasBlock = document.getElementById('_hw_canvas_wrap');
    if (canvasBlock) canvasBlock.classList.remove('_hw_complete');
    initWriters();
  });

  // Apply stored accent to all accent-colored elements
  try {
    var saved = localStorage.getItem('_hw_accentColor');
    if (saved) {
      var _ac = JSON.parse(saved);
      document.documentElement.style.setProperty('--accent', _ac);
      window._hwConfig.accentColor = _ac;
      var _py = document.getElementById('_hw_pinyin');
      if (_py) _py.style.color = _ac;
      var _eh = document.getElementById('_hw_edge_hint');
      if (_eh) _eh.style.background = _ac;
    }
  } catch(e) {}

  window._hwSpeak   = _hwSpeak;
  window._hwSetLabel = _hwSetLabel;
  window._hwDone    = _hwDone;

  if (typeof HanziWriter === 'undefined') {
    var s = document.createElement('script'); s.src = '_hanzi-writer.min.js';
    s.onload = initWriters; document.head.appendChild(s);
  } else {
    initWriters();
  }
})();
</script>
"""

# ── Shared Freehand Writer (Arabic-script / Latin freehand) ───────────────────
# Render letter-by-letter trace cells for non-CJK scripts. The shape data is
# produced in Python by kinesthetic.arabic_shaping.shape_word() and shipped
# in the per-note WriteCfg JSON field; this JS just renders cells, attaches
# pointer/touch handlers, plays per-letter audio, and calls back into the
# host card when done.
#
# Sync-critical: keys read here (writeModule, rtl, useNastaliq,
# letterByLetter, lettersByWord, congratsText, fontFamily) must match those
# emitted by kinesthetic.write_cfg.build().
#
# Public API:
#   window.lsFreehandInit(hostId, word, cfg) → { clear(), done(), destroy() }
#   - hostId : id of an empty container element to render into.
#   - word   : the string the host wants the user to write.
#   - cfg    : parsed WriteCfg + optional onDone callback.
#   - returns a handle, or null if cfg.writeModule is 'hanziwriter'
#     (caller should fall through to HanziWriter.create on null return).

FREEHAND_WRITER_CSS = r"""
<style>
""" + ARABIC_FONTFACE_CSS + r"""

.lsfh-row {
  display: flex; flex-wrap: wrap; gap: 10px;
  justify-content: center; align-items: center;
  margin: 6px 0;
}
.lsfh-row-rtl { flex-direction: row-reverse; }
.lsfh-cell {
  position: relative;
  display: inline-flex; flex-direction: column; align-items: center;
  padding: 4px;
  border-radius: 8px;
  background: #faf8f4;
  border: 2px solid transparent;
  transition: border-color 0.18s ease, box-shadow 0.18s ease;
}
.lsfh-cell .lsfh-canvas-wrap { position: relative; display: block; }
.lsfh-cell canvas {
  display: block; border-radius: 6px; touch-action: none;
}
.lsfh-cell .lsfh-guide { position: absolute; top: 0; left: 0; pointer-events: none; }
.lsfh-cell .lsfh-guide text { font-family: 'LS Naskh', 'Noto Sans Arabic', 'Amiri', serif; }
.lsfh-cell.lsfh-nastaliq .lsfh-guide text {
  font-family: 'LS Nastaliq', 'Noto Nastaliq Urdu', 'LS Naskh', serif;
}
.lsfh-cell-done {
  margin-top: 4px; padding: 4px 10px; font-size: 0.85em;
  border: none; border-radius: 6px; cursor: pointer;
  background: #2d2d3f; color: #e2e8f0; min-height: 28px;
}
.lsfh-cell.lsfh-active {
  border-color: var(--accent, #7c6aff);
  box-shadow: 0 0 14px 2px rgba(124,106,255,0.45);
}
.lsfh-cell.lsfh-finished {
  border-color: #4ade80; box-shadow: 0 0 0 1px #4ade80;
}
.lsfh-cell.lsfh-finished .lsfh-cell-done { background: #4ade80; color: #07140a; }

.lsfh-wrap {
  display: flex; flex-direction: column; align-items: center;
  gap: 10px; width: 100%;
}
.lsfh-canvas-wrap { position: relative; display: inline-block; }
.lsfh-single-canvas {
  display: block;
  background: #faf8f4;
  border: 1px solid #2d2d3f;
  border-radius: 8px;
  touch-action: none;
}
.lsfh-guide-svg {
  position: absolute; top: 0; left: 0; pointer-events: none; border-radius: 8px;
}
.lsfh-controls { display: flex; gap: 10px; }
.lsfh-btn {
  padding: 10px 22px; font-size: 1em;
  border: none; border-radius: 8px; cursor: pointer;
  background: #2d2d3f; color: #e2e8f0;
  min-width: 80px; min-height: 44px;
}
.lsfh-done { background: var(--accent, #7c6aff); color: #fff; }
.lsfh-btn:active { opacity: 0.7; }

@keyframes lsfh_fadein  { from { opacity:0; transform:scale(0.88) translateY(6px); } to { opacity:1; transform:scale(1) translateY(0); } }
@keyframes lsfh_fadeout { from { opacity:1; transform:translateY(0); } to { opacity:0; transform:translateY(10px); } }
</style>
"""

FREEHAND_WRITER_SCRIPT = FREEHAND_WRITER_CSS + r"""
<script>
(function(){
  if (window.lsFreehandInit) return;  // idempotent — embed once per card

  function strokeColor(){
    return (getComputedStyle(document.documentElement)
            .getPropertyValue('--accent')||'').trim() || '#7c6aff';
  }

  function attachPointer(canvas, col){
    var ctx = canvas.getContext('2d');
    var drawing=false, lX=0, lY=0;
    function gp(e){
      var r=canvas.getBoundingClientRect();
      var src=e.touches?e.touches[0]:e;
      return{x:src.clientX-r.left,y:src.clientY-r.top};
    }
    function sd(e){ drawing=true; var p=gp(e); lX=p.x; lY=p.y; e.preventDefault(); }
    function dr(e){
      if(!drawing) return; e.preventDefault();
      var p=gp(e);
      var pr=(e.pressure&&e.pressure>0)?e.pressure:0.5;
      var lw=Math.max(1.5,Math.min(6,pr*8));
      ctx.beginPath(); ctx.moveTo(lX,lY); ctx.lineTo(p.x,p.y);
      ctx.strokeStyle=col; ctx.lineWidth=lw;
      ctx.lineCap='round'; ctx.lineJoin='round'; ctx.stroke();
      lX=p.x; lY=p.y;
    }
    function su(){ drawing=false; }
    canvas.addEventListener('pointerdown',sd);
    canvas.addEventListener('pointermove',dr);
    canvas.addEventListener('pointerup',su);
    canvas.addEventListener('pointerleave',su);
    canvas.addEventListener('touchstart',sd,{passive:false});
    canvas.addEventListener('touchmove',dr,{passive:false});
    canvas.addEventListener('touchend',su);
    return ctx;
  }

  function showCongrats(text){
    var c=document.createElement('div');
    c.style.cssText='position:fixed;bottom:28px;left:0;right:0;'
      +'text-align:center;font-size:2em;font-weight:700;'
      +'color:var(--accent,#7c6aff);letter-spacing:.1em;'
      +'animation:lsfh_fadein 0.45s ease;z-index:9990;pointer-events:none;';
    c.textContent = text || '✓';
    document.body.appendChild(c);
    setTimeout(function(){
      c.style.animation='lsfh_fadeout 0.55s ease forwards';
      setTimeout(function(){ if(c.parentNode) c.remove(); }, 560);
    }, 1800);
  }

  function playLetter(name, letterAudio){
    if(!letterAudio || !name) return;
    try{ var a=new Audio('_ar_'+name+'.mp3'); a.play(); }catch(e){}
  }

  // ── Letter-by-letter cell renderer ────────────────────────────────────────
  function renderCells(host, word, cells, opts){
    host.innerHTML='';
    host.className=(host.className||'').replace(/\blsfh-row(-rtl)?\b/g,'').trim();
    host.classList.add('lsfh-row');
    if(opts.rtl) host.classList.add('lsfh-row-rtl');

    var col=strokeColor();
    var cW=110, cH=130;
    var fSize=Math.round(cH*0.62);
    var rtlAttr=opts.rtl?' direction="rtl"':'';
    var nCells=cells.length;
    var perDone=new Array(nCells).fill(false);
    var cellEls=[];
    var ctxes=[];

    cells.forEach(function(c, idx){
      var glyph=(opts.diacriticsOn && c.marks) ? (c.form + c.marks) : c.form;
      var baselineSvg = opts.baselineOn
        ? '<line x1="6" x2="'+(cW-6)+'" y1="'+Math.round(cH*0.72)+'" y2="'+Math.round(cH*0.72)+'"'
          + ' stroke="currentColor" stroke-width="0.7" stroke-dasharray="3,3" opacity="0.32"/>'
        : '';
      var guideSvg='<svg class="lsfh-guide" width="'+cW+'" height="'+cH+'"'
        +' xmlns="http://www.w3.org/2000/svg">'
        +baselineSvg
        +'<text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle"'
        +' font-size="'+fSize+'px" fill="currentColor" opacity="0.35"'
        +rtlAttr+'>'+glyph+'</text></svg>';
      var cell=document.createElement('div');
      cell.className='lsfh-cell'+(opts.useNastaliq?' lsfh-nastaliq':'');
      cell.innerHTML='<div class="lsfh-canvas-wrap">'
        +'<canvas width="'+cW+'" height="'+cH+'"></canvas>'
        +guideSvg
        +'</div>'
        +'<button class="lsfh-cell-done" title="Mark this letter done">&#10003; '+(c.name||'')+'</button>';
      host.appendChild(cell);
      var canvas=cell.querySelector('canvas');
      ctxes.push(attachPointer(canvas, col));
      cellEls.push(cell);
      cell.querySelector('.lsfh-cell-done').addEventListener('click', function(){
        if(perDone[idx]) return;
        perDone[idx]=true;
        cell.classList.remove('lsfh-active');
        cell.classList.add('lsfh-finished');
        if(opts.onCellAdvance) opts.onCellAdvance(idx, cells[idx]);
        advance();
      });
    });

    var bar=document.createElement('div');
    bar.className='lsfh-controls';
    bar.style.marginTop='6px';
    bar.innerHTML='<button class="lsfh-btn lsfh-clearall">&#10005; Clear all</button>'
      +'<button class="lsfh-btn lsfh-done lsfh-doneall">&#10003; Done</button>';
    host.appendChild(bar);
    bar.querySelector('.lsfh-clearall').addEventListener('click', function(){
      ctxes.forEach(function(ctx, i){
        var c=cellEls[i].querySelector('canvas');
        ctx.clearRect(0,0,c.width,c.height);
      });
    });
    bar.querySelector('.lsfh-doneall').addEventListener('click', function(){
      finish();
    });

    var curIdx=0, finished=false;
    function advance(){
      while(curIdx<nCells && perDone[curIdx]) curIdx++;
      if(curIdx>=nCells){ finish(); return; }
      cellEls.forEach(function(el){ el.classList.remove('lsfh-active'); });
      cellEls[curIdx].classList.add('lsfh-active');
      playLetter(cells[curIdx].name, opts.letterAudio);
    }
    function finish(){
      if(finished) return;
      finished=true;
      showCongrats(opts.congratsText);
      if(opts.onDone) setTimeout(opts.onDone, 200);
    }
    advance();

    return {
      clear: function(){
        ctxes.forEach(function(ctx, i){
          var c=cellEls[i].querySelector('canvas');
          ctx.clearRect(0,0,c.width,c.height);
        });
      },
      done: finish,
      destroy: function(){ host.innerHTML=''; }
    };
  }

  // ── Whole-word freehand renderer (fallback) ───────────────────────────────
  function renderWord(host, word, opts){
    host.innerHTML='';
    var col=strokeColor();
    var cW=320, cH=180;
    var fSize=Math.round(cH*0.52);
    var rtlAttr=opts.rtl?' direction="rtl"':'';
    var family=(opts.useNastaliq?"'LS Nastaliq', ":"")+"'LS Naskh', "+(opts.fontFamily||'sans-serif');
    var guideSvg='<svg class="lsfh-guide-svg" width="'+cW+'" height="'+cH+'"'
      +' xmlns="http://www.w3.org/2000/svg">'
      +'<text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle"'
      +' font-family="'+family+'"'
      +' font-size="'+fSize+'px" fill="currentColor" opacity="0.35"'
      +rtlAttr+'>'+word+'</text></svg>';
    var wrap=document.createElement('div');
    wrap.className='lsfh-wrap';
    wrap.innerHTML='<div class="lsfh-canvas-wrap">'
      +'<canvas class="lsfh-single-canvas" width="'+cW+'" height="'+cH+'"></canvas>'
      +guideSvg
      +'</div>'
      +'<div class="lsfh-controls">'
      +'<button class="lsfh-btn lsfh-clear">&#10005; Clear</button>'
      +'<button class="lsfh-btn lsfh-done lsfh-doneone">&#10003; Done</button>'
      +'</div>';
    host.appendChild(wrap);
    var canvas=wrap.querySelector('canvas');
    var ctx=attachPointer(canvas, col);
    var finished=false;
    function finish(){
      if(finished) return;
      finished=true;
      showCongrats(opts.congratsText);
      if(opts.onDone) setTimeout(opts.onDone, 200);
    }
    wrap.querySelector('.lsfh-clear').addEventListener('click', function(){
      ctx.clearRect(0,0,canvas.width,canvas.height);
    });
    wrap.querySelector('.lsfh-doneone').addEventListener('click', finish);
    return {
      clear: function(){ ctx.clearRect(0,0,canvas.width,canvas.height); },
      done:  finish,
      destroy: function(){ host.innerHTML=''; }
    };
  }

  window.lsFreehandInit = function(hostId, word, cfg){
    cfg = cfg || {};
    var host = document.getElementById(hostId);
    if (!host) return null;
    if (cfg.writeModule === 'hanziwriter') return null;
    var opts = {
      rtl:           !!cfg.rtl,
      useNastaliq:   !!cfg.useNastaliq,
      fontFamily:    cfg.fontFamily   || 'sans-serif',
      congratsText:  cfg.congratsText || '✓',
      letterAudio:   cfg.letterAudio   !== false,
      baselineOn:    cfg.baselineOn    !== false,
      diacriticsOn:  cfg.diacriticsOn  !== false,
      onDone:        typeof cfg.onDone === 'function' ? cfg.onDone : null,
      onCellAdvance: typeof cfg.onCellAdvance === 'function' ? cfg.onCellAdvance : null,
    };
    var cells = (cfg.letterByLetter !== false && cfg.lettersByWord)
                  ? cfg.lettersByWord[word] : null;
    if (cells && cells.length) return renderCells(host, word, cells, opts);
    return renderWord(host, word, opts);
  };

  // ── OCR-check freehand module ──────────────────────────────────────────────
  // Renders the same ghost-overlay canvas as the guided/ghost modules but
  // replaces the "Done" button with a "✓ Check" button that runs Tesseract.js
  // OCR and automatically grades the user's answer.
  // Falls back gracefully to self-grade buttons when _tesseract.min.js is
  // unavailable (AnkiDroid, no-network import, etc.).
  window.lsFreehandOcrInit = function(hostId, word, cfg){
    cfg = cfg || {};
    var host = document.getElementById(hostId);
    if (!host) return null;

    var tessLang  = cfg.tesseractLang || 'eng';
    var target    = (word || '').trim();
    var rtl       = !!cfg.rtl;
    var nastaliq  = !!cfg.useNastaliq;
    var family    = (nastaliq ? "'LS Nastaliq', " : "") + "'LS Naskh', " + (cfg.fontFamily || 'sans-serif');
    var congrats  = cfg.congratsText || '✓';
    var onDoneFn  = typeof cfg.onDone === 'function' ? cfg.onDone : null;

    host.innerHTML = '';
    var cW = 320, cH = 180;
    var fSize = Math.round(cH * 0.52);
    var rtlAttr = rtl ? ' direction="rtl"' : '';

    var guideSvg = '<svg class="lsfh-guide-svg" width="'+cW+'" height="'+cH+'"'
      +' xmlns="http://www.w3.org/2000/svg">'
      +'<text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle"'
      +' font-family="'+family+'"'
      +' font-size="'+fSize+'px" fill="currentColor" opacity="0.35"'
      +rtlAttr+'>'+target+'</text></svg>';

    var wrap = document.createElement('div');
    wrap.className = 'lsfh-wrap';
    wrap.innerHTML =
      '<div class="lsfh-canvas-wrap">'
      +'<canvas class="lsfh-single-canvas" width="'+cW+'" height="'+cH+'"></canvas>'
      +guideSvg
      +'</div>'
      +'<div class="lsfh-controls">'
      +'<button class="lsfh-btn lsfh-clear">&#10005; Clear</button>'
      +'<button class="lsfh-btn lsfh-done lsfh-check-btn">&#10003; Check</button>'
      +'</div>'
      +'<div class="lsfh-ocr-result" style="display:none;margin-top:8px;text-align:center;'
      +'font-size:1.1em;min-height:28px;"></div>';
    host.appendChild(wrap);

    var canvas   = wrap.querySelector('canvas');
    var resultEl = wrap.querySelector('.lsfh-ocr-result');
    var checkBtn = wrap.querySelector('.lsfh-check-btn');
    var ctx      = attachPointer(canvas, strokeColor());

    wrap.querySelector('.lsfh-clear').addEventListener('click', function(){
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      resultEl.style.display = 'none';
      checkBtn.disabled = false;
      checkBtn.innerHTML = '&#10003; Check';
    });

    function _normalizeOcr(text){
      var s = (text || '').replace(/\s+/g, '').trim();
      if (/^(ara|fas|urd)$/.test(tessLang)){
        // Strip Arabic tashkeel + normalize alef variants
        s = s.replace(/[ؐ-ًؚ-ٰٟ]/g, '');
        s = s.replace(/[آأإٱ]/g, 'ا');
      } else {
        try { s = s.normalize('NFD').replace(/[̀-ͯ]/g, '').normalize('NFC'); } catch(e){}
        s = s.toLowerCase();
      }
      return s;
    }

    function _showResult(correct, rawOcr){
      resultEl.style.display = 'block';
      if (correct){
        resultEl.innerHTML = '<span style="color:#4ade80;font-size:1.4em;">&#10003;</span>';
      } else {
        resultEl.innerHTML = '<span style="color:#f87171;font-size:1.2em;">&#10007;</span>'
          +'<span style="opacity:0.7;font-size:0.85em;margin-left:6px;">'+(rawOcr||'?')+'</span>';
      }
    }

    function _showSelfGrade(){
      resultEl.style.display = 'block';
      var okBtn  = document.createElement('button');
      var badBtn = document.createElement('button');
      okBtn.className  = 'lsfh-btn';
      badBtn.className = 'lsfh-btn';
      okBtn.style.cssText  = 'background:#4ade80;color:#07140a;margin:0 6px;';
      badBtn.style.cssText = 'background:#f87171;color:#07140a;margin:0 6px;';
      okBtn.innerHTML  = '&#10003; Correct';
      badBtn.innerHTML = '&#10007; Wrong';
      resultEl.innerHTML = '';
      resultEl.appendChild(okBtn);
      resultEl.appendChild(badBtn);
      okBtn.addEventListener('click', function(){
        resultEl.innerHTML = '<span style="color:#4ade80;font-size:1.4em;">&#10003;</span>';
        showCongrats(congrats);
        if (onDoneFn) setTimeout(onDoneFn, 200);
      });
      badBtn.addEventListener('click', function(){
        resultEl.innerHTML = '<span style="color:#f87171;font-size:1.2em;">&#10007;</span>';
        checkBtn.disabled = false;
        checkBtn.innerHTML = '&#8635; Retry';
      });
    }

    function _runOcr(){
      checkBtn.disabled = true;
      checkBtn.textContent = '…';
      function _doRecognize(){
        if (typeof Tesseract === 'undefined'){ _showSelfGrade(); checkBtn.disabled=false; checkBtn.innerHTML='&#10003; Check'; return; }
        Tesseract.recognize(canvas, tessLang, {
          langPath: '',
          cacheMethod: 'none',
          workerPath:  '_tesseract-worker.min.js',
          corePath:    '_tesseract-core.wasm.js',
          logger:      null,
        }).then(function(r){
          var raw  = (r.data && r.data.text) ? r.data.text : '';
          var got  = _normalizeOcr(raw);
          var want = _normalizeOcr(target);
          var ok   = (got === want) || (got.length > 0 && want.indexOf(got) !== -1);
          _showResult(ok, raw.trim());
          if (ok){ showCongrats(congrats); if(onDoneFn) setTimeout(onDoneFn, 400); }
          checkBtn.disabled = false;
          checkBtn.innerHTML = ok ? '&#10003;' : '&#8635; Retry';
        }).catch(function(){ _showSelfGrade(); checkBtn.disabled=false; checkBtn.innerHTML='&#10003; Check'; });
      }
      if (typeof Tesseract === 'undefined'){
        var s = document.createElement('script');
        s.src = '_tesseract.min.js';
        s.onload  = _doRecognize;
        s.onerror = function(){ _showSelfGrade(); checkBtn.disabled=false; checkBtn.innerHTML='&#10003; Check'; };
        document.head.appendChild(s);
      } else {
        _doRecognize();
      }
    }

    checkBtn.addEventListener('click', function(){
      var px = ctx.getImageData(0,0,canvas.width,canvas.height).data;
      var drawn = false;
      for (var i=3; i<px.length && !drawn; i+=4) drawn = (px[i] > 20);
      if (!drawn) return;
      _runOcr();
    });

    return {
      clear:   function(){ ctx.clearRect(0,0,canvas.width,canvas.height); resultEl.style.display='none'; },
      done:    function(){ checkBtn.click(); },
      destroy: function(){ host.innerHTML=''; },
    };
  };
})();
</script>
"""


# ── Card Templates ────────────────────────────────────────────────────────────

# Card 1: Meaning Recall — see character → recall meaning
_VOCAB_V3_DIR = Path(__file__).parent / "assets" / "vocab_v3"
_VOCAB_V3_CARDS = ("1_Meaning", "2_Reading", "3_Listening", "4_Writing", "5_Cloze_Fill")


def _vocab_v3_side(side: str) -> list:
    return [(_VOCAB_V3_DIR / f"{card}.{side}.html").read_text(encoding="utf-8") for card in _VOCAB_V3_CARDS]


CARD1_FRONT, CARD2_FRONT, CARD3_FRONT, CARD4_FRONT, CARD5_FRONT = _vocab_v3_side("front")
CARD1_BACK, CARD2_BACK, CARD3_BACK, CARD4_BACK, CARD5_BACK = _vocab_v3_side("back")
VOCAB_CSS = (_VOCAB_V3_DIR / "styling.css").read_text(encoding="utf-8")
VOCAB_MEDIA = sorted(str(p) for p in _VOCAB_V3_DIR.glob("_ls_*"))


CARD6_FRONT = """
{{#Image}}
<div class="card-header">What is <span class="highlight">this</span>?</div>

<div class="visual-image-wrap">{{Image}}</div>

<div class="audio-hidden" id="card-audio">{{Audio}}</div>
<button class="play-btn" data-audio="card-audio" title="Play audio">▶</button>

<div class="ls-typebox" style="margin-top:12px;">{{type:Simplified}}</div>
{{/Image}}
""" + AUDIO_SCRIPT

CARD6_BACK = """
{{FrontSide}}
<hr class="card-divider">

<div class="char-big">{{Simplified}}</div>
<div class="char-trad">{{Traditional}}</div>
<div class="pinyin-display">{{Pinyin}}</div>
<div class="meaning-display">{{Meaning}}</div>

{{#Sentence}}
<div class="sentence-block">
  <div class="sentence-zh">{{Sentence}}</div>
  <div class="sentence-pinyin">{{SentencePinyin}}</div>
  <div class="sentence-en">{{SentenceTranslation}}</div>
</div>
{{/Sentence}}
"""

_VISUAL_CARD_CSS = """
/* ── Visual recall card ─────────────────────────────────────────── */
.visual-image-wrap { margin: 14px auto; max-width: 420px; }
.visual-image-wrap img { max-width: 100%; max-height: 320px;
                         border-radius: 12px; object-fit: contain; }
"""


# ── genanki model builders ────────────────────────────────────────────────────

def get_hanzi_model(selected=None):
    """Build the main LinguaStudio note type.

    selected: set/list of template names to include, e.g. {"Writing"}.
    None or empty → the 5 classic templates (NOT Visual: the default
    'LinguaStudio' model in existing collections predates the Visual
    template, and AnkiConnect template updates can't add new template
    names to an existing note type — so Visual is opt-in via `selected`
    and lands on its own bitmask model id). Model ID varies by selection
    so different subsets create distinct Anki note types without collision.
    """
    if not HAS_GENANKI:
        raise RuntimeError("genanki not installed. pip install genanki --break-system-packages")

    _ALL_TEMPLATES = [
        {"name": "Meaning",    "qfmt": CARD1_FRONT, "afmt": CARD1_BACK},
        {"name": "Reading",    "qfmt": CARD2_FRONT, "afmt": CARD2_BACK},
        {"name": "Listening",  "qfmt": CARD3_FRONT, "afmt": CARD3_BACK},
        {"name": "Writing",    "qfmt": CARD4_FRONT, "afmt": CARD4_BACK},
        {"name": "Cloze Fill", "qfmt": CARD5_FRONT, "afmt": CARD5_BACK},
        {"name": "Visual",     "qfmt": CARD6_FRONT, "afmt": CARD6_BACK},
    ]
    _DEFAULT_TEMPLATES = _ALL_TEMPLATES[:5]  # classic set — never grows (see docstring)
    if not selected:
        templates = _DEFAULT_TEMPLATES
        model_id  = HANZI_MODEL_ID
        model_name = 'LinguaStudio'
    else:
        sel = set(selected)
        templates = [t for t in _ALL_TEMPLATES if t["name"] in sel]
        if not templates:
            templates = _DEFAULT_TEMPLATES
            model_id  = HANZI_MODEL_ID
            model_name = 'LinguaStudio'
        else:
            bitmask = sum(1 << i for i, t in enumerate(_ALL_TEMPLATES)
                         if t["name"] in sel)
            model_id  = HANZI_MODEL_ID + bitmask
            short = "+".join(t["name"].split()[0] for t in templates)
            model_name = f'LinguaStudio ({short})'

    return genanki.Model(
        model_id,
        model_name,
        fields=[
            {"name": "Simplified"},
            {"name": "Traditional"},
            {"name": "Pinyin"},
            {"name": "Zhuyin"},
            {"name": "Meaning"},
            {"name": "Audio"},
            {"name": "Sentence"},
            {"name": "SentencePinyin"},
            {"name": "SentenceTranslation"},
            {"name": "Tags"},
            {"name": "Resources"},
            {"name": "WriteCfg"},  # JSON for non-CJK freehand dispatch (kinesthetic.write_cfg.build_json)
            {"name": "Image"},     # <img> for the Visual template — appended LAST (append-only rule)
        ],
        templates=templates,
        css=VOCAB_CSS + _VISUAL_CARD_CSS,
    )


# ── Export helpers ────────────────────────────────────────────────────────────


# ── Multi-language model IDs (202601XXXX range) ───────────────────────────────

ARABIC_MODEL_ID    = 2026010010
HUNGARIAN_MODEL_ID = 2026040010
GERMAN_MODEL_ID    = 2026050010
SPANISH_MODEL_ID   = 2026060010

# ── Shared base CSS for multi-language cards ──────────────────────────────────

_LANG_BASE_CSS = SHARED_CSS + """
/* Multi-language card extras */
.word-large {
  font-size: 2.4em;
  font-weight: 700;
  color: var(--simplified-color, #1e40af);
  margin: 12px 0 4px;
  line-height: 1.2;
}
.word-rtl {
  direction: rtl;
  unicode-bidi: bidi-override;
}
.romanization {
  font-size: 1em;
  color: var(--pinyin-color, #ef6c00);
  letter-spacing: .04em;
  margin-bottom: 6px;
}
.lang-extra {
  font-size: 0.85em;
  color: var(--fg2);
  margin: 3px 0;
}
"""

# ══════════════════════════════════════════════════════════════════════════════
# Arabic (ara)
# ══════════════════════════════════════════════════════════════════════════════

_ARA_CSS = _LANG_BASE_CSS + """
/* Arabic: larger font for Arabic script */
.word-large { font-family: 'Noto Sans Arabic', 'Amiri', 'Scheherazade New', sans-serif; font-size: 2.8em; }
"""

_ARA_MEANING_FRONT = """\
<div class="card">
  <div class="word-large word-rtl">{{Word}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">What does this mean?</div>
</div>"""

_ARA_MEANING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  {{#Root}}<div class="lang-extra">Root: {{Root}}</div>{{/Root}}
  <div class="sentence" style="direction:rtl;">{{Sentence}}</div>
  <div class="sentence-translation">{{SentenceTranslation}}</div>
</div>""" + AUDIO_SCRIPT

_ARA_READING_FRONT = """\
<div class="card">
  <div class="word-large word-rtl">{{Word}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">How do you pronounce this?</div>
</div>"""

_ARA_READING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
</div>""" + AUDIO_SCRIPT

_ARA_LISTEN_FRONT = """\
<div class="card">
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:1em;margin-top:16px;">What word is this?</div>
</div>"""

_ARA_LISTEN_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="word-large word-rtl">{{Word}}</div>
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
</div>""" + AUDIO_SCRIPT


def get_arabic_model():
    """Arabic vocab note type — Word + Transliteration + Root."""
    if not HAS_GENANKI:
        raise RuntimeError("genanki not installed.")
    return genanki.Model(
        ARABIC_MODEL_ID,
        "LinguaStudio Arabic",
        fields=[
            {"name": "Word"},
            {"name": "Romanization"},
            {"name": "Meaning"},
            {"name": "Audio"},
            {"name": "Sentence"},
            {"name": "SentenceTranslation"},
            {"name": "Root"},
        ],
        templates=[
            {"name": "Meaning",   "qfmt": _ARA_MEANING_FRONT, "afmt": _ARA_MEANING_BACK},
            {"name": "Reading",   "qfmt": _ARA_READING_FRONT, "afmt": _ARA_READING_BACK},
            {"name": "Listening", "qfmt": _ARA_LISTEN_FRONT,  "afmt": _ARA_LISTEN_BACK},
        ],
        css=_ARA_CSS,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Hungarian (hun)
# ══════════════════════════════════════════════════════════════════════════════

_HUN_CSS = _LANG_BASE_CSS + """
/* Hungarian: standard Latin fonts */
.word-large { font-family: 'Noto Sans', 'Segoe UI', 'Liberation Sans', sans-serif; }
"""

_HUN_MEANING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">What does this mean?</div>
</div>"""

_HUN_MEANING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  {{#IPA}}<div class="lang-extra">IPA: {{IPA}}</div>{{/IPA}}
  {{#VowelHarmony}}<div class="lang-extra">Vowel harmony: {{VowelHarmony}}</div>{{/VowelHarmony}}
  <div class="sentence">{{Sentence}}</div>
  <div class="sentence-translation">{{SentenceTranslation}}</div>
</div>""" + AUDIO_SCRIPT

_HUN_READING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">How do you pronounce this? (IPA)</div>
</div>"""

_HUN_READING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
</div>""" + AUDIO_SCRIPT

_HUN_LISTEN_FRONT = """\
<div class="card">
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:1em;margin-top:16px;">What word is this? Type it:</div>
  <div class="ls-typebox" style="margin-top:12px;">{{type:Word}}</div>
</div>"""

_HUN_LISTEN_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="word-large">{{Word}}</div>
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
</div>""" + AUDIO_SCRIPT


def get_hungarian_model():
    """Hungarian vocab note type — Word + IPA + VowelHarmony."""
    if not HAS_GENANKI:
        raise RuntimeError("genanki not installed.")
    return genanki.Model(
        HUNGARIAN_MODEL_ID,
        "LinguaStudio Hungarian",
        fields=[
            {"name": "Word"},
            {"name": "Romanization"},
            {"name": "Meaning"},
            {"name": "Audio"},
            {"name": "Sentence"},
            {"name": "SentenceTranslation"},
            {"name": "IPA"},
            {"name": "VowelHarmony"},
        ],
        templates=[
            {"name": "Meaning",   "qfmt": _HUN_MEANING_FRONT, "afmt": _HUN_MEANING_BACK},
            {"name": "Reading",   "qfmt": _HUN_READING_FRONT, "afmt": _HUN_READING_BACK},
            {"name": "Listening", "qfmt": _HUN_LISTEN_FRONT,  "afmt": _HUN_LISTEN_BACK},
        ],
        css=_HUN_CSS,
    )


# ══════════════════════════════════════════════════════════════════════════════
# German (deu)
# ══════════════════════════════════════════════════════════════════════════════

_DEU_CSS = _LANG_BASE_CSS + """
/* German: standard Latin fonts */
.word-large { font-family: 'Noto Sans', 'Segoe UI', 'Liberation Sans', sans-serif; }
"""

_DEU_MEANING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  {{#Article}}<div class="lang-extra">Article: {{Article}}</div>{{/Article}}
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">What does this mean?</div>
</div>"""

_DEU_MEANING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  {{#IPA}}<div class="lang-extra">IPA: {{IPA}}</div>{{/IPA}}
  {{#Plural}}<div class="lang-extra">Plural: {{Plural}}</div>{{/Plural}}
  <div class="sentence">{{Sentence}}</div>
  <div class="sentence-translation">{{SentenceTranslation}}</div>
</div>""" + AUDIO_SCRIPT

_DEU_READING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">How do you pronounce this? (IPA)</div>
</div>"""

_DEU_READING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
</div>""" + AUDIO_SCRIPT

_DEU_LISTEN_FRONT = """\
<div class="card">
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:1em;margin-top:16px;">What word is this? Type it:</div>
  <div class="ls-typebox" style="margin-top:12px;">{{type:Word}}</div>
</div>"""

_DEU_LISTEN_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="word-large">{{Word}}</div>
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
</div>""" + AUDIO_SCRIPT


def get_german_model():
    """German vocab note type — Word + IPA + Article + Plural."""
    if not HAS_GENANKI:
        raise RuntimeError("genanki not installed.")
    return genanki.Model(
        GERMAN_MODEL_ID,
        "LinguaStudio German",
        fields=[
            {"name": "Word"},
            {"name": "Romanization"},
            {"name": "Meaning"},
            {"name": "Audio"},
            {"name": "Sentence"},
            {"name": "SentenceTranslation"},
            {"name": "Article"},
            {"name": "Plural"},
            {"name": "IPA"},
        ],
        templates=[
            {"name": "Meaning",   "qfmt": _DEU_MEANING_FRONT, "afmt": _DEU_MEANING_BACK},
            {"name": "Reading",   "qfmt": _DEU_READING_FRONT, "afmt": _DEU_READING_BACK},
            {"name": "Listening", "qfmt": _DEU_LISTEN_FRONT,  "afmt": _DEU_LISTEN_BACK},
        ],
        css=_DEU_CSS,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Spanish (spa)
# ══════════════════════════════════════════════════════════════════════════════

_SPA_CSS = _LANG_BASE_CSS + """
/* Spanish: standard Latin fonts */
.word-large { font-family: 'Noto Sans', 'Segoe UI', 'Liberation Sans', sans-serif; }
"""

_SPA_MEANING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  {{#Gender}}<div class="lang-extra">Gender: {{Gender}}</div>{{/Gender}}
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">What does this mean?</div>
</div>"""

_SPA_MEANING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  {{#IPA}}<div class="lang-extra">IPA: {{IPA}}</div>{{/IPA}}
  {{#ConjugationGroup}}<div class="lang-extra">Conjugation: {{ConjugationGroup}}</div>{{/ConjugationGroup}}
  <div class="sentence">{{Sentence}}</div>
  <div class="sentence-translation">{{SentenceTranslation}}</div>
</div>""" + AUDIO_SCRIPT

_SPA_READING_FRONT = """\
<div class="card">
  <div class="word-large">{{Word}}</div>
  <div style="color:var(--fg2);font-size:0.9em;margin-top:12px;">How do you pronounce this? (IPA)</div>
</div>"""

_SPA_READING_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
</div>""" + AUDIO_SCRIPT

_SPA_LISTEN_FRONT = """\
<div class="card">
  <div class="audio-hidden" id="card-audio">{{Audio}}</div>
  <div style="color:var(--fg2);font-size:1em;margin-top:16px;">What word is this? Type it:</div>
  <div class="ls-typebox" style="margin-top:12px;">{{type:Word}}</div>
</div>"""

_SPA_LISTEN_BACK = """\
{{FrontSide}}<hr id="answer">
<div class="card back">
  <div class="word-large">{{Word}}</div>
  <div class="romanization">{{Romanization}}</div>
  <div class="meaning">{{Meaning}}</div>
</div>""" + AUDIO_SCRIPT


def get_spanish_model():
    """Spanish vocab note type — Word + IPA + Gender + ConjugationGroup."""
    if not HAS_GENANKI:
        raise RuntimeError("genanki not installed.")
    return genanki.Model(
        SPANISH_MODEL_ID,
        "LinguaStudio Spanish",
        fields=[
            {"name": "Word"},
            {"name": "Romanization"},
            {"name": "Meaning"},
            {"name": "Audio"},
            {"name": "Sentence"},
            {"name": "SentenceTranslation"},
            {"name": "Gender"},
            {"name": "IPA"},
            {"name": "ConjugationGroup"},
        ],
        templates=[
            {"name": "Meaning",   "qfmt": _SPA_MEANING_FRONT, "afmt": _SPA_MEANING_BACK},
            {"name": "Reading",   "qfmt": _SPA_READING_FRONT, "afmt": _SPA_READING_BACK},
            {"name": "Listening", "qfmt": _SPA_LISTEN_FRONT,  "afmt": _SPA_LISTEN_BACK},
        ],
        css=_SPA_CSS,
    )


# ── Language model dispatcher (trimmed) ────────────────────────────────────
#
# Upstream's get_model_for_language() (linguastudio/anki_note_types.py:4425)
# dispatches 16 language codes; this vault only ever asks for the 4 the
# ingest pipeline actually produces alongside cmn (see LINGUA_CODES in
# ingest/lingua.py). The ValueError branch is kept verbatim on purpose: the
# caller catches it and falls back to get_hanzi_model(), so an unmapped code
# here (jpn, fra, rus, ...) degrades exactly the same way it would if this
# were the full upstream table and the caller had asked for a code with no
# per-language model at all.

def get_model_for_language(lang_code):
    """Return genanki Model for a language code."""
    _MAP = {
        "ara": get_arabic_model,
        "hun": get_hungarian_model,
        "deu": get_german_model,
        "spa": get_spanish_model,
    }
    fn = _MAP.get(lang_code)
    if fn is None:
        raise ValueError("No model defined for language code: {!r}".format(lang_code))
    return fn()

