"""The practice ledger (spec §10 rewrite, Stage 2).

Append-only JSONL, one file per device, at `08 Meta/Study/ledger/<device>.jsonl`
— one row per EVENT, never per word. This deliberately mirrors the FSRS review
log at `reviews/<device>.jsonl` (same per-device append-only convention, same
sync guarantee: per-device files never collide, and the rollup is a fold over
their union so replay order does not matter).

WHY NOT IN THE VOCABULARY CSV

Events are unbounded per term, and the CSV's whole reason to exist is that it
stays small and usable. A term glanced at 200 times would need 200 rows in a
table that is one-row-per-word. The CSV's `seen_count` / `lookup_count` /
`saved_count` / `produced_count` / `involvement` columns are the derived ROLLUP
of this log, recomputed by the sidecar — never appended to directly.

The ledger records TOKENS (segmented by coverageTokens / tokenize), not raw
regex words, so Chinese terms are 分享 not 分 + 享 — the same contract 1.1 fixed
in the tokenizer.
"""
from __future__ import annotations

import json
import logging
from collections import defaultdict
from pathlib import Path

from . import constants
from .config import config
from .vocab_csv import bucket_key

log = logging.getLogger("sidecar.ledger")

LEDGER_DIR = f"{constants.STUDY}/ledger"
REVIEW_DIR = f"{constants.STUDY}/reviews"

# Event types, in increasing involvement order (2.2's ordering).
READ_PAST = "read-past"
HOVERED = "hovered"
LOOKED_UP = "looked-up"
SAVED_WITH_SENTENCE = "saved-with-sentence"
PRODUCED = "produced"

EVENT_TYPES = (READ_PAST, HOVERED, LOOKED_UP, SAVED_WITH_SENTENCE, PRODUCED)

# Nation's Involvement Load Hypothesis. Three components — Need, Search,
# Evaluation — each 0..2; involvement is their SUM, not an arbitrary point
# value, so the ordering read-past < hovered < looked-up < saved-with-sentence
# < produced falls out of what each event actually asks of the learner rather
# than being assigned. The numbers will be argued with later; the reasoning is
# beside them so whoever argues can see why they are what they are.
#
#   read-past            Need 0: you did not need the word to keep reading.
#                        Search 0, Evaluation 0. Pure exposure.
#   hovered              Need 1: you stopped on it — mild need to understand.
#                        Search 0, Evaluation 0.
#   looked-up            Need 1, Search 1: you actively sought the gloss.
#                        Evaluation 0.
#   saved-with-sentence  Need 1, Search 1, Evaluation 1: you judged it worth
#                        keeping IN CONTEXT, which is a mild evaluation.
#   produced             Need 2, Search 2, Evaluation 2: you needed it to say
#                        or write something and used it in an original context.
EVENT_WEIGHTS = {
    READ_PAST: {"need": 0, "search": 0, "evaluation": 0},
    HOVERED: {"need": 1, "search": 0, "evaluation": 0},
    LOOKED_UP: {"need": 1, "search": 1, "evaluation": 0},
    SAVED_WITH_SENTENCE: {"need": 1, "search": 1, "evaluation": 1},
    PRODUCED: {"need": 2, "search": 2, "evaluation": 2},
}

# Which CSV count column each event type rolls into. Hover and read-past are
# both "seen" — passive exposure, distinguished only by their involvement.
_COUNT_COLUMN = {
    READ_PAST: "seen_count",
    HOVERED: "seen_count",
    LOOKED_UP: "lookup_count",
    SAVED_WITH_SENTENCE: "saved_count",
    PRODUCED: "produced_count",
}


def involvement_of(event_type: str) -> int:
    return sum(EVENT_WEIGHTS[event_type].values())


def parse_ledger(text: str) -> list[dict]:
    """One JSONL line per event, parsed leniently — a half-written final line
    from an interrupted append must not take the whole history down (the same
    contract as the review log's parser)."""
    out = []
    for line in (text or "").split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(e, dict) and e.get("term") and e.get("type") in EVENT_WEIGHTS \
                and e.get("ts"):
            out.append(e)
    return out


def read_events() -> list[dict]:
    """Every device's ledger, concatenated. Order does not matter — the rollup
    is a fold, so the files may be read in any order and still agree."""
    base = config.vault_path / LEDGER_DIR
    if not base.exists():
        return []
    out = []
    for f in sorted(base.glob("*.jsonl")):
        try:
            out.extend(parse_ledger(f.read_text(encoding="utf-8", errors="replace")))
        except OSError:
            continue
    return out


def rollup(events: list[dict]) -> dict[tuple[str, str], dict]:
    """Group events into per-(term, bucket) counts + involvement.

    The key's second element is the CSV bucket (bucket_key), so events tagged
    zh-hans and cmn roll into the same zh bucket, and yue stays its own. Returns
      {(term, bucket): {"seen_count", "lookup_count", "saved_count",
                        "produced_count", "involvement"}}
    """
    groups: dict[tuple[str, str], dict] = defaultdict(
        lambda: {"seen_count": 0, "lookup_count": 0, "saved_count": 0,
                 "produced_count": 0, "involvement": 0})
    for e in events:
        term = str(e["term"])
        key = (term, bucket_key(e.get("lang", "")))
        groups[key][_COUNT_COLUMN[e["type"]]] += 1
        groups[key]["involvement"] += involvement_of(e["type"])
    return dict(groups)


# --------------------------------------------------------------------- #
# FSRS review summary — the productive/receptive split (2.5's input)     #
# --------------------------------------------------------------------- #
# The review log records FSRS card reviews as {id, ts, grade, ms, dev},
# where id is card-types.js's cardId(type, lang, key) = type:lang:term.
# The card TYPE decides which track a successful recall is evidence for:
# recall of a RECEPTIVE card (you recognise the word) is evidence of receptive
# knowledge only; recall of a PRODUCTIVE card (you produce it) is evidence of
# productive knowledge. status_productive is only ever reached by a card that
# is UNAMBIGUOUSLY production — a card we cannot prove is output is treated as
# recognition, the weaker claim, even when its name suggests otherwise.
#
# "Unambiguous" means: card-types.js's own `archetype` is one with a real
# capture-and-grade UI behind it — "write"/"type" from the start, "order"/
# "tap" since 5.4 (reconstructing a sequence from its parts), "speak" since
# 5.5 (mic capture, Whisper-transcribed and compared to the target). main.js's
# isProductionKind, ~:6104, uses the identical test to decide whether a
# graded card writes a "produced" ledger EVENT. Every archetype WITHOUT such
# a UI ("reveal", "listen", "timed", "match" — pick-from-options is
# recognition even though it is new alongside speak) shows two sides and lets
# the reader self-assess, which is receptive-quality evidence no matter what
# the card's name implies. dictation/writing_prompt/dialogue_quiz/timed_recall
# still READ as production by name and are NOT — crediting them before they
# have a capture-and-grade UI of their own is the exact failure Stage 2's
# negative control exists to catch: self-assessment is not a token you
# produced.
#
# This set is machine-derived from card-types.js's archetypes (5.1's
# inventory), not hand-curated — tests/test_practice.py's
# test_productive_card_types_matches_card_types_js re-derives it from the
# real file on every run, so the two cannot drift apart again the way this
# set once did (it briefly hand-listed 11 reveal/listen/timed archetypes as
# productive on the strength of their NAMES, which never triggered the
# negative control because no fixture exercised a card-type conceptually
# "productive" whose archetype was not).
#
# "hanzi-write" (hyphenated) is not a card-types.js id at all — it is the raw
# review-log TYPE string main.js's hanziWriteCards() stamps directly onto its
# ids (id = "hanzi:" + char + ":write"), predating the card-types.js registry
# and kept as a literal exception for that reason.
PRODUCTIVE_CARD_TYPES = frozenset({
    "cascade_writing", "definition_drill", "hanzi_writer", "measure_word",
    "radical_drill", "tone_drill", "translation",
    # 5.4: order/tap gained real renderers — reconstructing a sequence from
    # its parts (word chunks, syllables, phonemes) by tapping them in order is
    # production the same way typing an answer is (main.js isProductionKind's
    # own comment gives the full reasoning, including why "match" — pick from
    # options — stays receptive despite being new in the same stage).
    "sentence_scramble", "chunk_sequence",     # order archetype
    "syllable_tap", "visual_phoneme", "rhythm",  # tap archetype
    # 5.5: shadowing/pronunciation gained the speak archetype — a real mic
    # capture, Whisper-transcribed and compared to the target, not the
    # self-assessment "listen" gave them before. This is the exact promotion
    # the module docstring above (and the old hand-listed mistake this set's
    # own derivation test guards against) said would happen "once each has a
    # capture-and-grade UI" — that UI now exists, so crediting them is no
    # longer the failure the negative control was built to catch.
    "shadowing", "pronunciation",  # speak archetype
    "hanzi-write",  # raw review-log id, not a card-types.js entry — see above
})

# FSRS grades, mirroring srs.js: AGAIN=1, HARD=2, GOOD=3, EASY=4. Only GOOD and
# EASY are a successful recall.
_SUCCESS_GRADE = 3


def card_track(card_type: str) -> str:
    return "productive" if card_type in PRODUCTIVE_CARD_TYPES else "receptive"


def parse_reviews(text: str) -> list[dict]:
    """One JSONL line per review, parsed leniently like the event log."""
    out = []
    for line in (text or "").split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(e, dict) and e.get("id") and e.get("ts"):
            out.append(e)
    return out


def read_reviews() -> list[dict]:
    """Every device's FSRS review log, concatenated (same fold as read_events)."""
    base = config.vault_path / REVIEW_DIR
    if not base.exists():
        return []
    out = []
    for f in sorted(base.glob("*.jsonl")):
        try:
            out.extend(parse_reviews(f.read_text(encoding="utf-8", errors="replace")))
        except OSError:
            continue
    return out


def summarize_reviews(reviews: list[dict]) -> dict[tuple[str, str], dict]:
    """Successful FSRS recalls per (term, bucket), split by track.

    Returns {(term, bucket): {"receptive_reviews": n, "productive_reviews": m}}.
    A review id is type:lang:term; the type decides the track, and only
    grade >= GOOD counts. Ids that are not that shape (hanzi:{char}:write and
    other Phase-1 forms) are skipped here — Stage 5 owns that mapping.
    """
    out: dict[tuple[str, str], dict] = defaultdict(
        lambda: {"receptive_reviews": 0, "productive_reviews": 0})
    for r in reviews:
        parts = str(r.get("id") or "").split(":")
        if len(parts) < 3:
            continue
        card_type, lang, key = parts[0], parts[1], ":".join(parts[2:])
        term = key.split("#")[0]  # sentence cards key term#sentenceId
        if not term:
            continue
        grade = r.get("grade")
        if not isinstance(grade, (int, float)) or grade < _SUCCESS_GRADE:
            continue
        bucket = bucket_key(lang)
        field = ("productive_reviews" if card_track(card_type) == "productive"
                 else "receptive_reviews")
        out[(term, bucket)][field] += 1
    return dict(out)
