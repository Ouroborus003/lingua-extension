"""Smart Management — run an operator-authored prompt over a scoped set of notes.

Every other AI feature here runs a fixed, version-controlled prompt over a fixed
input. This one takes an instruction the operator wrote ("add a tag for every
book listing the genres"), scopes it, and runs it across the vault.

The whole module is pure. Scope resolution, proposal parsing, queue rendering
and template validation are decisions, and a decision buried in a request
handler is one no test can reach — the repo has a P-VERIFY clause about exactly
that. `routers/smart.py` does the I/O and calls in here for anything that
decides something.

Two constraints shape the design, both measured rather than assumed:

  * **The local model returns confident wrong answers.** Extraction and
    classification are strong; localisation among plausible alternatives scored
    1/4, and three of those four failures came back clean with no hedging.
    Nothing in the output signals low confidence. So nothing here writes
    directly — a run proposes into a queue and the operator checks lines, the
    same shape as `generators/tag_review.py`.

  * **The write guard permits exactly one useful key.** `vault.SIDECAR_KEYS` is
    `{last_touched, exported_anki, status, tags, due}`, so "tag with the genres"
    lands as `tags: [genre/history]` and a `genres:` key is refused. Derived
    prose goes to `08 Meta/Generated/`, never into an authored note's body.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone

from . import constants

# ---------------------------------------------------------------- the queue

QUEUE_PATH = f"{constants.GENERATED}/Feeds/SmartManagement.md"
STATE_FILE = "smart_offers.json"

# One proposal per line, in the shape Obsidian renders as a checkbox so the
# review UI is the vault itself. Mirrors tag_review's _LINE, with a `kind` so
# one queue can carry tag / status / move proposals at once.
#
#   - [ ] tag · #genre/history — [[Ten Days That Shook the World]]
#   - [ ] move · 01 Notes/Reading — [[Some Note]] *(from 00 Inbox)*
_LINE = re.compile(
    r"^- \[(?P<done>x| )\] (?P<kind>tag|status|move|note) · (?P<value>.+?)"
    r" — \[\[(?P<target>[^\]|]+)\]\]\s*(?:\*\(.*\)\*\s*)?$"
)

# What a proposal may ask for. Deliberately closed: an unknown kind is dropped
# rather than guessed at, because the thing on the other end is a model that
# will cheerfully invent a verb.
KINDS = ("tag", "status", "move", "note")

# Mirrors vault.SIDECAR_KEYS — the only frontmatter keys a bulk writer may set.
# Duplicated as a literal on purpose: if vault.py ever widens its allowlist,
# this module should NOT silently widen with it. A bulk writer earning a new
# key is a decision, not an inheritance.
WRITABLE_KEYS = ("tags", "status")

# Status vocabulary is PER NOTE TYPE, and the templates are what define it.
#
# This was a flat five-value list — ("queued", "reading", "read", "abandoned",
# "reference") — written from the observation that all 57 library notes carry
# `status: queued`. That generalised from one folder to a vault that does not
# work that way. Measured across `08 Meta/Templates/`, each type ships its own
# meta-bind selector:
#
#   book     queued | reading | done | dropped
#   album    queued | active  | done | dropped
#   bug      open | investigating | fixed | wontfix
#   source   unread | skimmed | read | annotated
#   job      lead | applied | screen | interview | offer | rejected
#
# Two of the invented values (`abandoned`, `reference`) appear nowhere in the
# vault, and every real terminal value (`done`, `dropped`, `fixed`, `applied`)
# was rejected. So a proposal matching the dropdown the operator actually sees
# in Obsidian was refused, and one that passed would have written a value the
# widget cannot display.
#
# The templates are the single source of truth. `status_options()` reads them.
_STATUS_SELECT = re.compile(
    r"INPUT\[inlineSelect\((?P<opts>[^\]]*?)\)\s*:\s*status\]", re.I)
_OPTION = re.compile(r"option\(\s*([^)]+?)\s*\)")

# Used only when the note's type is unknown or has no template — the union of
# everything the templates permit. Deliberately permissive rather than a guess
# at which vocabulary applies: refusing a legitimate value is the failure this
# whole comment is about.
FALLBACK_STATUS: tuple[str, ...] = ()


def parse_status_options(text: str) -> tuple[str, ...]:
    """The status values one template's meta-bind selector offers.

    Empty when the template has no status widget, which is most of them — a
    template without a selector does not constrain status at all.
    """
    m = _STATUS_SELECT.search(text or "")
    if not m:
        return ()
    return tuple(o.strip().lower() for o in _OPTION.findall(m.group("opts")))


def status_options(templates: dict[str, str]) -> dict[str, tuple[str, ...]]:
    """Map note `type` -> permitted status values, from `{name: template_text}`.

    Keyed on the template's own `type:` frontmatter rather than its filename,
    because that is what a note carries and therefore what can be matched back.
    """
    out: dict[str, tuple[str, ...]] = {}
    for text in (templates or {}).values():
        opts = parse_status_options(text)
        if not opts:
            continue
        m = re.search(r"^type:\s*(.+?)\s*$", text or "", re.M)
        if not m:
            continue
        key = m.group(1).strip().strip("\"'").lower()
        if key:
            out[key] = opts
    return out


def allowed_status(note_type, vocab: dict | None) -> tuple[str, ...]:
    """What `note_type` may be set to. Empty tuple means 'unconstrained'."""
    if not vocab:
        return FALLBACK_STATUS
    key = str(note_type or "").strip().strip("\"'").lower()
    if key in vocab:
        return vocab[key]
    # Unknown type: accept anything any template permits rather than silently
    # dropping every proposal for a note class nobody has templated yet.
    return tuple(sorted({v for opts in vocab.values() for v in opts}))


# ---------------------------------------------------------------- scoping

def _fm(post, key, default=None):
    """Frontmatter read that tolerates the three shapes this vault uses."""
    if post is None:
        return default
    meta = getattr(post, "metadata", None) or {}
    v = meta.get(key, default)
    return v


def _as_list(v):
    """`tags: a` and `tags: [a, b]` both occur. Normalise to a list."""
    if v is None:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    s = str(v).strip()
    return [s] if s else []


def author_names(post) -> list[str]:
    """Every name credited on a note, from whichever field carries it.

    Measured across the 57 library notes: `author`, `authors` and `creator` all
    occur on 46 of them and **33 disagree**. Most differences are formatting
    (`"Mao Zedong"` vs `["Mao Zedong"]`), but not all —

        author:  Eckehard Schulz, Wolfgang Reuschel et al.
        authors: (empty)
        creator: Eckehard Schulz

    so reading `creator` alone silently drops co-authors, and reading `authors`
    alone drops the 11 notes carrying no author field. The union of all three,
    split on the separators actually in use, is the only reading that does not
    lose books.
    """
    raw: list[str] = []
    for key in ("author", "authors", "creator"):
        raw.extend(_as_list(_fm(post, key)))
    out: list[str] = []
    for chunk in raw:
        for name in re.split(r",| & | and |;", chunk):
            name = name.strip().strip('"').strip()
            name = re.sub(r"\bet al\.?$", "", name, flags=re.I).strip()
            if name and name.lower() not in {n.lower() for n in out}:
                out.append(name)
    return out


def author_key(name: str) -> str:
    """Match authors the way the shelf does: case- and punctuation-insensitive.

    Not the plugin's `authorFolderKey` — that one is order-insensitive across a
    *set* of authors for folder merging. This is per-name, for "does this book
    credit this person".
    """
    return re.sub(r"[^a-z0-9]+", "", str(name or "").lower())


def in_scope(rel: str, post, scope: dict) -> bool:
    """Does this note belong to the run?

    `scope` is `{"mode": ..., ...}`. Unknown modes match nothing rather than
    everything — a typo that silently selected the whole vault would be the
    expensive failure here.
    """
    mode = (scope or {}).get("mode")

    if mode == "all":
        return True

    if mode == "folder":
        folder = (scope.get("folder") or "").strip().rstrip("/")
        return bool(folder) and rel.startswith(folder + "/")

    if mode == "author":
        want = author_key(scope.get("author"))
        if not want:
            return False
        return any(author_key(n) == want for n in author_names(post))

    if mode == "status":
        want = str(scope.get("status") or "").strip().lower()
        return bool(want) and str(_fm(post, "status", "")).strip().lower() == want

    if mode == "tag":
        want = str(scope.get("tag") or "").strip().lstrip("#").lower()
        if not want:
            return False
        have = {t.strip().lstrip("#").lower() for t in _as_list(_fm(post, "tags"))}
        # A parent tag selects its children: `genre` matches `genre/history`.
        return any(t == want or t.startswith(want + "/") for t in have)

    if mode == "untagged":
        return not _as_list(_fm(post, "tags"))

    if mode == "imports":
        # Measured: `created` is on all 57 library notes and is a real import
        # date (46 on 2026-08-05, 10 on 2026-08-07, 1 on 2026-08-09), so this
        # needs no new field. `since` is an ISO date string; a note with no
        # `created` is NOT an import, because "unknown" must not mean "yes" on
        # a mode whose whole job is to narrow.
        since = str(scope.get("since") or "").strip()
        created = str(_fm(post, "created", "")).strip()
        if not since or not created:
            return False
        return created[:10] >= since[:10]

    return False


def resolve_scope(candidates, scope: dict, limit: int | None = None) -> list[str]:
    """The run's target list, in a stable order.

    `candidates` is an iterable of `(rel, post)` — whatever the caller walked.
    Sorted so two runs over an unchanged vault propose in the same order, which
    is what makes the queue diffable.
    """
    hits = [rel for rel, post in candidates if in_scope(rel, post, scope)]
    hits.sort()
    if limit is not None and limit >= 0:
        hits = hits[:limit]
    return hits


# ------------------------------------------------------------- templates

def validate_template(tpl: dict) -> tuple[bool, str]:
    """Is this template runnable? Returns (ok, reason).

    Checked before a run rather than at the first failing item, because the
    failure mode otherwise is 40 books in with a half-written queue.
    """
    if not isinstance(tpl, dict):
        return False, "template is not an object"

    name = str(tpl.get("name") or "").strip()
    if not name:
        return False, "template needs a name"
    if not re.fullmatch(r"[\w -]{1,60}", name):
        return False, f"template name {name!r} may only contain letters, digits, spaces, - and _"

    instruction = str(tpl.get("instruction") or "").strip()
    if len(instruction) < 12:
        return False, "instruction is too short to be an instruction"

    kind = tpl.get("kind")
    if kind not in KINDS:
        return False, f"kind must be one of {', '.join(KINDS)}"

    scope = tpl.get("scope")
    if not isinstance(scope, dict) or not scope.get("mode"):
        return False, "template needs a scope with a mode"
    # Prove the scope can match something: an unknown mode matches nothing, and
    # a run that silently proposes zero items looks identical to a model that
    # returned nothing.
    if scope.get("mode") not in {"all", "folder", "author", "status", "tag", "untagged", "imports"}:
        return False, f"unknown scope mode {scope.get('mode')!r}"

    return True, ""


# -------------------------------------------------------------- proposals

def parse_proposals(raw: str, kind: str, target: str,
                    statuses: tuple | None = None) -> list[dict]:
    """One model reply → zero or more proposals. Never raises.

    A model that returns prose, half a JSON object, or an unrequested field is
    the normal case, not the exceptional one. Everything unparseable is dropped
    and the item simply proposes nothing — one bad reply must not end the run.

    `statuses` is the vocabulary permitted for THIS note's type, from
    `allowed_status()`. An empty tuple or None means unconstrained — which is
    the honest answer for a note class whose template has no status widget, and
    is safer than the flat global list this used to enforce.
    """
    if kind not in KINDS:
        return []
    try:
        data = json.loads(raw)
    except (TypeError, ValueError):
        return []
    if not isinstance(data, dict):
        return []

    items = data.get("proposals")
    if not isinstance(items, list):
        return []

    out: list[dict] = []
    seen: set[str] = set()
    for it in items:
        if not isinstance(it, dict):
            continue
        payload = str(it.get("value") or "").strip()
        if not payload:
            continue

        if kind == "tag":
            payload = payload.lstrip("#").strip().replace(" ", "-").lower()
            # A tag with a slash is a hierarchy; anything else non-word is noise.
            if not re.fullmatch(r"[\w][\w/-]*", payload):
                continue
        elif kind == "status":
            payload = payload.strip().lower()
            if statuses and payload not in statuses:
                continue
        elif kind == "move":
            # Validate BEFORE normalising. Stripping slashes first turned
            # "/tmp" into "tmp" and let an absolute path through — the check
            # has to see what the model actually said.
            payload = payload.strip()
            if not payload or payload.startswith("/") or ".." in payload.split("/"):
                continue
            payload = payload.strip("/")
            if not payload:
                continue

        if payload in seen:
            continue
        seen.add(payload)

        note = str(it.get("note") or "").strip()
        out.append({"kind": kind, "target": target, "value": payload,
                    "note": note[:120]})
    return out


PROPOSAL_SCHEMA = {
    # Flat on purpose. The measured guidance says this model handles nesting to
    # four levels, but a flat shape is also the one a human can eyeball in the
    # queue when it goes wrong.
    "type": "object",
    "properties": {
        "proposals": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "value": {"type": "string"},
                    "note": {"type": "string"},
                },
                "required": ["value"],
            },
        },
    },
    "required": ["proposals"],
}


# ------------------------------------------------------------ queue render

def note_name(rel: str) -> str:
    """The wikilink target for a path — basename without extension."""
    return rel.rsplit("/", 1)[-1].removesuffix(".md")


def render_line(p: dict) -> str:
    """One proposal as a checkbox line.

    Every kind renders in the SAME shape — `kind · value — [[target]]` — so one
    regex reads them all back. An earlier version gave `move` its own
    `[[target]] → dest` layout because it read better, and the parser silently
    skipped every move line: the round trip returned 1 of 3 proposals with no
    error anywhere. Readability that costs parseability is not readability.

    A move's source folder rides in the note instead, so the operator still
    sees both ends of the journey.
    """
    kind = p["kind"]
    value = f"#{p['value']}" if kind == "tag" else p["value"]
    box = "x" if p.get("checked") else " "

    why = p.get("note") or ""
    if kind == "move":
        src = str(p.get("target", "")).rsplit("/", 1)[0]
        why = f"from {src}" + (f" · {why}" if why else "")
    suffix = f" *({why})*" if why else ""

    return f"- [{box}] {kind} · {value} — [[{note_name(p['target'])}]]{suffix}"


def render_queue(proposals: list[dict], meta: dict) -> str:
    """The whole queue note.

    Carries its own provenance — template, model and timestamp — because a bulk
    write is unrevertable without knowing which run produced it, and "which run
    was that" is not answerable from the notes afterwards.
    """
    tpl = meta.get("template") or "(unnamed)"
    model = meta.get("model") or "(unknown model)"
    scanned = meta.get("scanned", 0)
    stamp = meta.get("stamp") or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M")

    lines = [
        f"Run **{tpl}** · model `{model}` · {stamp}",
        "",
        f"Scanned {scanned} item(s), proposing {len(proposals)}.",
        "",
        "Check a line to apply it. Delete a line to reject it — a rejected"
        " proposal is never offered again.",
        "",
    ]
    if not proposals:
        lines.append("*Nothing proposed. Either the scope matched nothing, the"
                     " model had nothing to say, or LM Studio is offline.*")
    else:
        for p in proposals:
            lines.append(render_line(p))
    return "\n".join(lines)


def parse_queue(text: str) -> list[dict]:
    """Read the operator's verdicts back out of the queue note."""
    out = []
    for line in (text or "").splitlines():
        m = _LINE.match(line.strip())
        if not m:
            continue
        out.append({
            "checked": m.group("done") == "x",
            "kind": m.group("kind"),
            "target": m.group("target").strip(),
            "value": m.group("value").strip().lstrip("#"),
        })
    return out


def offer_id(p: dict) -> str:
    """Stable identity for a proposal, for the rejected-forever ledger."""
    return f"{p.get('kind')}|{note_name(str(p.get('target', '')))}|{p.get('value')}"


def newly_rejected(previous: list[str], current: list[dict]) -> list[str]:
    """Offers that were on the last queue and are gone from this one.

    The operator deleting a line is the reject gesture — same as tag_review.
    Anything still present, checked or not, is undecided rather than rejected.
    """
    now = {offer_id(p) for p in current}
    return [oid for oid in previous if oid not in now]
