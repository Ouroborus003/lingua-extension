"""On-demand backend supervisor — process lifetime follows the workspace.

The Lingua and Jobs workspaces need their engines (the LinguaStudio sidecar
and `jobsfair serve`) only while they're open, and the operator shouldn't
have to start either one. So the always-on vault sidecar owns the lifecycle:

  - a workspace plugin POSTs /services/<name>/start when it opens and
    /services/<name>/keepalive every minute while any of its views exist;
  - reap_idle() (a scheduler tick) stops any service that hasn't heard a
    keepalive within the idle window — closing the workspace is enough;
  - scheduled headless tasks use ensure_for_task()/release_after_task() so
    a nightly job can borrow an engine and put it away, without ever
    stopping one a workspace is actively using.

Obsidian stays display-only (spec §5): the plugins *ask* for a service,
they never own a process. Idle state costs nothing beyond this sidecar.

Commands and repo paths are config (never hardcode a personal parameter);
processes get their own session so stop() can kill the whole tree (uv/npm
wrappers included), and stdout/stderr land in .state/<name>.log.
"""
from __future__ import annotations

import logging
import os
import shlex
import signal
import subprocess
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

from . import settings
from .config import STATE_DIR

log = logging.getLogger("sidecar.services")

GRACE_SECONDS = 5           # SIGTERM -> SIGKILL escalation

# Where a checkout is habitually found. The configured path always wins when it
# exists; this is only consulted when it does not.
#
# The shipped defaults name "~/dev/<repo>", which is a guess about someone
# else's filesystem — and on the machine this vault runs on both repos are
# under ~/Documents/GitHub, so *every* supervised service failed to start with
# a FileNotFoundError pointing at a path the operator had never chosen. A
# wrong guess should degrade into looking around, not into an error about a
# directory nobody created.
REPO_SEARCH_BASES = ("~/dev", "~/Documents/GitHub", "~/src", "~/code",
                     "~/projects", "~/repos", "~")


def resolve_repo(configured: str) -> Path:
    """The directory a service should run in. Falls back to the same leaf name
    under the usual checkout roots when the configured path is absent, so a
    stale default self-heals instead of blocking the service."""
    p = Path(configured or "").expanduser()
    if p.is_dir():
        return p
    leaf = p.name
    if leaf:
        for base in REPO_SEARCH_BASES:
            cand = Path(base).expanduser() / leaf
            if cand.is_dir():
                return cand
    return p    # nothing found: report the miss against what was configured


def defs() -> dict[str, dict]:
    """Service definitions from the live config. Names are the contract the
    plugins and the router share."""
    cfg = settings.effective().services
    return {
        "lingua": {
            "command": cfg.lingua_command,
            "cwd": cfg.lingua_repo,
            "health": cfg.lingua_health,
        },
        "jobsfair": {
            "command": cfg.jobsfair_command,
            "cwd": cfg.jobsfair_repo,
            "health": settings.effective().jobsfair.dashboard_url,
        },
    }


@dataclass
class Proc:
    popen: subprocess.Popen
    started_at: float
    last_alive: float
    started_by: str = "workspace"   # workspace | task
    log_path: str = ""


_running: dict[str, Proc] = {}


def _now() -> float:
    return time.monotonic()


def _def(name: str) -> dict:
    d = defs().get(name)
    if d is None:
        raise KeyError(f"unknown service {name!r} (know: {sorted(defs())})")
    return d


def _alive(proc: Proc | None) -> bool:
    return proc is not None and proc.popen.poll() is None


def healthy(name: str, timeout: float = 1.5) -> bool:
    """One quick GET against the service's health URL."""
    url = _def(name)["health"]
    try:
        with urllib.request.urlopen(url, timeout=timeout) as res:
            return 200 <= res.status < 500
    except Exception:
        return False


def start(name: str, by: str = "workspace") -> dict:
    """Spawn the service if it isn't running; idempotent. Never blocks on
    health — the caller polls status() while its UI shows 'starting'."""
    d = _def(name)
    proc = _running.get(name)
    if _alive(proc):
        proc.last_alive = _now()
        if by == "workspace":
            proc.started_by = "workspace"   # a workspace claim outranks a task's
        return status(name)

    cwd = resolve_repo(d["cwd"])
    if not cwd.is_dir():
        raise FileNotFoundError(
            f"{name}: repo path {cwd} doesn't exist — set it in Settings "
            "(Vault Sidecar → Services)")
    log_path = STATE_DIR / f"service-{name}.log"
    out = open(log_path, "ab")
    popen = subprocess.Popen(
        shlex.split(d["command"]), cwd=str(cwd),
        stdout=out, stderr=subprocess.STDOUT,
        start_new_session=True)   # own group: stop() reaps wrappers too
    _running[name] = Proc(popen=popen, started_at=_now(), last_alive=_now(),
                          started_by=by, log_path=str(log_path))
    log.info("service %s started (pid %s) by %s", name, popen.pid, by)
    return status(name)


def keepalive(name: str) -> dict:
    proc = _running.get(name)
    if _alive(proc):
        proc.last_alive = _now()
        proc.started_by = "workspace"
    return status(name)


def stop(name: str) -> dict:
    proc = _running.pop(name, None)
    if not _alive(proc):
        return status(name)
    try:
        pgid = os.getpgid(proc.popen.pid)
        os.killpg(pgid, signal.SIGTERM)
        try:
            proc.popen.wait(timeout=GRACE_SECONDS)
        except subprocess.TimeoutExpired:
            os.killpg(pgid, signal.SIGKILL)
            proc.popen.wait(timeout=GRACE_SECONDS)
    except ProcessLookupError:
        pass
    log.info("service %s stopped", name)
    return status(name)


def status(name: str) -> dict:
    _def(name)  # raise on unknown
    proc = _running.get(name)
    running = _alive(proc)
    return {
        "name": name,
        "running": running,
        "pid": proc.popen.pid if running else None,
        "idle_seconds": round(_now() - proc.last_alive) if running else None,
        "started_by": proc.started_by if running else None,
        "log": proc.log_path if running else None,
    }


def reap_idle() -> list[str]:
    """Stop services whose keepalives went quiet (scheduler tick). A closed
    workspace simply stops heartbeating; nothing else has to happen."""
    idle_after = settings.effective().services.idle_minutes * 60
    stopped = []
    for name, proc in list(_running.items()):
        if not _alive(proc):
            _running.pop(name, None)
            continue
        if _now() - proc.last_alive > idle_after:
            stop(name)
            stopped.append(name)
    return stopped


def stop_all() -> None:
    for name in list(_running):
        stop(name)


# ---- scheduled-task borrowing ----------------------------------------------

def ensure_for_task(name: str, wait_seconds: float = 20.0) -> bool:
    """Start (or reuse) a service for a headless task; wait until healthy.
    Returns True if this call started it (the caller passes that to
    release_after_task so a workspace's running engine is never stopped)."""
    started_here = not _alive(_running.get(name))
    start(name, by="task")
    deadline = _now() + wait_seconds
    while _now() < deadline:
        if healthy(name):
            return started_here
        time.sleep(0.5)
    if started_here:   # never came up — don't leave a zombie behind
        stop(name)
    raise TimeoutError(f"{name} didn't become healthy in {wait_seconds:.0f}s")


def release_after_task(name: str, started_here: bool) -> None:
    """Put a borrowed engine away — unless a workspace claimed it meanwhile
    (start/keepalive from a workspace flips started_by, so the claim is the
    whole test)."""
    proc = _running.get(name)
    if not started_here or not _alive(proc):
        return
    if proc.started_by == "workspace":
        return
    stop(name)
