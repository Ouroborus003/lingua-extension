"""Configuration. YAML over dataclasses, defaults for everything.

Reads sidecar/config.yaml if present, else falls back entirely to defaults
(matching config.example.yaml). Never crashes on a missing file — the vault
must work with zero setup beyond `pip install`.
"""
from __future__ import annotations

import dataclasses
from pathlib import Path

import yaml

SIDECAR_DIR = Path(__file__).resolve().parent.parent
STATE_DIR = SIDECAR_DIR / ".state"


@dataclasses.dataclass
class ServerCfg:
    host: str = "127.0.0.1"
    port: int = 8749


@dataclasses.dataclass
class LMStudioCfg:
    base_url: str = "http://127.0.0.1:1234/v1"
    model: str = ""
    timeout_seconds: int = 300
    temperature: float = 0.7
    ttl_seconds: int = 1800  # LM Studio unloads an idle JIT-loaded model; 0 = keep resident
    # Bringing LM Studio's *server* up when an AI request finds it down. This
    # is not a model load and does not weaken the laziness rule (§11): the
    # server serves /api/v0/models with nothing resident, and the model still
    # only arrives on the completion call itself. See llm.ensure_server().
    autostart: bool = True
    # Empty = `lms server start`. Worth overriding with a direct launch of the
    # app when `lms` cannot bootstrap itself; on the AppImage install that is
    # the normal state after a reboot, see llm.ensure_server()'s comment.
    autostart_command: str = ""
    autostart_timeout_seconds: int = 90
    # How long to keep asking when LM Studio answers "no models loaded".
    #
    # This used to be a hardcoded (1, 2, 4, 8) ladder — 15 seconds — on the
    # premise that the server was mid-load and "succeeds unchanged on the next
    # try". That premise requires just-in-time loading to be ON. It is
    # deliberately OFF on this machine, which makes "no models loaded"
    # PERMANENT: nothing is loading, so every one of those 15 seconds is spent
    # waiting for an event that cannot happen. The old comment was true of a
    # build we do not run.
    #
    # Kept non-zero because the genuine case is real — a model actually loading
    # does answer on a retry — but bounded, because with JIT off the honest
    # answer is a fast, actionable error telling the operator to `lms load`.
    loader_wait_seconds: float = 3.0
    # Standby: drop the model after this many minutes unused, which is what
    # actually hands the VRAM back. 0 leaves it resident. Distinct from
    # ttl_seconds, which asks LM Studio to do the same thing on its own
    # schedule — this one the operator can see and set in minutes.
    standby_minutes: int = 10


@dataclasses.dataclass
class LastfmCfg:
    api_key: str = ""
    username: str = ""


@dataclasses.dataclass
class BooxCfg:
    watch_dir: str = ""
    format: str = "markdown"
    domain: str = "personal"
    exclude_unopened: bool = False


@dataclasses.dataclass
class JobsFairCfg:
    db_path: str = ""  # empty = $JOBSFAIR_HOME/jobsfair.db, else ~/.jobsfair/
    dashboard_url: str = "http://127.0.0.1:8787"
    queue_limit: int = 8


@dataclasses.dataclass
class ServicesCfg:
    """On-demand engines the sidecar supervises (app/services.py)."""
    idle_minutes: int = 5
    lingua_repo: str = "~/dev/lingua-studio"
    lingua_command: str = ("python -m uvicorn sidecar.server:app "
                           "--host 127.0.0.1 --port 8000")
    lingua_health: str = "http://127.0.0.1:8000/health"
    jobsfair_repo: str = "~/dev/JobsFair"
    jobsfair_command: str = "uv run jobsfair serve --port 8787"
    jobsfair_cli: str = "uv run jobsfair"   # headless pulls/score/prune


@dataclasses.dataclass
class TranslateCfg:
    """The local-first translation hub (app/translate.py). Orders are tried
    front to back; the first provider that answers wins. Passages default to a
    dedicated MT engine rather than the local LLM — measurably faster and
    lighter for bulk translation (see app/translate.py's module docstring) —
    with the LLM kept as the fallback for when nothing else answers.

    **"Local-first" was aspirational until 2026-08-25, and the gap was
    load-bearing.** The passage order was ["deeplx", "google", "deepl",
    "local_ai"]: a reverse-engineered proxy, a scraped web endpoint, a keyless
    API nobody had a key for, and the LLM. Not one of the first three is under
    our control, and all four failed the same afternoon — deeplx's container was
    not running, Google soft-banned this IP, deepl had no key, and LM Studio had
    no model loaded. Every dual-language surface in the vault went silently
    empty, because `stardict` (the one healthy provider) declines passages by
    design and is not in this order at all.

    `libretranslate` is therefore FIRST: a real MT model running on this
    machine, satisfying MT-first and local-first at the same time, which no
    previous head of this list did.

    **The model is the LAST resort for a word, not the second.** The word order
    used to read ["stardict", "local_ai", ...], which looks local-first and was
    not: `stardict` is empty until the operator configures a dictionary, and
    `deepl` is unavailable without a key, so in practice *every* hover fell
    through to the LLM. That is the slowest provider in the list and the one
    that returns the least — a bare gloss, where a dictionary returns part of
    speech, numbered senses and examples. A real dictionary answers in
    microseconds off a memory-mapped index.

    So the order now puts every deterministic source ahead of the model:
    dictionary, then DeepLX/DeepL (real MT), then Google, and `local_ai` last
    for the cases nothing else can serve."""
    provider_order: list = dataclasses.field(
        default_factory=lambda: ["libretranslate", "deeplx", "google", "deepl", "local_ai"])
    word_order: list = dataclasses.field(
        default_factory=lambda: ["stardict", "libretranslate", "deeplx", "deepl",
                                 "google", "local_ai"])
    # Hard per-provider deadline for a single-word lookup, and a ceiling for
    # the whole cascade. A word lookup is an interactive gesture — someone is
    # watching a "..." placeholder — so it must fail fast rather than answer
    # perfectly. Measured 2026-08-09: a Hungarian word took **90 seconds and
    # then returned nothing**, because stardict has no Hungarian dictionary,
    # deeplx/deepl are unconfigured, and the cascade reached local_ai, whose
    # available() is unconditionally True and which tried to AUTOSTART LM
    # Studio (lm_studio.autostart_timeout_seconds = 90) on the hover path.
    # Chinese never showed it because stardict answers first, in 3ms.
    word_provider_timeout_seconds: float = 4.0
    word_total_timeout_seconds: float = 10.0
    # The SAME guard for the passage cascade, which never got one. The 2026-08-09
    # fix above was applied to translate_word() and not to translate_texts(),
    # so the deadline lesson held for hovers and not for the dual reader or
    # captions. Measured 2026-08-25: POST /translate took **15.7 s** and then
    # returned {"provider":"","translations":[null]} — deeplx refused (~0.5 s),
    # google answered 429 (~0.5 s), and local_ai spent ~15 s in an LM Studio
    # loader backoff. A passage is legitimately slower than a word (many blocks,
    # possibly an LLM), so the budget is larger — but it is a CAP, not the fix.
    passage_provider_timeout_seconds: float = 8.0
    passage_total_timeout_seconds: float = 20.0
    # ...and the two above are a FLOOR, not the whole budget, because a flat
    # deadline silently assumed every passage is small. Measured 2026-08-25
    # against LibreTranslate on this machine: ~0.12s per segment, linear, so a
    # 400-line page read (surf-lingua's MAX_PAGE_LINES) takes ~46s and a flat
    # 8s cap killed it mid-flight and returned 400 nulls — the provider was
    # working perfectly and the deadline made it look broken.
    #
    # The cap exists to stop ONE UNREACHABLE provider owning the request, and a
    # per-block allowance still does that: an unreachable provider fails on its
    # first chunk regardless of how many blocks were asked for. What it stops
    # doing is punishing a provider for being handed a lot of legitimate work.
    #
    # 1.5 s/block. This was 0.35, described as "~3x the measured NMT cost" —
    # and the measurement it rested on (~0.12s per segment) does not hold on
    # this host. Re-measured 2026-08-29 straight against LibreTranslate, three
    # batch sizes:
    #
    #     1 segment    1.02s   (1.015s per segment)
    #     20 segments 15.08s   (0.754s per segment)
    #     50 segments 38.57s   (0.771s per segment)
    #
    # So the real cost is ~0.77s per segment, and 0.35 was under HALF of it.
    # surf-lingua sends chunks of 20, which got max(8.0, 20*0.35) = 8s for work
    # that takes 15s — so every chunk of every real page was cancelled
    # mid-flight, the provider was blamed for it ("libretranslate timed out on
    # passages after 8.0s"), and a 247-paragraph article translated nothing
    # while the same instance answered a two-line request in 0.7s.
    #
    # 1.5 is ~2x the measured cost, which is the headroom the old comment
    # claimed to have. Note this is a per-block ALLOWANCE, not a wait: a
    # provider that is actually unreachable still fails on its first chunk, so
    # raising it cannot make a dead provider slower to detect.
    passage_seconds_per_block: float = 1.5
    # An absolute ceiling so no amount of blocks can turn into an unbounded
    # wait. Nothing may hang forever just because the request was large.
    passage_max_timeout_seconds: float = 240.0
    # Offline dictionaries: [{lang: "ja", path: "~/dicts/ja-en.ifo", name?}].
    stardict: list = dataclasses.field(default_factory=list)
    google_enabled: bool = True   # free translate.googleapis.com endpoint (no key)
    # Where the Google provider actually posts. Configurable because the
    # hardcoded host is the single point of failure that took every passage
    # surface down on 2026-08-25: Google soft-banned this IP and answered
    # `302 -> www.google.com/sorry/` (429 to curl) for every request. An
    # alternative front-end (Lingva, Mozhi, SimplyTranslate) speaks the same
    # translate_a/single shape and can be pointed at here with no code change.
    #
    # It must be hosted ELSEWHERE to help. Those front-ends are scrapers: an
    # instance on this machine fetches Google from this same banned address and
    # inherits the ban. That is why the durable answer is libretranslate below
    # — a real local model — and this key is only an escape hatch.
    google_endpoint: str = "https://translate.googleapis.com/translate_a/single"
    deepl_api_key: str = ""
    deepl_free: bool = True   # api-free.deepl.com (free tier) vs api.deepl.com
    # DeepLX (github.com/OwO-Network/DeepLX) — DeepL quality with no API key,
    # via a proxy the operator runs. Empty = off; nothing is sent anywhere.
    # Typically "http://127.0.0.1:1188".
    deeplx_url: str = ""
    deeplx_token: str = ""    # only if the proxy was started with a token
    # LibreTranslate (github.com/LibreTranslate/LibreTranslate) — the only
    # passage provider in this list that is both a dedicated MT engine and
    # genuinely local. Every other one is either a scraper of somebody's web
    # endpoint (google, deeplx) or the LLM, and on 2026-08-25 all of them were
    # down at once while `/translate/status` still said ready:true.
    #
    # It earns first place in provider_order on the module docstring's own
    # rule — "passages default to a dedicated MT engine first, not the LLM" —
    # while also being offline, which no previous first-choice provider was.
    # Empty = off; nothing is sent anywhere until the operator sets it.
    # Typically "http://127.0.0.1:5000".
    libretranslate_url: str = ""
    libretranslate_api_key: str = ""   # only if the instance was started with one
    # Segments per request. LibreTranslate takes an ARRAY for `q`, so a whole
    # caption track is one round trip — but a 400-line page read (surf-lingua's
    # MAX_PAGE_LINES) in a single request would blow
    # passage_provider_timeout_seconds and be killed mid-flight, which reads as
    # "the provider is broken" rather than "the batch was too big". Chunking
    # keeps each request comfortably inside that bound.
    libretranslate_batch_size: int = 50


@dataclasses.dataclass
class OcrCfg:
    """Tesseract, shelled out for scans with no text layer (app/ocr.py,
    library-workspace's offline import). Requests always carry exactly one
    language — passing every installed pack at once is both slower and
    less accurate than the right single one."""
    default_lang: str = "eng"      # used when a request doesn't name one
    timeout_seconds: int = 20      # per-page tesseract subprocess budget
    max_pages: int = 3             # front-matter pages OCR'd per import
    # Empty = the system tessdata (whatever `tesseract --list-langs` finds
    # unaided). Point this at a directory of the float-LSTM `tessdata_best`
    # packs to use those instead — see app/ocr.py's env helper for why this
    # single value has to reach both the subprocess that runs OCR and the one
    # that validates a requested language, or the two can disagree about what
    # is actually installed. A path that doesn't exist degrades to system
    # tessdata rather than failing a request; app/ocr.py's status helper
    # reports that fallback for /ocr/status.
    tessdata_prefix: str = ""
    # The LM Studio model id for the opt-in `engine: "vlm"` escape hatch
    # (app/routers/ocr.py) — empty disables that path entirely (400/503 with
    # a "not configured" message) rather than guessing a model, the same
    # refusal LMStudioCfg.model makes in llm._resolve_model. LM Studio's
    # just-in-time loading is off for this operator on purpose, so naming a
    # model here does not load it — the operator loads it themselves with
    # `lms load <model>` before dropping a book in vlm/.
    vlm_model: str = ""


@dataclasses.dataclass
class AudioCfg:
    """Word pronunciation for the dual reader (app/forvo.py, /audio router)
    and lingua-workspace's TTS tab / vocab audio (app/tts_engine.py,
    app/audio_provider.py, /tts + /vocab routers). Forvo serves human
    recordings; the operator chooses whether a word plays the single
    most-voted clip or offers a small menu of speakers. audio_source decides
    whether /vocab/audio tries Forvo before falling back to TTS, or skips
    straight to TTS — ported from LinguaStudio, which used this exact name."""
    forvo_enabled: bool = True
    forvo_mode: str = "popular"   # "popular" (top clip auto-plays) | "menu" (pick a speaker)
    forvo_limit: int = 6          # alternates listed in menu mode
    # Ordered pronunciation sources, tried until one has a recording
    # (app/pronounce.py). Forvo first: more words, and community vote ordering.
    # Lingua Libre (Wikimedia Commons) second: fewer words, but no key and no
    # bot wall, so it still answers when Forvo's CloudFlare challenge does not.
    # An unknown name here is ignored rather than fatal.
    pronunciation_sources: str = "forvo,lingualibre"
    # Forvo's official API (apifree.forvo.com) needs a key — their Non-Profit
    # plan is $2/mo for 500 requests/day and is explicitly for individual use
    # with Anki/GoldenDict. NOTHING READS THIS YET. It exists so that adding
    # the API later is a new entry in pronounce._SOURCES rather than a refactor.
    forvo_api_key: str = ""
    audio_source: str = "human_first"  # "human_first" (Forvo, TTS fallback) | "tts_only"
    tts_backend: str = "edge-tts"      # edge-tts | piper | gtts | qwen3-tts (see tts_engine.py)
    tts_voice: str = ""                # empty = first curated edge-tts voice for the word's language
    tts_rate: str = "-10%"             # edge-tts rate string, e.g. "+0%", "-10%" (tts_engine.SPEEDS)


@dataclasses.dataclass
class WhisperCfg:
    """Local speech-to-text (app/whisper_engine.py, /whisper router) —
    lingua-workspace's Tools tab, transcribing a listening-material clip
    into study text. model_size is one of whisper_engine.MODEL_SIZES;
    kept as a plain string (not imported from whisper_engine) the same way
    AudioCfg.tts_backend is a plain string rather than importing
    tts_engine's BACKENDS — config.py stays free of engine-module imports."""
    model_size: str = "small"     # tiny | base | small | medium (see whisper_engine.py)
    default_language: str = ""    # "" = auto-detect per request


@dataclasses.dataclass
class SchedulerCfg:
    enabled: bool = True
    dashboard_minutes: int = 15
    responsibilities_minutes: int = 15
    states_minutes: int = 60
    lastfm_minutes: int = 30
    boox_minutes: int = 10
    rss_minutes: int = 60
    jobsfair_minutes: int = 30
    jobsfair_pull_hours: int = 6   # headless board pulls; 0 = manual only
    lingua_audio_prefetch: bool = True  # nightly Forvo/TTS cache warm-up
    daily_jobs_hour: int = 5
    # Off by default so inference stays user-initiated. These are the only
    # scheduled jobs that call the LLM, and because _last_daily starts empty
    # every launch past daily_jobs_hour fired them immediately — opening the
    # vault pulled a model into memory before the user had asked for anything.
    # The same work is still available on demand from the /ai/* endpoints.
    ai_jobs: bool = False


@dataclasses.dataclass
class SmartCfg:
    """Smart Management — the propose/review/apply loop in vault-sidecar.

    These were hardcoded in routers/smart.py, which meant the only way to
    change how much of a note the model sees, or how wide a scope may be, was
    to edit Python. They are operator-facing knobs, so they live here and are
    overridable from `08 Meta/Settings.md` like everything else.

    `min_instruction_chars` is MIRRORED in the plugin (SmartManagementView's
    doRun guard). Change one without the other and the UI accepts an
    instruction the server then rejects."""
    max_chars: int = 6000        # note text sent per item; the rest is truncated
    temperature: float = 0.2     # low: this is extraction, not prose
    scope_cap: int = 400         # max paths one scope resolve may return
    min_instruction_chars: int = 12
    seconds_per_item: int = 8    # estimate shown before a run


@dataclasses.dataclass
class Config:
    vault_path: Path = SIDECAR_DIR.parent
    server: ServerCfg = dataclasses.field(default_factory=ServerCfg)
    lm_studio: LMStudioCfg = dataclasses.field(default_factory=LMStudioCfg)
    lastfm: LastfmCfg = dataclasses.field(default_factory=LastfmCfg)
    boox: BooxCfg = dataclasses.field(default_factory=BooxCfg)
    jobsfair: JobsFairCfg = dataclasses.field(default_factory=JobsFairCfg)
    services: ServicesCfg = dataclasses.field(default_factory=ServicesCfg)
    translate: TranslateCfg = dataclasses.field(default_factory=TranslateCfg)
    ocr: OcrCfg = dataclasses.field(default_factory=OcrCfg)
    audio: AudioCfg = dataclasses.field(default_factory=AudioCfg)
    whisper: WhisperCfg = dataclasses.field(default_factory=WhisperCfg)
    scheduler: SchedulerCfg = dataclasses.field(default_factory=SchedulerCfg)
    smart: SmartCfg = dataclasses.field(default_factory=SmartCfg)
    responsibilities_horizon_days: int = 14
    agenda_horizon_days: int = 7
    tag_review_max: int = 15


def _build(cls, data):
    if not dataclasses.is_dataclass(cls) or not isinstance(data, dict):
        return data
    kwargs = {}
    for f in dataclasses.fields(cls):
        if f.name in data and data[f.name] is not None:
            default = f.default_factory() if f.default_factory is not dataclasses.MISSING else f.default
            if dataclasses.is_dataclass(default):
                kwargs[f.name] = _build(type(default), data[f.name])
            else:
                kwargs[f.name] = data[f.name]
    return cls(**kwargs)


def load_config() -> Config:
    path = SIDECAR_DIR / "config.yaml"
    raw = {}
    if path.exists():
        raw = yaml.safe_load(path.read_text()) or {}

    cfg = Config(
        server=_build(ServerCfg, raw.get("server", {})),
        lm_studio=_build(LMStudioCfg, raw.get("lm_studio", {})),
        lastfm=_build(LastfmCfg, raw.get("lastfm", {})),
        boox=_build(BooxCfg, raw.get("boox", {})),
        jobsfair=_build(JobsFairCfg, raw.get("jobsfair", {})),
        services=_build(ServicesCfg, raw.get("services", {})),
        translate=_build(TranslateCfg, raw.get("translate", {})),
        ocr=_build(OcrCfg, raw.get("ocr", {})),
        audio=_build(AudioCfg, raw.get("audio", {})),
        whisper=_build(WhisperCfg, raw.get("whisper", {})),
        scheduler=_build(SchedulerCfg, raw.get("scheduler", {})),
    )
    if raw.get("vault_path"):
        cfg.vault_path = Path(raw["vault_path"]).expanduser()
    if isinstance(raw.get("responsibilities"), dict):
        cfg.responsibilities_horizon_days = raw["responsibilities"].get(
            "horizon_days", cfg.responsibilities_horizon_days)
    if isinstance(raw.get("agenda"), dict):
        cfg.agenda_horizon_days = raw["agenda"].get(
            "horizon_days", cfg.agenda_horizon_days)
    if isinstance(raw.get("tag_review"), dict):
        cfg.tag_review_max = raw["tag_review"].get("max_per_session", cfg.tag_review_max)

    STATE_DIR.mkdir(exist_ok=True)
    return cfg


config = load_config()
