"""Recompute the derived vocabulary CSV columns from the practice ledger.

Stage 2.5. The ledger (append-only events) and the review log (FSRS recalls)
are the raw record; the CSV's count / involvement / status columns are their
derived rollup. This module is the single place that recomputes that rollup and
writes it back — patching a row ONLY when a value actually changed, so a no-op
recompute touches nothing. That "compute the change and skip the call" is
deliberate and visible here, not leaned on from vocab_csv._write's byte-compare.
"""
from __future__ import annotations

import logging
from collections import defaultdict

from . import ledger, resolver, vocab_csv

log = logging.getLogger("sidecar.status")

_EMPTY_COUNTS = {"seen_count": 0, "lookup_count": 0, "saved_count": 0,
                 "produced_count": 0, "involvement": 0}
_EMPTY_REVIEWS = {"receptive_reviews": 0, "productive_reviews": 0}


def _status_fields(counts: dict, reviews: dict) -> dict:
    statuses = resolver.resolve(
        seen=counts["seen_count"], lookup=counts["lookup_count"],
        saved=counts["saved_count"], produced=counts["produced_count"],
        involvement=counts["involvement"],
        receptive_reviews=reviews["receptive_reviews"],
        productive_reviews=reviews["productive_reviews"])
    return {
        "seen_count": counts["seen_count"],
        "lookup_count": counts["lookup_count"],
        "saved_count": counts["saved_count"],
        "produced_count": counts["produced_count"],
        "involvement": counts["involvement"],
        "status_receptive": statuses["status_receptive"],
        "status_productive": statuses["status_productive"],
    }


def recompute() -> int:
    """Roll up the ledger + review logs and write the derived columns back.

    Patches a CSV row ONLY when a value actually changed, and only for terms
    already in the CSV — a word merely glanced at is not a tracked word, so
    events never create a row. Returns how many rows changed.
    """
    groups = ledger.rollup(ledger.read_events())
    reviews = ledger.summarize_reviews(ledger.read_reviews())

    by_bucket: dict[str, dict[str, tuple[dict, dict]]] = defaultdict(dict)
    for (term, bucket) in set(groups) | set(reviews):
        by_bucket[bucket][term] = (groups.get((term, bucket), _EMPTY_COUNTS),
                                   reviews.get((term, bucket), _EMPTY_REVIEWS))

    changed = 0
    for bucket, terms in by_bucket.items():
        rows = vocab_csv.read(bucket)
        row_by_term = {str(r.get("term") or ""): r for r in rows}
        for term, (counts, rv) in terms.items():
            row = row_by_term.get(term)
            if row is None:
                continue
            want = _status_fields(counts, rv)
            diff = {k: v for k, v in want.items() if row.get(k) != v}
            if diff:
                vocab_csv.patch(bucket, term, diff)
                changed += 1
    return changed
