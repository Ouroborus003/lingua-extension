"""tts_engine.py — Multi-backend neural TTS, ported from LinguaStudio
(`linguastudio/tts_engine.py`) so the vault sidecar can synthesize audio
itself instead of borrowing the separate LinguaStudio process for it.

Backends (independently guarded so a missing package degrades instead of
crashing the whole module):
  1. edge-tts   — "the neural" the operator asked to port: free, online,
                  Microsoft's neural voices. Primary backend, in requirements.txt.
  2. piper-tts  — local, offline, no GPU (ONNX runtime, CPU). The second
                  engine a prior planning session actually decided on for
                  read-aloud (see routers/tts.py's /speak route) — one
                  curated voice per live-test language, downloaded on first
                  use via piper's own official download_voice() helper
                  (queries the real rhasspy/piper-voices catalog on Hugging
                  Face rather than a hand-maintained URL, so a renamed or
                  retired voice fails loudly instead of silently 404ing).
  3. gTTS       — simple online fallback, also in requirements.txt. Used
                  automatically when the primary backend fails (see save_sync).
  4. Qwen3-TTS  — local-GPU voice cloning. Deliberately NOT installed here:
                  qwen-tts + torch + soundfile is a multi-GB GPU-only
                  dependency, postponed by the operator ("lets postpone
                  narakeet quality until way lster"). The guarded import,
                  backend registry entry, and save path stay so the code
                  activates on its own if a future session installs those
                  three packages into this sidecar's venv — until then
                  HAS_QWEN_TTS is False and every entry point guarded by it
                  raises immediately, same as LinguaStudio's own "not
                  installed" behavior.

LinguaStudio's original derived gTTS's language and the tkinter voice-picker
state from two global singletons (`language_state`, `languages`) that don't
exist here — the vault has five languages live at once (see lingua-workspace's
LANGS table), not one "current" language, so `lang` is threaded explicitly
through every call instead (see `_gtts_save_sync`, `save_sync`).
"""
from __future__ import annotations

import asyncio
import atexit
import base64
import io
import json
import logging
import os
import queue
import subprocess
import threading
import warnings
import wave
from pathlib import Path

from . import audio_cache, audio_normalizer
from .config import STATE_DIR

# Suppress noisy PyTorch / transformers attention-implementation warnings —
# only ever fires if HAS_QWEN_TTS is True, kept in case that path activates.
warnings.filterwarnings("ignore", message=".*Torch was not compiled with flash attention.*")
warnings.filterwarnings("ignore", message=".*past_key_values.*")
warnings.filterwarnings("ignore", category=UserWarning, module="torch")

log = logging.getLogger("sidecar.tts_engine")

# ── Backend availability flags ─────────────────────────────────────────────

try:
    import edge_tts
    HAS_EDGE_TTS = True
except ImportError:
    HAS_EDGE_TTS = False

try:
    from piper.voice import PiperVoice
    from piper.config import SynthesisConfig as PiperSynthesisConfig
    from piper.download_voices import download_voice as _piper_download_voice
    HAS_PIPER = True
except ImportError:
    HAS_PIPER = False
    PiperSynthesisConfig = None

try:
    from qwen_tts import Qwen3TTSModel
    import torch
    import soundfile as sf
    HAS_QWEN_TTS = True
except ImportError:
    HAS_QWEN_TTS = False

try:
    from gtts import gTTS as GoogleTTS
    HAS_GTTS = True
except ImportError:
    HAS_GTTS = False

KOKORO_PYTHON = Path(os.environ.get("KOKORO_PYTHON")
                     or Path.home() / ".local/share/uv/tools/abogen/bin/python")
KOKORO_WORKER = Path(__file__).with_name("kokoro_worker.py")


def kokoro_installed() -> bool:
    if not KOKORO_PYTHON.exists() or not KOKORO_WORKER.exists():
        return False
    lib = KOKORO_PYTHON.parent.parent / "lib"
    return any(lib.glob("python3*/site-packages/kokoro/__init__.py"))


HAS_KOKORO = kokoro_installed()

# ── Backend registry ─────────────────────────────────────────────────

BACKENDS: dict[str, str] = {}


def _register_backends() -> None:
    """Populate BACKENDS based on what's actually importable."""
    BACKENDS.clear()
    if HAS_EDGE_TTS:
        BACKENDS["edge-tts"] = "Edge-TTS (Online, Free, 26+ Voices)"
    if HAS_PIPER:
        BACKENDS["piper"] = "Piper (Local, Offline, No GPU)"
    if HAS_QWEN_TTS:
        BACKENDS["qwen3-tts"] = "Qwen3-TTS (Local GPU, Highest Quality)"
    if HAS_GTTS:
        BACKENDS["gtts"] = "Google TTS (Online, Simple Fallback)"
    if HAS_KOKORO:
        BACKENDS["kokoro"] = "Kokoro (Local GPU via abogen, Highest Quality)"
    # Shown even when not installed, for UI discoverability (the operator
    # settings dropdown should explain why a backend can't be picked, not omit it).
    if "edge-tts" not in BACKENDS:
        BACKENDS["edge-tts"] = "Edge-TTS (NOT INSTALLED)"
    if "piper" not in BACKENDS:
        BACKENDS["piper"] = "Piper (NOT INSTALLED)"
    if "qwen3-tts" not in BACKENDS:
        BACKENDS["qwen3-tts"] = "Qwen3-TTS (NOT INSTALLED)"
    if "kokoro" not in BACKENDS:
        BACKENDS["kokoro"] = "Kokoro (NOT INSTALLED)"


_register_backends()


def backend_list() -> list[str]:
    return list(BACKENDS.values())


def backend_keys() -> list[str]:
    return list(BACKENDS.keys())


def piper_voices_installed() -> list[str]:
    """Voice codes with BOTH files present. Empty means piper cannot speak yet."""
    if not PIPER_VOICE_DIR.exists():
        return []
    return sorted(p.stem for p in PIPER_VOICE_DIR.glob("*.onnx")
                  if p.with_suffix(".onnx.json").exists())


def backend_available(key: str) -> bool:
    """Can this backend actually produce audio right now?

    For piper this is deliberately stricter than "the library imports". Piper
    fetches its voice lazily on first synthesis, so an install with no voice on
    disk reported itself as an available *offline* backend and then failed —
    or silently required the network — the first time anything asked it to
    speak. That is the "local audio doesn't work" symptom: the predicate being
    reported ("is the package importable") was not the predicate that decides
    whether a word gets pronounced (P-VERIFY/V7).

    `piper_ready()` distinguishes the two states for the UI, so the settings
    pane can say "installed, no voice downloaded" instead of "available".
    """
    if key == "edge-tts":
        return HAS_EDGE_TTS
    elif key == "piper":
        return HAS_PIPER and bool(piper_voices_installed())
    elif key == "qwen3-tts":
        return HAS_QWEN_TTS
    elif key == "gtts":
        return HAS_GTTS
    elif key == "kokoro":
        return HAS_KOKORO
    return False


def piper_ready() -> dict:
    """Why piper is or is not usable — for the settings pane and /health."""
    if not HAS_PIPER:
        return {"ok": False, "why": "the piper package is not installed"}
    voices = piper_voices_installed()
    if not voices:
        return {"ok": False, "voices": [], "dir": str(PIPER_VOICE_DIR),
                "why": "piper is installed but no voice is downloaded, so it "
                       "cannot speak offline yet. The first synthesis would "
                       "fetch one over the network."}
    return {"ok": True, "voices": voices, "dir": str(PIPER_VOICE_DIR)}


# ── Edge-TTS voices ────────────────────────────────────────────────
# Grouped so male voices are easy to find; keys shown in UI dropdowns.
# ★ marks recommended defaults for each gender. Ported verbatim from
# LinguaStudio's curated table (linguastudio/tts_engine.py) — it's exactly
# the shape lingua-workspace's TTS tab already renders (ttsVoiceLabel).

_EDGE_VOICES_BY_LANG = {
    "cmn": {
        # ── Male — Mainland (zh-CN) ──────────────────────────────────────────
        "♂ Yunxi    ★ Male Mainland (Natural)":     "zh-CN-YunxiNeural",
        "♂ Yunyang  ★ Male Mainland (News)":        "zh-CN-YunyangNeural",
        "♂ Yunjian    Male Mainland (Sporty)":      "zh-CN-YunjianNeural",
        "♂ Yunfeng    Male Mainland (Excited)":     "zh-CN-YunfengNeural",
        "♂ Yunhao     Male Mainland (Ads)":         "zh-CN-YunhaoNeural",
        "♂ Yunxia     Male Mainland (Calm)":        "zh-CN-YunxiaNeural",
        "♂ Yunye      Male Mainland (Story)":       "zh-CN-YunyeNeural",
        "♂ Yunze      Male Mainland (Elder)":       "zh-CN-YunzeNeural",
        # ── Female — Mainland (zh-CN) ────────────────────────────────────────
        "♀ Xiaoxiao ★ Female Mainland (Warm)":      "zh-CN-XiaoxiaoNeural",
        "♀ Xiaoyi   ★ Female Mainland (Lively)":    "zh-CN-XiaoyiNeural",
        "♀ Xiaohan    Female Mainland (Calm)":      "zh-CN-XiaohanNeural",
        "♀ Xiaomeng   Female Mainland (Cute)":      "zh-CN-XiaomengNeural",
        "♀ Xiaomo     Female Mainland (Relaxed)":   "zh-CN-XiaomoNeural",
        "♀ Xiaorui    Female Mainland (Senior)":    "zh-CN-XiaoruiNeural",
        "♀ Xiaoshuang Female Mainland (Child)":     "zh-CN-XiaoshuangNeural",
        "♀ Xiaoxuan   Female Mainland (Pro)":       "zh-CN-XiaoxuanNeural",
        "♀ Xiaoyan    Female Mainland (Pro2)":      "zh-CN-XiaoyanNeural",
        "♀ Xiaozhen   Female Mainland (Energetic)": "zh-CN-XiaozhenNeural",
        "♀ Xiaochen   Female Mainland (Gentle)":    "zh-CN-XiaochenNeural",
        # ── Taiwan / Cantonese ───────────────────────────────────────────────
        "♂ YunJhe  ★ Male Taiwan":                  "zh-TW-YunJheNeural",
        "♀ HsiaoChen ★ Female Taiwan":              "zh-TW-HsiaoChenNeural",
        "♀ HsiaoYu    Female Taiwan (Alt)":         "zh-TW-HsiaoYuNeural",
        "♂ WanLung  ★ Male Cantonese":              "zh-HK-WanLungNeural",
        "♀ HiuMaan  ★ Female Cantonese":            "zh-HK-HiuMaanNeural",
        "♀ HiuGaai    Female Cantonese (Alt)":      "zh-HK-HiuGaaiNeural",
    },
    "ara": {
        "♀ Salma   ★ Female Egyptian (Warm)":        "ar-EG-SalmaNeural",
        "♂ Shakir    Male Egyptian":                 "ar-EG-ShakirNeural",
        "♀ Zariyah ★ Female Saudi":                  "ar-SA-ZariyahNeural",
        "♂ Hamed    Male Saudi":                     "ar-SA-HamedNeural",
    },
    "fas": {
        "♀ Dilara  ★ Female Farsi (Warm)":           "fa-IR-DilaraNeural",
        "♂ Farid    Male Farsi":                     "fa-IR-FaridNeural",
    },
    "urd": {
        "♀ Uzma    ★ Female Urdu (Warm)":            "ur-PK-UzmaNeural",
        "♂ Asad     Male Urdu":                      "ur-PK-AsadNeural",
    },
    "hun": {
        "♀ Noemi   ★ Female Hungarian":              "hu-HU-NoemiNeural",
        "♂ Tamas    Male Hungarian":                 "hu-HU-TamasNeural",
    },
    "deu": {
        "♀ Katja   ★ Female German (Warm)":          "de-DE-KatjaNeural",
        "♀ Seraphina  Female German (Expressive)":   "de-DE-SeraphinaNeural",
        "♂ Conrad  ★ Male German":                   "de-DE-ConradNeural",
        "♂ Bernd    Male German (Alt)":              "de-DE-BerndNeural",
        "♂ Killian  Male German (Alt2)":             "de-DE-KillianNeural",
    },
    "spa": {
        "♀ Elvira  ★ Female Spanish (Warm)":         "es-ES-ElviraNeural",
        "♀ Ximena    Female Spanish (Mexico)":       "es-MX-DaliaNeural",
        "♂ Alvaro  ★ Male Spanish":                  "es-ES-AlvaroNeural",
        "♂ Jorge    Male Spanish (Mexico)":          "es-MX-JorgeNeural",
    },
    # Japanese and Korean remain accessible via the flat EDGE_VOICES dict.
    "_ja": {
        "♀ Nanami  ★ Female Japanese":              "ja-JP-NanamiNeural",
        "♂ Keita   ★ Male Japanese":               "ja-JP-KeitaNeural",
        "♀ Aoi       Female Japanese (Cheerful)":   "ja-JP-AoiNeural",
        "♂ Daichi    Male Japanese (Friendly)":     "ja-JP-DaichiNeural",
        "♀ Mayu      Female Japanese (Soft)":       "ja-JP-MayuNeural",
        "♂ Naoki     Male Japanese (Calm)":         "ja-JP-NaokiNeural",
    },
    "_ko": {
        "♀ SunHi   ★ Female Korean":               "ko-KR-SunHiNeural",
        "♂ InJoon  ★ Male Korean":                 "ko-KR-InJoonNeural",
        "♀ BongJin   Female Korean (Alt)":          "ko-KR-BongJinNeural",
        "♂ GookMin   Male Korean (Alt)":            "ko-KR-GookMinNeural",
        "♀ JiMin     Female Korean (Calm)":         "ko-KR-JiMinNeural",
        "♀ SeoHyeon  Female Korean (Young)":        "ko-KR-SeoHyeonNeural",
    },
    # French, Italian and Russian: read languages of this vault (they have
    # Tatoeba corpora in reading-companion/data) that LinguaStudio never
    # covered, so default_voice_for found no matching voice and fell back to
    # EDGE_DEFAULT_ENGLISH. A US English voice reading French out loud is the
    # "robotic" complaint — measured: fr, it and ru all resolved to
    # en-US-AriaNeural.
    "fra": {
        "♀ Denise  ★ Female French":                "fr-FR-DeniseNeural",
        "♂ Henri   ★ Male French":                  "fr-FR-HenriNeural",
        "♀ Eloise    Female French (Young)":        "fr-FR-EloiseNeural",
    },
    "ita": {
        "♀ Elsa    ★ Female Italian":               "it-IT-ElsaNeural",
        "♂ Diego   ★ Male Italian":                 "it-IT-DiegoNeural",
        "♀ Isabella  Female Italian (Warm)":        "it-IT-IsabellaNeural",
    },
    "rus": {
        "♀ Svetlana ★ Female Russian":              "ru-RU-SvetlanaNeural",
        "♂ Dmitry  ★ Male Russian":                 "ru-RU-DmitryNeural",
    },
    # English has no place in LinguaStudio's original table (it's a foreign-
    # language learning tool — English is always the "native" side, never a
    # synthesis target). reading-companion's plain Read aloud has no language
    # signal at all and reads mostly-English vault notes, so without this
    # entry an English note would auto-pick whatever the flat dict's first
    # key happens to be (a Mandarin voice) — see pick_read_aloud_backend.
    "_en": {
        "♀ Aria   ★ Female US English (Warm)":     "en-US-AriaNeural",
        "♂ Guy    ★ Male US English":              "en-US-GuyNeural",
        "♀ Jenny    Female US English (Assistant)": "en-US-JennyNeural",
        "♀ Sonia  ★ Female British English":        "en-GB-SoniaNeural",
        "♂ Ryan   ★ Male British English":          "en-GB-RyanNeural",
    },
}

# Flat merged dict — display-name key -> edge-tts ShortName, every language.
EDGE_VOICES: dict[str, str] = {}
for _v in _EDGE_VOICES_BY_LANG.values():
    EDGE_VOICES.update(_v)

EDGE_DEFAULT_MALE = "♂ Yunxi    ★ Male Mainland (Natural)"
EDGE_DEFAULT_FEMALE = "♀ Xiaoxiao ★ Female Mainland (Warm)"

# lingua-workspace's LANGS[].lingua codes (main.js) -> the curated table above.
# Cantonese shares Mandarin's dict (zh-HK voices live inside "cmn"); codes with
# no curated subset fall through to the full flat EDGE_VOICES in edge_voices_for_lang.
_LANG_CODE_TO_EDGE_KEY = {
    "cmn": "cmn", "yue": "cmn", "jpn": "_ja", "kor": "_ko",
    "ara": "ara", "fas": "fas", "urd": "urd", "hun": "hun",
    "deu": "deu", "spa": "spa", "eng": "_en",
    "fra": "fra", "ita": "ita", "rus": "rus",
}

import re as _re
_SHORTNAME_RE = _re.compile(r"^[a-z]{2,3}-[A-Za-z0-9]+-\w+$")

EDGE_DEFAULT_ENGLISH = "♀ Aria   ★ Female US English (Warm)"


# 3-letter -> 2-letter, for codes with no curated voice subset. Only the ones
# this vault's dictionaries and readers actually use; anything else falls
# through to its own first two letters, which is right far more often than not.
_ISO3_TO_ISO1 = {
    "zho": "zh", "cmn": "zh", "yue": "zh", "jpn": "ja", "kor": "ko",
    "ara": "ar", "fas": "fa", "per": "fa", "urd": "ur", "hun": "hu",
    "deu": "de", "ger": "de", "spa": "es", "eng": "en", "fra": "fr",
    "fre": "fr", "ita": "it", "rus": "ru", "por": "pt", "tur": "tr",
    "lat": "la", "kur": "ku", "nld": "nl", "dut": "nl", "pol": "pl",
    "swe": "sv", "ces": "cs", "ell": "el", "heb": "he", "hin": "hi",
}

# 2-letter aliases for the curated subsets, so a reader sending ISO-639-1
# reaches the same voices as one sending ISO-639-3.
_LANG_CODE_TO_EDGE_KEY.update({
    iso1: key for iso1, key in (
        ("zh", "cmn"), ("ja", "jpn"), ("ko", "kor"), ("ar", "ara"),
        ("fa", "fas"), ("ur", "urd"), ("hu", "hun"), ("de", "deu"),
        ("es", "spa"), ("en", "eng"), ("zho", "cmn"),
    ) if key in _EDGE_VOICES_BY_LANG
})


def edge_voices_for_lang(lang_code: str | None = None) -> list[dict]:
    """Curated edge-tts voices for a lingua-workspace lang code, as
    [{id, shortName, locale, gender}, ...].

    `id` is the EDGE_VOICES display-name key — the same value validate_voice()
    and save_sync() require, NOT edge-tts's raw ShortName (LinguaStudio's
    ERR-165: the two used to disagree, so every voice /tts/voices listed
    failed /tts/preview's validation). Falls back to the full flat EDGE_VOICES
    dict when lang_code is empty or has no curated subset, so the list is
    never empty.
    """
    code = (lang_code or "").strip().lower()
    key = _LANG_CODE_TO_EDGE_KEY.get(code) if code else None
    if key:
        voices = _EDGE_VOICES_BY_LANG.get(key, EDGE_VOICES)
    elif code:
        # No curated subset for this code. Falling straight back to the flat
        # EDGE_VOICES dict was the bug: callers take voices[0], and entry zero
        # is Mandarin — so **Hungarian was read aloud by zh-CN-YunxiNeural**.
        # The map is keyed on lingua-workspace's 3-letter codes while the
        # reader plugin sends 2-letter ones, so `hu`, `de`, `fr`, `zh` all
        # missed and every language got the same Chinese voice.
        #
        # Select by the voice's own locale prefix instead. That covers every
        # language edge-tts ships, not just the eleven curated ones, and it
        # cannot silently hand back the wrong language.
        iso1 = _ISO3_TO_ISO1.get(code, code)[:2]
        voices = {d: s for d, s in EDGE_VOICES.items()
                  if s.lower().startswith(iso1 + "-")}
        if not voices:
            # No voice in this language (the table covers eleven; fr/it/ru/tr
            # are not among them). The full table is the right answer *here*,
            # because this function also backs the voice PICKER — offering
            # every voice for an unlisted language lets the operator choose one
            # deliberately. Picking what *speaks* is a different question, and
            # is decided in default_voice_for(), which must not take entry zero.
            voices = EDGE_VOICES
    else:
        voices = EDGE_VOICES
    out = []
    for display_name, short_name in voices.items():
        parts = short_name.split("-")
        locale = "-".join(parts[:2]) if len(parts) >= 2 else ""
        stripped = display_name.strip()
        gender = "Female" if stripped.startswith("♀") else ("Male" if stripped.startswith("♂") else "")
        out.append({"id": display_name, "shortName": short_name, "locale": locale, "gender": gender})
    return out


# ── Piper voices — local, offline, no GPU ─────────────────────────────────
# One curated voice per live-test language (see project handoff's "live-test
# languages" convention) rather than edge-tts's big per-language menu — piper's
# whole value here is "one solid always-available local voice", not choice.
# Names confirmed live against the real rhasspy/piper-voices catalog on
# Hugging Face (voices.json) at the time this was written, not guessed —
# a renamed/retired voice will fail loudly in _piper_save_sync rather than
# silently 404 partway through a chapter read.
PIPER_VOICES = {
    "eng": "en_US-ryan-high",
    "deu": "de_DE-thorsten-high",
    "rus": "ru_RU-irina-medium",
    "cmn": "zh_CN-huayan-medium",
    "ara": "ar_JO-kareem-medium",
}

PIPER_VOICE_CODE_RE = __import__("re").compile(r"^[a-z]{2,3}_[A-Z]{2}-[A-Za-z0-9_]+-(x_low|low|medium|high)$")

PIPER_SYNTHESIS = {
    "length_scale": float(os.environ.get("PIPER_LENGTH_SCALE") or 1.05),
    "noise_scale": float(os.environ.get("PIPER_NOISE_SCALE") or 0.667),
    "noise_w_scale": float(os.environ.get("PIPER_NOISE_W_SCALE") or 0.8),
}

PIPER_VOICE_DIR = STATE_DIR / "piper_voices"

_piper_voice_cache: dict[str, "PiperVoice"] = {}
_piper_lock = threading.Lock()


# 2-letter aliases, so a caller sending ISO-639-1 reaches the same voice as
# one sending ISO-639-3. Edge already learned this ("hu", "de", "fr" and "zh"
# all missed a table keyed on 3-letter codes, and every language ended up
# read by the same Mandarin voice — see edge_voices_for_lang). PIPER_VOICES
# had the identical shape and the identical hole: `en` and `de` resolved to
# nothing, so /tts/speak with an ISO-1 language failed validation outright.
_PIPER_LANG_ALIASES = {
    _ISO3_TO_ISO1[iso3]: iso3 for iso3 in PIPER_VOICES if iso3 in _ISO3_TO_ISO1
}


def piper_lang_key(lang_code: str | None) -> str:
    code = (lang_code or "").strip().lower()
    return _PIPER_LANG_ALIASES.get(code, code)


def piper_voice_for_lang(lang_code: str | None) -> str | None:
    """The curated Piper voice code for a lingua-workspace lang code, or
    None if piper has no curated voice for that language yet."""
    return PIPER_VOICES.get(piper_lang_key(lang_code))


def resolve_piper_voice(voice_key: str | None) -> str | None:
    """A caller may name a language ("eng") or a Piper voice outright
    ("en_US-ryan-high"). The picker hands back the latter now that Piper
    exposes more than one voice per language; /speak's auto path still
    sends the former. Both resolve here so exactly one function decides
    what "the piper voice" means."""
    key = (voice_key or "").strip()
    if PIPER_VOICE_CODE_RE.match(key):
        return key
    return PIPER_VOICES.get(key.lower())


def piper_locale_of(voice_code: str) -> str:
    return (voice_code or "").split("-")[0]


def piper_voices_for_lang(lang_code: str | None) -> list[str]:
    """Every Piper voice this machine can offer for a language: the curated
    one first, then any other voice already downloaded for the same locale.
    Listing only the curated voice is what made the picker look frozen —
    one entry never changes, whichever backend is selected.

    NO language is not the same question as an unsupported one, and
    collapsing the two is what made Piper's menu read "no voices for this
    engine" in the reader. Plain read-aloud has no language signal at all
    (reading-companion never had one to send; pick_read_aloud_backend says so
    in its own docstring), so it asks with `lang=""` — and every other engine
    answers that with its whole list while Piper answered with nothing.

      · no language  -> everything this machine can offer, like
                        edge_voices_for_lang's full-table fallback. This
                        function backs the PICKER; choosing what actually
                        speaks is default_voice_for's job and stays strict.
      · a language piper has no curated voice for -> empty, deliberately, so
                        lingua-workspace can say "Piper has no curated voice
                        for Hungarian yet" instead of offering a German one.
    """
    installed = piper_voices_installed()
    if not (lang_code or "").strip():
        rest = [v for v in installed if v not in PIPER_VOICES.values()]
        return list(dict.fromkeys(list(PIPER_VOICES.values()) + sorted(rest)))
    curated = piper_voice_for_lang(lang_code)
    if not curated:
        return []
    locale = piper_locale_of(curated)
    others = [v for v in installed if piper_locale_of(v) == locale and v != curated]
    return [curated] + sorted(others)


def piper_synthesis_config():
    """Piper's own default peak-normalizes EVERY SENTENCE to full scale
    independently (voice.py: `audio / max(abs(audio))` per chunk), so a
    quiet clause and a loud one come out at the same level and the read
    pumps between sentences. That is a large part of what reads as
    "robotic"; loudness is set once for the whole file by
    audio_normalizer instead."""
    if PiperSynthesisConfig is None:
        return None
    return PiperSynthesisConfig(normalize_audio=False, **PIPER_SYNTHESIS)


def _get_piper_voice(voice_code: str) -> "PiperVoice":
    """Lazy singleton per voice code — downloads the .onnx/.onnx.json pair
    into STATE_DIR (gitignored, same area audio_cache.py already uses) via
    piper's own official download_voice() the first time this voice is
    needed, then keeps the loaded model resident for subsequent reads
    rather than reloading the ONNX graph on every chunk."""
    if not HAS_PIPER:
        raise RuntimeError("piper-tts not installed. Run: pip install piper-tts")
    with _piper_lock:
        if voice_code in _piper_voice_cache:
            return _piper_voice_cache[voice_code]
        PIPER_VOICE_DIR.mkdir(parents=True, exist_ok=True)
        model_path = PIPER_VOICE_DIR / f"{voice_code}.onnx"
        config_path = PIPER_VOICE_DIR / f"{voice_code}.onnx.json"
        if not model_path.exists() or not config_path.exists():
            log.info("piper: downloading voice %s into %s", voice_code, PIPER_VOICE_DIR)
            _piper_download_voice(voice_code, PIPER_VOICE_DIR)
        voice = PiperVoice.load(model_path, config_path=config_path)
        _piper_voice_cache[voice_code] = voice
        return voice


# ── Qwen3-TTS voices (CustomVoice speakers) — inert unless HAS_QWEN_TTS ────

QWEN_SPEAKERS = {
    "Vivian  ★ Female Mandarin (Clear)":     "Vivian",
    "Serena    Female English (Warm)":        "Serena",
    "Ono_anna  Female Japanese":              "Ono_anna",
    "Sohee     Female Korean":                "Sohee",
    "Aiden     Male English":                 "Aiden",
    "Dylan     Male English (Young)":         "Dylan",
    "Eric      Male English (Deep)":          "Eric",
    "Ryan      Male English (Natural)":       "Ryan",
    "Uncle_fu  Male Mandarin (Mature)":       "Uncle_fu",
}

QWEN_MODELS = {
    "CustomVoice 1.7B (Best Quality)":     "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice",
    "CustomVoice 0.6B (Faster, Less VRAM)": "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice",
}

QWEN_LANGUAGES = ["Chinese", "English", "Japanese", "Korean", "Auto"]

# ── Speed options (edge-tts rate strings) ────────────────────────────────

SPEEDS = ["+30%", "+20%", "+10%", "+0%", "-10%", "-20%", "-30%", "-40%", "-50%"]

# lingua-workspace's LANGS[].lingua codes -> gTTS's language codes. gTTS takes
# plain ISO 639-1 for almost everything; only Mandarin needs a region suffix.
# This replaces LinguaStudio's `language_state`/`languages` globals (the vault
# has five languages live at once, not one "current" language) — see the
# module docstring and save_sync's `lang` parameter.
# Codes confirmed against the installed gTTS's own gtts.lang.tts_langs(),
# not guessed — Hebrew is "iw" there, not "he", and Persian and Kurdish are
# absent entirely.
#
# This table held eight languages and defaulted everything else to "en". gTTS
# is save_sync's AUTOMATIC fallback for every backend, so a failed Russian or
# French read fell through to it and was spoken, fluently, in English — the
# same silent wrong-language failure as the Mandarin-voice-reads-Hungarian
# bug (see edge_voices_for_lang), with no error anywhere to say so.
_GTTS_LANG = {
    "cmn": "zh-CN", "zho": "zh-CN", "yue": "zh-CN",
    "eng": "en", "deu": "de", "ger": "de", "fra": "fr", "fre": "fr",
    "spa": "es", "ita": "it", "rus": "ru", "por": "pt", "nld": "nl",
    "dut": "nl", "pol": "pl", "swe": "sv", "ces": "cs", "ell": "el",
    "heb": "iw", "hin": "hi", "tur": "tr", "ara": "ar", "hun": "hu",
    "jpn": "ja", "kor": "ko", "urd": "ur", "lat": "la",
}
_GTTS_LANG.update({_ISO3_TO_ISO1[k]: v for k, v in list(_GTTS_LANG.items())
                   if k in _ISO3_TO_ISO1})


def gtts_supports(lang: str) -> bool:
    """Whether gTTS can actually speak this language, as distinct from
    whether gtts_lang_for will return something. An empty language is
    English on purpose (pick_read_aloud_backend's reasoning), not unknown."""
    code = (lang or "").strip().lower()
    return not code or code in _GTTS_LANG


def gtts_lang_for(lang: str) -> str:
    """English is the last-resort default because this also backs save_sync's
    fallback path, which must produce audio rather than raise. Anything that
    needs to know whether the language is genuinely covered must ask
    gtts_supports() — the "en" here is a floor, not an answer."""
    return _GTTS_LANG.get((lang or "").strip().lower(), "en")


# ── Qwen3-TTS model singleton (inert: only reachable when HAS_QWEN_TTS) ────

_qwen_model = None
_qwen_model_name = None
_qwen_lock = threading.Lock()


def _get_qwen_model(model_name="Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice"):
    """Load Qwen3-TTS model (lazy singleton). Ported verbatim; unreachable
    until qwen-tts/torch/soundfile are installed (see module docstring)."""
    global _qwen_model, _qwen_model_name
    if not HAS_QWEN_TTS:
        raise RuntimeError(
            "qwen-tts not installed.\n"
            "Install: pip install qwen-tts torch soundfile\n"
            "Optional: pip install flash-attn --no-build-isolation"
        )
    with _qwen_lock:
        if _qwen_model is None or _qwen_model_name != model_name:
            dtype = torch.bfloat16 if torch.cuda.is_available() else torch.float32
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
            try:
                import flash_attn  # noqa: F401
                attn_impl = "flash_attention_2"
            except ImportError:
                attn_impl = "sdpa"
            _qwen_model = Qwen3TTSModel.from_pretrained(
                model_name, device_map=device, dtype=dtype,
                attn_implementation=attn_impl,
            )
            _qwen_model_name = model_name
    return _qwen_model


def unload_qwen_model() -> None:
    """Free GPU memory by unloading the Qwen model."""
    global _qwen_model, _qwen_model_name
    with _qwen_lock:
        if _qwen_model is not None:
            del _qwen_model
            _qwen_model = None
            _qwen_model_name = None
            if HAS_QWEN_TTS and torch.cuda.is_available():
                torch.cuda.empty_cache()


# ── Save functions per backend ────────────────────────────────────────────────

async def _edge_save(text: str, voice: str, speed: str, path) -> None:
    c = edge_tts.Communicate(text, voice, rate=speed)
    await c.save(str(path))


def _edge_save_sync(text: str, voice_key: str, speed: str, path, timeout: int = 45) -> None:
    """Edge-TTS blocking save with a timeout so a stalled connection can't
    hang the caller forever. This function itself is blocking — callers on
    the event loop (the /tts and /vocab routers) must run it via
    asyncio.to_thread, not await it directly."""
    if not HAS_EDGE_TTS:
        raise RuntimeError("edge-tts not installed. Run: pip install edge-tts")
    import concurrent.futures
    vid = EDGE_VOICES.get(voice_key)
    if vid is None:
        # A raw edge-tts ShortName ("hu-HU-NoemiNeural") is a legitimate key
        # too; only a genuinely unknown value falls back. Defaulting straight
        # to Mandarin meant any caller that passed a ShortName got Chinese
        # audio for every language, silently — the same failure shape as the
        # Hungarian-read-by-Yunxi bug this table already carries a note about.
        vid = voice_key if _SHORTNAME_RE.match(str(voice_key or "")) \
              else "zh-CN-XiaoxiaoNeural"

    def _run():
        loop = asyncio.new_event_loop()
        try:
            loop.run_until_complete(_edge_save(text, vid, speed, path))
        finally:
            loop.close()

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(_run)
        try:
            future.result(timeout=timeout)
        except concurrent.futures.TimeoutError:
            raise RuntimeError(
                f"Edge-TTS timed out after {timeout}s for voice {voice_key!r}. "
                "Check network connectivity or try the gTTS fallback."
            )


def _qwen_save_sync(text, voice_key, speed, path,
                     model_key="CustomVoice 1.7B (Best Quality)",
                     language="Chinese", instruct=""):
    """Qwen3-TTS blocking save. Ported verbatim; unreachable until
    qwen-tts/torch/soundfile are installed (HAS_QWEN_TTS)."""
    if not HAS_QWEN_TTS:
        raise RuntimeError(
            "Qwen3-TTS is not installed.\n"
            "Install: pip install qwen-tts torch soundfile"
        )
    model_name = QWEN_MODELS.get(model_key, "Qwen/Qwen3-TTS-12Hz-1.7B-CustomVoice")
    speaker = QWEN_SPEAKERS.get(voice_key, "Vivian")
    if speaker not in QWEN_SPEAKERS.values():
        raise ValueError(f"Unknown Qwen3-TTS speaker: {speaker!r}. "
                         f"Available: {list(QWEN_SPEAKERS.values())}")
    try:
        model = _get_qwen_model(model_name)
    except RuntimeError as e:
        raise RuntimeError(f"Failed to load Qwen3-TTS model: {e}") from e
    except Exception as e:
        raise RuntimeError(
            f"Qwen3-TTS model load error ({type(e).__name__}): {e}\n"
            "Check that your GPU has enough VRAM (6+ GB required)."
        ) from e
    try:
        wavs, sr = model.generate_custom_voice(
            text=text, language=language, speaker=speaker,
            instruct=instruct if instruct else None,
        )
    except Exception as e:
        err = str(e)
        if "CUDA out of memory" in err or "out of memory" in err.lower():
            try:
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            except Exception:
                pass
            raise RuntimeError(
                "GPU out of memory during Qwen3-TTS generation. "
                "Try the 0.6B model or close other GPU applications."
            ) from e
        raise RuntimeError(f"Qwen3-TTS generation failed ({type(e).__name__}): {e}") from e
    if wavs is None or len(wavs) == 0:
        raise RuntimeError("Qwen3-TTS returned empty audio — generation failed.")
    path = str(path)
    if path.endswith(".mp3"):
        wav_tmp = path.rsplit(".", 1)[0] + "_tmp.wav"
        try:
            sf.write(wav_tmp, wavs[0], sr)
            result = subprocess.run(
                ["ffmpeg", "-y", "-i", wav_tmp, "-codec:a", "libmp3lame",
                 "-qscale:a", "2", path],
                capture_output=True,
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"ffmpeg conversion failed: {result.stderr.decode(errors='replace')}")
        finally:
            try:
                os.unlink(wav_tmp)
            except OSError:
                pass
    else:
        sf.write(path, wavs[0], sr)


def _gtts_save_sync(text: str, lang: str, path) -> None:
    """Google TTS blocking save. `lang` is the caller's explicit language
    code (see module docstring) — not guessed from a global."""
    if not HAS_GTTS:
        raise RuntimeError("gtts not installed. Run: pip install gTTS")
    tts = GoogleTTS(text=text, lang=gtts_lang_for(lang))
    tts.save(str(path))


def piper_wav_bytes(text: str, voice_key: str) -> bytes:
    """One sentence-or-more of Piper audio as a WAV, at the voice's own
    sample rate. The audiobook renderer wants bytes; save_sync wants a
    file — both come through here so there is one synthesis path."""
    if not HAS_PIPER:
        raise RuntimeError("piper-tts not installed. Run: pip install piper-tts")
    voice_code = resolve_piper_voice(voice_key)
    if not voice_code:
        raise ValueError(f"No Piper voice for {voice_key!r}")
    voice = _get_piper_voice(voice_code)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wav_file:
        voice.synthesize_wav(text, wav_file, syn_config=piper_synthesis_config())
    return buf.getvalue()


def _piper_save_sync(text: str, voice_key: str, path) -> None:
    """Piper blocking save, straight to WAV. `voice_key` is a
    lingua-workspace lang code (e.g. "deu") or a Piper voice code outright
    — see resolve_piper_voice.

    It used to encode the WAV to mp3 here and then save_sync ran loudnorm
    over that mp3 and encoded a SECOND time, at 128k and resampled 22050 ->
    24000. Two lossy generations and a pointless resample, for one file.
    save_sync now finalizes the WAV once (see _WAV_BACKENDS)."""
    with open(str(path), "wb") as fh:
        fh.write(piper_wav_bytes(text, voice_key))



KOKORO_VOICE_RE = __import__("re").compile(r"^[a-z]{2}_[a-z0-9]+$")

KOKORO_DEFAULT_VOICE = os.environ.get("KOKORO_VOICE") or "bm_daniel"
KOKORO_VOICE_BY_LANG = {
    "eng": KOKORO_DEFAULT_VOICE, "en": KOKORO_DEFAULT_VOICE,
    "fra": "ff_siwis", "fr": "ff_siwis",
    "spa": "ef_dora", "es": "ef_dora",
    "ita": "if_sara", "it": "if_sara",
    "por": "pf_dora", "pt": "pf_dora",
    "jpn": "jf_alpha", "ja": "jf_alpha",
    "hin": "hf_alpha", "hi": "hf_alpha",
    "zho": "zf_xiaoxiao", "cmn": "zf_xiaoxiao", "zh": "zf_xiaoxiao",
}

# The picker's list, with locales so /tts/voices can answer per language the
# way the edge and piper engines do. Kept here rather than in the plugin
# because the plugin hardcoding it is precisely why the voice menu showed
# Kokoro's speakers whichever backend was selected.
KOKORO_VOICES = [
    ("bm_daniel", "Daniel (British, m)", "en-GB", "Male"),
    ("bm_george", "George (British, m)", "en-GB", "Male"),
    ("bf_emma", "Emma (British, f)", "en-GB", "Female"),
    ("bf_isabella", "Isabella (British, f)", "en-GB", "Female"),
    ("am_adam", "Adam (American, m)", "en-US", "Male"),
    ("am_michael", "Michael (American, m)", "en-US", "Male"),
    ("af_heart", "Heart (American, f)", "en-US", "Female"),
    ("af_bella", "Bella (American, f)", "en-US", "Female"),
    ("af_nicole", "Nicole (American, f)", "en-US", "Female"),
    ("ff_siwis", "Siwis (French, f)", "fr-FR", "Female"),
    ("ef_dora", "Dora (Spanish, f)", "es-ES", "Female"),
    ("if_sara", "Sara (Italian, f)", "it-IT", "Female"),
    ("pf_dora", "Dora (Portuguese, f)", "pt-BR", "Female"),
    ("jf_alpha", "Alpha (Japanese, f)", "ja-JP", "Female"),
    ("zf_xiaoxiao", "Xiaoxiao (Mandarin, f)", "zh-CN", "Female"),
    ("hf_alpha", "Alpha (Hindi, f)", "hi-IN", "Female"),
]


def kokoro_voices_for_lang(lang_code: str | None) -> list[dict]:
    """Kokoro speakers for a language, or all of them when the language has
    none — the same "never hand the picker an empty list" contract
    edge_voices_for_lang already follows."""
    code = (lang_code or "").strip().lower()
    iso1 = _ISO3_TO_ISO1.get(code, code)[:2]
    rows = [{"id": vid, "shortName": label, "locale": locale, "gender": gender}
            for vid, label, locale, gender in KOKORO_VOICES]
    if not iso1:
        return rows
    hit = [r for r in rows if r["locale"].lower().startswith(iso1)]
    return hit or rows


KOKORO_IDLE_SECONDS = int(os.environ.get("KOKORO_IDLE_SECONDS") or 300)
KOKORO_START_TIMEOUT = 240
KOKORO_REQUEST_TIMEOUT = 120
KOKORO_LOG = STATE_DIR / "kokoro_worker.log"


def kokoro_voice_for_lang(lang_code: str | None) -> str:
    return KOKORO_VOICE_BY_LANG.get((lang_code or "eng").strip().lower(), KOKORO_DEFAULT_VOICE)


class _KokoroWorker:

    def __init__(self) -> None:
        self.proc: subprocess.Popen | None = None
        self.lines: queue.Queue = queue.Queue()
        self.lock = threading.Lock()
        self.timer: threading.Timer | None = None
        self.device: str | None = None

    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def _pump(self, proc: subprocess.Popen, lines: queue.Queue) -> None:
        for line in proc.stdout:
            lines.put(line)
        lines.put(None)

    def _start(self) -> None:
        KOKORO_LOG.parent.mkdir(parents=True, exist_ok=True)
        log_fh = open(KOKORO_LOG, "ab")
        self.lines = queue.Queue()
        self.proc = subprocess.Popen(
            [str(KOKORO_PYTHON), str(KOKORO_WORKER)],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log_fh,
            text=True, bufsize=1,
            env={**os.environ, "KOKORO_VOICE": KOKORO_DEFAULT_VOICE})
        log_fh.close()
        threading.Thread(target=self._pump, args=(self.proc, self.lines), daemon=True).start()
        msg = self._read(KOKORO_START_TIMEOUT, "start")
        if not msg.get("ready"):
            self._kill()
            raise RuntimeError(f"kokoro worker did not report ready: {msg!r}")
        self.device = msg.get("device")
        log.info("kokoro worker ready on %s (pid %s)", self.device, self.proc.pid)

    def _read(self, timeout: float, what: str) -> dict:
        try:
            line = self.lines.get(timeout=timeout)
        except queue.Empty:
            self._kill()
            raise RuntimeError(f"kokoro worker timed out after {timeout}s ({what}); see {KOKORO_LOG}")
        if line is None:
            self._kill()
            raise RuntimeError(f"kokoro worker exited during {what}; see {KOKORO_LOG}")
        return json.loads(line)

    def _kill(self) -> None:
        proc, self.proc = self.proc, None
        if proc is None:
            return
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def _arm_idle(self) -> None:
        self._cancel_idle()
        self.timer = threading.Timer(KOKORO_IDLE_SECONDS, self._idle)
        self.timer.daemon = True
        self.timer.start()

    def _cancel_idle(self) -> None:
        if self.timer is not None:
            self.timer.cancel()
            self.timer = None

    def _idle(self) -> None:
        with self.lock:
            if self.alive():
                log.info("kokoro worker idle %ss — releasing it", KOKORO_IDLE_SECONDS)
            self._kill()

    def synth(self, text: str, voice: str, speed: float = 1.0) -> bytes:
        with self.lock:
            self._cancel_idle()
            if not self.alive():
                self._start()
            self.proc.stdin.write(json.dumps({"text": text, "voice": voice, "speed": speed}) + "\n")
            self.proc.stdin.flush()
            msg = self._read(KOKORO_REQUEST_TIMEOUT, "synthesis")
            self._arm_idle()
            if not msg.get("ok"):
                raise RuntimeError(f"kokoro: {msg.get('error') or 'unknown error'}")
            return base64.b64decode(msg["wav"])

    def warm(self) -> str | None:
        with self.lock:
            self._cancel_idle()
            if not self.alive():
                self._start()
            self._arm_idle()
            return self.device

    def stop(self) -> None:
        with self.lock:
            self._cancel_idle()
            self._kill()


_kokoro = _KokoroWorker()
atexit.register(_kokoro.stop)


def kokoro_warm() -> dict:
    if not HAS_KOKORO:
        return {"ok": False, "error": f"kokoro is not installed under {KOKORO_PYTHON}"}
    return {"ok": True, "device": _kokoro.warm()}


def kokoro_ready() -> dict:
    if not HAS_KOKORO:
        return {"ok": False, "why": f"kokoro is not installed under {KOKORO_PYTHON}"}
    return {"ok": True, "resident": _kokoro.alive(), "device": _kokoro.device}


def _kokoro_save_sync(text: str, voice_key: str, path) -> None:
    """Writes Kokoro's WAV as-is; save_sync encodes it once (_WAV_BACKENDS),
    for the same double-encode reason spelled out in _piper_save_sync."""
    if not HAS_KOKORO:
        raise RuntimeError(f"kokoro is not installed under {KOKORO_PYTHON}")
    with open(str(path), "wb") as fh:
        fh.write(_kokoro.synth(text, voice_key or KOKORO_DEFAULT_VOICE))

# ── Unified interface ─────────────────────────────────────────────────────

# Backends whose _save_sync writes a WAV rather than an mp3. Their output is
# encoded exactly once, at the voice's own sample rate — see
# _piper_save_sync's docstring for what doing it twice cost.
_WAV_BACKENDS = ("piper", "kokoro")

READ_ALOUD_BITRATE = "192k"

# Bump whenever the ENCODING pipeline changes — the voice, the synthesis
# config, the number of encodes, the sample rate. The cache is keyed on
# (text, voice, speed, backend), which says nothing about how the bytes were
# produced, so a pipeline fix otherwise keeps serving the audio it fixed,
# from disk, with nothing in the logs. Caught live: after the double-encode
# fix, edge-tts still answered with a 48 kHz clip rendered by the old code.
#
# 2 — single encode at the source's own rate; piper's per-sentence peak
#     normalization off; curated English/German voices moved to -high.
PIPELINE_REV = 2


def cache_backend_key(backend: str) -> str:
    """The cache's backend component, carrying the pipeline revision so a
    pipeline change invalidates rather than shadows itself."""
    return f"{backend}#r{PIPELINE_REV}"


def cache_voice_key(voice_key: str, backend: str) -> str:
    """What the audio cache should file this clip under.

    For piper the caller's key is usually a LANGUAGE ("eng"), not a voice —
    so swapping the curated voice for that language leaves every cached clip
    keyed identically and the old voice keeps playing forever, from disk,
    with nothing in the logs. The cache must be keyed by the thing that
    decides the sound."""
    if backend == "piper":
        return resolve_piper_voice(voice_key) or voice_key
    return voice_key


def validate_voice(voice_key: str, backend: str = "edge-tts") -> tuple[bool, str]:
    """Check that voice_key is valid for the given backend.
    Returns (True, '') on success or (False, reason) on failure."""
    if backend == "edge-tts":
        if not HAS_EDGE_TTS:
            return False, "edge-tts is not installed"
        if voice_key not in EDGE_VOICES:
            return False, f"Unknown Edge-TTS voice: {voice_key!r}"
        return True, ""
    elif backend == "piper":
        if not HAS_PIPER:
            return False, "piper-tts is not installed"
        if not resolve_piper_voice(voice_key):
            return False, f"No Piper voice for: {voice_key!r}"
        return True, ""
    elif backend == "qwen3-tts":
        if not HAS_QWEN_TTS:
            return False, "Qwen3-TTS is not installed"
        if voice_key not in QWEN_SPEAKERS:
            return False, f"Unknown Qwen3-TTS speaker: {voice_key!r}"
        return True, ""
    elif backend == "gtts":
        if not HAS_GTTS:
            return False, "gTTS is not installed"
        return True, ""
    elif backend == "kokoro":
        if not HAS_KOKORO:
            return False, f"kokoro is not installed under {KOKORO_PYTHON}"
        if not KOKORO_VOICE_RE.match(voice_key or ""):
            return False, f"Not a Kokoro voice id: {voice_key!r}"
        return True, ""
    return False, f"Unknown backend: {backend!r}"


def save_sync(text: str, voice_key: str, speed: str, path, backend: str = "edge-tts",
             lang: str = "", use_cache: bool = True, normalize: bool = True,
             auto_fallback: bool = True, hifi: bool = False, **kwargs) -> None:
    """Blocking save — call via asyncio.to_thread from a route, never awaited
    directly (edge-tts's round trip plus two ffmpeg loudnorm passes is
    seconds of wall time; inline on the event loop it would stall every other
    request and the scheduler).

    `lang` drives gTTS's language when it's used — either as the requested
    backend or as the automatic fallback after edge-tts fails below. Passing
    it explicitly (rather than reading a "current language" global, as
    LinguaStudio did) is what keeps a failed German synthesis from silently
    falling back to Mandarin.

    use_cache:  Check/store in the SHA-256 TTS cache (default True).
    normalize:  Apply -18 LUFS normalization after generation (default True).
    hifi:       Keep the voice's own sample rate and encode at
                READ_ALOUD_BITRATE instead of the 24 kHz / 128k Anki-deck
                convention. Read-aloud and preview pass True; the vocab and
                Forvo paths must not, because a deck mixing human recordings
                with synthesis is filed at one spec (audio_provider.py).
    kwargs:     qwen3-tts only (model_key, language, instruct) — see
                _qwen_save_sync.
    """
    path = str(path)

    ok, reason = validate_voice(voice_key, backend)
    if not ok:
        raise ValueError(f"Voice validation failed: {reason}")

    ckey = cache_voice_key(voice_key, backend)

    if use_cache:
        cached = audio_cache.get(text, ckey, speed, cache_backend_key(backend))
        if cached:
            import shutil
            shutil.copy2(str(cached), path)
            return

    last_exc = None
    attempts = 2 if backend == "edge-tts" else 1
    for attempt in range(attempts):
        try:
            if backend == "edge-tts":
                _edge_save_sync(text, voice_key, speed, path)
            elif backend == "piper":
                _piper_save_sync(text, voice_key, path)
            elif backend == "qwen3-tts":
                _qwen_save_sync(text, voice_key, speed, path, **kwargs)
            elif backend == "gtts":
                _gtts_save_sync(text, lang, path)
            elif backend == "kokoro":
                _kokoro_save_sync(text, voice_key, path)
            else:
                raise ValueError(f"Unknown TTS backend: {backend}")
            last_exc = None
            break  # success
        except Exception as exc:
            last_exc = exc
            if attempt < attempts - 1:
                log.warning("TTS backend %s attempt %d failed (%s) — retrying",
                           backend, attempt + 1, exc)

    if last_exc is not None:
        if auto_fallback and backend != "gtts" and HAS_GTTS:
            log.warning("TTS backend %s failed after %d attempt(s) (%s) — falling back to gTTS",
                       backend, attempts, last_exc)
            _gtts_save_sync(text, lang, path)
        else:
            raise last_exc

    if not os.path.exists(path) or os.path.getsize(path) == 0:
        return

    # A WAV backend that fell through to gTTS above already wrote an mp3.
    wrote_wav = backend in _WAV_BACKENDS and last_exc is None

    if normalize:
        import tempfile as _tf
        tmp = _tf.NamedTemporaryFile(suffix=".mp3", delete=False)
        tmp.close()
        if hifi:
            ok = audio_normalizer.normalize_lufs(path, tmp.name,
                                                 sample_rate=_source_sample_rate(path),
                                                 bitrate=READ_ALOUD_BITRATE)
        else:
            ok = audio_normalizer.normalize_lufs(path, tmp.name)
        if ok:
            import shutil
            shutil.move(tmp.name, path)
        else:
            log.warning("audio_normalizer: normalization failed for %s — "
                       "ffmpeg missing or file corrupt", path)
            try:
                os.unlink(tmp.name)
            except OSError:
                pass
            if wrote_wav:
                _encode_mp3(path, hifi)
    elif wrote_wav:
        _encode_mp3(path, hifi)

    if use_cache and os.path.exists(path) and os.path.getsize(path) > 0:
        try:
            audio_cache.put(text, ckey, speed, cache_backend_key(backend), path)
        except Exception:
            pass


def _source_sample_rate(path: str) -> int | None:
    """The source's own rate, pinned explicitly rather than left to ffmpeg.

    Leaving `-ar` off does NOT mean "keep the rate": loudnorm resamples to
    192 kHz internally, and in dynamic mode (which `linear=true` silently
    falls back to when pass 1 measures out of range — a short clip does it
    routinely) the encoder then lands on 48 kHz. A 22.05 kHz piper voice came
    out upsampled to 48 kHz for a one-sentence read and stayed at 22.05 kHz
    for a longer one, which is not a property anything should have.

    This read WAV headers only, so it answered None for edge-tts and gTTS —
    which hand back mp3 — and those two went straight back to being decided
    by which loudnorm path happened to run: measured live, a 24 kHz edge
    clip came out at 48 kHz and a 24 kHz gTTS clip at 24 kHz, from the same
    code. ffprobe covers every container the backends produce."""
    try:
        with wave.open(path) as w:
            return w.getframerate()
    except Exception:
        pass
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "a:0",
             "-show_entries", "stream=sample_rate", "-of", "default=nw=1:nk=1", path],
            capture_output=True, timeout=20)
        return int(r.stdout.decode().strip().splitlines()[0])
    except Exception:
        return None


def _encode_mp3(path: str, hifi: bool = False) -> None:
    """Encode a WAV in place to mp3 at `path`. Only reached when loudnorm is
    off or failed — without it a WAV backend would leave WAV bytes behind a
    .mp3 name, which every caller here base64s straight into an <audio>
    tagged audio/mpeg."""
    tmp = path + ".enc.mp3"
    rate = () if hifi else ("-ar", "24000")
    result = subprocess.run(
        ["ffmpeg", "-y", "-loglevel", "error", "-i", path, "-codec:a", "libmp3lame",
         "-b:a", READ_ALOUD_BITRATE if hifi else "128k", *rate, "-ac", "1", tmp],
        capture_output=True)
    if result.returncode != 0:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise RuntimeError("ffmpeg conversion failed: "
                           + result.stderr.decode(errors="replace")[-400:])
    os.replace(tmp, path)


# ── Read-aloud auto-pick (reading-companion's Speaker, routers/tts.py's /speak) ──

def pick_read_aloud_backend(lang_code: str | None) -> str:
    """Auto-select a TTS backend for long-form read-aloud, given a language
    code. Empty defaults to English — reading-companion's plain Read aloud
    (unlike lingua-workspace's dual reader) has no language signal at all,
    and the vault's own notes/articles are overwhelmingly English, so
    treating "" as anything other than English here would silently pick a
    Mandarin voice for an ordinary English note (see the "_en" table above).

    Piper is preferred when a curated voice exists for the resolved
    language — once its model is cached on disk it's a local CPU call with
    no per-chunk network round trip, which is what chapter-length
    read-aloud actually wants (a remote edge-tts call every few seconds
    reads as stutter, not quality). Falls back to edge-tts, then gTTS —
    save_sync's own auto_fallback already re-tries in this same order if
    the picked backend fails at synthesis time, so a missing/broken piper
    voice degrades gracefully rather than going silent."""
    lang_code = (lang_code or "eng").strip().lower()
    if HAS_PIPER and piper_voice_for_lang(lang_code):
        return "piper"
    if HAS_EDGE_TTS:
        return "edge-tts"
    if HAS_GTTS:
        return "gtts"
    return "edge-tts"  # no backend installed — save_sync raises a clear error


def default_voice_for(backend: str, lang_code: str | None) -> str:
    """The voice_key save_sync needs to go with an auto-picked backend."""
    lang_code = (lang_code or "eng").strip().lower()
    if backend == "piper":
        return piper_lang_key(lang_code)
    if backend == "kokoro":
        return kokoro_voice_for_lang(lang_code)
    if backend == "edge-tts":
        if lang_code in ("eng", "en"):
            return EDGE_DEFAULT_ENGLISH
        # Take the first voice that is ACTUALLY in the requested language, not
        # simply the first voice returned. edge_voices_for_lang() falls back to
        # the whole table for a language it has no voices for (deliberately —
        # it also backs the picker), and entry zero of that table is Mandarin.
        # Taking it blindly is why Hungarian was read aloud by
        # zh-CN-YunxiNeural and why /tts/speak returned byte-identical audio
        # for hu and zh.
        voices = edge_voices_for_lang(lang_code)
        iso1 = _ISO3_TO_ISO1.get(lang_code, lang_code)[:2]
        for v in voices:
            if str(v.get("shortName", "")).lower().startswith(iso1 + "-"):
                return v["id"]
        # Nothing in this language: English is a defensible "read it anyway".
        return EDGE_DEFAULT_ENGLISH
    return lang_code
