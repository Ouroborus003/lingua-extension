"""Vault sidecar — the second client (spec §5). All logic lives here;
Obsidian renders and captures. Run: uvicorn app.main:app --port 8749
"""
from __future__ import annotations

import asyncio
import contextlib
import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import llm, scheduler, services as services_mod
from .config import config
from .routers import (ai, anki, audio, audiobook, boox, capture, companion, coursework, generate,
                      gloss, health, library, lingua, ocr, pdf, services, sidebar_chat,
                      searxng_sites, translate, tts, vocab, vocab_audio, whisper, smart)

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(name)s %(levelname)s %(message)s")


@contextlib.asynccontextmanager
async def lifespan(app: FastAPI):
    # Open the offline dictionaries before anyone asks. Off the event loop and
    # fire-and-forget: a slow or missing dictionary must not delay startup, and
    # a lookup arriving first still works, it just pays the open itself.
    async def _warm():
        try:
            from . import settings as _s, translate as _t
            n = await asyncio.to_thread(_t.warm_stardicts, _s.effective())
            if n:
                logging.getLogger("sidecar").info("warmed %d offline dictionaries", n)
        except Exception as e:              # noqa: BLE001 — never block startup
            logging.getLogger("sidecar").warning("dictionary warm-up skipped: %s", e)

    warm = asyncio.create_task(_warm())
    task = asyncio.create_task(scheduler.loop())
    yield
    warm.cancel()
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await task
    services_mod.stop_all()   # never orphan a supervised engine


app = FastAPI(title="Vault Sidecar", lifespan=lifespan)

# Obsidian's renderer origins, and only those.
#
# Every other plugin call reaches this service through obsidian.requestUrl,
# which is a main-process fetch and never sends an Origin — so nothing here
# needed CORS until the chat panel started streaming. Streaming has to use the
# renderer's own fetch (requestUrl resolves once, with the whole body; there is
# no way to read it as it arrives), and that request *is* subject to CORS.
#
# Enumerated rather than "*". The sidecar binds to localhost, but a page in an
# ordinary browser can still reach 127.0.0.1, and "*" would let any website the
# operator has open POST to a service that reads and writes their vault. These
# two are the scheme Electron serves Obsidian from on desktop and mobile.
# 127.0.0.1:8888 is the local SearXNG: its Preferences page's "My sites" card
# edits the engine's site list from the browser, so the search origin needs
# POST/DELETE here too (DELETE is browser-preflighted like any other method).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["app://obsidian.md", "capacitor://localhost",
                   "http://127.0.0.1:8888", "http://localhost:8888"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type"],
)

for r in (health, generate, ai, anki, boox, capture, coursework, library, lingua,
          services, companion, translate, audio, ocr, pdf, tts, vocab, vocab_audio, whisper,
          sidebar_chat, gloss, smart, searxng_sites, audiobook):
    app.include_router(r.router)


@app.exception_handler(llm.LLMOffline)
async def _llm_offline(request: Request, exc: llm.LLMOffline) -> JSONResponse:
    """One answer for "the model isn't running", for every AI route at once.

    The alternative was teaching each router to recognise it, and there are
    seven of them across four plugins (chat, translate, cloze, identify, tags,
    digests, tag review) — they would have drifted. `code` is the contract the
    plugins match on so the prompt never depends on the wording of `detail`.
    """
    return JSONResponse(status_code=503,
                        content={"detail": str(exc), "code": "llm_offline"})


def run() -> None:
    import uvicorn
    uvicorn.run("app.main:app", host=config.server.host, port=config.server.port)


if __name__ == "__main__":
    run()
