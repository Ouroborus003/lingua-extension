"""whisper_engine.py — local speech-to-text via faster-whisper (CTranslate2),
mirroring tts_engine.py's shape: a guarded import, a lazy model singleton,
and a single blocking entry point the router calls via asyncio.to_thread.

Phase 1 only covers "transcribe an audio file/clip into text" (routers/
whisper.py's POST /whisper/transcribe) — lingua-workspace's Tools tab, for
turning a downloaded podcast/listening clip into study text. Two things are
explicitly NOT built here, and shouldn't be until a phase-2 slice asks for
them: live microphone capture (needs a browser mic-recording UI —
getUserMedia/MediaRecorder — that has no precedent anywhere in this vault's
plugins yet) and target-sentence comparison/scoring for pronunciation
practice (a distinct grading feature, not a transcription one). Both need
real design work this phase didn't scope.

Backend choice: faster-whisper over openai-whisper. It wraps the same
Whisper weights in CTranslate2 instead of PyTorch — CPU-viable without a
mandatory torch dependency (openai-whisper pulls in full PyTorch; faster-
whisper's only native dependencies are ctranslate2, av, and onnxruntime,
already the size class piper-tts is in) — and is meaningfully faster on CPU
at the same quality, which is what "reasonable CPU latency" here means in
practice: a live run of a 6.4s clip on this machine transcribed in ~8.5s at
compute_type="int8" (see the commit message for the full cold/warm numbers).

Model size: "small" (multilingual) by default — see MODEL_SIZES. "tiny"/
"base" are faster but noticeably worse on non-English (this vault runs five
languages live); "medium"/"large*" are GPU territory, out of scope per the
operator's own ceiling for this phase. Configurable via Settings.md's
whisper_model_size (see settings.py's OVERLAY) down to "tiny" for a slower
machine, or up to "medium" for one that can afford it.

Device: hardcoded to CPU, not auto-detected, even though this machine has a
GPU (RTX 5060). Confirmed live: `WhisperModel(..., device="auto")`
constructs without error (ctranslate2 sees the CUDA device), but the first
real transcribe() call fails with "Library libcublas.so.12 is not found or
cannot be loaded" — the GPU has no CUDA runtime installed system-wide (no
sudo, same bar TTS/OCR were held to), so the failure is silent at load time
and only surfaces on the first real request. Catching that class of error
after the fact (unload the GPU model, rebuild on CPU, retry) is exactly the
kind of speculative infrastructure CLAUDE.md says not to build ahead of a
milestone that needs it — nothing here asked for GPU accel, only for CPU to
never be blocked on it. If a future session wants GPU transcription, wire a
whisper_device setting and re-add the auto/cuda path then, once cuDNN/cuBLAS
are actually part of this machine's setup story.
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path

from .config import STATE_DIR

log = logging.getLogger("sidecar.whisper_engine")

try:
    from faster_whisper import WhisperModel
    HAS_FASTER_WHISPER = True
except ImportError:
    HAS_FASTER_WHISPER = False

MODEL_DIR = STATE_DIR / "whisper_models"

# tiny/base/small/medium only — large* needs a GPU to be usable at all, which
# this phase deliberately doesn't require (see module docstring). Keep this
# tuple and settings.py's whisper_model_size _choice(...) in sync — a
# mismatch here is the exact ERR-165 class of bug (a value the UI offers
# that the engine then rejects).
MODEL_SIZES = ("tiny", "base", "small", "medium")
DEFAULT_MODEL_SIZE = "small"

_model_cache: dict[str, "WhisperModel"] = {}
_lock = threading.Lock()


def available() -> bool:
    return HAS_FASTER_WHISPER


def _get_model(model_size: str) -> "WhisperModel":
    """Lazy singleton per model size — downloads into MODEL_DIR (gitignored,
    same STATE_DIR area piper's voices and the TTS cache already use) via
    faster-whisper's own huggingface_hub-backed fetch the first time this
    size is requested, then keeps the loaded model resident."""
    if not HAS_FASTER_WHISPER:
        raise RuntimeError("faster-whisper not installed. Run: pip install faster-whisper")
    if model_size not in MODEL_SIZES:
        raise ValueError(f"Unknown whisper model size: {model_size!r} "
                         f"(expected one of {MODEL_SIZES})")
    with _lock:
        if model_size in _model_cache:
            return _model_cache[model_size]
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        model = WhisperModel(model_size, device="cpu", compute_type="int8",
                             download_root=str(MODEL_DIR))
        _model_cache[model_size] = model
        return model


def _timestamp(seconds: float, *, comma: bool) -> str:
    """seconds -> "HH:MM:SS.mmm" (vtt) or "HH:MM:SS,mmm" (srt). Whisper's
    segment boundaries are floats that can land a hair past the true
    millisecond (e.g. 1.2000000000000002); round instead of truncating so
    cues don't drift a tick early against the audio."""
    total_ms = round(seconds * 1000)
    hh, rem = divmod(total_ms, 3_600_000)
    mm, rem = divmod(rem, 60_000)
    ss, ms = divmod(rem, 1_000)
    sep = "," if comma else "."
    return f"{hh:02d}:{mm:02d}:{ss:02d}{sep}{ms:03d}"


def to_vtt(segments: list[dict]) -> str:
    """Whisper `segments` ([{start, end, text}, ...]) -> a WebVTT file.

    This is the seam that hands lingua-workspace's Tools-tab transcription
    to Mira's existing manual subtitle loader (mira_universal_subs.js's 📄
    button reads a local .srt/.vtt/.ass file for a video with no native
    subs) — no changes needed on the extension side, it already accepts a
    file in this exact format.
    """
    lines = ["WEBVTT", ""]
    for seg in segments:
        start = _timestamp(seg["start"], comma=False)
        end = _timestamp(seg["end"], comma=False)
        text = seg["text"].strip()
        lines.append(f"{start} --> {end}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


def to_srt(segments: list[dict]) -> str:
    """Same segments -> SubRip (.srt): 1-based cue numbers, comma decimal."""
    lines = []
    for i, seg in enumerate(segments, start=1):
        start = _timestamp(seg["start"], comma=True)
        end = _timestamp(seg["end"], comma=True)
        text = seg["text"].strip()
        lines.append(str(i))
        lines.append(f"{start} --> {end}")
        lines.append(text)
        lines.append("")
    if not lines:
        return ""
    return "\n".join(lines).rstrip("\n") + "\n"


def transcribe(audio_path: str | Path, language: str | None = None,
              model_size: str = "") -> dict:
    """Blocking transcription — call via asyncio.to_thread from a route,
    never awaited directly (model load + CPU inference is real wall time,
    same reasoning as tts_engine.save_sync).

    Returns {ok, text, language, language_probability, segments} on success,
    {ok: False, error} on any failure (missing/corrupt file, unknown model
    size, faster-whisper not installed) — never raises, so the router's job
    is just to pass the dict through, matching the shape the router spec
    asks for rather than tts_engine's raise-and-let-the-router-catch style.

    `language` is an ISO-639-1 code (e.g. "en", "de") or None/"" to let
    Whisper auto-detect from the first 30s of audio. `segments` is
    [{start, end, text}, ...] in playback order — not surfaced in the
    Tools-tab UI this phase, but cheap to include (the model already
    produces them) and is exactly what a future target-sentence-timing
    phase 2 would need without a second engine change.
    """
    model_size = model_size or DEFAULT_MODEL_SIZE
    audio_path = str(audio_path)
    if not Path(audio_path).exists():
        return {"ok": False, "error": f"audio file not found: {audio_path}"}
    try:
        model = _get_model(model_size)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    try:
        segments_iter, info = model.transcribe(audio_path, language=language or None)
        segments = [{"start": s.start, "end": s.end, "text": s.text} for s in segments_iter]
    except Exception as exc:
        # PyAV raising on a corrupt/empty/non-audio file lands here too —
        # av's exception types vary by what's wrong with the container, so
        # this is deliberately a broad catch rather than naming them.
        return {"ok": False, "error": f"transcription failed: {exc}"}
    text = "".join(s["text"] for s in segments).strip()
    return {
        "ok": True, "text": text, "language": info.language,
        "language_probability": info.language_probability,
        "segments": segments, "model_size": model_size,
    }
