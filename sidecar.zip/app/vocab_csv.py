"""The single vocabulary record: one CSV per language (spec §10 rewrite).

The vault used to store one markdown note per word under
`01 Notes/linguistics/Vocab/`. That was rejected: a 299-byte note still costs a
4096-byte block, so the cost is file COUNT not content, and thousands of
frontmatter-only notes degrade search, the tree and the graph for the whole
vault. One CSV per language replaces them.

This module is the ONLY writer. That concentration is deliberate — it also
concentrates the risk, so every guard below exists because losing this file
loses the word list outright:

  - `read` raises on a corrupt file rather than returning a partial list, and
    `upsert`/`patch` abort on that raise. We cannot rebuild this file from
    anything else, so a parse error must stop the write, never start from an
    empty list.
  - Writes go through a temp file + `os.replace`, so a crash cannot truncate
    the file mid-write.
  - `upsert` merges on `term` and never clobbers a non-empty field with an
    empty one — a capture that knows only the term must not wipe a sentence we
    already had.
  - `snapshot(lang)` zstd-compresses the known-good state to
    `08 Meta/Study/.backups/` BEFORE each day's first write. That snapshot is
    both the operator's backup and the archival format.

Columns deliberately ABSENT: `reading`, `gloss`, `traditional`. Those belong to
the dictionary and are joined at read time (a stored gloss goes stale the
moment the dictionary is corrected). `frequency_rank` is the one stored
exception — it comes from a static list and is treated as a cache with a
refresh path, not authored data.
"""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import io
import json
import logging
import os
import re
import tempfile
from pathlib import Path

import zstandard as zstd

from . import constants
from .config import config
from .lang import base_lang

log = logging.getLogger("sidecar.vocab_csv")

# The columns, in order. This IS the schema. `language` is the base code the
# file is grouped by; `note` is an optional [[wikilink]] for the rare word worth
# prose (only the promote-to-note path writes it).
COLUMNS = [
    "term", "language", "sentence", "source", "first_seen", "last_seen",
    "seen_count", "lookup_count", "saved_count", "produced_count",
    "involvement", "status_receptive", "status_productive", "ignored",
    "synonyms", "derived_from", "contrasts", "collocates", "audio", "image",
    "exported_anki", "anki_note_ids", "tags", "frequency_rank", "note",
]

# The relationship families and other list-valued columns are serialised as
# JSON arrays in their cell; the CSV module still owns the quoting of the cell
# itself (RFC-4180 — terms and sentences contain commas, quotes and newlines).
LIST_COLUMNS = frozenset({
    "synonyms", "derived_from", "contrasts", "collocates", "anki_note_ids", "tags",
})

# The four relationship columns (spec §10 rewrite, Stage 9). `synonyms` and
# `contrasts` have no direction — a synonym relation written on only one side
# would draw as half an edge in a relationship graph — so `relate()` writes
# both rows. `derived_from` (compound -> component/etymon) and `collocates`
# are directional: recording it on `a` says nothing about `b`.
SYMMETRIC_RELATIONS = frozenset({"synonyms", "contrasts"})
DIRECTIONAL_RELATIONS = frozenset({"derived_from", "collocates"})
RELATION_COLUMNS = SYMMETRIC_RELATIONS | DIRECTIONAL_RELATIONS
BOOL_COLUMNS = frozenset({"ignored", "exported_anki"})
INT_COLUMNS = frozenset({
    "seen_count", "lookup_count", "saved_count", "produced_count", "involvement",
    "frequency_rank",
})

STUDY_DIR = constants.STUDY
BACKUP_SUBDIR = ".backups"

_MAX_DAILY = 30
_MAX_MONTHLY = 12


class VocabError(Exception):
    pass


class TermMissingError(VocabError):
    """A term that is not (yet) in the CSV. Subclassed so the route can map it
    to 404 — a missing term is the caller asking for something that is not on
    record, not a malformed request like a bad family or a self-relation."""
    pass


def bucket_key(lang: str) -> str:
    """The CSV storage bucket for a language code.

    Deliberately NOT `base_lang()`: that fold is right for MATCHING a vocab
    note against an inventory (where yue, cmn and zh-hans are all "Chinese")
    but wrong as a STORAGE bucket. Cantonese is its own language, not a
    Mandarin script variant — flashcards-workspace already decides this and
    documents it at main.js:81-89 — so yue (and wuu, the same category) stay
    distinct instead of collapsing into zh. An empty/unknown language maps to
    `und`, the convention the sidecar's own audio filenames already use, so a
    word captured off an unmapped-language page is recorded instead of dropped.
    """
    code = (lang or "").strip().lower()
    if not code:
        return "und"
    head = code.split("-")[0]
    if head in ("yue", "wuu"):
        return head
    return base_lang(code)


def _lang_key(lang: str) -> str:
    """The safe filename component, or refuse the write."""
    key = bucket_key(lang)
    if not re.fullmatch(r"[a-z0-9]+", key):
        raise VocabError(f"refusing unsafe language key {key!r}")
    return key


def path(lang: str) -> str:
    """Vault-relative path of the CSV for a language."""
    return f"{STUDY_DIR}/Vocabulary — {_lang_key(lang)}.csv"


def _abs(lang: str) -> Path:
    return config.vault_path / path(lang)


def _backup_dir() -> Path:
    return config.vault_path / STUDY_DIR / BACKUP_SUBDIR


def known_languages() -> list[str]:
    """The language keys that have a vocabulary CSV on disk, sorted.

    Used by the scheduler to regenerate the relationship graphs for every
    language that has a word list, rather than hardcoding a language list that
    would drift from the files."""
    d = config.vault_path / STUDY_DIR
    if not d.exists():
        return []
    keys = []
    for p in d.glob("Vocabulary — *.csv"):
        m = re.match(r"Vocabulary — ([a-z0-9]+)\.csv$", p.name)
        if m:
            keys.append(m.group(1))
    return sorted(set(keys))


def _backup_path(lang: str, date_iso: str) -> Path:
    return _backup_dir() / f"Vocabulary — {_lang_key(lang)}.{date_iso}.csv.zst"


def _serialize(col: str, val) -> str:
    if col in LIST_COLUMNS:
        if val is None:
            return ""
        if isinstance(val, str):
            return val.strip()
        lst = list(val)
        return json.dumps(lst, ensure_ascii=False) if lst else ""
    if col in BOOL_COLUMNS:
        return "true" if val else ""
    if col in INT_COLUMNS:
        return str(int(val)) if val else ""
    return str(val) if val is not None else ""


def _deserialize(col: str, cell: str):
    cell = (cell or "").strip()
    if col in LIST_COLUMNS:
        if not cell:
            return []
        try:
            v = json.loads(cell)
            return v if isinstance(v, list) else [v]
        except json.JSONDecodeError:
            return [cell]  # tolerate a hand-edited bare value
    if col in BOOL_COLUMNS:
        return cell.lower() in ("true", "1", "yes")
    if col in INT_COLUMNS:
        try:
            return int(cell)
        except ValueError:
            return 0
    return cell


def _merge(existing: dict, incoming: dict) -> dict:
    """Merge `incoming` over `existing` on the serialised-empty rule: a field
    that serialises to "" is "unknown" and never clobbers a non-empty one."""
    out = dict(existing)
    for col in COLUMNS:
        if col not in incoming:
            continue
        if _serialize(col, incoming[col]) == "":
            continue
        out[col] = incoming[col]
    return out


def read(lang: str) -> list[dict]:
    """Rows sorted by `term`. `[]` when the file does not exist; a corrupt or
    structurally wrong file RAISES rather than returning a partial read — this
    is the guard that keeps a failed parse from being treated as an empty list
    and overwriting the whole word list."""
    p = _abs(lang)
    if not p.exists():
        return []
    try:
        with p.open("r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            header = next(reader, None)
            if header is None:
                return []  # empty file, nothing recorded yet
            if header != COLUMNS:
                raise VocabError(
                    f"corrupt header in {p}: expected {COLUMNS}, got {header}")
            rows = []
            for raw in reader:
                if not raw:
                    continue
                if len(raw) != len(COLUMNS):
                    raise VocabError(
                        f"corrupt row in {p}: {len(raw)} fields, expected "
                        f"{len(COLUMNS)}")
                rows.append({c: _deserialize(c, raw[i])
                             for i, c in enumerate(COLUMNS)})
    except VocabError:
        raise
    except Exception as e:  # noqa: BLE001 — any read failure must abort the write
        raise VocabError(f"refusing to read vocab csv {p}: {e}") from e
    rows.sort(key=lambda r: str(r.get("term") or ""))
    return rows


def _render(rows: list[dict]) -> bytes:
    rows = sorted(rows, key=lambda r: str(r.get("term") or ""))
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(COLUMNS)
    for r in rows:
        w.writerow([_serialize(c, r.get(c)) for c in COLUMNS])
    return buf.getvalue().encode("utf-8")


def _write(lang: str, rows: list[dict]) -> None:
    """Atomic write: temp file in the same directory, then os.replace.

    Byte-identical content is left alone (the write_generated pattern): a
    re-save of an already-known word must not dirty git or churn the file's
    mtime when nothing actually changed."""
    p = _abs(lang)
    content = _render(rows)
    if p.exists() and p.read_bytes() == content:
        log.debug("vocab %s unchanged — left alone", path(lang))
        return
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=".vocab-", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
        os.replace(tmp, p)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise
    log.info("wrote %d vocab rows to %s", len(rows), path(lang))


def snapshot(lang: str) -> str | None:
    """Compress the CURRENT on-disk CSV into today's zstd snapshot, once.

    Called BEFORE a write, so it always captures a state that was known good.
    Returns the backup path, or None when there is nothing to snapshot (no file
    yet) or today's snapshot already exists."""
    p = _abs(lang)
    if not p.exists():
        return None
    today = dt.date.today().isoformat()
    bp = _backup_path(lang, today)
    if bp.exists():
        return str(bp)
    bp.parent.mkdir(parents=True, exist_ok=True)
    cctx = zstd.ZstdCompressor(level=3)
    bp.write_bytes(cctx.compress(p.read_bytes()))
    _prune(lang)
    log.info("snapshotted %s", path(lang))
    return str(bp)


def _prune(lang: str) -> None:
    """Keep the newest ~30 daily snapshots plus one per month (capped at ~12)."""
    d = _backup_dir()
    if not d.exists():
        return
    files: list[tuple[str, Path]] = []
    for f in d.glob(f"Vocabulary — {_lang_key(lang)}.*.csv.zst"):
        m = re.search(r"(\d{4}-\d{2}-\d{2})\.csv\.zst$", f.name)
        if m:
            files.append((m.group(1), f))
    files.sort(key=lambda t: t[0], reverse=True)  # newest first
    keep: set[Path] = set()
    for _, p in files[:_MAX_DAILY]:
        keep.add(p)
    monthly: list[tuple[str, Path]] = []
    for date_s, p in files[_MAX_DAILY:]:
        month = date_s[:7]
        if not monthly or monthly[-1][0] != month:
            monthly.append((month, p))
    for _, p in monthly[:_MAX_MONTHLY]:
        keep.add(p)
    for _, p in files:
        if p not in keep:
            with contextlib.suppress(OSError):
                p.unlink()


def upsert(lang: str, row: dict) -> tuple[bool, dict]:
    """Merge `row` into the language's CSV on `term`. Returns `(created, row)`.

    Never clobbers a non-empty field with an empty one; snapshots the known-good
    state first; writes atomically. A failed read aborts without writing."""
    if not isinstance(row, dict):
        raise VocabError("row must be a mapping")
    term = str(row.get("term") or "").strip()
    if not term:
        raise VocabError("term is required")
    for key in row:
        if key not in COLUMNS:
            raise VocabError(f"unknown column {key!r}")
    key = _lang_key(lang)

    rows = read(lang)  # raises on corrupt -> abort, no write
    by_term = {str(r.get("term") or ""): r for r in rows}
    created = term not in by_term
    merged = _merge(by_term.get(term, {}), row)
    merged["term"] = term
    merged["language"] = key
    # First capture records the date; a re-capture must not move it.
    if created and _serialize("first_seen", merged.get("first_seen")) == "":
        merged["first_seen"] = dt.date.today().isoformat()
    by_term[term] = merged

    snapshot(lang)
    _write(lang, list(by_term.values()))
    return created, merged


def patch(lang: str, term: str, fields: dict) -> dict | None:
    """Overwrite the named fields of `term`'s row (deliberate update, so it may
    set a field to empty — unlike upsert's merge guard). Returns the patched
    row, or None when the term is absent. `term` may not be patched."""
    term = str(term or "").strip()
    if not term:
        raise VocabError("term is required")
    if not isinstance(fields, dict):
        raise VocabError("fields must be a mapping")
    if "term" in fields:
        raise VocabError("term is the key and may not be patched")
    for key in fields:
        if key not in COLUMNS:
            raise VocabError(f"unknown column {key!r}")

    rows = read(lang)  # raises on corrupt -> abort, no write
    for r in rows:
        if str(r.get("term") or "") == term:
            for k, v in fields.items():
                r[k] = v
            snapshot(lang)
            _write(lang, rows)
            return r
    return None


def relate(lang: str, a: str, b: str, family: str, add: bool = True) -> tuple[dict, dict | None]:
    """Link (or with `add=False`, unlink) two terms under one relationship
    family. Returns `(a's row, b's row or None)` — `b`'s row is only returned
    when the family is symmetric, since that is the only case it changed.

    Refuses a `family` that is not one of the four relationship columns, or
    either term being absent from the CSV: the reason to call this instead of
    `patch()` is that it cannot create a dangling reference a graph view would
    draw as an edge to nowhere. Idempotent — relating the same pair twice
    leaves a single entry, and unlinking a pair that was never linked is a
    no-op rather than an error."""
    if family not in RELATION_COLUMNS:
        raise VocabError(f"not a relationship column {family!r}")
    a = str(a or "").strip()
    b = str(b or "").strip()
    if not a or not b:
        raise VocabError("both terms are required")
    if a == b:
        raise VocabError("a term cannot relate to itself")

    rows = read(lang)  # raises on corrupt -> abort, no write
    by_term = {str(r.get("term") or ""): r for r in rows}
    if a not in by_term:
        raise TermMissingError(f"no term {a!r} in {lang!r}")
    if b not in by_term:
        raise TermMissingError(f"no term {b!r} in {lang!r}")

    def _toggle(row: dict, other: str) -> None:
        cur = list(row.get(family) or [])
        if add:
            if other not in cur:
                cur.append(other)
        else:
            cur = [t for t in cur if t != other]
        row[family] = cur

    _toggle(by_term[a], b)
    symmetric = family in SYMMETRIC_RELATIONS
    if symmetric:
        _toggle(by_term[b], a)

    snapshot(lang)
    _write(lang, list(by_term.values()))
    return by_term[a], (by_term[b] if symmetric else None)
