from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..generators import (agenda, canvas_maps, dashboard,
                          project_state, responsibilities, training)
from ..ingest import jobsfair

router = APIRouter(prefix="/generate", tags=["generate"])


@router.post("/dashboard")
def gen_dashboard():
    return {"path": dashboard.generate()}


@router.post("/responsibilities")
def gen_responsibilities():
    return {"path": responsibilities.generate()}


@router.post("/agenda")
def gen_agenda():
    return {"path": agenda.generate()}


@router.post("/canvas-maps")
def gen_canvas_maps(domain: str | None = None):
    return canvas_maps.stage(domain)


@router.post("/states")
def gen_states(project: str | None = None):
    return {"paths": project_state.generate(project)}


@router.post("/training")
def gen_training():
    return {"path": training.generate()}


@router.post("/jobs")
def gen_jobs():
    return {"path": jobsfair.write_feed()}
