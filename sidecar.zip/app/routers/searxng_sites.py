"""The operator's own search sites for the local SearXNG instance.

The "My sites" card in SearXNG's Preferences page talks to these routes.
The file they edit — ~/.config/searxng/my-sites.yml — is the single source
of truth: mysites.py (the engine in the SearXNG tree) re-reads it on every
mtime change, so a save here takes effect on the next search with no
restart. The sidecar owns writes because the file must be editable from the
browser while the search service itself runs as the unprivileged `searxng`
user — a cross-user handoff is exactly what this service is for.

The route is thin; the rules live in pure functions so the suite can hold
them without a running service.
"""

from __future__ import annotations

import logging
import os
import re
import tempfile
from pathlib import Path

import yaml
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

log = logging.getLogger("sidecar.searxng_sites")

router = APIRouter(prefix="/searxng/sites", tags=["searxng_sites"])

# NOT under ~/.config. The SearXNG engine that reads this file runs as the
# unprivileged `searxng` user, and /home/brandon is drwx------ — searxng cannot
# even traverse into it, let alone read a 0600 file. The feature was installed
# with the list in ~/.config and the engine logged "no sites configured" on
# every search: it was reading a path it could never reach, and reported that
# as an empty list rather than as a permission error.
#
# /var/lib/searxng-mysites is owned brandon:searxng and mode 2750. The SETGID
# bit is the load-bearing part: brandon is not a member of group searxng, so a
# plain chgrp would be refused, but a file created inside a setgid directory
# inherits the DIRECTORY's group regardless of its creator. That is what lets
# the sidecar (brandon) keep writing it and the engine (searxng) keep reading
# it, with neither one granted access to the other's home.
SITES_PATH = Path("/var/lib/searxng-mysites/my-sites.yml")

# A site is a domain, optionally with a path narrowing it (example.org/docs).
# No scheme — the engine applies `site:` to whatever is stored, and a scheme
# in a `site:` filter silently matches nothing.
_SITE_RE = re.compile(r"^[a-z0-9-]+(\.[a-z0-9-]+)+(:\d+)?(/[^\s]*)?$")
_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9 ._-]{0,40}$")
MAX_SITES = 50


class SiteBody(BaseModel):
    name: str
    site: str


def validate_entry(name: str, site: str) -> str:
    """Returns an error string, or "" when the entry is acceptable."""
    name = (name or "").strip()
    site = (site or "").strip().lower()
    if not name:
        return "a label is required"
    if not _NAME_RE.match(name):
        return "label: letters, digits, spaces, . _ - only"
    if site.startswith(("http://", "https://")) or "/" == site[:1]:
        return "domain only, no scheme (e.g. example.org or docs.example.org/guide)"
    if not _SITE_RE.match(site):
        return "not a domain (e.g. example.org)"
    return ""


def load_sites(path: Path = SITES_PATH) -> list[dict[str, str]]:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError:
        return []
    sites = data.get("sites") or []
    return [s for s in sites
            if isinstance(s, dict) and s.get("name") and s.get("site")]


def save_sites(sites: list[dict[str, str]], path: Path = SITES_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = yaml.safe_dump({"sites": sites}, sort_keys=False,
                             allow_unicode=True)
    # Atomic: the engine reads this file on every mtime change, and a search
    # landing mid-write must see the old list or the new one, never a half
    # file (yaml.safe_load on a truncated document is a hard error there).
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(payload)
    # mkstemp creates 0600 and os.replace PRESERVES the temp file's mode, so
    # without this every save would silently re-lock the file against the
    # engine — one chmod on the existing file would have been undone by the
    # next edit. The group comes from the setgid directory, so only the mode
    # needs setting here.
    os.chmod(tmp, 0o640)
    os.replace(tmp, path)


@router.get("")
def list_sites():
    return {"sites": load_sites(SITES_PATH)}


@router.post("")
def add_site(body: SiteBody):
    name = body.name.strip()
    site = body.site.strip().lower()
    err = validate_entry(name, site)
    if err:
        raise HTTPException(422, err)
    sites = load_sites(SITES_PATH)
    if any(s["site"] == site for s in sites):
        raise HTTPException(409, f"{site} is already in the list")
    if any(s["name"].lower() == name.lower() for s in sites):
        raise HTTPException(409, f"a site labelled {name!r} already exists")
    if len(sites) >= MAX_SITES:
        raise HTTPException(422, f"the list is capped at {MAX_SITES} sites")
    sites.append({"name": name, "site": site})
    save_sites(sites, SITES_PATH)
    return {"sites": sites}


@router.delete("/{name}")
def remove_site(name: str):
    sites = load_sites(SITES_PATH)
    kept = [s for s in sites if s["name"] != name]
    if len(kept) == len(sites):
        raise HTTPException(404, f"no site labelled {name!r}")
    save_sites(kept, SITES_PATH)
    return {"sites": kept}
