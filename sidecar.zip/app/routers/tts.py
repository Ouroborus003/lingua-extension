"""tts.py — neural voice synthesis for lingua-workspace's TTS tab.

Ported from LinguaStudio's `sidecar/server.py` TTS routes and
`generator_api.preview_voice`. The point of the port: the vault sidecar now
does edge-tts synthesis itself, so the TTS tab (voice list, Preview, cache
management) no longer needs the separate LinguaStudio process running —
only main.js's base URL changed, these response shapes match what it
already parses (ttsVoiceId/ttsVoiceLabel/ttsAudioB64).
"""
from __future__ import annotations

import asyncio
import base64
import os
import tempfile

from fastapi import APIRouter
from pydantic import BaseModel

from .. import audio_cache, tts_engine

router = APIRouter(prefix="/tts", tags=["tts"])


_ENGINE_TO_BACKEND = {"edge": "edge-tts", "edge-tts": "edge-tts", "piper": "piper",
                      "gtts": "gtts", "kokoro": "kokoro"}


@router.get("/voices")
async def tts_voices(engine: str = "edge", lang: str = ""):
    """Voices for `lang` on the given engine -> [{id, shortName, locale, gender}].

    `id` is the value save_sync()/validate_voice() require for that engine's
    backend, not necessarily a raw provider ID — edge-tts's ERR-165 was
    exactly the display-name/ShortName pair disagreeing, which made every
    voice this endpoint listed fail Preview's validation. A bare list (not
    {voices: [...]}) — main.js's loadBtn handler does
    `Array.isArray(voices) ? voices : []`.

    Piper ids are voice CODES ("en_US-ryan-high"), not the language code —
    save_sync accepts either (tts_engine.resolve_piper_voice), and a picker
    that can only ever offer one entry per language is a picker that looks
    broken. The curated voice comes first; anything else already downloaded
    for the same locale follows. gTTS has no named voices at all — one
    synthetic entry so the UI's voice list is never empty for a language it
    actually supports.

    Every engine answers here, including kokoro: the plugin used to carry
    its own hardcoded Kokoro list and show it for every backend, which is
    why picking Piper or Edge-TTS never changed the voices on offer.
    """
    engine = (engine or "").strip().lower()
    if engine in ("edge", "edge-tts"):
        if not tts_engine.HAS_EDGE_TTS:
            return []
        return await asyncio.to_thread(tts_engine.edge_voices_for_lang, lang or None)
    if engine == "piper":
        if not tts_engine.HAS_PIPER:
            return []
        codes = tts_engine.piper_voices_for_lang(lang)
        installed = set(tts_engine.piper_voices_installed())
        return [{"id": code, "shortName": code,
                 "locale": tts_engine.piper_locale_of(code).replace("_", "-"),
                 "gender": "", "downloaded": code in installed}
                for code in codes]
    if engine == "kokoro":
        if not tts_engine.HAS_KOKORO:
            return []
        return tts_engine.kokoro_voices_for_lang(lang)
    if engine == "gtts":
        # gTTS has no named voices — one synthetic entry so the picker is
        # never empty for a language it supports. It must be empty for one it
        # does NOT: gtts_lang_for floors to "en", so listing an entry for an
        # unsupported language advertised a voice that would read the text
        # aloud in English.
        if not tts_engine.HAS_GTTS or not tts_engine.gtts_supports(lang):
            return []
        code = tts_engine.gtts_lang_for(lang)
        return [{"id": "gtts", "shortName": f"Google TTS ({code})",
                 "locale": code, "gender": ""}]
    return []


class TtsPreviewBody(BaseModel):
    voice: str
    text: str
    engine: str = ""
    lang: str = ""


@router.post("/preview")
async def tts_preview(body: TtsPreviewBody):
    """Synthesize a short sample with `voice` and return it as base64 mp3
    for the renderer to play via the Web Audio API (never server-side —
    this sidecar has no speakers to assume).

    `engine` picks the backend ("edge"/"piper"/"gtts" -> _ENGINE_TO_BACKEND),
    defaulting to edge-tts when empty or unrecognized. Every voice
    `/tts/voices` hands back for a given `engine` is already the right key
    for that engine's backend (edge-tts's display name, piper's voice code,
    kokoro's speaker id, or the literal "gtts" placeholder) — `/tts/voices` and `/preview` must
    stay in lockstep on this or a listed voice fails validation here.
    `/vocab/audio`'s resolver (audio_provider.py) reads the operator's
    configured backend independently — this route is specifically "demo the
    voice the picker just listed."

    use_cache=False: a preview is a one-off listen, not something a later
    export should reuse — caching it would grow the cache with previews
    nobody asked to keep (mirrors LinguaStudio's own preview_voice).
    """
    sample = body.text.strip() or "Hello."
    backend = _ENGINE_TO_BACKEND.get(body.engine, "edge-tts")
    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    tmp.close()
    try:
        await asyncio.to_thread(
            tts_engine.save_sync, sample, body.voice, "+0%", tmp.name,
            backend=backend, lang=body.lang, use_cache=False, hifi=True)
        if not os.path.exists(tmp.name) or os.path.getsize(tmp.name) == 0:
            return {"ok": False, "error": "TTS produced no audio"}
        with open(tmp.name, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode("ascii")
        return {"ok": True, "audio": audio_b64}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


class TtsSpeakBody(BaseModel):
    text: str
    lang: str = ""
    voice: str = ""
    backend: str = ""


@router.post("/speak")
async def tts_speak(body: TtsSpeakBody):
    """Long-form read-aloud synthesis for reading-companion's Speaker —
    distinct from /preview on purpose:
      - backend auto-picked per language (tts_engine.pick_read_aloud_backend)
        rather than hardcoded to edge-tts, so piper's local voices are used
        where curated instead of always paying a network round trip;
      - use_cache=True: a chapter's chunks get re-read (re-opening a book, a
        RSVP-synced pass, a second listen), so caching them is worth it —
        /preview is a one-off "hear this voice" click, this is not.
    Returns the backend that actually spoke (an explicit "piper" vs
    "edge-tts" in the response lets the caller show what's playing, and
    lets a fallback-to-gTTS-inside-save_sync stay honest about what ran).
    """
    text = body.text.strip()
    if not text:
        return {"ok": False, "error": "empty text"}
    backend = body.backend or tts_engine.pick_read_aloud_backend(body.lang)
    voice = body.voice or tts_engine.default_voice_for(backend, body.lang)
    # A voice belongs to ONE backend, and the caller keeps a voice per
    # backend precisely so it cannot send Kokoro's "bm_daniel" to piper.
    # If one arrives anyway, speak in this backend's own default rather than
    # 500-ing a chapter read — but say so in the response, because silently
    # substituting a voice is how "the picker does nothing" stays invisible.
    voice_fallback = ""
    ok_voice, why = tts_engine.validate_voice(voice, backend)
    if not ok_voice and body.voice:
        voice_fallback = f"{body.voice!r} is not a {backend} voice ({why})"
        voice = tts_engine.default_voice_for(backend, body.lang)
    tmp = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    tmp.close()
    try:
        await asyncio.to_thread(
            tts_engine.save_sync, text, voice, "+0%", tmp.name,
            backend=backend, lang=body.lang, use_cache=True, hifi=True)
        if not os.path.exists(tmp.name) or os.path.getsize(tmp.name) == 0:
            return {"ok": False, "error": "TTS produced no audio"}
        with open(tmp.name, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode("ascii")
        return {"ok": True, "audio": audio_b64, "backend": backend, "voice": voice,
                **({"voice_fallback": voice_fallback} if voice_fallback else {})}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


class TtsWarmBody(BaseModel):
    backend: str = ""


@router.post("/warm")
async def tts_warm(body: TtsWarmBody):
    if body.backend != "kokoro":
        return {"ok": True, "backend": body.backend, "resident": False}
    try:
        return await asyncio.to_thread(tts_engine.kokoro_warm)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


@router.get("/cache/stats")
async def tts_cache_stats():
    return {"bytes": await asyncio.to_thread(audio_cache.size_bytes)}


async def tts_cache_clear():
    return {"deleted": await asyncio.to_thread(audio_cache.clear)}


# GET as well as POST: lingua-workspace's Clear-cache button calls the
# plugin's `call()` helper with no body (main.js), which sends a GET —
# LinguaStudio's own POST-only route 405s on that exact click. Accept both
# rather than port the bug along with the feature. Registered via
# add_api_route (not a decorator) with explicit, distinct operation_ids —
# FastAPI derives an id from the function name alone otherwise and warns
# about the GET/POST pair colliding.
router.add_api_route("/cache/clear", tts_cache_clear, methods=["GET"],
                     operation_id="tts_cache_clear_get")
router.add_api_route("/cache/clear", tts_cache_clear, methods=["POST"],
                     operation_id="tts_cache_clear_post")
