"""Assignments intake (spec §9.5, corrected 2026-07-19).

The spec claimed a prior Tampermonkey Sakai scraper existed to reuse; the
operator confirmed that was a hallucination in the spec's drafting — there
is no scraper. This endpoint therefore stands alone: any client that can
POST JSON (a future userscript, a shell script, an LMS export converter)
can feed coursework notes. Notes are created on the §6 coursework schema;
for existing notes the feed source stays authoritative for the due date
until the note is marked done.
"""
from __future__ import annotations

import datetime as dt
import re

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import constants, vault
from ..generators import responsibilities

router = APIRouter(prefix="/coursework", tags=["coursework"])


class Assignment(BaseModel):
    course: str
    title: str
    due: str            # ISO date
    url: str = ""


class AssignmentsBody(BaseModel):
    assignments: list[Assignment]


def _note_rel(a: Assignment) -> str:
    safe = re.sub(r'[\\/:*?"<>|]', "-", f"{a.course} — {a.title}").strip()
    return f"{constants.COURSEWORK}/{safe}.md"


@router.post("/assignments")
def ingest(body: AssignmentsBody):
    created, updated = [], []
    for a in body.assignments:
        try:
            due = dt.date.fromisoformat(a.due).isoformat()
        except ValueError:
            raise HTTPException(400, f"bad due date {a.due!r} for {a.title!r}")
        rel = _note_rel(a)
        content = f"""---
created: {dt.date.today().isoformat()}
type: note
domain: coursework
aliases: []
tags: []
generated: false
course: "{a.course}"
due: {due}
status: todo
weight:
source: "{a.url or 'assignments-feed'}"
---
"""
        if vault.create_if_absent(rel, content):
            created.append(rel)
        else:
            note = vault.read(rel)
            if note is not None and str(note.metadata.get("due")) != due \
                    and note.metadata.get("status") != "done":
                vault.set_frontmatter_key(rel, "due", due)
                updated.append(rel)
    feed = responsibilities.generate()
    return {"created": created, "updated": updated, "feed": feed}
