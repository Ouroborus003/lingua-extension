from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .. import services

router = APIRouter(prefix="/services", tags=["services"])


def _guard(fn, name: str) -> dict:
    try:
        return fn(name)
    except KeyError as e:
        raise HTTPException(404, str(e))
    except FileNotFoundError as e:
        raise HTTPException(400, str(e))
    except OSError as e:
        raise HTTPException(500, f"{name}: {e}")


@router.get("")
def list_services():
    return {name: services.status(name) for name in services.defs()}


@router.get("/{name}/status")
def get_status(name: str):
    return _guard(services.status, name)


@router.post("/{name}/start")
def post_start(name: str):
    return _guard(services.start, name)


@router.post("/{name}/keepalive")
def post_keepalive(name: str):
    return _guard(services.keepalive, name)


@router.post("/{name}/stop")
def post_stop(name: str):
    return _guard(services.stop, name)
