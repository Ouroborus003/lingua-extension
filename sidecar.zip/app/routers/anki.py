"""anki.py — lingua-workspace's "Export .apkg" button (POST /vocab/export).

A separate module from routers/vocab_audio.py despite sharing the `/vocab`
prefix — vocab_audio.py's own docstring already explains the house
reasoning for prefix choices here: a dedicated top-level `/vocab` prefix
per caller-contract rather than folding into an existing router whose
prefix already means something else. The same logic applies twice over
here:

  (a) The path itself, `/vocab/export`, mirrors LinguaStudio's own sidecar
      route byte-for-byte on purpose. lingua-workspace's main.js already
      POSTs `{words[], lang, deckName, selectedTemplates[], filename}` to
      whichever sidecar answers `/vocab/export` and expects back
      `{ok: true, path}` / `{ok: false, error}` — that contract predates
      this port. Keeping the path identical meant the plugin needed a base
      URL change only (`vocabExportSidecar` in main.js), not a payload or
      response-shape change.

  (b) `/vocab/push` — the AnkiConnect live-push that writes straight into
      a running Anki via the AnkiConnect add-on — deliberately still goes
      to LinguaStudio this phase. Porting it needs `anki_push.py` (kept in
      sync with `anki_note_types.py` upstream) and a local AnkiConnect
      client; out of scope for what was asked here, which is the
      offline .apkg build path only. See app/anki_export.py's module
      docstring point 5.
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter
from pydantic import BaseModel, Field

from .. import anki_export

router = APIRouter(prefix="/vocab", tags=["anki"])


class VocabWord(BaseModel):
    word: str
    trans: str = ""
    meaning: str = ""
    audio: str = ""
    traditional: str = ""
    zhuyin: str = ""
    image: str = ""


class VocabExportBody(BaseModel):
    words: list[VocabWord]
    lang: str
    deckName: str = ""
    selectedTemplates: list[str] = Field(default_factory=list)
    filename: str = ""


@router.post("/export")
async def vocab_export(body: VocabExportBody):
    """Build a .apkg from the given words and return its path on disk.

    genanki's Package.write_to_file plus audio resolution (Forvo/edge-tts
    network calls, ffmpeg normalization) is blocking I/O and can run to
    several seconds for a large batch — run it off the event loop via
    asyncio.to_thread, the same way routers/vocab_audio.py does for a
    single word's audio resolve.

    `words` are handed to anki_export.export_apkg as plain dicts, not the
    Pydantic models: `_ensure_audio` mutates each word's `audio` field in
    place once resolved, and `_vocab_fields_for_language` reads that
    mutation back out when building the note — a list of BaseModel
    instances would either reject the attribute set or silently discard it,
    and every Audio field would come out empty.
    """
    words = [w.model_dump() for w in body.words]
    result = await asyncio.to_thread(
        anki_export.export_apkg, words, body.lang,
        filename=body.filename, deck_name=body.deckName,
        selected_templates=body.selectedTemplates or None,
    )
    return result
