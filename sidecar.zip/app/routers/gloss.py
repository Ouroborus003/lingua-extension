from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import ai_models, config, llm, prompts, settings
from ..llm import LLMOffline, LLMUnavailable

router = APIRouter(prefix="/ai", tags=["ai"])

GLOSS_MODES = ("exclaim", "explain", "examine", "enquiry")
WORD_LIMITS = {"examine": 170}
DEFAULT_WORD_LIMIT = 110
_MAX_PASSAGE_CHARS = 6000


def mode_instructions(text: str) -> tuple[str, dict[str, str]]:
    parts = re.split(r"^##\s+(\w+)\s*$", text, flags=re.M)
    base = parts[0].strip()
    modes = {}
    for i in range(1, len(parts) - 1, 2):
        modes[parts[i].strip().lower()] = parts[i + 1].strip()
    return base, modes


class GlossTurn(BaseModel):
    role: str
    content: str


class GlossBody(BaseModel):
    mode: str
    passage: str
    book: str = ""
    author: str = ""
    chapter: str = ""
    message: str = ""
    history: list[GlossTurn] = []


def build_gloss_prompt(body: GlossBody) -> tuple[str, str]:
    mode = body.mode.strip().lower()
    base, modes = mode_instructions(prompts.load("reader_gloss"))
    limit = WORD_LIMITS.get(mode, DEFAULT_WORD_LIMIT)
    where = " by ".join(x for x in (f'"{body.book}"' if body.book else "", body.author) if x)
    system = base
    if where:
        system += f"\n\nThe reader is reading {where}."
    if body.chapter:
        system += f" This passage is from \"{body.chapter}\"."
    system += f"\n\nMode: {mode.capitalize()}. {modes.get(mode, '')}"
    system += f"\n\nKeep the reply under {limit} words."
    passage = body.passage.strip()[:_MAX_PASSAGE_CHARS]
    lines = [f'PASSAGE: "{passage}"']
    for t in body.history:
        who = "READER" if t.role == "user" else "YOU"
        lines.append(f"{who}: {t.content.strip()}")
    if body.message.strip():
        lines.append(f"READER: {body.message.strip()}")
    return system, "\n\n".join(lines)


@router.post("/gloss")
async def gloss(body: GlossBody):
    if body.mode.strip().lower() not in GLOSS_MODES:
        raise HTTPException(400, f"mode must be one of {', '.join(GLOSS_MODES)}")
    if not body.passage.strip():
        raise HTTPException(400, "passage is required")
    system, user = build_gloss_prompt(body)
    try:
        answer = await llm.chat(system, user, temperature=0.5, feature="reader_gloss")
    except LLMOffline:
        raise
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))
    return {"answer": answer.strip(), "model": await _model_label()}


async def _model_label() -> str:
    cfg = settings.effective().lm_studio
    picked = ai_models.model_for("reader_gloss", ai_models.load(config.SIDECAR_DIR), cfg.model or "")
    if picked:
        return picked
    try:
        loaded = await llm.loaded_model_ids(cfg)
    except Exception:
        return ""
    return loaded[0] if loaded else ""
