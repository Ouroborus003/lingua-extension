"""Smart Management — HTTP surface.

Thin on purpose: every decision lives in `app/smart_management.py`, which is
pure and tested. This file walks the vault, calls the model, and writes.

**One item per request.** There is no job abstraction in this sidecar — no
job id, no status endpoint, no progress channel, no server-side cancel — and
inventing one for this feature would be the largest new thing in the codebase.
The plugin already owns exactly this pattern for downloads: a queue, a
concurrency cap, and a pure `status(record)` renderer. So the server stays
stateless per item and the plugin drives the loop, which also makes cancel free
(stop calling) and progress honest (it knows how many are left).

The cap therefore lives in the caller. It must not go in `llm.chat` — that
would silently serialise the sidebar chat behind a batch.
"""
from __future__ import annotations

import json
import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

import re

import yaml

from .. import config, constants, llm, prompts, settings, smart_management as sm, vault
from ..llm import LLMOffline, LLMUnavailable

router = APIRouter(prefix="/smart", tags=["smart"])
log = logging.getLogger("sidecar.smart")

# How much of a note the model sees. Enough for genre, subject and sources;
# short enough that a 200-item run does not each carry a full book.
# Measured guidance: a half-window job is ~55s, a near-full one ~90s, so the
# difference between 6k and 30k chars is hours across a batch.
# Fallback only — the live value is settings-driven (`smart.max_chars`,
# settable as `smart_max_chars` in 08 Meta/Settings.md). Kept as a module
# constant so a settings read that fails still has a sane number.
_MAX_CHARS = 6000


def _smart_cfg():
    """The Smart Management knobs, re-read per request.

    Per-request rather than at import: `08 Meta/Settings.md` is re-read live,
    and the operator changing a value should not need a sidecar restart —
    every other settings-driven behaviour here works that way."""
    try:
        return settings.effective().smart
    except Exception:
        return None


def _knob(name, fallback):
    cfg = _smart_cfg()
    val = getattr(cfg, name, None) if cfg is not None else None
    return fallback if val is None else val


TEMPLATE_DIR = f"{constants.META}/Templates"

# Filled by _style_card() so the checker below and the prompt cannot disagree
# about what this vault supports.
_ALLOWED_CALLOUTS: set[str] = set()


def _check_template(content: str) -> dict:
    """Deterministic checks on a proposed template.

    The model is asked to use only the vault's callouts and to write no
    placeholder prose. It mostly complies — and when it does not, it does so
    confidently, with nothing in the output signalling a problem. So the
    obvious failures are checked here rather than trusted: an unknown callout
    renders as a plain grey quote, and frontmatter that does not parse makes
    every note from the template broken.

    Reports; does not rewrite. The operator reviews before anything is written,
    and silently editing the answer would hide what the model actually did.
    """
    used = set(re.findall(r"^\s*>\s*\[!([a-zA-Z0-9_-]+)\]", content, re.M))
    unknown = sorted(u for u in used if u.lower() not in _ALLOWED_CALLOUTS)

    fm_ok, fm_error = True, ""
    m = re.match(r"(?s)\A(?:.*?\n)?---\n(.*?)\n---\s*\n", content)
    if m:
        try:
            yaml.safe_load(m.group(1))
        except Exception as exc:
            fm_ok = False
            fm_error = str(exc).split("\n")[0][:160]
    return {"unknown_callouts": unknown, "frontmatter_ok": fm_ok,
            "frontmatter_error": fm_error}

# Flat on purpose: quantised models degrade badly on schemas nested 3+ levels,
# and every field here is a scalar the caller renders directly.
TEMPLATE_SCHEMA = {
    "type": "object",
    "properties": {
        "name": {"type": "string"},
        "content": {"type": "string"},
        "notes": {"type": "string"},
    },
    "required": ["name", "content"],
}


def _style_card() -> str:
    """What this vault actually supports, harvested live.

    A model told only "write a template" invents callout types that render as
    plain grey quotes and frontmatter keys nothing reads. It cannot know this
    vault's vocabulary, so it is handed it — read from the same config files
    Obsidian reads, never from a hardcoded list that would go stale the day a
    callout is added.
    """
    root = vault.abs_path(".")
    cfg = root / ".obsidian"
    parts: list[str] = []

    callouts: list[str] = []
    try:
        css = (root / ".obsidian/snippets/semantic-callouts.css").read_text(encoding="utf-8")
        callouts += sorted(set(re.findall(r'\[data-callout="([a-z-]+)"\]', css)))
    except Exception:
        pass
    try:
        data = json.loads((cfg / "plugins/callout-manager/data.json").read_text(encoding="utf-8"))
        custom = (data.get("callouts") or {}).get("custom") or []
        for c in custom:
            cid = c.get("id") if isinstance(c, dict) else c
            if cid and cid not in callouts:
                callouts.append(cid)
    except Exception:
        pass
    # Obsidian's built-ins are always available and are not in either file.
    builtins = ["note", "tip", "info", "warning", "danger", "example", "quote", "abstract"]
    _ALLOWED_CALLOUTS.clear()
    _ALLOWED_CALLOUTS.update(builtins + callouts)
    parts.append("CALLOUTS (use only these): " + ", ".join(builtins + callouts))

    props: list[str] = []
    try:
        pp = json.loads((cfg / "plugins/pretty-properties/data.json").read_text(encoding="utf-8"))
        for k, v in pp.items():
            if k.endswith("Property") and isinstance(v, str) and v:
                props.append(v)
        for v in (pp.get("progressProperties") or []):
            name = v.get("property") if isinstance(v, dict) else v
            if name:
                props.append(str(name))
    except Exception:
        pass
    if props:
        parts.append("DISPLAY PROPERTIES (Pretty Properties renders these): "
                     + ", ".join(sorted(set(props))))

    parts.append("ALWAYS-PRESENT FRONTMATTER: created (ISO date), type, domain, tags")
    parts.append("DOMAINS: " + ", ".join(constants.DOMAINS)
                 if getattr(constants, "DOMAINS", None) else
                 "DOMAINS: personal, work, study")
    parts.append("CSSCLASSES CONVENTION: cssclasses: [domain-<domain>]")

    # A real template from this vault beats any description of one.
    for sample in ("Note.md", "Book.md"):
        post = vault.read(f"{TEMPLATE_DIR}/{sample}")
        if post is not None:
            raw = (post.content or "")[:900]
            parts.append(f"EXISTING TEMPLATE ({sample}) — imitate this shape, "
                         f"including its PRELUDE delimiters:\n{raw}")
            break
    return "\n\n".join(parts)


class TemplateBody(BaseModel):
    instruction: str = ""
    name: str = ""


class TemplateWriteBody(BaseModel):
    name: str
    content: str


class ScopeBody(BaseModel):
    scope: dict = {}
    limit: int | None = None


class RunOneBody(BaseModel):
    path: str
    instruction: str
    kind: str = "tag"


class ApplyBody(BaseModel):
    # The plugin sends back what it parsed from the queue note, so the operator's
    # edits in Obsidian are the source of truth rather than anything remembered
    # here.
    decisions: list[dict] = []


def _candidates():
    """Every note Smart Management may consider.

    The library's book notes and the authored folders. Deliberately excludes
    `08 Meta/Generated/` — proposing changes to generated notes would fight the
    generators that own them.
    """
    seen = set()
    for folder in (constants.LIBRARY_DIR, constants.BOOKS_DIR,
                   constants.NOTES, constants.INBOX):
        for rel, post in vault.notes(folder):
            if rel in seen or rel.startswith(constants.GENERATED + "/"):
                continue
            seen.add(rel)
            yield rel, post


@router.post("/scope")
async def resolve(body: ScopeBody):
    """What would this scope select? No model involved.

    Called before a run so the operator sees the count and can sanity-check it
    against what they expected — the cheapest possible guard against a template
    that silently matches the whole vault.
    """
    paths = sm.resolve_scope(_candidates(), body.scope, body.limit)
    return {"count": len(paths), "paths": paths[:int(_knob("scope_cap", 400))]}


@router.post("/template")
async def design_template(body: TemplateBody):
    """Propose a template. Writes NOTHING — the caller reviews, then applies.

    The operator's instruction goes in the USER turn, never into the system
    prompt: prompts are version-controlled files here, and a free-form system
    prompt would also make the response schema unusable.
    """
    instruction = (body.instruction or "").strip()
    min_chars = int(_knob("min_instruction_chars", 12))
    if len(instruction) < min_chars:
        raise HTTPException(400, "instruction is too short to be an instruction")

    user = (f"INSTRUCTION: {instruction}\n\n"
            + (f"SUGGESTED FILE NAME: {body.name.strip()}\n\n" if body.name.strip() else "")
            + "STYLE CARD — this vault supports exactly the following:\n"
            + _style_card())

    llm.mark_used()
    try:
        raw = await llm.chat(prompts.load("template_design"), user,
                             temperature=float(_knob("temperature", 0.2)),
                             json_schema=TEMPLATE_SCHEMA,
                             feature="template_design")
    except LLMOffline:
        raise                                   # 503 + code=llm_offline, app-wide
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(502, f"the model did not answer: {e}")

    try:
        out = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        raise HTTPException(502, "the model did not return usable JSON")

    name = sm.note_name(str(out.get("name") or body.name or "Untitled"))
    content = str(out.get("content") or "").strip()
    if not content:
        raise HTTPException(502, "the model returned an empty template")

    path = f"{TEMPLATE_DIR}/{name}.md"
    return {
        "name": name,
        "path": path,
        "content": content,
        "notes": str(out.get("notes") or ""),
        # Deterministic review aids — see _check_template.
        **_check_template(content),
        # Told plainly rather than discovered on apply: create_if_absent will
        # refuse, and the operator should know that before they press Save.
        "exists": vault.read(path) is not None,
    }


@router.post("/template/apply")
def write_template(body: TemplateWriteBody):
    """Write a reviewed template. Creation-only.

    `create_if_absent` is the ONLY legal write to an authored path like
    08 Meta/Templates: `write_generated` refuses anything outside
    08 Meta/Generated, and `set_frontmatter_key` refuses new keys. Never
    overwrite — a template the operator has since edited by hand is not ours
    to replace.
    """
    name = sm.note_name((body.name or "").strip())
    content = (body.content or "").strip()
    if not name or not content:
        raise HTTPException(400, "both a name and content are required")
    path = f"{TEMPLATE_DIR}/{name}.md"
    created = vault.create_if_absent(path, content + "\n")
    return {"ok": created, "path": path,
            "error": None if created else "a template already exists at that path"}


@router.post("/run-one")
async def run_one(body: RunOneBody):
    """Propose changes for ONE note. The caller loops."""
    if body.kind not in sm.KINDS:
        raise HTTPException(400, f"kind must be one of {', '.join(sm.KINDS)}")
    instruction = (body.instruction or "").strip()
    # Mirrored in the plugin's doRun guard. If these two ever disagree the UI
    # accepts an instruction the server then refuses, which reads as a random
    # failure rather than a rule.
    min_chars = int(_knob("min_instruction_chars", 12))
    if len(instruction) < min_chars:
        raise HTTPException(400, "instruction is too short to be an instruction")

    post = vault.read(body.path)
    if post is None:
        raise HTTPException(404, f"no note at {body.path}")

    title = post.metadata.get("title") or sm.note_name(body.path)
    existing = post.metadata.get("tags") or []
    user = (
        f"INSTRUCTION: {instruction}\n\n"
        f"NOTE: {title}\n"
        f"EXISTING TAGS: {', '.join(str(t) for t in existing) or '(none)'}\n\n"
        f"{(post.content or '')[:int(_knob('max_chars', _MAX_CHARS))]}"
    )

    # Keep the model resident. `mark_used` is what the standby reaper measures,
    # and a batch whose items are minutes apart can otherwise be unloaded
    # mid-run when a global model is pinned.
    llm.mark_used()

    try:
        raw = await llm.chat(prompts.load("smart_management"), user,
                             temperature=float(_knob("temperature", 0.2)),
                             json_schema=sm.PROPOSAL_SCHEMA,
                             feature="smart_management")
    except LLMOffline:
        raise                                   # 503 + code=llm_offline, app-wide
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        # One bad item must cost one item, not the run. The caller sees an empty
        # proposal list and moves on.
        log.warning("smart: %s failed: %s", body.path, e)
        return {"path": body.path, "proposals": [], "error": str(e)[:200]}

    return {"path": body.path,
            "proposals": sm.parse_proposals(
                raw, body.kind, body.path,
                sm.allowed_status(post.metadata.get("type"), _status_vocab()))}


class QueueBody(BaseModel):
    proposals: list[dict] = []
    meta: dict = {}


@router.post("/queue")
async def write_queue(body: QueueBody):
    """Write the review queue the operator checks lines in.

    Rejected offers — lines deleted from the previous queue — are recorded
    before the new one overwrites it, or the record of what was rejected dies
    with the note that carried it.
    """
    prev_ids = _load_offers()
    existing = vault.read(sm.QUEUE_PATH)
    if existing is not None:
        still = sm.parse_queue(existing.content or "")
        gone = sm.newly_rejected(prev_ids, still)
        if gone:
            _save_rejected(_load_rejected() + gone)

    fresh = [p for p in body.proposals
             if sm.offer_id(p) not in set(_load_rejected())]
    path = vault.write_generated(sm.QUEUE_PATH,
                                 sm.render_queue(fresh, body.meta),
                                 {"type": "inbox"})
    _save_offers([sm.offer_id(p) for p in fresh])
    return {"path": path, "written": len(fresh),
            "suppressed": len(body.proposals) - len(fresh)}


@router.post("/apply")
async def apply(body: ApplyBody):
    """Apply the checked lines. Nothing else is touched."""
    applied, skipped, failed = 0, 0, []
    for d in body.decisions:
        if not d.get("checked"):
            skipped += 1
            continue
        kind, value = d.get("kind"), str(d.get("value") or "").strip()
        rel = _resolve_note(str(d.get("target") or ""))
        if not rel or not value:
            failed.append({"target": d.get("target"), "why": "note not found"})
            continue
        try:
            if kind == "tag":
                current = (vault.read(rel).metadata.get("tags") or [])
                if value not in current:
                    vault.set_frontmatter_key(rel, "tags", list(current) + [value])
                    applied += 1
            elif kind == "status":
                post = vault.read(rel)
                ok = sm.allowed_status((post.metadata.get("type") if post else None),
                                       _status_vocab())
                if ok and value not in ok:
                    failed.append({"target": rel,
                                   "why": f"status {value!r} is not one of "
                                          f"{', '.join(ok)} for this note type"})
                    continue
                vault.set_frontmatter_key(rel, "status", value)
                applied += 1
            else:
                # `move` and `note` are the plugin's to perform: a move must go
                # through Obsidian's fileManager so inbound wikilinks are
                # rewritten, and the adapter here cannot do that.
                failed.append({"target": rel, "why": f"{kind} is applied by the plugin"})
        except Exception as e:
            failed.append({"target": rel, "why": str(e)[:160]})
    return {"applied": applied, "skipped": skipped, "failed": failed}


# ---------------------------------------------------------- status vocabulary

_TEMPLATE_DIR = "08 Meta/Templates"
_VOCAB_CACHE: dict | None = None


def _status_vocab() -> dict:
    """`type` -> permitted status values, read from the vault's own templates.

    Cached for the process: the templates are authored files that change on
    human timescales, and re-reading 34 of them per proposal in a 200-item run
    is pure waste. Restart the sidecar after editing a template's selector.
    """
    global _VOCAB_CACHE
    if _VOCAB_CACHE is None:
        texts = {}
        for rel, post in vault.notes(_TEMPLATE_DIR):
            # The selector lives in the body, and frontmatter carries `type`.
            texts[rel] = (getattr(post, "content", "") or "") + "\n" + \
                "\n".join(f"{k}: {v}" for k, v in (post.metadata or {}).items())
        _VOCAB_CACHE = sm.status_options(texts)
        log.info("smart: status vocabulary for %d note types", len(_VOCAB_CACHE))
    return _VOCAB_CACHE


# ------------------------------------------------------------------ state

def _state_path():
    return config.STATE_DIR / sm.STATE_FILE


def _read_state() -> dict:
    try:
        return json.loads(_state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write_state(d: dict) -> None:
    config.STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = _state_path().with_suffix(".json.tmp")
    tmp.write_text(json.dumps(d, indent=2, sort_keys=True), encoding="utf-8")
    # Atomic: a half-written offers file parses as corrupt, and a corrupt one
    # means every rejected proposal comes back.
    tmp.replace(_state_path())


def _load_offers() -> list[str]:
    return list(_read_state().get("offered") or [])


def _save_offers(ids: list[str]) -> None:
    d = _read_state(); d["offered"] = ids; _write_state(d)


def _load_rejected() -> list[str]:
    return list(_read_state().get("rejected") or [])


def _save_rejected(ids: list[str]) -> None:
    d = _read_state(); d["rejected"] = sorted(set(ids)); _write_state(d)


def _resolve_note(name: str) -> str | None:
    """A wikilink name back to a path. The queue stores names, not paths."""
    if name.endswith(".md") and vault.read(name) is not None:
        return name
    for rel, _ in _candidates():
        if sm.note_name(rel) == name:
            return rel
    return None
