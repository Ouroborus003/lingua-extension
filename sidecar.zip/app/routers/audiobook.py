from __future__ import annotations

from fastapi import APIRouter
from pydantic import BaseModel

from .. import audiobook

router = APIRouter(prefix="/audiobook", tags=["audiobook"])


class Section(BaseModel):
    key: str
    title: str = ""
    paragraphs: list[list[str]] = []


class RenderBody(BaseModel):
    book: str
    title: str = ""
    voice: str = ""
    backend: str = ""
    lang: str = ""
    skip_citations: bool = True
    sections: list[Section]


@router.post("/render")
async def render(body: RenderBody):
    if not audiobook.valid_book_id(body.book):
        return {"ok": False, "error": f"bad book id: {body.book!r}"}
    job = audiobook.renderer.submit({"book": body.book, "title": body.title, "voice": body.voice,
                                     "backend": body.backend, "lang": body.lang,
                                     "skip_citations": body.skip_citations,
                                     "sections": [s.model_dump() for s in body.sections]})
    return {"ok": True, "job": job}


@router.get("/status/{book}")
async def status(book: str):
    if not audiobook.valid_book_id(book):
        return {"ok": False, "error": f"bad book id: {book!r}"}
    return {"ok": True, "job": audiobook.renderer.public(book),
            "manifest": audiobook.read_manifest(book),
            "dir": str(audiobook.book_dir(book))}


@router.post("/cancel/{book}")
async def cancel(book: str):
    if not audiobook.valid_book_id(book):
        return {"ok": False, "error": f"bad book id: {book!r}"}
    return {"ok": True, "job": audiobook.renderer.cancel(book)}
