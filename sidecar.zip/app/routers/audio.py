"""Pronunciation audio for the dual reader (app/forvo.py).

When a reader clicks a word in the word-pair overlay it can hear a *human*
recording, not just device TTS. Forvo serves those; the operator chooses (in
settings) whether a click plays the single most-voted clip straight away
("popular") or opens a small menu of speakers to pick from ("menu").

The plugin fetches over `obsidian.requestUrl` (no CORS), so audio is returned
base64-encoded for it to play from a data URI. Everything here degrades to an
empty answer when Forvo is unreachable — the reader falls back to TTS.
"""
from __future__ import annotations

import asyncio
import base64

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import pronounce, settings

router = APIRouter(prefix="/audio", tags=["audio"])


class ForvoBody(BaseModel):
    word: str
    lang: str = ""
    mode: str = ""      # "popular" | "menu"; "" = the operator's audio.forvo_mode
    limit: int = 0      # menu alternates; 0 = the operator's audio.forvo_limit


class ClipBody(BaseModel):
    url: str            # a recording url from a prior /audio/forvo menu response


@router.get("/status")
def status():
    """Whether human pronunciation is on and how a word click behaves."""
    acfg = settings.effective().audio
    return {
        "forvo_enabled": bool(acfg.forvo_enabled),
        "forvo_mode": acfg.forvo_mode,
        "forvo_limit": acfg.forvo_limit,
    }


@router.post("/forvo")
async def forvo_word(body: ForvoBody):
    """Human pronunciation for a word.

    "popular" (default): the top clip, downloaded — {provider, mode, audio_b64,
    url, user, votes}; provider "" when Forvo has nothing / is off.
    "menu": ranked alternates without audio — {provider, mode, items:[{url,
    votes, user}]} — the plugin shows a picker and calls /audio/forvo/clip.
    """
    acfg = settings.effective().audio
    if not acfg.forvo_enabled:
        return {"provider": "", "mode": "off", "items": []}
    word = (body.word or "").strip()
    if not word:
        raise HTTPException(400, "word is required")
    mode = body.mode or acfg.forvo_mode
    limit = body.limit or acfg.forvo_limit

    if mode == "menu":
        r = await asyncio.to_thread(pronounce.recordings, word, body.lang, limit)
        items = r["items"]
        # `unavailable` says the SOURCE failed. Without it the plugin cannot tell
        # "Forvo is blocking us" from "this word has no recordings", and shows
        # the second when the truth is the first.
        return {"provider": r["source"], "mode": "menu", "items": items,
                "unavailable": r["unavailable"], "reason": r["reason"],
                "tried": r["tried"]}

    hit = await asyncio.to_thread(pronounce.top, word, body.lang)
    # popular mode reports unavailable/reason TOO. It used to return a bare
    # empty result, so the operator's own configured mode was the one with no
    # diagnosis at all — the honesty fix had only ever covered `menu`.
    if not hit.get("audio"):
        return {"provider": "", "mode": "popular", "audio_b64": "", "url": "",
                "unavailable": hit["unavailable"], "reason": hit["reason"],
                "tried": hit.get("tried", [])}
    return {
        "provider": hit.get("source") or "forvo", "mode": "popular",
        "audio_b64": base64.b64encode(hit["audio"]).decode("ascii"),
        "url": hit["url"], "user": hit.get("user", ""), "votes": hit.get("votes", 0),
        "unavailable": False, "reason": "", "tried": hit.get("tried", []),
    }


@router.post("/forvo/clip")
async def forvo_clip(body: ClipBody):
    """Download one alternate (menu mode) -> {audio_b64}. Empty when the url is
    not on the audio-host allowlist (pronounce.AUDIO_HOSTS) or the fetch fails.

    Routed through `pronounce` so a Lingua Libre .wav on upload.wikimedia.org
    works as well as a Forvo .mp3 — these urls come from a scraped page, so the
    check stays an allowlist and never a substring test."""
    audio = await asyncio.to_thread(pronounce.download, body.url)
    if not audio:
        return {"audio_b64": ""}
    return {"audio_b64": base64.b64encode(audio).decode("ascii")}
