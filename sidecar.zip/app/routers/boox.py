"""Boox sync endpoints (spec §9.8+): two-way annotation sync, progress sync, offline queue."""
from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import constants, settings, vault
from ..config import STATE_DIR

router = APIRouter(prefix="/boox", tags=["boox"])

_BOOKS_DIR = constants.BOOKS_DIR
_NOTES_DIR = constants.NOTES
_OFFLINE_QUEUE = STATE_DIR / "boox_offline_queue.jsonl"


def _load_offline_queue() -> list:
    if _OFFLINE_QUEUE.exists():
        try:
            return [json.loads(line) for line in _OFFLINE_QUEUE.read_text().splitlines() if line.strip()]
        except Exception:
            return []
    return []


def _save_offline_queue(queue: list) -> None:
    _OFFLINE_QUEUE.parent.mkdir(parents=True, exist_ok=True)
    _OFFLINE_QUEUE.write_text("\n".join(json.dumps(item) for item in queue) + "\n")


def _add_to_offline_queue(op: dict) -> None:
    queue = _load_offline_queue()
    queue.append({"ts": datetime.utcnow().isoformat(), **op})
    _save_offline_queue(queue)


def _flush_offline_queue() -> int:
    """Process offline queue, return number of processed items."""
    queue = _load_offline_queue()
    if not queue:
        return 0
    
    # In a real implementation, this would process each item
    # For now, just clear the queue
    _save_offline_queue([])
    return len(queue)


class SyncBody(BaseModel):
    force: bool = False


class PushAnnotationsBody(BaseModel):
    work_ids: list[str] | None = None  # None = all open/annotated books
    format: str = "markdown"  # markdown or canvas


class ProgressSyncBody(BaseModel):
    work_id: str
    chapter_url: str | None = None
    page: int | None = None
    progress: float | None = None  # 0.0 - 1.0
    last_opened: int | None = None  # timestamp


class ProgressQueryBody(BaseModel):
    work_id: str


@router.post("/sync")
async def boox_sync(body: SyncBody):
    """Full Boox annotation sync (ingest from Syncthing folder)."""
    from .ingest import boox
    try:
        result = boox.scan()
        return result
    except Exception as e:
        raise HTTPException(500, f"Boox sync failed: {e}")


@router.post("/push")
async def boox_push_annotations(body: PushAnnotationsBody):
    """Push Obsidian annotations to Boox device via Syncthing."""
    # This writes annotation files to the Syncthing watch folder
    # Boox app on device will pick them up
    
    cfg = settings.effective().boox
    watch_dir = Path(cfg.watch_dir).expanduser() if cfg.watch_dir else None
    if not watch_dir or not watch_dir.exists():
        raise HTTPException(400, "Boox watch_dir not configured or missing")
    
    # Determine which books to push
    work_ids = body.work_ids
    if not work_ids:
        # Default: all books with annotations in the vault
        # This would need to query the vault for annotated books
        pass
    
    pushed = 0
    # In a real implementation, this would:
    # 1. Collect annotations from vault for each work_id
    # 2. Format as Boox expects (JSON or CSV)
    # 3. Write to watch_dir for Syncthing to pick up
    
    # For now, return placeholder
    return {"pushed": 0, "message": "Push not fully implemented - requires Boox export format spec"}


@router.post("/progress")
async def boox_progress_sync(body: ProgressSyncBody):
    """Sync reading progress for a book."""
    # Store progress in vault note frontmatter
    work = vault.read(body.work_id)
    if not work:
        raise HTTPException(404, f"Work not found: {body.work_id}")
    
    updates = {}
    if body.chapter_url is not None:
        updates["chapterUrl"] = body.chapter_url
    if body.page is not None:
        updates["page"] = body.page
    if body.progress is not None:
        updates["progress"] = body.progress
    if body.last_opened is not None:
        updates["lastOpened"] = body.last_opened
    
    if updates:
        vault.set_frontmatter_key(body.work_id, "readingProgress", updates)
    
    return {"ok": True, "updated": list(updates.keys())}


@router.get("/progress")
async def get_progress(work_id: str):
    """Get reading progress for a book."""
    work = vault.read(work_id)
    if not work:
        raise HTTPException(404, f"Work not found: {work_id}")
    
    progress = work.metadata.get("readingProgress", {})
    return {"work_id": work_id, "progress": progress}


@router.post("/offline/flush")
async def flush_offline_queue():
    """Process queued offline operations."""
    processed = _flush_offline_queue()
    return {"processed": processed}


@router.get("/offline/queue")
async def get_offline_queue():
    """Get current offline queue."""
    return {"queue": _load_offline_queue()}


@router.post("/offline/queue")
async def add_offline_operation(op: dict):
    """Add an operation to the offline queue."""
    _add_to_offline_queue(op)
    return {"ok": True}