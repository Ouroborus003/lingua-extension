"""Translation + dual-reading endpoints (local-first hub, app/translate.py).

The reading plugins (Reading Companion's dual reader, the RSS and Library
readers) POST here: block translation for the side-by-side pane, single-word
lookup for the word-pair reader, and a comprehensible-input coverage check.
Everything runs through the local-first provider cascade; nothing here picks a
provider itself — that is the operator's `translate.provider_order`.
"""
from __future__ import annotations

import time

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import settings, translate, vocab_csv

router = APIRouter(prefix="/translate", tags=["translate"])

# In-memory only, one slot, no persistence — a live pointer to "the last word
# a non-vault client (LinguaBrowse) saved", for reading-companion's Word
# Detail panel to poll (GET /vocab/last-activity) and follow along while
# browsing. Not the practice ledger: this is a UI convenience signal, not an
# involvement event, and a restart losing it is fine (the panel just stops
# auto-following until the next save). ts is epoch milliseconds, matching
# main.js's Date.now() convention (see ledger.py's `ts` fields) so a poller's
# `since` compares directly with no unit conversion.
_last_activity: dict | None = None


class TranslateBody(BaseModel):
    texts: list[str]
    src: str = ""          # source language ("" = auto-detect)
    tgt: str = "EN"        # target language
    provider: str = ""     # force one provider; "" = cascade


@router.post("")
async def translate_blocks(body: TranslateBody):
    return await translate.translate_texts(body.texts, body.src, body.tgt, body.provider)


class WordBody(BaseModel):
    word: str
    src: str = ""
    tgt: str = "EN"
    context: str = ""      # the sentence the word sits in (helps the local AI)
    provider: str = ""


@router.post("/word")
async def translate_word(body: WordBody):
    return await translate.translate_word(body.word, body.src, body.tgt,
                                          body.context, body.provider)


class AnalyzeBody(BaseModel):
    text: str
    lang: str = ""             # language whose vault vocab counts as "known"
    known: list[str] = []      # explicit known words (overrides/augments vault)
    threshold: float = 0.95    # comprehensible floor (Krashen: ~0.90–0.98)


@router.post("/analyze")
def analyze(body: AnalyzeBody):
    """Comprehensible-input coverage: what share of the text the reader knows,
    the Krashen band, and the unknown words to pre-learn. Known words come from
    the request and (when `lang` is given) the vault's vocab notes."""
    known = {w.lower() for w in body.known}
    if body.lang:
        known |= translate.known_terms(body.lang)
    return translate.analyze_coverage(body.text, known, body.threshold, body.lang)


class SaveVocabBody(BaseModel):
    term: str
    language: str
    reading: str = ""          # accepted but NOT stored — joined from the dictionary
    gloss: str = ""            # accepted but NOT stored — same reason
    source: str = ""          # where it was met (feed/article/book/note title/URL)
    # 7.4: the context the word was captured in. Additive — every existing
    # caller (LinguaBrowse v3.7, reading-companion pre-7.4) omits this and gets
    # the old behaviour unchanged, since upsert's merge rule never clobbers an
    # existing sentence with a blank one.
    sentence: str = ""
    image: str = ""
    audio: str = ""
    # Which app made this call — "source" above already means "where the word
    # was MET" (a feed/article/URL), so this needed its own name rather than
    # overloading that field. "" (the default, and every caller before this
    # one) means reading-companion / the vault itself; LinguaBrowse sends
    # "linguabrowse". Not stored in the CSV — CSV rows don't care who saved
    # them — only used below to update the last-activity pointer.
    client: str = ""


@router.post("/save-vocab")
def save_vocab(body: SaveVocabBody):
    """Record a looked-up/unknown word in the language's vocabulary CSV
    (spec §10 rewrite — this used to create a `type: vocab` note per word).

    URL and body shape are kept exactly — LinguaBrowse v3.7 and
    reading-companion both call this — but `reading`/`gloss` are no longer
    stored: they belong to the dictionary and are joined at read time, because
    a stored gloss goes stale the moment the dictionary is corrected.
    Returns {created, path}; created=false when the term was already recorded.
    """
    term = body.term.strip()
    if not term:
        raise HTTPException(400, "term is required")
    try:
        created, _ = vocab_csv.upsert(body.language, {
            "term": term, "language": body.language, "source": body.source,
            "sentence": body.sentence, "image": body.image, "audio": body.audio,
        })
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    global _last_activity
    _last_activity = {
        "term": term, "language": body.language,
        "client": body.client, "ts": int(time.time() * 1000),
    }
    return {"created": created, "path": vocab_csv.path(body.language)}


@router.get("/last-activity")
def last_activity(since: int = 0):
    """The most recent save-vocab call's {term, language, client, ts}, or null
    if none has happened yet (or none since `since`, epoch ms) — what
    reading-companion's Word Detail panel polls to follow along with words
    saved from LinguaBrowse while it's open. See _last_activity above for why
    this is in-memory rather than persisted."""
    if _last_activity is None or _last_activity["ts"] <= since:
        return None
    return _last_activity


@router.get("/status")
async def status():
    """Which providers are configured, and — separately for each cascade —
    whether anything can actually serve it.

    `ready` used to be `any(provider is configured)`, and that single boolean
    was actively misleading. On 2026-08-25 it reported **true** while every
    passage in the vault came back empty: `stardict` was configured and healthy,
    which satisfied `any(...)`, but a dictionary declines passages by design and
    is not in `provider_order` at all, while all four providers that *are* in it
    were down at once. surf-lingua tells the operator to check this endpoint
    when its translation row is blank — so the one diagnostic on offer confirmed
    that everything was fine.

    Hence `passage_ready` and `word_ready`, each computed over the providers
    that can genuinely serve that cascade. `ready` is kept for existing callers
    but is now derived from the two, so it can never again report ready with no
    passage provider.

    `providers` remains a CONFIGURATION report — `available()` says a provider
    is set up, not that anything is on the other end, and that alone was never
    going to answer the question. `live` is the liveness probe beside it:
    `true` answered, `false` did not, `null` was not probed (see
    `translate.probe_liveness`). A readiness flag counts a provider only if it
    is configured AND not *known* dead, so a DeepLX whose container is not
    running stops propping up `passage_ready`.

    Only local providers are ever probed. Reaching out to Google on every
    status poll would be a worse bug than the one being fixed, and reaching
    local_ai only ever LISTS what LM Studio has resident — nothing here may
    load a model to answer a status call.
    """
    cfg = settings.effective()
    providers = {
        name: bool(p.available(cfg)) for name, p in translate.PROVIDERS.items()
    }
    live = await translate.probe_liveness(cfg)
    tcfg = cfg.translate
    p_order = [n for n in tcfg.provider_order if n in translate.PROVIDERS]
    w_order = [n for n in tcfg.word_order if n in translate.PROVIDERS]

    # Providers currently inside a negative-cache window: configured, maybe
    # even answering a probe, but the cascade will skip them for the next few
    # seconds because a connection to them failed. Reported because this
    # endpoint's whole history is claiming readiness it did not have — it said
    # `ready: true` while every passage in the vault came back empty, and
    # surf-lingua's failure Notice sends the operator here to find out why. A
    # decline window is the single most likely reason a configured, live-looking
    # provider is nonetheless not being used, so it belongs in the answer.
    declining = translate.decline_windows(cfg)

    def usable(name: str) -> bool:
        return (providers[name]
                and live.get(name) is not False
                and not declining.get(name))

    passage_ready = any(usable(n) for n in p_order if n in translate.PASSAGE_CAPABLE)
    word_ready = any(usable(n) for n in w_order)
    return {
        "providers": providers,
        "live": live,
        "declining": declining,
        "provider_order": p_order,
        "word_order": w_order,
        "passage_capable": sorted(translate.PASSAGE_CAPABLE),
        "passage_ready": passage_ready,
        "word_ready": word_ready,
        "ready": passage_ready or word_ready,
        "stardict": [e.get("lang", "") for e in (tcfg.stardict or []) if isinstance(e, dict)],
    }
