"""OCR endpoint for scanned PDFs with no text layer.

Library Workspace's offline import calls this only when a scan's pdf.js
text layer already came back empty or near-empty — see app/ocr.py's own
header for why the rasterising happens in the plugin, not here, and
why localhost tesseract stays inside the vault's "no network to third
parties" rule even though this is, mechanically, a fetch.
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import llm, ocr, settings

router = APIRouter(prefix="/ocr", tags=["ocr"])

# Valid values for OcrBody.engine — named here so the 400 for a bad one and
# the branch in run_ocr() can't drift apart.
ENGINES = ("", "tesseract", "vlm")


class OcrBody(BaseModel):
    images: list[str]      # base64 PNG page images, front-matter order
    lang: str = ""          # "" = the operator's configured default
    # "" and "tesseract" are the same thing: today's default path, byte-
    # identical to before this field existed. "vlm" is the strictly opt-in
    # escape hatch for a `vlm/` import folder — see app/ocr.py's
    # vlm_ocr_images docstring for why tesseract stays the default.
    engine: str = ""


@router.get("/status")
async def status():
    """What the sidecar can OCR with, so the plugin can skip rendering and
    collecting page images entirely when tesseract isn't there — the same
    shape of pre-flight check /audio/status gives the dual reader for
    Forvo. Also reports the VLM escape hatch's own pre-flight: whether a
    model is configured for it and whether that model is actually resident,
    since LM Studio here never loads one just-in-time."""
    cfg = settings.effective().ocr
    langs = await asyncio.to_thread(ocr.installed_langs, cfg.tessdata_prefix)
    vlm_loaded = False
    if cfg.vlm_model:
        vlm_loaded = cfg.vlm_model in await llm.loaded_model_ids()
    return {
        "available": ocr.available(),
        "langs": sorted(langs),
        "default_lang": cfg.default_lang,
        "max_pages": cfg.max_pages,
        "tessdata_prefix": ocr.tessdata_status(cfg.tessdata_prefix),
        "vlm_model": cfg.vlm_model,
        "vlm_loaded": vlm_loaded,
    }


@router.post("")
async def run_ocr(body: OcrBody):
    if body.engine not in ENGINES:
        raise HTTPException(
            400, f"engine must be one of {ENGINES!r}, got {body.engine!r}")
    if not body.images:
        raise HTTPException(400, "images is required")

    effective = settings.effective()
    cfg = effective.ocr

    if body.engine == "vlm":
        # Tesseract's own availability/language checks are meaningless for a
        # VLM — it needs a model, not a language pack — so this path never
        # touches ocr.available()/installed_langs() at all.
        try:
            text = await ocr.vlm_ocr_images(body.images, effective)
        except (ocr.VlmNotConfigured, ocr.VlmUnavailable) as e:
            # Both are "this machine cannot do that right now" states, the
            # same class of problem as "tesseract is not installed" above —
            # a 503 with a message the operator can act on, not a 400 (the
            # request itself was fine) or a stack trace.
            raise HTTPException(503, str(e)) from e
        return {"text": text, "lang": body.lang, "engine": "vlm"}

    if not ocr.available():
        raise HTTPException(503, "tesseract is not installed on this machine")

    lang = (body.lang or cfg.default_lang or "eng").strip()
    langs = await asyncio.to_thread(ocr.installed_langs, cfg.tessdata_prefix)
    if lang not in langs:
        # A request the operator can act on (install the pack, or pick a
        # different one) — 400, not a tesseract stderr dump the plugin
        # would have no way to explain.
        raise HTTPException(
            400, f"tesseract language {lang!r} is not installed on this "
                f"machine (have: {', '.join(sorted(langs)) or 'none'})")

    text = await asyncio.to_thread(
        ocr.ocr_images, body.images, lang, cfg.timeout_seconds, cfg.max_pages,
        cfg.tessdata_prefix)
    return {"text": text, "lang": lang}
