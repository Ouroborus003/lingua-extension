"""Companion / second-screen channel (spec §5): a tiny in-memory relay so
one device (the laptop) can broadcast the note it is editing and another
(the Boox / phone) can follow it in near-real-time over the LAN.

Deliberately *not* persisted: this is live presence, not vault data. The
followed note's *content* still travels by ordinary sync — this only
relays *which* note is active and where the cursor sits, so the follower
can open the same file (already synced) and scroll to the same spot.
"""
from __future__ import annotations

import time
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/companion", tags=["companion"])

# The single piece of live state. One broadcaster at a time is the whole
# model — a second screen follows a first, not a mesh.
_STATE: dict = {"path": None, "cursor": None, "selection": None,
                "source": None, "ts": 0.0}


class ActiveBody(BaseModel):
    path: str
    cursor: Optional[dict] = None      # {"line": int, "ch": int}
    selection: Optional[dict] = None   # {"anchor": {...}, "head": {...}}
    source: Optional[str] = None       # a device label, e.g. "laptop"


def set_active(path: str, cursor: Optional[dict] = None,
               selection: Optional[dict] = None, source: Optional[str] = None,
               now: Optional[float] = None) -> dict:
    """Record the broadcaster's active note. Empty path clears the target
    (nothing to follow) rather than storing an empty string."""
    _STATE.update({
        "path": path or None,
        "cursor": cursor,
        "selection": selection,
        "source": source,
        "ts": now if now is not None else time.time(),
    })
    return dict(_STATE)


def get_active() -> dict:
    """A copy of the live state, so callers can't mutate the relay."""
    return dict(_STATE)


@router.post("/active")
async def post_active(body: ActiveBody):
    state = set_active(body.path, body.cursor, body.selection, body.source)
    return {"ok": True, "state": state}


@router.get("/active")
async def read_active():
    return {"ok": True, "state": get_active()}
