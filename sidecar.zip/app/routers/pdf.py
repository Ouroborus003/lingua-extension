"""pdf.py — router for pdf_reflow.py, reading-companion's "reflow a PDF"
command. Same shape as routers/whisper.py: a /status pre-flight the plugin
can check before offering the command, path in (the plugin already has an
absolute path from the vault adapter — no base64/upload path needed here,
a PDF has no browser-file-picker origin the way an ad-hoc audio clip does),
the engine's own dict passed straight through.
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter
from pydantic import BaseModel

from .. import pdf_reflow

router = APIRouter(prefix="/pdf", tags=["pdf"])


@router.get("/status")
async def status():
    return {"available": pdf_reflow.available()}


class ReflowBody(BaseModel):
    path: str


@router.post("/reflow")
async def reflow(body: ReflowBody):
    if not body.path:
        return {"ok": False, "error": "empty path"}
    return await asyncio.to_thread(pdf_reflow.reflow, body.path)
