"""vocab_audio.py — one-word audio resolution for lingua-workspace's pending
list and vocab table row tools (POST /vocab/audio).

Ported from LinguaStudio's `generator_api.resolve_word_audio`; the
Forvo-vs-TTS policy itself lives in `app/audio_provider.py`, reusing this
sidecar's existing `app/forvo.py` for the human half instead of re-porting
LinguaStudio's separate `forvo_client.py`.

A dedicated top-level `/vocab` prefix rather than folding into
`routers/audio.py`'s `/audio` prefix: that router already answers a
different contract (Forvo-only, for the dual reader's word-pair overlay,
`{provider, mode, ...}`) at `/audio/forvo*` — `/vocab/audio` is a different
caller (lingua-workspace) expecting a different shape
(`{ok, filename, audioB64, source}`), so giving it its own prefix keeps the
two from reading like variations on one contract.
"""
from __future__ import annotations

import asyncio
import base64

from fastapi import APIRouter
from pydantic import BaseModel

from .. import audio_provider, settings

router = APIRouter(prefix="/vocab", tags=["vocab"])


class VocabAudioBody(BaseModel):
    word: str
    lang: str = ""


@router.post("/audio")
async def vocab_audio(body: VocabAudioBody):
    """Resolve one word's audio (Forvo -> TTS, per audio_provider's policy)
    and return it for in-app preview.

    Returns {ok, filename, audioB64, source} — the same shape LinguaStudio's
    /vocab/audio answered, so lingua-workspace's rowTool/ttsAudioB64 plumbing
    needed no changes beyond its base URL (main.js).
    """
    word = (body.word or "").strip()
    if not word:
        return {"ok": False, "error": "empty word"}
    cfg = settings.effective()
    try:
        fname, abspath, source = await asyncio.to_thread(
            audio_provider.resolve_audio_detailed, word, body.lang, cfg)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if not (fname and abspath):
        return {"ok": False, "error": "no audio (Forvo miss + TTS unavailable)"}
    with open(abspath, "rb") as fh:
        audio_b64 = base64.b64encode(fh.read()).decode("ascii")
    return {"ok": True, "filename": fname, "audioB64": audio_b64, "source": source}
