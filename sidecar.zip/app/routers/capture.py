"""Zero-friction capture (spec §9.2): timestamped note in 00 Inbox, no
prompts. The listening variant pre-links the currently scrobbling track
(§9.6) — a thought arriving while listening has somewhere to land.
"""
from __future__ import annotations

import datetime as dt

from fastapi import APIRouter
from pydantic import BaseModel

from .. import constants, vault
from ..ingest import lastfm

router = APIRouter(prefix="/capture", tags=["capture"])


class CaptureBody(BaseModel):
    text: str = ""
    title: str = ""


def _inbox_note(title: str, body: str) -> str:
    stamp = dt.datetime.now()
    name = title or stamp.strftime("%Y-%m-%d %H.%M.%S")
    rel = f"{constants.INBOX}/{name}.md"
    content = f"""---
created: {stamp.date().isoformat()}
type: inbox
domain: personal
aliases: []
tags: []
generated: false
---
{body}
"""
    if not vault.create_if_absent(rel, content):
        rel = f"{constants.INBOX}/{name} {stamp.strftime('%f')}.md"
        vault.create_if_absent(rel, content)
    return rel


@router.post("")
def capture(body: CaptureBody):
    return {"path": _inbox_note(body.title, body.text)}


@router.post("/listening")
def capture_listening(body: CaptureBody):
    now = lastfm.now_playing()
    context = ""
    if now:
        album = f" from [[{now['album']}]]" if now.get("album") else ""
        context = f"\n\n— while listening to **{now['track']}** · {now['artist']}{album}\n"
    return {"path": _inbox_note(body.title, (body.text or "") + context),
            "now_playing": now}
