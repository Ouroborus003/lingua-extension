from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..ingest import lingua

router = APIRouter(prefix="/lingua", tags=["lingua"])


class Entry(BaseModel):
    term: str
    reading: str = ""
    gloss: str = ""
    rhythm: list[str] = []


class ExportBody(BaseModel):
    language: str
    source: str = ""
    entries: list[Entry]


@router.post("/export")
def export(body: ExportBody):
    try:
        n = lingua.append_entries(body.language,
                                  [e.model_dump() for e in body.entries],
                                  body.source)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"appended": n}


class AnkiExportedBody(BaseModel):
    language: str
    terms: list[str]


@router.post("/anki-exported")
def anki_exported(body: AnkiExportedBody):
    """Memex round-trip (spec §10 rewrite): after the .apkg is generated, mark
    the exported terms in the vocabulary CSV so the views show what is already
    in Anki."""
    from .. import vocab_csv
    wanted = set(body.terms)
    flipped = []
    for row in vocab_csv.read(body.language):
        term = str(row.get("term") or "")
        if term in wanted and not row.get("exported_anki"):
            vocab_csv.patch(body.language, term, {"exported_anki": True})
            flipped.append(term)
    return {"marked": flipped}
