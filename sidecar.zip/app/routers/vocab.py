"""The vocabulary-record routes (spec §10 rewrite): one CSV per language.

`app/vocab_csv.py` is the only writer; these routes are thin — they validate
the shape and hand the work to it. The `/translate/save-vocab` compatibility
endpoint lives in routers/translate.py and calls the same upsert, so the two
surfaces can never disagree about how a word is recorded.
"""
from __future__ import annotations

import datetime as dt
import re

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import constants, status, translate, vault, vocab_csv

router = APIRouter(prefix="/vocab", tags=["vocab"])


@router.get("/rows")
def vocab_rows(lang: str, enrich: int = 0):
    """Every recorded term for a language, sorted by term. `rows` is [] for an
    unknown language — an unknown language is empty, not an error. `enrich=1`
    joins reading/gloss from the offline dictionaries; a missing dictionary
    leaves the rows bare rather than failing."""
    rows = vocab_csv.read(lang)
    if enrich:
        translate.enrich_vocab_rows(rows, lang)
    return {"rows": rows}


class UpsertBody(BaseModel):
    lang: str
    row: dict


@router.post("/upsert")
def vocab_upsert(body: UpsertBody):
    """Merge one term into the language's CSV (never clobbers a non-empty field
    with an empty one). Returns {created, row}."""
    try:
        created, row = vocab_csv.upsert(body.lang, body.row)
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    return {"created": created, "row": row}


class PatchBody(BaseModel):
    lang: str
    term: str
    fields: dict


@router.post("/patch")
def vocab_patch(body: PatchBody):
    """Overwrite the named fields of one term (a deliberate update, so it may
    clear a field). 404 when the term is absent."""
    try:
        row = vocab_csv.patch(body.lang, body.term, body.fields)
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    if row is None:
        raise HTTPException(404, f"no term {body.term!r} in {body.lang!r}")
    return {"row": row}


class RelateBody(BaseModel):
    lang: str
    a: str
    b: str
    family: str
    add: bool = True


@router.post("/relate")
def vocab_relate(body: RelateBody):
    """Link (or with `add=False`, unlink) two saved terms under one
    relationship family. Thin over `vocab_csv.relate()`, which refuses a family
    that is not one of the four relationship columns and a term that is not in
    the CSV — this exists because `/vocab/patch` (the raw-overwrite path for
    bulk/migration) can write a dangling reference a graph would draw as an
    edge to nowhere, and this cannot. A missing term is 404 (nothing on record);
    a bad family or a self-relation is 400."""
    try:
        a_row, b_row = vocab_csv.relate(body.lang, body.a, body.b,
                                        body.family, body.add)
    except vocab_csv.TermMissingError as e:
        raise HTTPException(404, str(e)) from e
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    return {"a": a_row, "b": b_row}


@router.post("/recompute")
def vocab_recompute():
    """Roll the practice ledger + review logs up into the CSV's count /
    involvement / status columns, patching only rows whose values changed."""
    try:
        changed = status.recompute()
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    return {"changed": changed}


def _vocab_note_path(term: str) -> str:
    safe = re.sub(r'[\\/:*?"<>|#^\[\]]', "", term).strip() or "term"
    return f"{constants.NOTES}/linguistics/Vocab/{safe}.md"


class PromoteBody(BaseModel):
    lang: str
    term: str


@router.post("/promote")
def vocab_promote(body: PromoteBody):
    """Create the prose note for ONE word and point the CSV `note` column at it.

    This is the ONLY path that makes a vocab note (spec §10 rewrite): a word
    worth prose is rare, and the note is for that prose, not for the record.
    The term must already be in the CSV — promoting an unsaved term would create
    an orphan note with no backing data, the exact failure mode this re-plan
    exists to prevent."""
    term = body.term.strip()
    if not term:
        raise HTTPException(400, "term is required")
    try:
        rows = vocab_csv.read(body.lang)
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    if not any(str(r.get("term") or "") == term for r in rows):
        raise HTTPException(404, f"no term {term!r} in {body.lang!r} — save it first")
    today = dt.date.today().isoformat()
    fm = [
        "---",
        f'created: "{today}"', 'type: "vocab"', 'domain: "linguistics"',
        "aliases: []", "tags: []", "generated: false",
        f'language: "{body.lang}"', f'term: "{term}"', f'first_seen: "{today}"',
        "---", "", "## Notes", "",
    ]
    rel = _vocab_note_path(term)
    created = vault.create_if_absent(rel, "\n".join(fm) + "\n")
    try:
        row = vocab_csv.patch(body.lang, term, {"note": f"[[{term}]]"})
    except vocab_csv.VocabError as e:
        raise HTTPException(400, str(e)) from e
    return {"created": created, "path": rel, "row": row}
