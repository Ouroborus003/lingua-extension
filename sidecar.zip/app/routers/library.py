"""Identify a shelved book from its own front-matter text.

Library Workspace's offline import already reads a book's own bytes for
metadata (cover, imprint, filename) with plain regexes — see
offline-import/first-page.js's readFrontMatter. That is exactly what fails on
a messy or rare scan: a title page with a stray running header, a scanner's
OCR noise, an imprint that names a translator right next to the author. This
endpoint is the "something smarter" for that case — the plugin does all the
reading (extractFirstPages, ocrPages, readFrontMatter all live client-side),
and hands the resulting text here for the one part that needs a model: pull a
title and an author out of it, and don't mistake the translator or the
publisher for the author.

A foreground, operator-triggered action — the operator clicked "Identify"
on one book and is waiting on an answer — not a background generator like
tag_review's queue. So a failure is reported, not swallowed: {"ok": False,
"error": ...} rather than tag_review's "skip this one and keep going".
Nothing here writes to the vault or renames anything; the plugin proposes
the result to the operator and only acts on an explicit confirm.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from pathlib import Path

from fastapi import APIRouter
from pydantic import BaseModel

from .. import llm, prompts, vault
from ..config import STATE_DIR
from ..config import config as sidecar_config

router = APIRouter(prefix="/library", tags=["library"])

# Kept flat per this repo's rule of thumb for local models: a quantized
# ~3-8B model degrades on JSON schemas nested 3+ levels deep, and there is
# nothing here that needs nesting.
_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "author": {"type": "string"},
        "year": {"type": ["integer", "null"]},
        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
    },
    "required": ["title", "author", "confidence"],
}

# The front-matter window the plugin sends is a handful of pages (readBook
# only ever reads/OCRs up to OCR_PAGE_CAP=3 of them), so this is generous
# headroom rather than a real limit — it exists to keep a pathological OCR
# dump from blowing the model's context, matching tag_review's own cap on
# note content.
_MAX_TEXT_CHARS = 6000

_CONFIDENCES = {"high", "medium", "low"}


class IdentifyBody(BaseModel):
    text: str


class RegisterOpenedBook(BaseModel):
    work_id: str
    title: str
    author: str | None = None
    work_type: str = "local"  # local, marxists, etc.


class BooxSyncStatus(BaseModel):
    watch_dir: str | None = None
    watch_dir_exists: bool = False
    exclude_unopened: bool = False
    seen_files: int = 0
    opened_books_count: int = 0
    last_scan: str | None = None
    syncthing_status: str | None = None


# Track opened books in memory (persisted to STATE_DIR)
_OPENED_BOOKS_STATE = STATE_DIR / "boox_opened_books.json"


def _load_opened_books() -> dict:
    if _OPENED_BOOKS_STATE.exists():
        try:
            return json.loads(_OPENED_BOOKS_STATE.read_text())
        except Exception:
            return {}
    return {}


def _save_opened_books(data: dict) -> None:
    _OPENED_BOOKS_STATE.write_text(json.dumps(data, sort_keys=True))


@router.post("/register-opened-book")
async def register_opened_book(body: RegisterOpenedBook):
    """Register a book as opened so Boox sync knows to include it."""
    data = _load_opened_books()
    data[body.work_id] = {
        "title": body.title,
        "author": body.author,
        "work_type": body.work_type,
        "last_opened": dt.datetime.now().isoformat(),
    }
    _save_opened_books(data)
    return {"ok": True}


@router.get("/boox-sync-status", response_model=BooxSyncStatus)
async def boox_sync_status():
    """Get Boox sync status and diagnostics."""
    from ..config import config as sidecar_config
    cfg = sidecar_config().boox
    
    watch_dir = cfg.watch_dir
    watch_path = Path(watch_dir).expanduser() if watch_dir else None
    
    # Load seen files
    seen_state = STATE_DIR / "boox_seen.json"
    seen_count = 0
    if seen_state.exists():
        try:
            seen_data = json.loads(seen_state.read_text())
            if isinstance(seen_data, list):
                seen_count = len(seen_data)
            else:
                seen_count = len(seen_data)
        except Exception:
            pass
    
    # Load opened books
    opened_data = _load_opened_books()
    
    return BooxSyncStatus(
        watch_dir=watch_dir,
        watch_dir_exists=watch_path.exists() if watch_path else False,
        exclude_unopened=cfg.exclude_unopened,
        seen_files=seen_count,
        opened_books_count=len(opened_data),
        last_scan=None,  # Could be enhanced with timestamp
        syncthing_status="unknown",  # Would need Syncthing API integration
    )


@router.post("/identify")
async def identify(body: IdentifyBody):
    text = (body.text or "").strip()
    if not text:
        return {"ok": False, "error": "no text to identify from"}
    try:
        raw = await llm.chat(prompts.load("identify_book"), text[:_MAX_TEXT_CHARS], feature="identify_book",
                             temperature=0.2, json_schema=_SCHEMA)
        data = json.loads(raw)
    except llm.LLMOffline:
        # Not "couldn't identify this one": the model was never asked. This
        # one propagates so the plugin can offer to start it and try again,
        # rather than reporting a failed identification that never happened.
        raise
    except Exception as e:
        # LM Studio unreachable/no model loaded (LLMUnavailable), or the
        # response wasn't the JSON it was asked for — both read to the
        # operator as "couldn't identify this one", which is the honest
        # answer; there's no vault state to roll back either way.
        return {"ok": False, "error": str(e)}

    title = str(data.get("title") or "").strip()
    if not title:
        return {"ok": False, "error": "the model returned no title"}
    confidence = data.get("confidence")
    if confidence not in _CONFIDENCES:
        confidence = "low"      # an unparseable/missing confidence is not a high one
    return {
        "ok": True,
        "title": title,
        "author": str(data.get("author") or "").strip(),
        "year": data.get("year") if isinstance(data.get("year"), int) else None,
        "confidence": confidence,
    }
