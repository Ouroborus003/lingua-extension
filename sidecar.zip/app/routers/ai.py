from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .. import ai_models, config, llm, settings
from ..generators import digests, insight, tag_hierarchy, tag_review
from ..llm import LLMOffline, LLMUnavailable

log = logging.getLogger("sidecar.ai")

router = APIRouter(prefix="/ai", tags=["ai"])


class AskBody(BaseModel):
    question: str


@router.post("/digest/{level}")
async def digest(level: str, period: str):
    fn = digests.LEVELS.get(level)
    if fn is None:
        raise HTTPException(404, f"unknown level {level!r}")
    try:
        return {"path": await fn(period)}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))


@router.post("/ask")
async def ask(body: AskBody):
    try:
        return await insight.ask(body.question)
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))


@router.post("/morning")
async def morning():
    try:
        return {"path": await insight.morning_note()}
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))


@router.post("/tags/propose")
async def tags_propose():
    try:
        return {"path": await tag_review.generate()}
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))


@router.post("/tags/apply")
def tags_apply():
    return tag_review.apply_reviewed()


@router.post("/tags/hierarchy")
async def tags_hierarchy():
    try:
        return {"path": await tag_hierarchy.generate()}
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))


@router.post("/tags/hierarchy/apply")
def tags_hierarchy_apply():
    return tag_hierarchy.apply_reviewed()


# --------------------------------------------------------------- model map
# The settings tab in the vault-sidecar plugin is the UI for these three. It
# renders straight off the catalogue rather than hardcoding a feature list, so
# adding a feature to ai_models.FEATURES is all it takes to make it selectable.


class ModelMapBody(BaseModel):
    # {feature: {"model": str, "route": str, "base_url": str}}. Validated by
    # ai_models.sanitize rather than by a schema here, because the same
    # validation has to apply to a file an operator edited by hand.
    overrides: dict = {}


@router.get("/models")
async def list_models():
    """What can be selected, and what is already loaded.

    `loaded` is the honest list — /api/v0/models is the only endpoint that
    reports state, and with just-in-time loading off it is also the only one
    that can distinguish "downloaded" from "resident". A model that is not
    loaded can still be chosen; the request will simply fail with an
    actionable error rather than silently pulling weights onto the card.
    """
    try:
        loaded = await llm.loaded_model_ids()
    except Exception as e:
        # A dead LM Studio must not stop the settings tab from rendering — the
        # operator may be opening it precisely to point a feature elsewhere.
        loaded = []
        log.info("model list unavailable (%s); settings tab will show none", e)

    # `available` is the catalogue and `loaded` is residency, and they are two
    # different questions. With just-in-time loading off, /api/v0/models
    # answers only the second — it returns an empty list when nothing is
    # resident, which is exactly how this picker first shipped with no models
    # in it. The catalogue has to come from `lms ls`.
    available = llm.downloaded_model_ids()
    for m in loaded:
        if m not in available:
            available.append(m)

    return {
        "features": list(ai_models.FEATURES),
        "routes": list(ai_models.ROUTES),
        "default_route": ai_models.DEFAULT_ROUTE,
        "whisper_sizes": list(ai_models.WHISPER_SIZES),
        "available": sorted(available),
        "loaded": loaded,
        "global_model": settings.effective().lm_studio.model or "",
    }


@router.get("/model-map")
async def get_model_map():
    return {"overrides": ai_models.load(config.SIDECAR_DIR)}


@router.put("/model-map")
async def put_model_map(body: ModelMapBody):
    """Store the selections and return what was actually kept.

    Returning the sanitized map rather than echoing the request is deliberate:
    a feature the sidecar dropped (unknown key, blank model) must show as
    dropped in the UI immediately, not persist as a setting the operator
    believes is in force.
    """
    return {"overrides": ai_models.save(config.SIDECAR_DIR, body.overrides)}


# --------------------------------------------------------------- reading assist
class ReadingAssistBody(BaseModel):
    prompt: str
    max_tokens: int = 2000
    temperature: float = 0.3


@router.post("/reading-assist")
async def reading_assist(body: ReadingAssistBody):
    """Summarization, questions, concepts, synthesis for the reader.

    This route had NEVER worked: it called `llm.chat_json(...)`, which does not
    exist — llm.py exports chat / chat_stream / model_id. Every request raised
    AttributeError, which the blanket except turned into a 503 reading
    "module 'app.llm' has no attribute 'chat_json'", so reading-companion's
    "AI request failed" Notice was the only symptom.

    Returns {"result": str} because that is what the caller reads
    (reading-companion/main.js callAi: `res.json?.result || res.text`).
    `max_tokens` is accepted and ignored — llm.chat does not take one, and
    silently dropping it is better than pretending to honour a cap.
    """
    from .. import llm
    try:
        text = await llm.chat(
            "You are a careful reading assistant. Produce clear, structured output.",
            body.prompt,
            temperature=body.temperature,
            feature="reading_assist",
        )
        return {"result": text}
    except LLMOffline:
        raise
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(500, str(e))


# --------------------------------------------------------------- semantic search
class SemanticSearchBody(BaseModel):
    query: str
    limit: int = 20
    threshold: float = 0.7


@router.post("/semantic-search")
async def semantic_search(body: SemanticSearchBody):
    """NOT IMPLEMENTED, and now says so instead of pretending.

    This route never ran. It called three things that do not exist:
    `llm.embed` (llm.py has no embedding function at all),
    `constants.VAULT_PATH` (absent from constants.py), and it used `json`
    without importing it. There is no embeddings/ directory in the vault
    either — the feature was never built, not merely broken.

    What made it costly rather than merely dead: the per-file `except:
    continue` meant that even past the 503 it would return `{"results": []}`,
    which reads as "nothing matched" rather than "this does not work". Its
    caller, library-workspace's hybridSearch, merges those empty results with
    real BM25 hits and shows the union — so a silent failure here looks like a
    thin search index.

    Returning 501 is the honest answer: the caller already handles a non-2xx
    by throwing, and hybridSearch stays unwired until there is an embedding
    backend to wire it to.
    """
    raise HTTPException(
        501,
        "semantic search is not implemented: no embedding backend "
        "(llm.embed does not exist) and no embeddings store in the vault",
    )

# --------------------------------------------------------------- model map
