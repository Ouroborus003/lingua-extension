"""whisper.py — local speech-to-text for lingua-workspace's Tools tab.

Ported to the router+engine shape routers/tts.py and routers/ocr.py already
established: audio in as base64 JSON (same convention /tts/preview and
/audio/forvo already use for audio out, and /ocr already uses for images
in — never multipart, this sidecar has no UploadFile route anywhere), the
engine itself never touching FastAPI or the settings module directly.

Phase 1 only: transcribe a file the operator already has, one request at a
time. No live microphone capture, no target-sentence scoring — see
app/whisper_engine.py's module docstring for why those are a distinct
phase 2, not built here.
"""
from __future__ import annotations

import asyncio
import base64
import os
import tempfile

from fastapi import APIRouter
from pydantic import BaseModel

from .. import settings, whisper_engine

router = APIRouter(prefix="/whisper", tags=["whisper"])

# mime type (or bare file extension) -> temp file suffix, so PyAV's demuxer
# gets a plausible extension to sniff alongside the container magic bytes.
# Falls back to ".audio" for anything unrecognized rather than rejecting the
# upload outright — PyAV mostly detects format from content, the extension
# is a hint, not a gate.
_MIME_SUFFIX = {
    "audio/mpeg": ".mp3", "audio/mp3": ".mp3", "mp3": ".mp3",
    "audio/wav": ".wav", "audio/x-wav": ".wav", "audio/wave": ".wav", "wav": ".wav",
    "audio/ogg": ".ogg", "ogg": ".ogg",
    "audio/webm": ".webm", "webm": ".webm",
    "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/aac": ".m4a", "m4a": ".m4a",
    "audio/flac": ".flac", "flac": ".flac",
}


def _suffix_for(mime: str) -> str:
    key = (mime or "").strip().lower()
    if key in _MIME_SUFFIX:
        return _MIME_SUFFIX[key]
    key = key.rsplit("/", 1)[-1]
    return _MIME_SUFFIX.get(key, ".audio")


@router.get("/status")
async def status():
    """Whether the sidecar can transcribe at all, and what it'll use by
    default — the same pre-flight shape /ocr/status gives the plugin so it
    can skip offering the tool (or explain why) before the operator picks a
    file, rather than failing only after an upload."""
    cfg = settings.effective().whisper
    return {
        "available": whisper_engine.available(),
        "model_sizes": list(whisper_engine.MODEL_SIZES),
        "default_model_size": cfg.model_size,
        "default_language": cfg.default_language,
    }


class WhisperBody(BaseModel):
    audio: str = ""         # base64-encoded audio bytes — mutually exclusive with `path`
    path: str = ""          # absolute path to a local audio/video file, already on this
                             # machine — cinema-workspace's video view uses this (no
                             # base64 round-trip, no size ceiling) instead of the browser
                             # file-picker upload the Tools tab needs `audio` for.
    mime: str = ""          # e.g. "audio/mp3" — picks the temp file's extension
    language: str = ""      # "" = the operator's configured default, else auto-detect
    model_size: str = ""    # "" = the operator's configured default


async def _decode_and_transcribe(body: WhisperBody) -> dict:
    """Shared by /transcribe and /subtitle: both land on the same
    whisper_engine.transcribe() call and only diverge in how the result is
    presented back to the caller. `path` wins over `audio` when both are
    set — whisper_engine.transcribe already returns {ok: False, error: ...}
    for a missing/bad path, so no extra validation is needed here."""
    if not whisper_engine.available():
        return {"ok": False, "error": "faster-whisper is not installed "
                                      "(pip install faster-whisper)"}
    cfg = settings.effective().whisper
    language = (body.language or cfg.default_language or "").strip() or None
    model_size = (body.model_size or cfg.model_size or "").strip()

    if body.path:
        return await asyncio.to_thread(
            whisper_engine.transcribe, body.path, language=language, model_size=model_size)

    try:
        raw = base64.b64decode(body.audio)
    except Exception:
        return {"ok": False, "error": "audio is not valid base64"}
    if not raw:
        return {"ok": False, "error": "empty audio"}

    tmp = tempfile.NamedTemporaryFile(suffix=_suffix_for(body.mime), delete=False)
    try:
        tmp.write(raw)
        tmp.close()
        return await asyncio.to_thread(
            whisper_engine.transcribe, tmp.name, language=language, model_size=model_size)
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


@router.post("/transcribe")
async def transcribe(body: WhisperBody):
    return await _decode_and_transcribe(body)


_SUBTITLE_FORMATTERS = {"vtt": whisper_engine.to_vtt, "srt": whisper_engine.to_srt}


class SubtitleBody(WhisperBody):
    format: str = "vtt"    # "vtt" | "srt"


@router.post("/subtitle")
async def subtitle(body: SubtitleBody):
    """Same input as /transcribe, but returns a subtitle file instead of
    plain text — the segment timing whisper_engine.transcribe() already
    computes, formatted for Mira's manual subtitle loader (or any HTML5
    <track>) rather than a study-text textarea. PyAV (faster-whisper's
    decoder) demuxes audio straight out of a video container, so a video
    file works here exactly like an audio clip — no separate video path
    needed."""
    fmt = (body.format or "vtt").strip().lower()
    formatter = _SUBTITLE_FORMATTERS.get(fmt)
    if formatter is None:
        return {"ok": False, "error": f"unknown subtitle format: {fmt!r} "
                                      f"(expected one of {sorted(_SUBTITLE_FORMATTERS)})"}
    result = await _decode_and_transcribe(body)
    if not result.get("ok"):
        return result
    return {**result, "format": fmt, "subtitle": formatter(result["segments"])}
