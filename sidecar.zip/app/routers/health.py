from __future__ import annotations

import asyncio
import dataclasses
from datetime import datetime, timezone

from fastapi import APIRouter, Request
from starlette.routing import BaseRoute

from .. import constants, ocr, settings
from ..config import config
from ..llm import LLMUnavailable, model_id

router = APIRouter(tags=["health"])

# Captured once at import — i.e. once per process, not once per request — so
# /health can tell a caller how old the *running* server is. This is the
# sidecar's answer to "is this a stale process": uvicorn is started by hand
# without --reload, so a process that has been up since before a route was
# added silently keeps serving the old route table. The symptom looked like
# "the plugin can't find the sidecar" when the sidecar was actually up and
# answering, just running old code.
STARTED_AT = datetime.now(timezone.utc).isoformat()


def _route_paths(routes: list[BaseRoute]) -> list[str]:
    """Recursively collect every mounted path.

    Hardcoding this list was rejected on sight — it's exactly the kind of
    thing that goes stale the same way the route table itself does. But a
    plain `[getattr(r, "path", None) for r in app.routes]` isn't enough: as of
    the FastAPI version pinned here, `include_router` is lazy and each
    included router shows up on `app.routes` as a bare `_IncludedRouter` with
    no `.path` of its own — only an `.original_router` whose own `.routes`
    hold the real `APIRoute` objects (this is the same quirk
    test_sidebar_chat.py's mounted-on-app test hit and worked around with a
    live request). Walking one level of `.path` only would report the four
    docs/openapi routes and nothing this sidecar actually serves.
    """
    paths = []
    for r in routes:
        path = getattr(r, "path", None)
        if path:
            paths.append(path)
        sub = getattr(r, "original_router", None)
        if sub is not None:
            paths.extend(_route_paths(sub.routes))
    return paths


@router.get("/health")
async def health(request: Request):
    try:
        model = await model_id()
    except LLMUnavailable as e:
        model = f"unavailable ({e})"
    # OCR visibility (app/ocr.py): the library import's own /health-style
    # pre-flight, folded into the sidecar's rather than a second endpoint,
    # since "what can this machine see" is exactly what /health is for.
    # Routed through the same tessdata_prefix the /ocr router resolves a
    # request against — otherwise this could report a language as installed
    # against the system tessdata while a configured prefix is what OCR
    # actually runs with.
    langs = await asyncio.to_thread(
        ocr.installed_langs, settings.effective().ocr.tessdata_prefix)
    return {
        "ok": True, "vault": str(config.vault_path), "lm_studio_model": model,
        "tesseract": ocr.available(),
        "tesseract_langs": sorted(set(ocr.VAULT_LANGS) & set(langs)),
        "started_at": STARTED_AT,
        "routes": sorted(set(_route_paths(request.app.routes))),
    }


def _mask(key: str, value):
    if key in settings.SECRET_KEYS:
        return "configured" if value else "not configured"
    return value


@router.get("/settings/effective")
async def settings_effective():
    """What the sidecar is actually running with: defaults < config.yaml
    < Settings.md. Secrets are masked to configured/not configured."""
    cfg = settings.effective()
    data = dataclasses.asdict(cfg)
    data["vault_path"] = str(cfg.vault_path)
    data["lastfm"]["api_key"] = _mask("lastfm_api_key", cfg.lastfm.api_key)
    return {
        "settings_note_found": settings.note_found(),
        "settings_note": settings.SETTINGS_NOTE,
        "overridden": {k: _mask(k, v) for k, v in settings.overridden().items()},
        "effective": data,
        # folder_* keys apply at import — a sidecar restart picks them up
        "folders": constants.folder_map(),
    }
