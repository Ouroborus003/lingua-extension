"""The AI sidebar's chat endpoint — ai-sidebar's context-aware panel.

Deliberately not app/generators/insight.py's /ai/ask: that route searches the
whole vault for relevant notes and writes the answer into a permanent Answers
note. This one has no search and no vault write — the plugin already knows
exactly what's on screen (a note's text, an RSS article, a book chapter) and
sends it directly; the sidecar's only job is turning {context, message,
history} into one llm.chat() call and handing the answer back. An ephemeral
chat, kept in the plugin's own view state, not persisted here.
"""
from __future__ import annotations

import json

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .. import llm, prompts
from ..llm import LLMOffline, LLMUnavailable

router = APIRouter(prefix="/ai", tags=["ai"])

# A cap on the attached context, as a last line of defence.
#
# Raised from 12k, which was sized for "a note or an RSS article" and became
# wrong the moment the panel learned to attach several pieces at once: folded
# into one string, four book chapters shared a budget that one chapter could
# already exceed, and the *tail* was cut — so "compare these two" reliably
# dropped most of the second piece and all of any third. The client now does
# the real budgeting (it knows how many attachments there are and can trim
# each one fairly), and states what it sent; this is only the backstop for a
# caller that doesn't.
#
# Still a truncation rather than a rejection: a long chapter should get a
# best-effort answer, not an error. But it is marked now, because silently
# returning an answer about the first half of a book is indistinguishable
# from the model having misread it.
_MAX_CONTEXT_CHARS = 60000

_TRUNCATION_NOTE = (
    "\n\n[The attached text was cut off here because it exceeded this "
    "endpoint's limit. Say so if the answer depends on the missing part.]"
)


def _fit(text: str, limit: int = _MAX_CONTEXT_CHARS) -> str:
    """Trim to `limit`, marking the cut so the model can disclose it."""
    if len(text) <= limit:
        return text
    return text[: limit - len(_TRUNCATION_NOTE)] + _TRUNCATION_NOTE


class ChatTurn(BaseModel):
    role: str   # "user" | "assistant"
    content: str


class SidebarChatBody(BaseModel):
    message: str
    context: str = ""
    context_title: str = ""
    context_kind: str = ""     # "note" | "rss" | "epub" | "catalog" | ""
    history: list[ChatTurn] = []
    # Which system-prompt persona to answer as. Empty or "sidebar_chat" is the
    # built-in reading/writing assistant; any other id names a file in
    # prompts/personas/. Validated (and safely defaulted) by prompts.load_persona
    # — an unknown or malformed id falls back to the default rather than erroring.
    persona: str = ""


@router.get("/personas")
async def list_personas():
    """The system-prompt personas the sidebar can switch between. Listing only
    — reads filenames (and at most a heading line), never a model — so the
    dropdown can populate without pulling anything into memory (§11)."""
    return {"personas": prompts.personas(), "default": prompts.DEFAULT_PERSONA}


@router.get("/lm-studio/status")
async def lm_studio_status():
    """Whether inference is available right now. Cheap and side-effect free —
    it only lists, so polling this never pulls a model into memory (§11)."""
    return {"running": await llm.server_is_running()}


class ConsentBody(BaseModel):
    # "Remember selection" in the start-the-model prompt. Remembering only
    # ever means "yes, without asking again" — a declined start is just a
    # declined start, so there is no remembered "no" to get stuck behind.
    remember: bool = False


@router.get("/lm-studio/consent")
async def lm_studio_get_consent():
    return {"consent": llm.consent()}


@router.post("/lm-studio/consent")
async def lm_studio_set_consent(body: ConsentBody):
    return {"consent": llm.set_consent("always" if body.remember else "ask")}


@router.post("/lm-studio/start")
async def lm_studio_start(body: ConsentBody | None = None):
    """Start LM Studio's server on request — the panel's own button.

    Distinct from the automatic start a chat request performs: this is the
    operator saying "bring it up now", so it reports the outcome instead of
    folding the failure into an answer bubble.
    """
    if body and body.remember:
        # Recorded before the attempt, not after: the user's answer to "start
        # it, and stop asking" is about the asking, and is still their answer
        # even if this particular launch goes on to fail.
        llm.set_consent("always")
    ok = await llm.ensure_server(force=True)
    if not ok:
        raise HTTPException(503, "could not start LM Studio — open it manually "
                                 "or check sidecar.log for what was tried")
    return {"running": True, "consent": llm.consent()}


@router.post("/lm-studio/stop")
async def lm_studio_stop():
    ok = await llm.stop_server()
    if not ok:
        raise HTTPException(503, "could not stop LM Studio's server")
    return {"running": False}


@router.post("/sidebar-chat")
async def sidebar_chat(body: SidebarChatBody):
    message = body.message.strip()
    if not message:
        raise HTTPException(400, "message is required")

    system = prompts.load_persona(body.persona)
    if body.context.strip():
        kind = body.context_kind or "content"
        title = body.context_title or "(untitled)"
        system += (f"\n\nAttached {kind}: \"{title}\"\n\n"
                   + _fit(body.context.strip()))

    # llm.chat() takes one system + one user turn, not a message list — the
    # running conversation rides in the user turn instead, oldest first,
    # same shape a plain chat transcript already reads as.
    turns = "\n\n".join(f"{t.role.upper()}: {t.content}" for t in body.history)
    user = (turns + "\n\n" if turns else "") + f"USER: {message}"

    try:
        answer = await llm.chat(system, user, temperature=0.4,
                                feature="sidebar_chat")
    except LLMOffline:
        raise      # app-level handler; carries code="llm_offline" for the UI
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))
    return {"answer": answer.strip()}


def _build_prompt(body: SidebarChatBody) -> tuple[str, str]:
    """The system + user pair both chat routes send. One definition, so the
    streamed answer and the non-streamed one can never be answers to
    differently-worded questions."""
    system = prompts.load_persona(body.persona)
    if body.context.strip():
        kind = body.context_kind or "content"
        title = body.context_title or "(untitled)"
        system += (f"\n\nAttached {kind}: \"{title}\"\n\n"
                   + _fit(body.context.strip()))
    turns = "\n\n".join(f"{t.role.upper()}: {t.content}" for t in body.history)
    user = (turns + "\n\n" if turns else "") + f"USER: {body.message.strip()}"
    return system, user


@router.post("/sidebar-chat/stream")
async def sidebar_chat_stream(body: SidebarChatBody):
    """The same answer as /sidebar-chat, delivered as it is generated.

    Newline-delimited JSON rather than SSE: the client reads this with fetch
    and a stream reader, so it is already parsing a byte stream by hand, and
    NDJSON is one json.loads per line instead of SSE's framing rules for a
    channel that carries exactly one kind of event.

    Errors are the awkward part of any streaming endpoint: the status line is
    committed the moment the first byte leaves, so a failure after that cannot
    be a 503 any more. llm.chat_stream raises everything it is going to raise
    *before* its first chunk, which is what lets the common failures — model
    not running, consent not given — still arrive as real HTTP errors that the
    plugin's existing llm_offline handling recognises. Anything that goes
    wrong mid-generation is reported as a final {"error": ...} line instead,
    and the client renders it against the partial answer it already has.
    """
    if not body.message.strip():
        raise HTTPException(400, "message is required")
    system, user = _build_prompt(body)

    # Outside the generator on purpose: raising here still produces a normal
    # response, whereas raising inside one that StreamingResponse has begun
    # consuming would truncate a 200 that has already been sent.
    try:
        stream = llm.chat_stream(system, user, temperature=0.4,
                                 feature="sidebar_chat")
        first = await anext(stream)
    except StopAsyncIteration:
        first = ""
    except LLMOffline:
        raise
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))

    async def body_iter():
        if first:
            yield json.dumps({"delta": first}) + "\n"
        try:
            async for chunk in stream:
                yield json.dumps({"delta": chunk}) + "\n"
        except Exception as e:                      # noqa: BLE001 — see docstring
            yield json.dumps({"error": str(e)}) + "\n"
        yield json.dumps({"done": True}) + "\n"

    return StreamingResponse(body_iter(), media_type="application/x-ndjson",
                             # Proxies and Chromium both buffer aggressively;
                             # without this the whole point of streaming is
                             # lost to a buffer that flushes once at the end.
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


# ---------------------------------------------------------------------------
# the structured reading note
# ---------------------------------------------------------------------------

# What a reading note is, as a schema the model is *constrained* to rather
# than asked for.
#
# The difference matters more than it sounds. Prompting for headings gets
# headings most of the time, and the rest of the time gets prose with the
# headings described in it, a preamble ("Certainly! Here is your note:"), or
# markdown fences around the whole thing — and every one of those has to be
# either cleaned up by fragile string surgery or written into the vault as-is.
# A json_schema response makes the shape the model's only option, so the note
# writer receives fields rather than text it has to parse.
#
# Flat on purpose: quantized local models degrade badly on schemas nested more
# than two deep, and everything here is one level of objects inside arrays.
_NOTE_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["summary", "themes", "claims", "terms", "questions"],
    "properties": {
        "summary": {
            "type": "string",
            "description": "2-4 sentences on what this text is doing, in the "
                           "author's own terms. No preamble.",
        },
        "themes": {
            "type": "array",
            "maxItems": 6,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["name", "note"],
                "properties": {
                    "name": {"type": "string", "description": "2-5 words."},
                    "note": {"type": "string", "description": "One sentence."},
                },
            },
        },
        "claims": {
            "type": "array",
            "maxItems": 8,
            "description": "Arguments the text actually makes, not topics it "
                           "mentions.",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["claim", "evidence"],
                "properties": {
                    "claim": {"type": "string"},
                    "evidence": {
                        "type": "string",
                        "description": "How the text supports it. Say 'asserted "
                                       "without support' when it does not.",
                    },
                },
            },
        },
        "terms": {
            "type": "array",
            "maxItems": 8,
            "description": "Terms of art this text uses in a specific sense.",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["term", "sense"],
                "properties": {
                    "term": {"type": "string"},
                    "sense": {"type": "string", "description": "One sentence."},
                },
            },
        },
        "questions": {
            "type": "array",
            "maxItems": 5,
            "description": "Questions this text raises and does not settle. "
                           "Real openings, not comprehension quiz items.",
            "items": {"type": "string"},
        },
    },
}


class ReadingNoteBody(BaseModel):
    context: str
    context_title: str = ""
    context_kind: str = ""
    # A conversation worth keeping is part of the note: the questions actually
    # asked about a text say as much about the reading as any summary does.
    history: list[ChatTurn] = []


@router.post("/reading-note")
async def reading_note(body: ReadingNoteBody):
    """A structured reading note for the attached text.

    Returns fields, not markdown. The plugin renders them, because a note's
    layout is a vault convention (frontmatter keys, heading levels, callout
    syntax) and the model has no business deciding it — and because a schema
    that returns prose would put us straight back to parsing.
    """
    if not body.context.strip():
        raise HTTPException(400, "context is required")

    system = (
        "You are reading closely on behalf of someone building a research "
        "note. Work only from the attached text: if it does not support a "
        "field, return an empty array rather than inventing plausible "
        "content. Prefer the text's own vocabulary over paraphrase. Never "
        "add commentary outside the requested fields."
    )
    title = body.context_title or "(untitled)"
    kind = body.context_kind or "text"
    user = f"Attached {kind}: \"{title}\"\n\n{_fit(body.context.strip())}"
    if body.history:
        # Included as what the reader was asking, not as instructions — a
        # question in the transcript is evidence of interest, and without the
        # framing the model reads the last one as the task and answers it.
        turns = "\n".join(f"{t.role.upper()}: {t.content}" for t in body.history)
        user += ("\n\nFor context, the reader asked about this text:\n" + turns
                 + "\n\nDo not answer those questions here — build the note.")

    try:
        raw = await llm.chat(system, user, temperature=0.2,
                             json_schema=_NOTE_SCHEMA)
    except LLMOffline:
        raise
    except LLMUnavailable as e:
        raise HTTPException(503, str(e))

    try:
        note = json.loads(raw)
    except ValueError as e:
        # Constrained decoding makes this rare, not impossible — an LM Studio
        # build that ignores response_format falls back to prose. Reported as
        # a 502 (the model misbehaved) rather than a 500 (we did).
        raise HTTPException(502, f"the model did not return a structured note: {e}")
    return {"note": note, "title": body.context_title, "kind": body.context_kind}
