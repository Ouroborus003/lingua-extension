"""audio_provider.py — the one place that decides where a vocab word's audio
comes from. Ported from LinguaStudio's `audio_provider.py` +
`generator_api.resolve_word_audio`, reshaped around this sidecar's existing
pieces: `app/pronounce.py` for the human recording — a cascade over
`app/forvo.py` and `app/lingualibre.py`, since Forvo alone answers only
intermittently (LinguaStudio's own
`forvo_client.py` was never ported here — Forvo already lives in this
sidecar for the dual reader) and `app/tts_engine.py` for the synthesis half
this module adds.

Source policy (driven by settings `audio.audio_source` and `audio.forvo_enabled`):
    "human_first"  → try Forvo; on a miss, fall back to TTS.
    "tts_only"     → skip Forvo, go straight to TTS.
    Forvo disabled entirely (audio.forvo_enabled = False) behaves like
    "tts_only" regardless of audio_source — an operator who turned Forvo off
    for the dual reader almost certainly doesn't want lingua-workspace's vocab
    audio quietly scraping it anyway.

Both Forvo and TTS output are run through `audio_normalizer` to -18 LUFS, so
a deck mixing human recordings and TTS plays at an even volume. A resolved
file is cached on disk under a name derived from (lang, word); a second
lookup for the same word is a no-op.
"""
from __future__ import annotations

import logging
import re
import tempfile
from pathlib import Path

from . import audio_normalizer, pronounce, tts_engine
from .config import STATE_DIR

log = logging.getLogger("sidecar.audio_provider")

# Canonical per-word audio, keyed by (lang, word) — distinct from
# tts_engine/audio_cache's generic (text, voice, speed, backend) cache, which
# is what save_sync consults for a raw synthesis. This is the file whose bare
# name rides in a card's `[sound:...]` field.
AUDIO_DIR = STATE_DIR / "vocab_audio"

# Characters unsafe in a filename across platforms / inside an .apkg media map.
_UNSAFE = re.compile(r'[\\/:*?"<>|\s]+')


def media_filename(text: str, lang: str) -> str:
    """Deterministic media filename for a word, e.g. 'cmn-你好.mp3'.

    CJK characters are kept (Anki media names allow UTF-8); only filesystem-
    unsafe characters are collapsed to a hyphen. `lang` is renderer-supplied
    (POST /vocab/audio) and sanitized the same way as `text` — without this a
    crafted lang like '../../../../etc/passwd' would join outside AUDIO_DIR
    (the same path-traversal bug class LinguaStudio's ERR-165 fixed).
    """
    safe = _UNSAFE.sub("-", (text or "").strip()).strip("-")
    safe_lang = _UNSAFE.sub("-", (lang or "").strip()).strip("-") or "und"
    return f"{safe_lang}-{safe}.mp3"


def _normalize_into(src_path: str, dest: Path) -> bool:
    """Normalize src to dest at -18 LUFS; on failure copy raw as a last
    resort — a resolved word with unnormalized audio beats no audio."""
    try:
        if audio_normalizer.normalize_lufs(src_path, str(dest)):
            return True
    except Exception as exc:
        log.debug("normalize failed (%s); using raw audio", exc)
    try:
        import shutil
        shutil.copy2(src_path, dest)
        return True
    except Exception:
        return False


def _from_human(text: str, lang: str, dest: Path) -> str:
    """A human recording from any configured source (app/pronounce.py).

    Returns the SOURCE NAME that supplied it ("forvo" / "lingualibre"), or ""
    on a miss — the caller records that name against the card, so it must not
    be flattened to a bool.

    Was Forvo-only. Vocab/Anki audio now gets the same cascade the dual reader
    does, so a word Forvo is blocking — or simply lacks — can still land a real
    voice on the card instead of falling straight to synthesis.
    """
    hit = pronounce.top(text, lang)
    if not hit.get("audio"):
        return ""
    # Lingua Libre serves .wav, Forvo .mp3 — the suffix only tells ffmpeg what
    # it is reading, and _normalize_into transcodes to the .mp3 `dest` either
    # way. Naming it by source keeps the temp file honest if a run is inspected.
    suffix = ".wav" if hit.get("source") == "lingualibre" else ".mp3"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tf:
        tf.write(hit["audio"])
        tmp = tf.name
    try:
        return hit.get("source", "") if _normalize_into(tmp, dest) else ""
    finally:
        Path(tmp).unlink(missing_ok=True)


def active_voice(lang: str, acfg) -> str:
    """The TTS voice to use for `lang`: the operator's configured voice if it
    is actually a valid voice for that language, else the language's first
    curated default.

    edge-tts's display-name keys are unique across every language (the
    curated table merges into one flat dict), so a bare `tts_voice` setting
    saved while previewing Mandarin would silently speak Mandarin-accented
    audio for a German word if applied without this check — the vault runs
    five languages at once (lingua-workspace's LANGS), unlike LinguaStudio's
    single "current language".

    A voice is only meaningful for the backend that owns it. This resolved
    against edge-tts's table whatever `tts_backend` said, so setting the
    backend to piper handed piper an edge DISPLAY NAME, which is not a piper
    voice — validate_voice refused it, _from_tts swallowed the exception and
    returned False, and the word simply had no audio. validate_voice is the
    authority on what each backend accepts, so ask it rather than keeping a
    second opinion here.
    """
    backend = getattr(acfg, "tts_backend", "edge-tts") or "edge-tts"
    if backend != "edge-tts":
        if acfg.tts_voice and tts_engine.validate_voice(acfg.tts_voice, backend)[0]:
            return acfg.tts_voice
        return tts_engine.default_voice_for(backend, lang)
    lang_voices = tts_engine.edge_voices_for_lang(lang)
    ids = {v["id"] for v in lang_voices}
    if acfg.tts_voice and acfg.tts_voice in ids:
        return acfg.tts_voice
    return lang_voices[0]["id"] if lang_voices else tts_engine.EDGE_DEFAULT_FEMALE


def _from_tts(text: str, lang: str, dest: Path, cfg) -> bool:
    """Generate via tts_engine (edge-tts -> gTTS fallback, cached, normalized).
    `dest` is written directly by save_sync."""
    acfg = cfg.audio
    try:
        tts_engine.save_sync(
            text, active_voice(lang, acfg), acfg.tts_rate, str(dest),
            backend=acfg.tts_backend, lang=lang, use_cache=True, normalize=True,
        )
        return dest.exists() and dest.stat().st_size > 0
    except Exception as exc:
        log.debug("tts save failed for %r: %s", text, exc)
        return False


def resolve_audio_detailed(text: str, lang: str, cfg):
    """Return (filename, abspath, source) for a word's audio, or
    (None, None, ""). `source` is 'cache' | 'tts' | the name of whichever
    human source answered ('forvo' | 'lingualibre' — see app/pronounce.py).

    Returns a cached file immediately if present (no refetch). Otherwise
    resolves per the audio_source policy, normalizes, and caches. The
    filename is what a card's `[sound:...]` field wants; the abspath is what
    a future export/AnkiConnect push would ship as media.
    """
    text = (text or "").strip()
    if not text:
        return None, None, ""

    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    fname = media_filename(text, lang)
    dest = AUDIO_DIR / fname

    if dest.exists() and dest.stat().st_size > 0:
        return fname, str(dest), "cache"

    acfg = cfg.audio
    # An operator who disabled Forvo for the dual reader gets the same
    # decision here — audio_source alone can't re-enable a scrape they turned off.
    policy = acfg.audio_source if acfg.forvo_enabled else "tts_only"

    if policy != "tts_only":
        # The NAME of the source is returned, not a hardcoded "forvo" — a card
        # whose audio came from Lingua Libre should not be labelled Forvo.
        human = _from_human(text, lang, dest)
        if human:
            log.info("%s audio for %r (%s)", human, text, lang)
            return fname, str(dest), human

    if _from_tts(text, lang, dest, cfg):
        log.info("tts audio for %r (%s)", text, lang)
        return fname, str(dest), "tts"

    return None, None, ""
