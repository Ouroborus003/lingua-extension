#!/usr/bin/env python3
"""
Create a reference.docx for pandoc --reference-doc with academic formatting:
- 1" margins all sides
- Letter paper
- Times New Roman 12pt
- Double-spaced body text
- Proper heading styles
"""

from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import sys

def create_reference_docx(output_path: str):
    doc = Document()

    # ---- Page setup ----
    for section in doc.sections:
        section.page_width = Inches(8.5)
        section.page_height = Inches(11)
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # ---- Helper: set default font for a style ----
    def set_style_font(style, name="Times New Roman", size=12, bold=False, color=RGBColor(0, 0, 0)):
        font = style.font
        font.name = name
        font.size = Pt(size)
        font.bold = bold
        font.color.rgb = color
        # Ensure East Asian font fallback works
        rPr = style.element.get_or_add_rPr()
        rFonts = rPr.find(qn('w:rFonts'))
        if rFonts is None:
            rFonts = OxmlElement('w:rFonts')
            rPr.append(rFonts)
        rFonts.set(qn('w:ascii'), name)
        rFonts.set(qn('w:hAnsi'), name)
        rFonts.set(qn('w:cs'), name)

    def set_paragraph_format(style, alignment=WD_ALIGN_PARAGRAPH.JUSTIFY, line_spacing=2.0, space_before=Pt(0), space_after=Pt(0)):
        pf = style.paragraph_format
        pf.alignment = alignment
        pf.line_spacing_rule = 1  # Multiple
        pf.line_spacing = Pt(size * line_spacing) if (size := style.font.size) else Pt(24)
        pf.space_before = space_before
        pf.space_after = space_after

    # ---- Normal style (body text) ----
    normal = doc.styles['Normal']
    set_style_font(normal, "Times New Roman", 12)
    normal.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    normal.paragraph_format.line_spacing_rule = 1  # Multiple
    normal.paragraph_format.line_spacing = Pt(24)  # 12pt * 2 = double-spaced
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.first_line_indent = Inches(0.5)

    # ---- No-indent variant for first paragraph after heading ----
    # Pandoc uses "Normal" for all body; first-line indent is standard

    # ---- Heading 1 ----
    h1 = doc.styles['Heading 1']
    set_style_font(h1, "Times New Roman", 14, bold=True)
    h1.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    h1.paragraph_format.line_spacing = Pt(14)  # Single-spaced
    h1.paragraph_format.space_before = Pt(24)
    h1.paragraph_format.space_after = Pt(12)
    h1.paragraph_format.keep_with_next = True

    # ---- Heading 2 ----
    h2 = doc.styles['Heading 2']
    set_style_font(h2, "Times New Roman", 13, bold=True)
    h2.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    h2.paragraph_format.line_spacing = Pt(13)
    h2.paragraph_format.space_before = Pt(18)
    h2.paragraph_format.space_after = Pt(6)
    h2.paragraph_format.keep_with_next = True

    # ---- Heading 3 ----
    h3 = doc.styles['Heading 3']
    set_style_font(h3, "Times New Roman", 12, bold=True)
    h3.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    h3.paragraph_format.line_spacing = Pt(12)
    h3.paragraph_format.space_before = Pt(12)
    h3.paragraph_format.space_after = Pt(6)
    h3.paragraph_format.keep_with_next = True

    # ---- Block Quote ----
    if 'Block Quote' not in doc.styles:
        bq = doc.styles.add_style('Block Quote', WD_STYLE_TYPE.PARAGRAPH)
    else:
        bq = doc.styles['Block Quote']
    set_style_font(bq, "Times New Roman", 12, bold=False, color=RGBColor(0x33, 0x33, 0x33))
    bq.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
    bq.paragraph_format.line_spacing = Pt(24)
    bq.paragraph_format.left_indent = Inches(0.5)
    bq.paragraph_format.right_indent = Inches(0.5)
    bq.paragraph_format.space_before = Pt(6)
    bq.paragraph_format.space_after = Pt(6)

    # ---- List Bullet ----
    bullet = doc.styles['List Bullet']
    set_style_font(bullet, "Times New Roman", 12)
    bullet.paragraph_format.line_spacing = Pt(24)
    bullet.paragraph_format.left_indent = Inches(0.5)
    bullet.paragraph_format.space_before = Pt(0)
    bullet.paragraph_format.space_after = Pt(0)

    # ---- List Number ----
    number = doc.styles['List Number']
    set_style_font(number, "Times New Roman", 12)
    number.paragraph_format.line_spacing = Pt(24)
    number.paragraph_format.left_indent = Inches(0.5)
    number.paragraph_format.space_before = Pt(0)
    number.paragraph_format.space_after = Pt(0)

    # ---- Code / Verbatim ----
    if 'Code' not in doc.styles:
        code_style = doc.styles.add_style('Code', WD_STYLE_TYPE.PARAGRAPH)
    else:
        code_style = doc.styles['Code']
    set_style_font(code_style, "Consolas", 10, color=RGBColor(0x22, 0x22, 0x22))
    code_style.paragraph_format.line_spacing = Pt(12)
    code_style.paragraph_format.left_indent = Inches(0.5)
    code_style.paragraph_format.space_before = Pt(6)
    code_style.paragraph_format.space_after = Pt(6)
    # Shading for code blocks
    pPr = code_style.element.get_or_add_pPr()
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), 'F0F0F0')
    shading.set(qn('w:val'), 'clear')
    pPr.append(shading)

    # ---- Hyperlink ----
    if 'Hyperlink' in doc.styles:
        hl = doc.styles['Hyperlink']
        set_style_font(hl, "Times New Roman", 12, color=RGBColor(0, 0, 0xCC))
        hl.font.underline = True

    # ---- Save ----
    doc.save(output_path)
    print(f"Created {output_path}")

if __name__ == "__main__":
    output = sys.argv[1] if len(sys.argv) > 1 else ".obsidian/plugins/obsidian-enhancing-export/reference.docx"
    create_reference_docx(output)