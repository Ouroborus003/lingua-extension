#!/usr/bin/env python3
"""Point `translate.stardict` at every dictionary found under a directory.

    python3 tools/wire_dictionaries.py ~/dicts            # show what it found
    python3 tools/wire_dictionaries.py ~/dicts --apply    # write config.yaml

Why a script rather than a hand-edited list: the entries carry a language code
that must match what the reader is asked for, and that code is derivable from
the FreeDict directory naming (`deu-eng` -> source `de`). Typing a dozen of
them by hand is how one ends up with a dictionary that silently never matches,
which looks exactly like a dictionary with poor coverage.

Nothing is written without --apply, and the previous config.yaml is copied
aside first — the same rule the library tools follow.
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import shutil
import sys
from pathlib import Path

# FreeDict uses ISO 639-3; the vault's reader is asked with the 2-letter code
# the reading pane knows. Only the pairs likely to be installed are mapped —
# an unmapped code falls through to its first two letters, which is right far
# more often than it is wrong, and is reported so it can be checked.
ISO3_TO_2 = {
    "ara": "ar", "deu": "de", "eng": "en", "fra": "fr", "spa": "es",
    "ita": "it", "rus": "ru", "lat": "la", "grc": "el", "ell": "el",
    "por": "pt", "nld": "nl", "pol": "pl", "swe": "sv", "tur": "tr",
    "jpn": "ja", "zho": "zh", "cmn": "zh", "kor": "ko", "heb": "he",
    "hin": "hi", "fas": "fa", "ukr": "uk", "ces": "cs", "dan": "da",
    "fin": "fi", "hun": "hu", "nor": "no", "ron": "ro", "srp": "sr",
}


def find_dictionaries(root: Path) -> list[dict]:
    """Every readable dictionary under `root`, as config entries."""
    found: list[dict] = []
    seen: set[str] = set()
    # .index before .ifo: where a pair ships both, dictd carries the headword,
    # IPA and numbered senses that the StarDict build of the same data drops.
    for pattern in ("**/*.index", "**/*.index.gz", "**/*.ifo",
                    "**/cedict*.u8", "**/cedict*.u8.gz"):
        for p in sorted(root.glob(pattern)):
            stem = re.sub(r"\.(index|ifo|u8)(\.gz)?$", "", p.name)
            if stem in seen:
                continue
            if stem.startswith("cedict"):
                # CC-CEDICT names itself, not its language pair. It is always
                # Chinese, and its directory name is not a reliable source.
                seen.add(stem)
                found.append({"lang": "zh", "path": str(p),
                              "name": "CC-CEDICT (CC BY-SA 4.0, via MDBG)",
                              "_guessed": False})
                continue
            m = re.match(r"^([a-z]{3})-([a-z]{3})$", stem)
            if m:
                src3, tgt3 = m.group(1), m.group(2)
                src = ISO3_TO_2.get(src3, src3[:2])
                guessed = src3 not in ISO3_TO_2
                name = f"FreeDict {src3}->{tgt3}"
            else:
                src, guessed, name = "", False, stem
            seen.add(stem)
            found.append({"lang": src, "path": str(p), "name": name,
                          "_guessed": guessed})
    return found


def render(entries: list[dict]) -> str:
    lines = ["  stardict:"]
    for e in entries:
        lines.append(f'    - {{ lang: "{e["lang"]}", path: "{e["path"]}", '
                     f'name: "{e["name"]}" }}')
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("root", help="Directory holding the installed dictionaries.")
    ap.add_argument("--config", default=str(Path(__file__).resolve().parents[1] / "config.yaml"))
    ap.add_argument("--apply", action="store_true", help="Write config.yaml.")
    args = ap.parse_args()

    root = Path(args.root).expanduser()
    if not root.is_dir():
        print(f"not a directory: {root}", file=sys.stderr)
        return 2

    entries = find_dictionaries(root)
    if not entries:
        print(f"no .index/.ifo dictionaries found under {root}", file=sys.stderr)
        return 1

    for e in entries:
        flag = "  <-- language code guessed, check it" if e["_guessed"] else ""
        print(f'  {e["lang"] or "(any)":6} {e["name"]:24} {e["path"]}{flag}')
    block = render(entries)

    if not args.apply:
        print(f"\n{len(entries)} dictionaries. Re-run with --apply to write:\n")
        print(block)
        return 0

    cfg = Path(args.config)
    text = cfg.read_text(encoding="utf-8")
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    shutil.copy2(cfg, cfg.with_name(cfg.name + f".bak-{stamp}"))

    # Replace the `stardict:` key and any list items already under it.
    pat = re.compile(r"^  stardict:.*?(?=^  [a-z_]+:)", re.S | re.M)
    if not pat.search(text):
        print("could not find a `  stardict:` key in config.yaml — not writing",
              file=sys.stderr)
        return 1
    cfg.write_text(pat.sub(block + "\n", text), encoding="utf-8")
    print(f"\nwrote {len(entries)} dictionaries to {cfg} (backup .bak-{stamp})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
